// @ts-check
/**
 * eslint.config.js — Flat config ESLint untuk X7BOTZ-MD.
 *
 * ── Q2 ──────────────────────────────────────────────────────────────
 * Sebelumnya `package.json` punya script `lint: eslint App/ src/` tapi
 * TIDAK ada config visible. Sekarang config flat ini:
 *   - `@eslint/js` recommended rules
 *   - `eslint-plugin-node` untuk best-practice Node.js
 *   - Custom rules minimum yang disebut di laporan refactor.
 * ────────────────────────────────────────────────────────────────────
 */

const js = require('@eslint/js');
const nodePlugin = require('eslint-plugin-node');

module.exports = [
    {
        ignores: ['node_modules/**', 'Storage/**', 'tmp/**', 'database/drivers/__tests__/**']
    },
    js.configs.recommended,
    {
        files: ['**/*.js'],
        languageOptions: {
            ecmaVersion: 2022,
            sourceType: 'commonjs',
            globals: {
                // Node.js globals
                process: 'readonly',
                console: 'readonly',
                Buffer: 'readonly',
                setTimeout: 'readonly',
                setInterval: 'readonly',
                clearTimeout: 'readonly',
                clearInterval: 'readonly',
                setImmediate: 'readonly',
                clearImmediate: 'readonly',
                URL: 'readonly',
                URLSearchParams: 'readonly',
                queueMicrotask: 'readonly',
                require: 'readonly',
                module: 'readonly',
                exports: 'readonly',
                __dirname: 'readonly',
                __filename: 'readonly',
                global: 'readonly',
                globalThis: 'readonly',
                // Global JS built-in yang dipakai runtime (Node 18+)
                fetch: 'readonly',
                Intl: 'readonly',
                TextEncoder: 'readonly',
                TextDecoder: 'readonly',
                AbortController: 'readonly',
                AbortSignal: 'readonly',
                structuredClone: 'readonly'
            }
        },
        plugins: {
            node: nodePlugin
        },
        rules: {
            // ── Required minimum rules ───────────────────────────────
            'no-unused-vars': ['warn', { argsIgnorePattern: '^_', varsIgnorePattern: '^_' }],
            'no-empty': ['warn', { allowEmptyCatch: true }],
            eqeqeq: ['error', 'always'],
            'prefer-const': ['warn', { destructuring: 'any' }],
            'no-undef': 'error',
            'no-redeclare': 'error',

            // ── no-console ──────────────────────────────────────────
            // Production build: error. Dev: warn via .eslintrc.dev.json override.
            // Untuk saat ini: warn dulu (P7) supaya transisi tidak breaking.
            'no-console': process.env.NODE_ENV === 'production' ? ['warn', { allow: ['warn', 'error'] }] : 'off',

            // ── Node-specific ──────────────────────────────────────
            'node/no-deprecated-api': 'warn',
            'node/no-missing-require': 'off',
            'node/no-unpublished-require': 'off',
            'node/no-extraneous-require': 'off',
            'node/shebang': 'off',

            // ── Stylistic ─────────────────────────────────────────
            'no-var': 'warn',
            'object-shorthand': ['warn', 'always'],
            'prefer-template': 'warn'
        }
    },
    {
        // Override: test files & scripts boleh pakai console & globals.
        files: ['**/__tests__/**/*.js', '**/*.test.js', 'database/utils/backup.js', 'scripts/**'],
        rules: {
            'no-console': 'off'
        }
    },
    {
        // Globals Jest untuk file test (jest tidak diimport eksplisit).
        files: ['**/__tests__/**/*.js', '**/*.test.js'],
        languageOptions: {
            globals: {
                describe: 'readonly',
                test: 'readonly',
                it: 'readonly',
                expect: 'readonly',
                beforeAll: 'readonly',
                afterAll: 'readonly',
                beforeEach: 'readonly',
                afterEach: 'readonly',
                jest: 'readonly'
            }
        }
    }
];

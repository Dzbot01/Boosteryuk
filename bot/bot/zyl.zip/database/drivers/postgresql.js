const BaseDriver = require('./base');
const { SQLAdapter } = require('./sqlcommon');
const { ConnectionError, QueryError, wrapError } = require('../errors');
const { deepClone } = require('../utils/validator');

class PostgreSQLDriver extends BaseDriver {
    constructor(options = {}) {
        super({ ...options, type: 'postgresql' });
        const cfg = options.config || {};
        this.pgConfig = {
            host: cfg.host || 'localhost',
            port: Number(cfg.port) || 5432,
            database: cfg.database || 'x7botz_db',
            user: cfg.user || 'postgres',
            password: cfg.password || '',
            ssl: cfg.ssl ? { rejectUnauthorized: false } : undefined,
            max: (options.pool && options.pool.max) || 10,
            min: (options.pool && options.pool.min) || 2,
            idleTimeoutMillis: (options.pool && options.pool.idleTimeoutMillis) || 30000,
            connectionTimeoutMillis: (options.pool && options.pool.acquireTimeoutMillis) || 10000
        };
        this.pool = null;
        this.adapter = null;
        this.schemaReady = false;
    }

    async _doConnect() {
        let pg;
        try {
            pg = require('pg');
        } catch (err) {
            throw new ConnectionError('library pg belum terinstall. Jalankan: bun add pg', {
                driver: 'postgresql',
                cause: err
            });
        }
        try {
            this.pool = new pg.Pool(this.pgConfig);
            this.pool.on('error', (err) => {
                this.logger.error(`PostgreSQL pool error: ${err.message}`);
                this.metrics.lastErrorAt = Date.now();
                this.metrics.lastError = err.message;
            });
            const client = await this.pool.connect();
            client.release();
            this.adapter = new SQLAdapter('postgresql', (sql, params) => this._query(sql, params), this.logger);
            this.adapter.txRunnerImpl = (work) => this._runTransaction(work);
            await this.adapter.ensureSchema();
            this.schemaReady = true;
        } catch (err) {
            this.pool = null;
            const wrapped = wrapError(err, { driver: 'postgresql' });
            throw new ConnectionError(`Gagal connect PostgreSQL: ${wrapped.message}`, {
                driver: 'postgresql',
                cause: err
            });
        }
    }

    async _query(sql, params = []) {
        this._assertOpen();
        try {
            const res = await this.pool.query(sql, params);
            return res;
        } catch (err) {
            throw new QueryError(err.message, { driver: 'postgresql', sql, params, cause: err });
        }
    }

    async _runTransaction(work) {
        this._assertOpen();
        const client = await this.pool.connect();
        try {
            await client.query('BEGIN');
            const scopedExec = async (sql, params = []) => {
                try {
                    return await client.query(sql, params);
                } catch (err) {
                    throw new QueryError(err.message, { driver: 'postgresql', sql, params, cause: err });
                }
            };
            const prevExec = this.adapter.exec;
            const prevTx = this.adapter.txRunner;
            this.adapter.exec = scopedExec;
            this.adapter.txRunner = null;
            try {
                const result = await work();
                await client.query('COMMIT');
                return result;
            } catch (err) {
                await client.query('ROLLBACK').catch(() => {});
                throw err;
            } finally {
                this.adapter.exec = prevExec;
                this.adapter.txRunner = prevTx;
            }
        } finally {
            client.release();
        }
    }

    _assertOpen() {
        if (!this.pool) {
            throw new ConnectionError('Pool PostgreSQL belum terhubung', { driver: 'postgresql' });
        }
    }

    async _doDisconnect() {
        if (this.pool) {
            const pool = this.pool;
            this.pool = null;
            this.adapter = null;
            try {
                await pool.end();
            } catch {}
        }
        return true;
    }

    _parseKey(key) {
        const parsed = super._parseKey(key);
        return parsed;
    }

    async _get({ namespace, subKey }) {
        const doc = await this.adapter.loadDoc(namespace);
        if (doc === null || doc === undefined) return null;
        if (subKey === null) return deepClone(doc);
        return this.getSub(doc, subKey);
    }

    async _set({ namespace, subKey }, value) {
        let doc = await this.adapter.loadDoc(namespace);
        if (doc === null || doc === undefined) {
            doc = this._defaultFor(namespace);
        }
        if (subKey === null) {
            doc = value;
        } else {
            doc = this.setSub(deepClone(doc), subKey, value);
        }
        await this.adapter.saveDoc(namespace, doc);
        return true;
    }

    async _delete({ namespace, subKey }) {
        if (subKey === null) {
            return this.adapter.deleteNamespace(namespace);
        }
        const doc = await this.adapter.loadDoc(namespace);
        if (doc === null) return false;
        const result = this.deleteSub(deepClone(doc), subKey);
        if (!result.changed) return false;
        await this.adapter.saveDoc(namespace, result.doc);
        return true;
    }

    async _getAll() {
        const result = {};
        for (const ns of await this.adapter.listNamespaces()) {
            const doc = await this.adapter.loadDoc(ns);
            if (doc !== null && doc !== undefined) result[ns] = deepClone(doc);
        }
        return result;
    }

    async _getKeys() {
        const keys = [];
        for (const ns of await this.adapter.listNamespaces()) {
            keys.push(ns);
            const doc = await this.adapter.loadDoc(ns);
            if (doc && typeof doc === 'object' && !Array.isArray(doc)) {
                for (const sub of Object.keys(doc)) keys.push(`${ns}:${sub}`);
            }
        }
        return keys;
    }

    async _clear() {
        for (const table of [
            'users',
            'chat_stats',
            'premium_users',
            'bot_sewa',
            'banned_users',
            'maintenance_mode',
            'payment_transactions',
            'game_sessions',
            'bot_settings',
            'afk_status',
            'pterodactyl_users',
            'pterodactyl_servers',
            'generic_data'
        ]) {
            await this._query(`DELETE FROM ${table}`);
        }
        return true;
    }

    async _ping() {
        await this._query('SELECT 1 AS ok');
        return true;
    }

    async listNamespaces() {
        return this.adapter.listNamespaces();
    }

    async saveDocument(namespace, doc) {
        await this.adapter.saveDoc(namespace, doc === undefined ? null : doc);
        return doc;
    }

    async getDocument(namespace) {
        return deepClone(await this.adapter.loadDoc(namespace));
    }

    async deleteDocument(namespace) {
        return this.adapter.deleteNamespace(namespace);
    }

    async countRecords(namespace) {
        return this.adapter.countNamespace(namespace);
    }

    async _transaction(fn) {
        return this.adapter.transactional(async () => {
            const snapshot = {};
            for (const ns of await this.adapter.listNamespaces()) {
                snapshot[ns] = await this.adapter.loadDoc(ns);
            }
            const writable = {
                get: (key) => {
                    const parts = this._parseKey(key);
                    const doc = snapshot[parts.namespace];
                    if (parts.subKey === null) return doc === undefined || doc === null ? null : deepClone(doc);
                    return doc && typeof doc === 'object' ? this.getSub(doc, parts.subKey) : null;
                },
                set: (key, value) => {
                    const parts = this._parseKey(key);
                    if (typeof value === 'undefined') throw new Error('Value tidak boleh undefined');
                    if (parts.subKey === null) snapshot[parts.namespace] = value;
                    else {
                        if (!snapshot[parts.namespace] || typeof snapshot[parts.namespace] !== 'object') {
                            snapshot[parts.namespace] = {};
                        }
                        snapshot[parts.namespace][parts.subKey] = value;
                    }
                    return true;
                },
                delete: (key) => {
                    const parts = this._parseKey(key);
                    if (parts.subKey === null) delete snapshot[parts.namespace];
                    else if (snapshot[parts.namespace] && typeof snapshot[parts.namespace] === 'object') {
                        delete snapshot[parts.namespace][parts.subKey];
                    }
                    return true;
                }
            };
            const result = await fn(writable);
            for (const [ns, doc] of Object.entries(snapshot)) {
                if (doc === undefined) continue;
                await this.adapter.saveDoc(ns, doc);
            }
            return result;
        });
    }

    async exportAll() {
        const data = {};
        for (const ns of await this.adapter.listNamespaces()) {
            data[ns] = await this.adapter.loadDoc(ns);
        }
        return data;
    }

    getStats() {
        const base = super.getStats();
        return { ...base, host: this.pgConfig.host, database: this.pgConfig.database, poolMax: this.pgConfig.max };
    }
}

module.exports = PostgreSQLDriver;

const path = require('path');
const fs = require('fs');
const BaseDriver = require('./base');
const registry = require('../registry');
const { safeParse, deepClone } = require('../utils/validator');
const { QueryError, ConnectionError } = require('../errors');

const SCHEMA_VERSION = 2;

/**
 * Daftar migrasi incremental. Setiap entry: { version, name, up: (db) => void }.
 * Saat versi DB < CURRENT, jalankan semua up() dari versi > currentVersion.
 */
const MIGRATIONS = [
    {
        version: 2,
        name: 'add_users_last_seen_column',
        up: (db) => {
            // Contoh: tambah kolom last_seen ke users (idempotent — cek dulu).
            const cols = db.pragma('table_info(users)');
            if (!cols.find((c) => c.name === 'last_seen')) {
                db.exec('ALTER TABLE users ADD COLUMN last_seen INTEGER');
            }
        }
    }
];

const TABLES = {
    users: `CREATE TABLE IF NOT EXISTS users (
    jid TEXT PRIMARY KEY,
    "limit" INTEGER DEFAULT 30,
    money INTEGER DEFAULT 0,
    role TEXT DEFAULT '-',
    level_user INTEGER DEFAULT 1,
    level_cache INTEGER DEFAULT 0,
    last_reset INTEGER,
    last_claim_limit INTEGER,
    extra TEXT,
    created_at INTEGER,
    updated_at INTEGER
  )`,
    chat_stats: `CREATE TABLE IF NOT EXISTS chat_stats (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    total_chat INTEGER DEFAULT 0,
    last_chat INTEGER,
    created_at INTEGER,
    updated_at INTEGER,
    UNIQUE(group_id, user_id)
  )`,
    premium_users: `CREATE TABLE IF NOT EXISTS premium_users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scope TEXT NOT NULL DEFAULT 'main',
    user_id TEXT NOT NULL,
    expired INTEGER NOT NULL,
    created_at INTEGER,
    updated_at INTEGER,
    UNIQUE(scope, user_id)
  )`,
    bot_sewa: `CREATE TABLE IF NOT EXISTS bot_sewa (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scope TEXT NOT NULL DEFAULT 'main',
    group_id TEXT NOT NULL,
    group_name TEXT,
    start TEXT,
    expired INTEGER,
    created_at INTEGER,
    updated_at INTEGER,
    UNIQUE(scope, group_id)
  )`,
    banned_users: `CREATE TABLE IF NOT EXISTS banned_users (
    user_id TEXT PRIMARY KEY,
    reason TEXT,
    banned_at TEXT,
    expired_at TEXT,
    permanent INTEGER DEFAULT 0,
    created_at INTEGER
  )`,
    maintenance_mode: `CREATE TABLE IF NOT EXISTS maintenance_mode (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    enabled INTEGER DEFAULT 0,
    reason TEXT,
    start_at INTEGER,
    end_at INTEGER,
    duration INTEGER DEFAULT 0,
    updated_at INTEGER
  )`,
    payment_transactions: `CREATE TABLE IF NOT EXISTS payment_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id TEXT UNIQUE NOT NULL,
    user_id TEXT,
    amount INTEGER DEFAULT 0,
    status TEXT DEFAULT 'pending',
    data TEXT,
    created_at INTEGER,
    updated_at INTEGER
  )`,
    game_sessions: `CREATE TABLE IF NOT EXISTS game_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    game_type TEXT,
    group_id TEXT,
    user_id TEXT,
    state TEXT,
    created_at INTEGER,
    updated_at INTEGER
  )`,
    bot_settings: `CREATE TABLE IF NOT EXISTS bot_settings (
    namespace TEXT NOT NULL,
    key TEXT NOT NULL,
    value TEXT,
    created_at INTEGER,
    updated_at INTEGER,
    PRIMARY KEY (namespace, key)
  )`,
    afk_status: `CREATE TABLE IF NOT EXISTS afk_status (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id TEXT,
    user_id TEXT,
    reason TEXT,
    started_at INTEGER,
    mentioned INTEGER DEFAULT 0,
    created_at INTEGER,
    updated_at INTEGER,
    UNIQUE(group_id, user_id)
  )`,
    pterodactyl_users: `CREATE TABLE IF NOT EXISTS pterodactyl_users (
    user_id TEXT PRIMARY KEY,
    api_key TEXT,
    data TEXT,
    created_at INTEGER
  )`,
    pterodactyl_servers: `CREATE TABLE IF NOT EXISTS pterodactyl_servers (
    server_id TEXT PRIMARY KEY,
    user_id TEXT,
    server_name TEXT,
    data TEXT,
    created_at INTEGER
  )`,
    generic_data: `CREATE TABLE IF NOT EXISTS generic_data (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    namespace TEXT NOT NULL,
    key TEXT NOT NULL DEFAULT '__doc__',
    value TEXT,
    created_at INTEGER,
    updated_at INTEGER,
    UNIQUE(namespace, key)
  )`,
    db_meta: `CREATE TABLE IF NOT EXISTS db_meta (
    key TEXT PRIMARY KEY,
    value TEXT
  )`
};

const INDEXES = [
    'CREATE INDEX IF NOT EXISTS idx_chat_stats_group ON chat_stats(group_id)',
    'CREATE INDEX IF NOT EXISTS idx_chat_stats_user ON chat_stats(user_id)',
    'CREATE INDEX IF NOT EXISTS idx_premium_user ON premium_users(user_id)',
    'CREATE INDEX IF NOT EXISTS idx_premium_scope ON premium_users(scope)',
    'CREATE INDEX IF NOT EXISTS idx_sewa_scope ON bot_sewa(scope)',
    'CREATE INDEX IF NOT EXISTS idx_settings_namespace ON bot_settings(namespace)',
    'CREATE INDEX IF NOT EXISTS idx_generic_namespace ON generic_data(namespace)',
    'CREATE INDEX IF NOT EXISTS idx_users_money ON users(money)',
    'CREATE INDEX IF NOT EXISTS idx_users_level ON users(level_user)',
    'CREATE INDEX IF NOT EXISTS idx_payment_status ON payment_transactions(status)'
];

class SQLiteDriver extends BaseDriver {
    constructor(options = {}) {
        super({ ...options, type: 'sqlite' });
        const cfg = options.config || {};
        this.dbPath = path.resolve(cfg.path || './bot.db');
        this.db = null;
        this.stmts = new Map();
    }

    async _doConnect() {
        let Database;
        try {
            Database = require('better-sqlite3');
        } catch (err) {
            throw new ConnectionError('better-sqlite3 belum terinstall. Jalankan: bun add better-sqlite3', {
                driver: 'sqlite',
                cause: err
            });
        }
        try {
            const dir = path.dirname(this.dbPath);
            if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
            this.db = new Database(this.dbPath);
            this.db.pragma('journal_mode = WAL');
            this.db.pragma('synchronous = NORMAL');
            this.db.pragma('foreign_keys = ON');
            this.db.pragma('busy_timeout = 5000');
            this._migrate();
        } catch (err) {
            if (err instanceof ConnectionError) throw err;
            throw new QueryError(`Gagal inisialisasi SQLite: ${err.message}`, { driver: 'sqlite', cause: err });
        }
    }

    _migrate() {
        const createAll = this.db.transaction(() => {
            for (const ddl of Object.values(TABLES)) {
                this.db.exec(ddl);
            }
            for (const ddl of INDEXES) {
                this.db.exec(ddl);
            }
        });
        createAll();

        const metaStmt = this.db.prepare("SELECT value FROM db_meta WHERE key = 'schema_version'");
        const current = metaStmt.get();
        if (!current) {
            this.db
                .prepare("INSERT INTO db_meta (key, value) VALUES ('schema_version', ?)")
                .run(String(SCHEMA_VERSION));
        } else if (Number(current.value) < SCHEMA_VERSION) {
            this._runMigrations(Number(current.value));
            this.db.prepare("UPDATE db_meta SET value = ? WHERE key = 'schema_version'").run(String(SCHEMA_VERSION));
        }
    }

    _runMigrations(fromVersion) {
        this.logger.info(`Menjalankan migrasi SQLite dari versi ${fromVersion} → ${SCHEMA_VERSION}`);
        const pending = MIGRATIONS.filter((m) => m.version > fromVersion).sort((a, b) => a.version - b.version);
        if (!pending.length) {
            this.logger.debug(`Tidak ada migrasi SQLite untuk versi ${fromVersion} → ${SCHEMA_VERSION}`);
            return;
        }
        const runAll = this.db.transaction(() => {
            for (const m of pending) {
                try {
                    this.logger.info(`  ↳ migrate v${m.version}: ${m.name}`);
                    m.up(this.db);
                } catch (err) {
                    this.logger.error(`  ↳ GAGAL migrate v${m.version} (${m.name}): ${err.message}`);
                    throw err;
                }
            }
        });
        runAll();
        this.logger.success(`Migrasi SQLite selesai: ${pending.length} langkah dijalankan.`);
    }

    _prepare(id, sql) {
        if (!this.stmts.has(id)) {
            this.stmts.set(id, this.db.prepare(sql));
        }
        return this.stmts.get(id);
    }

    async _doDisconnect() {
        if (this.db) {
            try {
                this.db.close();
            } finally {
                this.db = null;
                this.stmts.clear();
            }
        }
        return true;
    }

    _assertOpen() {
        if (!this.db) {
            throw new ConnectionError('Koneksi SQLite sudah ditutup', { driver: 'sqlite' });
        }
    }

    async _get({ namespace, subKey }) {
        this._assertOpen();
        const doc = this._loadDoc(namespace);
        if (doc === null || doc === undefined) return null;
        if (subKey === null) return deepClone(doc);
        return this.getSub(doc, subKey);
    }

    async _set({ namespace, subKey }, value) {
        this._assertOpen();
        let doc = this._loadDoc(namespace);
        if (doc === null || doc === undefined) {
            doc = this._defaultFor(namespace);
        }
        if (subKey === null) {
            doc = value;
        } else {
            doc = this.setSub(deepClone(doc), subKey, value);
        }
        this._saveDoc(namespace, doc);
        return true;
    }

    async _delete({ namespace, subKey }) {
        this._assertOpen();
        if (subKey === null) {
            return this._deleteNamespace(namespace);
        }
        const doc = this._loadDoc(namespace);
        if (doc === null) return false;
        const result = this.deleteSub(deepClone(doc), subKey);
        if (!result.changed) return false;
        this._saveDoc(namespace, result.doc);
        return true;
    }

    _deleteNamespace(namespace) {
        const meta = registry.resolveNamespace(namespace);
        if (meta.name.startsWith('jadibot:')) {
            const parts = meta.name.split(':');
            const scope = parts[1];
            const dataset = parts[2] || 'sewa';
            if (dataset === 'premium') {
                this._prepare('del_premium_scope', 'DELETE FROM premium_users WHERE scope = ?').run(scope);
                return true;
            }
            if (dataset === 'sewa') {
                this._prepare('del_sewa_scope', 'DELETE FROM bot_sewa WHERE scope = ?').run(scope);
                return true;
            }
            this._prepare('del_generic_ns', 'DELETE FROM generic_data WHERE namespace = ?').run(meta.name);
            return true;
        }
        switch (namespace) {
            case 'user':
                this._prepare('del_users_all', 'DELETE FROM users').run();
                return true;
            case 'userDB':
                this._prepare('del_chat_all', 'DELETE FROM chat_stats').run();
                return true;
            case 'premium':
                this._prepare('del_premium_main', "DELETE FROM premium_users WHERE scope = 'main'").run();
                return true;
            case 'sewa':
                this._prepare('del_sewa_main', "DELETE FROM bot_sewa WHERE scope = 'main'").run();
                return true;
            case 'bannedDB':
                this._prepare('del_banned_all', 'DELETE FROM banned_users').run();
                return true;
            case 'maintenance':
                this._prepare('del_maint', 'DELETE FROM maintenance_mode').run();
                return true;
            case 'afk':
                this._prepare('del_afk_all', 'DELETE FROM afk_status').run();
                return true;
            case 'payment':
                this._prepare('del_payment_all', 'DELETE FROM payment_transactions').run();
                return true;
            case 'ptreodactyl':
                this._prepare('del_ptero_u', 'DELETE FROM pterodactyl_users').run();
                this._prepare('del_ptero_s', 'DELETE FROM pterodactyl_servers').run();
                return true;
            case 'welcome':
            case 'left':
                this._prepare('del_settings_ns', 'DELETE FROM bot_settings WHERE namespace = ?').run(namespace);
                return true;
            default:
                this._prepare('del_generic_ns', 'DELETE FROM generic_data WHERE namespace = ?').run(namespace);
                return true;
        }
    }

    _defaultFor(namespace) {
        const meta = registry.resolveNamespace(namespace);
        if (meta.generic && meta.dynamic) return {};
        if (meta.name.startsWith('jadibot:')) {
            const sub = meta.name.split(':')[2] || 'sewa';
            const base = registry.DATASETS[sub];
            return base ? deepClone(base.defaults) : {};
        }
        return deepClone(meta.defaults || {});
    }

    async _getAll() {
        this._assertOpen();
        const result = {};
        for (const ns of this._listNamespacesSync()) {
            const doc = this._loadDoc(ns);
            if (doc !== null && doc !== undefined) result[ns] = deepClone(doc);
        }
        return result;
    }

    async _getKeys() {
        this._assertOpen();
        const keys = [];
        for (const ns of this._listNamespacesSync()) {
            keys.push(ns);
            const doc = this._loadDoc(ns);
            if (doc && typeof doc === 'object' && !Array.isArray(doc)) {
                for (const sub of Object.keys(doc)) keys.push(`${ns}:${sub}`);
            }
        }
        return keys;
    }

    async _clear() {
        this._assertOpen();
        const run = this.db.transaction(() => {
            for (const table of [
                'users',
                'chat_stats',
                'premium_users',
                'bot_sewa',
                'banned_users',
                'maintenance_mode',
                'payment_transactions',
                'game_sessions',
                'bot_settings',
                'afk_status',
                'pterodactyl_users',
                'pterodactyl_servers',
                'generic_data'
            ]) {
                this.db.exec(`DELETE FROM ${table}`);
            }
        });
        run();
        return true;
    }

    async _ping() {
        this._assertOpen();
        this._prepare('ping', 'SELECT 1 AS ok').get();
        return true;
    }

    _listNamespacesSync() {
        const namespaces = new Set();
        if (this._prepare('cnt_users', 'SELECT COUNT(*) AS c FROM users').get().c > 0) namespaces.add('user');
        if (this._prepare('cnt_chat', 'SELECT COUNT(*) AS c FROM chat_stats').get().c > 0) namespaces.add('userDB');
        if (this._prepare('cnt_banned', 'SELECT COUNT(*) AS c FROM banned_users').get().c > 0)
            namespaces.add('bannedDB');
        if (this._prepare('cnt_maint', 'SELECT COUNT(*) AS c FROM maintenance_mode').get().c > 0)
            namespaces.add('maintenance');
        if (this._prepare('cnt_afk', 'SELECT COUNT(*) AS c FROM afk_status').get().c > 0) namespaces.add('afk');
        if (this._prepare('cnt_payment', 'SELECT COUNT(*) AS c FROM payment_transactions').get().c > 0)
            namespaces.add('payment');
        const pteroU = this._prepare('cnt_ptero_u', 'SELECT COUNT(*) AS c FROM pterodactyl_users').get().c;
        const pteroS = this._prepare('cnt_ptero_s', 'SELECT COUNT(*) AS c FROM pterodactyl_servers').get().c;
        if (pteroU > 0 || pteroS > 0) namespaces.add('ptreodactyl');

        for (const row of this._prepare('sel_premium_scopes', 'SELECT DISTINCT scope FROM premium_users').all()) {
            namespaces.add(row.scope === 'main' ? 'premium' : `jadibot:${row.scope}:premium`);
        }
        for (const row of this._prepare('sel_sewa_scopes', 'SELECT DISTINCT scope FROM bot_sewa').all()) {
            namespaces.add(row.scope === 'main' ? 'sewa' : `jadibot:${row.scope}:sewa`);
        }
        for (const row of this._prepare('sel_settings_ns', 'SELECT DISTINCT namespace FROM bot_settings').all()) {
            namespaces.add(row.namespace);
        }
        for (const row of this._prepare('sel_generic_ns', 'SELECT DISTINCT namespace FROM generic_data').all()) {
            namespaces.add(row.namespace);
        }
        return [...namespaces];
    }

    async listNamespaces() {
        this._assertOpen();
        return this._listNamespacesSync();
    }

    _loadDoc(namespace) {
        const meta = registry.resolveNamespace(namespace);
        if (meta.name.startsWith('jadibot:')) {
            const parts = meta.name.split(':');
            const scope = parts[1];
            const dataset = parts[2] || 'sewa';
            if (dataset === 'premium') {
                const rows = this._prepare('sel_premium_scope', 'SELECT * FROM premium_users WHERE scope = ?').all(
                    scope
                );
                return rows.length ? registry.normalizeForLoad('premium', { single: rows }, scope) : null;
            }
            if (dataset === 'sewa') {
                const rows = this._prepare('sel_sewa_scope', 'SELECT * FROM bot_sewa WHERE scope = ?').all(scope);
                return rows.length ? registry.normalizeForLoad('sewa', { single: rows }, scope) : null;
            }
            const row = this._prepare(
                'sel_generic',
                'SELECT value FROM generic_data WHERE namespace = ? AND key = ?'
            ).get(meta.name, '__doc__');
            return row ? safeParse(row.value, null) : null;
        }

        switch (namespace) {
            case 'user': {
                const rows = this._prepare('sel_users', 'SELECT * FROM users').all();
                return rows.length ? registry.normalizeForLoad('user', { single: rows }) : null;
            }
            case 'userDB': {
                const rows = this._prepare('sel_chat', 'SELECT * FROM chat_stats').all();
                return rows.length ? registry.normalizeForLoad('userDB', { single: rows }) : null;
            }
            case 'premium': {
                const rows = this._prepare(
                    'sel_premium_main',
                    "SELECT * FROM premium_users WHERE scope = 'main'"
                ).all();
                return rows.length ? registry.normalizeForLoad('premium', { single: rows }, 'main') : null;
            }
            case 'sewa': {
                const rows = this._prepare('sel_sewa_main', "SELECT * FROM bot_sewa WHERE scope = 'main'").all();
                return rows.length ? registry.normalizeForLoad('sewa', { single: rows }, 'main') : null;
            }
            case 'bannedDB': {
                const rows = this._prepare('sel_banned', 'SELECT * FROM banned_users').all();
                return rows.length ? registry.normalizeForLoad('bannedDB', { single: rows }) : null;
            }
            case 'maintenance': {
                const row = this._prepare('sel_maint', 'SELECT * FROM maintenance_mode WHERE id = 1').get();
                return row ? registry.normalizeForLoad('maintenance', { maintenance: row }) : null;
            }
            case 'afk': {
                const rows = this._prepare('sel_afk', 'SELECT * FROM afk_status').all();
                return rows.length ? registry.normalizeForLoad('afk', { single: rows }) : null;
            }
            case 'payment': {
                const rows = this._prepare('sel_payment', 'SELECT * FROM payment_transactions').all();
                return rows.length ? registry.normalizeForLoad('payment', { single: rows }) : null;
            }
            case 'ptreodactyl': {
                const users = this._prepare('sel_ptero_u', 'SELECT * FROM pterodactyl_users').all();
                const servers = this._prepare('sel_ptero_s', 'SELECT * FROM pterodactyl_servers').all();
                if (!users.length && !servers.length) return null;
                return registry.normalizeForLoad('ptreodactyl', { users, servers });
            }
            case 'welcome':
            case 'left': {
                const rows = this._prepare('sel_settings', 'SELECT * FROM bot_settings WHERE namespace = ?').all(
                    namespace
                );
                return rows.length ? registry.normalizeForLoad(namespace, { single: rows }) : null;
            }
            default: {
                const row = this._prepare(
                    'sel_generic',
                    'SELECT value FROM generic_data WHERE namespace = ? AND key = ?'
                ).get(namespace, '__doc__');
                return row ? safeParse(row.value, null) : null;
            }
        }
    }

    _saveDoc(namespace, doc) {
        const meta = registry.resolveNamespace(namespace);
        if (meta.name.startsWith('jadibot:')) {
            const parts = meta.name.split(':');
            const scope = parts[1];
            const dataset = parts[2] || 'sewa';
            if (dataset === 'premium') {
                const rows = registry.normalizeForSave('premium', doc, scope).rows.single;
                const tx = this.db.transaction(() => {
                    this._prepare('del_premium_scope', 'DELETE FROM premium_users WHERE scope = ?').run(scope);
                    const ins = this._prepare(
                        'ins_premium',
                        'INSERT INTO premium_users (scope, user_id, expired, created_at, updated_at) VALUES (?, ?, ?, ?, ?)'
                    );
                    for (const r of rows) ins.run(r.scope, r.user_id, r.expired, r.created_at, r.updated_at);
                });
                tx();
                return;
            }
            if (dataset === 'sewa') {
                const rows = registry.normalizeForSave('sewa', doc, scope).rows.single;
                const tx = this.db.transaction(() => {
                    this._prepare('del_sewa_scope', 'DELETE FROM bot_sewa WHERE scope = ?').run(scope);
                    const ins = this._prepare(
                        'ins_sewa',
                        'INSERT INTO bot_sewa (scope, group_id, group_name, start, expired, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
                    );
                    for (const r of rows)
                        ins.run(r.scope, r.group_id, r.group_name, r.start, r.expired, r.created_at, r.updated_at);
                });
                tx();
                return;
            }
            this._prepare(
                'upsert_generic',
                `INSERT INTO generic_data (namespace, key, value, created_at, updated_at) VALUES (?, '__doc__', ?, ?, ?)
         ON CONFLICT(namespace, key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`
            ).run(meta.name, JSON.stringify(doc === undefined ? null : doc), Date.now(), Date.now());
            return;
        }

        switch (namespace) {
            case 'user': {
                const rows = registry.normalizeForSave('user', doc).rows.single;
                const tx = this.db.transaction(() => {
                    this._prepare('del_users_all', 'DELETE FROM users').run();
                    const ins = this._prepare(
                        'ins_user',
                        `INSERT INTO users (jid, "limit", money, role, level_user, level_cache, last_reset, last_claim_limit, extra, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
                    );
                    for (const r of rows) {
                        ins.run(
                            r.jid,
                            r.limit,
                            r.money,
                            r.role,
                            r.level_user,
                            r.level_cache,
                            r.last_reset,
                            r.last_claim_limit,
                            JSON.stringify(r.extra || {}),
                            r.created_at,
                            r.updated_at
                        );
                    }
                });
                tx();
                return;
            }
            case 'userDB': {
                const rows = registry.normalizeForSave('userDB', doc).rows.single;
                const tx = this.db.transaction(() => {
                    this._prepare('del_chat_all', 'DELETE FROM chat_stats').run();
                    const ins = this._prepare(
                        'ins_chat',
                        'INSERT INTO chat_stats (group_id, user_id, total_chat, last_chat, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)'
                    );
                    for (const r of rows)
                        ins.run(r.group_id, r.user_id, r.total_chat, r.last_chat, r.created_at, r.updated_at);
                });
                tx();
                return;
            }
            case 'premium': {
                const rows = registry.normalizeForSave('premium', doc, 'main').rows.single;
                const tx = this.db.transaction(() => {
                    this._prepare('del_premium_main', "DELETE FROM premium_users WHERE scope = 'main'").run();
                    const ins = this._prepare(
                        'ins_premium',
                        'INSERT INTO premium_users (scope, user_id, expired, created_at, updated_at) VALUES (?, ?, ?, ?, ?)'
                    );
                    for (const r of rows) ins.run(r.scope, r.user_id, r.expired, r.created_at, r.updated_at);
                });
                tx();
                return;
            }
            case 'sewa': {
                const rows = registry.normalizeForSave('sewa', doc, 'main').rows.single;
                const tx = this.db.transaction(() => {
                    this._prepare('del_sewa_main', "DELETE FROM bot_sewa WHERE scope = 'main'").run();
                    const ins = this._prepare(
                        'ins_sewa',
                        'INSERT INTO bot_sewa (scope, group_id, group_name, start, expired, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
                    );
                    for (const r of rows)
                        ins.run(r.scope, r.group_id, r.group_name, r.start, r.expired, r.created_at, r.updated_at);
                });
                tx();
                return;
            }
            case 'bannedDB': {
                const rows = registry.normalizeForSave('bannedDB', doc).rows.single;
                const tx = this.db.transaction(() => {
                    this._prepare('del_banned_all', 'DELETE FROM banned_users').run();
                    const ins = this._prepare(
                        'ins_banned',
                        'INSERT INTO banned_users (user_id, reason, banned_at, expired_at, permanent, created_at) VALUES (?, ?, ?, ?, ?, ?)'
                    );
                    for (const r of rows)
                        ins.run(r.user_id, r.reason, r.banned_at, r.expired_at, r.permanent, r.created_at);
                });
                tx();
                return;
            }
            case 'maintenance': {
                const row = registry.normalizeForSave('maintenance', doc).rows.maintenance;
                this._prepare(
                    'repl_maint',
                    `INSERT INTO maintenance_mode (id, enabled, reason, start_at, end_at, duration, updated_at) VALUES (1, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(id) DO UPDATE SET enabled = excluded.enabled, reason = excluded.reason, start_at = excluded.start_at,
           end_at = excluded.end_at, duration = excluded.duration, updated_at = excluded.updated_at`
                ).run(row.enabled, row.reason, row.start_at, row.end_at, row.duration, row.updated_at);
                return;
            }
            case 'afk': {
                const rows = registry.normalizeForSave('afk', doc).rows.single;
                const tx = this.db.transaction(() => {
                    this._prepare('del_afk_all', 'DELETE FROM afk_status').run();
                    const ins = this._prepare(
                        'ins_afk',
                        'INSERT INTO afk_status (group_id, user_id, reason, started_at, mentioned, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
                    );
                    for (const r of rows)
                        ins.run(r.group_id, r.user_id, r.reason, r.started_at, r.mentioned, r.created_at, r.updated_at);
                });
                tx();
                return;
            }
            case 'payment': {
                const rows = registry.normalizeForSave('payment', doc).rows.single;
                const tx = this.db.transaction(() => {
                    this._prepare('del_payment_all', 'DELETE FROM payment_transactions').run();
                    const ins = this._prepare(
                        'ins_payment',
                        'INSERT INTO payment_transactions (order_id, user_id, amount, status, data, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
                    );
                    for (const r of rows)
                        ins.run(r.order_id, r.user_id, r.amount, r.status, r.data, r.created_at, r.updated_at);
                });
                tx();
                return;
            }
            case 'ptreodactyl': {
                const norm = registry.normalizeForSave('ptreodactyl', doc);
                const tx = this.db.transaction(() => {
                    this._prepare('del_ptero_u', 'DELETE FROM pterodactyl_users').run();
                    this._prepare('del_ptero_s', 'DELETE FROM pterodactyl_servers').run();
                    const insU = this._prepare(
                        'ins_ptero_u',
                        'INSERT INTO pterodactyl_users (user_id, api_key, data, created_at) VALUES (?, ?, ?, ?)'
                    );
                    for (const r of norm.rows.userRows) insU.run(r.user_id, r.api_key, r.data, r.created_at);
                    const insS = this._prepare(
                        'ins_ptero_s',
                        'INSERT INTO pterodactyl_servers (server_id, user_id, server_name, data, created_at) VALUES (?, ?, ?, ?, ?)'
                    );
                    for (const r of norm.rows.serverRows)
                        insS.run(r.server_id, r.user_id, r.server_name, r.data, r.created_at);
                });
                tx();
                return;
            }
            case 'welcome':
            case 'left': {
                const rows = registry.normalizeForSave(namespace, doc).rows.single;
                const tx = this.db.transaction(() => {
                    this._prepare('del_settings_ns', 'DELETE FROM bot_settings WHERE namespace = ?').run(namespace);
                    const ins = this._prepare(
                        'ins_settings',
                        'INSERT INTO bot_settings (namespace, key, value, created_at, updated_at) VALUES (?, ?, ?, ?, ?)'
                    );
                    for (const r of rows) ins.run(r.namespace, r.key, r.value, r.created_at, r.updated_at);
                });
                tx();
                return;
            }
            default: {
                this._prepare(
                    'upsert_generic',
                    `INSERT INTO generic_data (namespace, key, value, created_at, updated_at) VALUES (?, '__doc__', ?, ?, ?)
           ON CONFLICT(namespace, key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`
                ).run(namespace, JSON.stringify(doc === undefined ? null : doc), Date.now(), Date.now());
            }
        }
    }

    async saveDocument(namespace, doc) {
        this._assertOpen();
        this._saveDoc(namespace, doc === undefined ? null : doc);
        return doc;
    }

    async getDocument(namespace) {
        this._assertOpen();
        return deepClone(this._loadDoc(namespace));
    }

    async deleteDocument(namespace) {
        this._assertOpen();
        return this._deleteNamespace(namespace);
    }

    async countRecords(namespace) {
        this._assertOpen();
        const meta = registry.resolveNamespace(namespace);
        if (meta.name.startsWith('jadibot:')) {
            const parts = meta.name.split(':');
            const dataset = parts[2] || 'sewa';
            if (dataset === 'premium') {
                return this._prepare(
                    'cnt_premium_scope',
                    'SELECT COUNT(*) AS c FROM premium_users WHERE scope = ?'
                ).get(parts[1]).c;
            }
            if (dataset === 'sewa') {
                return this._prepare('cnt_sewa_scope', 'SELECT COUNT(*) AS c FROM bot_sewa WHERE scope = ?').get(
                    parts[1]
                ).c;
            }
            const row = this._prepare('cnt_generic', 'SELECT COUNT(*) AS c FROM generic_data WHERE namespace = ?').get(
                meta.name
            );
            return row ? row.c : 0;
        }
        switch (namespace) {
            case 'user':
                return this._prepare('cnt_users', 'SELECT COUNT(*) AS c FROM users').get().c;
            case 'userDB':
                return this._prepare('cnt_chat', 'SELECT COUNT(*) AS c FROM chat_stats').get().c;
            case 'premium':
                return this._prepare(
                    'cnt_premium_main',
                    "SELECT COUNT(*) AS c FROM premium_users WHERE scope = 'main'"
                ).get().c;
            case 'sewa':
                return this._prepare('cnt_sewa_main', "SELECT COUNT(*) AS c FROM bot_sewa WHERE scope = 'main'").get()
                    .c;
            case 'bannedDB':
                return this._prepare('cnt_banned', 'SELECT COUNT(*) AS c FROM banned_users').get().c;
            case 'maintenance':
                return this._prepare('cnt_maint', 'SELECT COUNT(*) AS c FROM maintenance_mode').get().c;
            case 'afk':
                return this._prepare('cnt_afk', 'SELECT COUNT(*) AS c FROM afk_status').get().c;
            case 'payment':
                return this._prepare('cnt_payment', 'SELECT COUNT(*) AS c FROM payment_transactions').get().c;
            case 'welcome':
            case 'left':
                return this._prepare('cnt_settings', 'SELECT COUNT(*) AS c FROM bot_settings WHERE namespace = ?').get(
                    namespace
                ).c;
            default: {
                const row = this._prepare(
                    'cnt_generic',
                    'SELECT COUNT(*) AS c FROM generic_data WHERE namespace = ?'
                ).get(namespace);
                return row ? row.c : 0;
            }
        }
    }

    async _transaction(fn) {
        this._assertOpen();
        const snapshot = {};
        for (const ns of this._listNamespacesSync()) {
            snapshot[ns] = this._loadDoc(ns);
        }
        const writable = {
            get: (key) => {
                const parts = this._parseKey(key);
                const doc = snapshot[parts.namespace];
                if (parts.subKey === null) return doc === undefined || doc === null ? null : deepClone(doc);
                return doc && typeof doc === 'object' && parts.subKey in doc ? deepClone(doc[parts.subKey]) : null;
            },
            set: (key, value) => {
                const parts = this._parseKey(key);
                if (typeof value === 'undefined') throw new Error('Value tidak boleh undefined');
                if (parts.subKey === null) snapshot[parts.namespace] = value;
                else {
                    if (!snapshot[parts.namespace] || typeof snapshot[parts.namespace] !== 'object') {
                        snapshot[parts.namespace] = {};
                    }
                    snapshot[parts.namespace][parts.subKey] = value;
                }
                return true;
            },
            delete: (key) => {
                const parts = this._parseKey(key);
                if (parts.subKey === null) delete snapshot[parts.namespace];
                else if (snapshot[parts.namespace] && typeof snapshot[parts.namespace] === 'object') {
                    delete snapshot[parts.namespace][parts.subKey];
                }
                return true;
            }
        };
        const result = await fn(writable);
        for (const [ns, doc] of Object.entries(snapshot)) {
            if (doc === undefined) continue;
            this._saveDoc(ns, doc);
        }
        return result;
    }

    async exportAll() {
        this._assertOpen();
        const data = {};
        for (const ns of this._listNamespacesSync()) {
            data[ns] = this._loadDoc(ns);
        }
        return data;
    }

    vacuum() {
        this._assertOpen();
        this.db.exec('VACUUM');
        return true;
    }

    getStats() {
        const base = super.getStats();
        let tables = {};
        if (this.db) {
            for (const table of [
                'users',
                'chat_stats',
                'premium_users',
                'bot_sewa',
                'banned_users',
                'maintenance_mode',
                'payment_transactions',
                'bot_settings',
                'afk_status',
                'generic_data'
            ]) {
                try {
                    tables[table] = this._prepare(`cnt_${table}`, `SELECT COUNT(*) AS c FROM ${table}`).get().c;
                } catch {
                    tables[table] = -1;
                }
            }
        }
        return {
            ...base,
            path: this.dbPath,
            tables
        };
    }
}

module.exports = SQLiteDriver;

const BaseDriver = require('./base');
const { SQLAdapter } = require('./sqlcommon');
const { ConnectionError, QueryError, wrapError } = require('../errors');
const { deepClone } = require('../utils/validator');

class MySQLDriver extends BaseDriver {
    constructor(options = {}) {
        super({ ...options, type: 'mysql' });
        const cfg = options.config || {};
        this.mysqlConfig = {
            host: cfg.host || 'localhost',
            port: Number(cfg.port) || 3306,
            database: cfg.database || 'x7botz_db',
            user: cfg.user || 'root',
            password: cfg.password || '',
            waitForConnections: true,
            connectionLimit: (options.pool && options.pool.max) || 10,
            maxIdle: (options.pool && options.pool.min) || 2,
            idleTimeout: (options.pool && options.pool.idleTimeoutMillis) || 30000,
            connectTimeout: (options.pool && options.pool.acquireTimeoutMillis) || 10000,
            charset: 'utf8mb4_unicode_ci',
            enableKeepAlive: true
        };
        this.pool = null;
        this.adapter = null;
    }

    async _doConnect() {
        let mysql;
        try {
            mysql = require('mysql2/promise');
        } catch (err) {
            throw new ConnectionError('library mysql2 belum terinstall. Jalankan: bun add mysql2', {
                driver: 'mysql',
                cause: err
            });
        }
        try {
            this.pool = mysql.createPool(this.mysqlConfig);
            const conn = await this.pool.getConnection();
            await conn.ping();
            conn.release();
            this.adapter = new SQLAdapter('mysql', (sql, params) => this._query(sql, params), this.logger);
            this.adapter.txRunnerImpl = (work) => this._runTransaction(work);
            await this.adapter.ensureSchema();
        } catch (err) {
            this.pool = null;
            const wrapped = wrapError(err, { driver: 'mysql' });
            throw new ConnectionError(`Gagal connect MySQL: ${wrapped.message}`, { driver: 'mysql', cause: err });
        }
    }

    async _query(sql, params = []) {
        this._assertOpen();
        try {
            const [rows] = await this.pool.execute(sql, params);
            return rows;
        } catch (err) {
            if (
                err &&
                (err.code === 'ER_CON_COUNT_ERROR' ||
                    err.code === 'ECONNRESET' ||
                    err.code === 'PROTOCOL_CONNECTION_LOST')
            ) {
                const wrapped = wrapError(err, { driver: 'mysql' });
                wrapped.retryable = true;
                throw wrapped;
            }
            throw new QueryError(err.message, { driver: 'mysql', sql, params, cause: err });
        }
    }

    async _runTransaction(work) {
        this._assertOpen();
        const conn = await this.pool.getConnection();
        try {
            await conn.beginTransaction();
            const scopedExec = async (sql, params = []) => {
                try {
                    const [rows] = await conn.execute(sql, params);
                    return rows;
                } catch (err) {
                    throw new QueryError(err.message, { driver: 'mysql', sql, params, cause: err });
                }
            };
            const prevExec = this.adapter.exec;
            const prevTx = this.adapter.txRunner;
            this.adapter.exec = scopedExec;
            this.adapter.txRunner = null;
            try {
                const result = await work();
                await conn.commit();
                return result;
            } catch (err) {
                await conn.rollback().catch(() => {});
                throw err;
            } finally {
                this.adapter.exec = prevExec;
                this.adapter.txRunner = prevTx;
            }
        } finally {
            conn.release();
        }
    }

    _assertOpen() {
        if (!this.pool) {
            throw new ConnectionError('Pool MySQL belum terhubung', { driver: 'mysql' });
        }
    }

    async _doDisconnect() {
        if (this.pool) {
            const pool = this.pool;
            this.pool = null;
            this.adapter = null;
            try {
                await pool.end();
            } catch {}
        }
        return true;
    }

    async _get({ namespace, subKey }) {
        const doc = await this.adapter.loadDoc(namespace);
        if (doc === null || doc === undefined) return null;
        if (subKey === null) return deepClone(doc);
        return this.getSub(doc, subKey);
    }

    async _set({ namespace, subKey }, value) {
        let doc = await this.adapter.loadDoc(namespace);
        if (doc === null || doc === undefined) {
            doc = this._defaultFor(namespace);
        }
        if (subKey === null) {
            doc = value;
        } else {
            doc = this.setSub(deepClone(doc), subKey, value);
        }
        await this.adapter.saveDoc(namespace, doc);
        return true;
    }

    async _delete({ namespace, subKey }) {
        if (subKey === null) {
            return this.adapter.deleteNamespace(namespace);
        }
        const doc = await this.adapter.loadDoc(namespace);
        if (doc === null) return false;
        const result = this.deleteSub(deepClone(doc), subKey);
        if (!result.changed) return false;
        await this.adapter.saveDoc(namespace, result.doc);
        return true;
    }

    async _getAll() {
        const result = {};
        for (const ns of await this.adapter.listNamespaces()) {
            const doc = await this.adapter.loadDoc(ns);
            if (doc !== null && doc !== undefined) result[ns] = deepClone(doc);
        }
        return result;
    }

    async _getKeys() {
        const keys = [];
        for (const ns of await this.adapter.listNamespaces()) {
            keys.push(ns);
            const doc = await this.adapter.loadDoc(ns);
            if (doc && typeof doc === 'object' && !Array.isArray(doc)) {
                for (const sub of Object.keys(doc)) keys.push(`${ns}:${sub}`);
            }
        }
        return keys;
    }

    async _clear() {
        for (const table of [
            'users',
            'chat_stats',
            'premium_users',
            'bot_sewa',
            'banned_users',
            'maintenance_mode',
            'payment_transactions',
            'game_sessions',
            'bot_settings',
            'afk_status',
            'pterodactyl_users',
            'pterodactyl_servers',
            'generic_data'
        ]) {
            await this._query(`DELETE FROM ${table}`);
        }
        return true;
    }

    async _ping() {
        await this._query('SELECT 1 AS ok');
        return true;
    }

    async listNamespaces() {
        return this.adapter.listNamespaces();
    }

    async saveDocument(namespace, doc) {
        await this.adapter.saveDoc(namespace, doc === undefined ? null : doc);
        return doc;
    }

    async getDocument(namespace) {
        return deepClone(await this.adapter.loadDoc(namespace));
    }

    async deleteDocument(namespace) {
        return this.adapter.deleteNamespace(namespace);
    }

    async countRecords(namespace) {
        return this.adapter.countNamespace(namespace);
    }

    async _transaction(fn) {
        return this.adapter.transactional(async () => {
            const snapshot = {};
            for (const ns of await this.adapter.listNamespaces()) {
                snapshot[ns] = await this.adapter.loadDoc(ns);
            }
            const writable = {
                get: (key) => {
                    const parts = this._parseKey(key);
                    const doc = snapshot[parts.namespace];
                    if (parts.subKey === null) return doc === undefined || doc === null ? null : deepClone(doc);
                    return doc && typeof doc === 'object' ? this.getSub(doc, parts.subKey) : null;
                },
                set: (key, value) => {
                    const parts = this._parseKey(key);
                    if (typeof value === 'undefined') throw new Error('Value tidak boleh undefined');
                    if (parts.subKey === null) snapshot[parts.namespace] = value;
                    else {
                        if (!snapshot[parts.namespace] || typeof snapshot[parts.namespace] !== 'object') {
                            snapshot[parts.namespace] = {};
                        }
                        snapshot[parts.namespace][parts.subKey] = value;
                    }
                    return true;
                },
                delete: (key) => {
                    const parts = this._parseKey(key);
                    if (parts.subKey === null) delete snapshot[parts.namespace];
                    else if (snapshot[parts.namespace] && typeof snapshot[parts.namespace] === 'object') {
                        delete snapshot[parts.namespace][parts.subKey];
                    }
                    return true;
                }
            };
            const result = await fn(writable);
            for (const [ns, doc] of Object.entries(snapshot)) {
                if (doc === undefined) continue;
                await this.adapter.saveDoc(ns, doc);
            }
            return result;
        });
    }

    async exportAll() {
        const data = {};
        for (const ns of await this.adapter.listNamespaces()) {
            data[ns] = await this.adapter.loadDoc(ns);
        }
        return data;
    }

    getStats() {
        const base = super.getStats();
        return {
            ...base,
            host: this.mysqlConfig.host,
            database: this.mysqlConfig.database,
            poolMax: this.mysqlConfig.connectionLimit
        };
    }
}

module.exports = MySQLDriver;

const { wrapError, ConnectionError } = require('../errors');
const { assertNamespace, assertKey, assertValue, patternToRegex, deepClone } = require('../utils/validator');
const { DbLogger } = require('../utils/logger');

class BaseDriver {
    constructor(options = {}) {
        this.type = options.type || 'base';
        this.config = options.config || {};
        this.debug = Boolean(options.debug);
        this.logger = (options.logger || new DbLogger({ tag: this.type.toUpperCase(), debug: this.debug })).child({
            tag: this.type.toUpperCase()
        });
        this.connected = false;
        this.connecting = null;
        this.metrics = {
            connects: 0,
            reconnects: 0,
            queries: 0,
            errors: 0,
            lastConnectAt: null,
            lastErrorAt: null,
            lastError: null,
            totalQueryMs: 0
        };
        this.retryConfig = {
            maxRetries: options.maxRetries !== undefined ? options.maxRetries : 3,
            baseDelay: options.baseDelay !== undefined ? options.baseDelay : 200,
            maxDelay: options.maxDelay !== undefined ? options.maxDelay : 5000
        };
    }

    get name() {
        return this.type;
    }

    async connect() {
        if (this.connected) return true;
        if (this.connecting) return this.connecting;
        this.connecting = (async () => {
            try {
                await this._doConnect();
                this.connected = true;
                this.metrics.connects += 1;
                this.metrics.lastConnectAt = Date.now();
                this.logger.debug(`DRIVER ${this.type} CONNECTED`);
                return true;
            } catch (err) {
                const wrapped = wrapError(err, { driver: this.type });
                this.metrics.errors += 1;
                this.metrics.lastErrorAt = Date.now();
                this.metrics.lastError = wrapped.message;
                this.logger.error(`Gagal connect driver ${this.type}: ${wrapped.message}`);
                throw wrapped;
            } finally {
                this.connecting = null;
            }
        })();
        return this.connecting;
    }

    async _doConnect() {
        throw new Error('_doConnect() harus diimplementasikan oleh driver');
    }

    async disconnect() {
        if (!this.connected) return true;
        try {
            await this._doDisconnect();
            this.connected = false;
            this.logger.debug(`DRIVER ${this.type} DISCONNECTED`);
            return true;
        } catch (err) {
            const wrapped = wrapError(err, { driver: this.type });
            this.logger.error(`Gagal disconnect driver ${this.type}: ${wrapped.message}`);
            throw wrapped;
        }
    }

    async _doDisconnect() {}

    async reconnect() {
        this.metrics.reconnects += 1;
        try {
            await this.disconnect();
        } catch {}
        return this.connect();
    }

    _guard() {
        if (!this.connected) {
            throw new ConnectionError(`Driver ${this.type} belum terhubung. Panggil connect() terlebih dahulu.`, {
                driver: this.type
            });
        }
    }

    async _withRetry(operation, context = {}) {
        const { maxRetries, baseDelay, maxDelay } = this.retryConfig;
        let attempt = 0;
        let lastErr = null;
        while (attempt <= maxRetries) {
            try {
                const start = Date.now();
                const result = await operation(attempt);
                this.metrics.queries += 1;
                this.metrics.totalQueryMs += Date.now() - start;
                return result;
            } catch (err) {
                lastErr = err;
                const wrapped = wrapError(err, { driver: this.type, ...context });
                if (!wrapped.retryable || attempt === maxRetries) {
                    this.metrics.errors += 1;
                    this.metrics.lastErrorAt = Date.now();
                    this.metrics.lastError = wrapped.message;
                    throw wrapped;
                }
                attempt += 1;
                const delay = Math.min(baseDelay * 2 ** (attempt - 1), maxDelay);
                this.logger.warn(
                    `Retry ${attempt}/${maxRetries} operasi ${context.operation || ''} dalam ${delay}ms: ${wrapped.message}`
                );
                await this._sleep(delay);
            }
        }
        throw wrapError(lastErr, { driver: this.type, ...context });
    }

    _sleep(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }

    _parseKey(key) {
        assertKey(key);
        const str = String(key);
        if (str.startsWith('jadibot:')) {
            const segments = str.split(':');
            if (segments.length <= 3) {
                return { namespace: assertNamespace(str), subKey: null };
            }
            return {
                namespace: assertNamespace(segments.slice(0, 3).join(':')),
                subKey: segments.slice(3).join(':') || null
            };
        }
        const idx = str.indexOf(':');
        if (idx === -1) {
            return { namespace: assertNamespace(str), subKey: null };
        }
        return {
            namespace: assertNamespace(str.slice(0, idx)),
            subKey: str.slice(idx + 1) || null
        };
    }

    getSub(doc, subKey) {
        if (doc === null || doc === undefined) return null;
        if (Array.isArray(doc)) {
            const item = doc.find((it) => it && (it.id === subKey || it.user_id === subKey));
            return item === undefined ? null : deepClone(item);
        }
        if (typeof doc !== 'object') return null;
        if (!(subKey in doc)) return null;
        return deepClone(doc[subKey]);
    }

    setSub(doc, subKey, value) {
        if (Array.isArray(doc)) {
            const idx = doc.findIndex((it) => it && (it.id === subKey || it.user_id === subKey));
            if (idx === -1) {
                doc.push({ ...(typeof value === 'object' && value !== null ? value : { value }), id: subKey });
            } else {
                doc[idx] =
                    typeof value === 'object' && value !== null && !Array.isArray(value)
                        ? { ...doc[idx], ...value, id: doc[idx].id !== undefined ? doc[idx].id : subKey }
                        : value;
            }
            return doc;
        }
        if (typeof doc !== 'object' || doc === null) doc = {};
        doc[subKey] = value;
        return doc;
    }

    deleteSub(doc, subKey) {
        let changed = false;
        if (Array.isArray(doc)) {
            const idx = doc.findIndex((it) => it && (it.id === subKey || it.user_id === subKey));
            if (idx !== -1) {
                doc.splice(idx, 1);
                changed = true;
            }
            return { doc, changed };
        }
        if (doc && typeof doc === 'object' && subKey in doc) {
            delete doc[subKey];
            changed = true;
        }
        return { doc, changed };
    }

    async get(key) {
        this._guard();
        return this._withRetry(() => this._get(this._parseKey(key)), { operation: 'get', key });
    }

    async _get() {
        throw new Error('_get() harus diimplementasikan oleh driver');
    }

    async set(key, value) {
        this._guard();
        assertValue(value);
        return this._withRetry(() => this._set(this._parseKey(key), value), { operation: 'set', key });
    }

    async _set() {
        throw new Error('_set() harus diimplementasikan oleh driver');
    }

    async delete(key) {
        this._guard();
        return this._withRetry(() => this._delete(this._parseKey(key)), { operation: 'delete', key });
    }

    async _delete() {
        throw new Error('_delete() harus diimplementasikan oleh driver');
    }

    async getAll() {
        this._guard();
        return this._withRetry(() => this._getAll(), { operation: 'getAll' });
    }

    async _getAll() {
        throw new Error('_getAll() harus diimplementasikan oleh driver');
    }

    async clear() {
        this._guard();
        return this._withRetry(() => this._clear(), { operation: 'clear' });
    }

    async _clear() {
        throw new Error('_clear() harus diimplementasikan oleh driver');
    }

    async exists(key) {
        const value = await this.get(key);
        return value !== null && value !== undefined;
    }

    async getKeys(pattern) {
        this._guard();
        const regex = patternToRegex(pattern);
        return this._withRetry(
            async () => {
                const keys = await this._getKeys();
                return regex ? keys.filter((k) => regex.test(k)) : keys;
            },
            { operation: 'getKeys' }
        );
    }

    async _getKeys() {
        throw new Error('_getKeys() harus diimplementasikan oleh driver');
    }

    async getDocument(namespace) {
        assertNamespace(namespace);
        const value = await this.get(namespace);
        return value === null ? null : value;
    }

    async saveDocument(namespace, doc) {
        assertNamespace(namespace);
        await this.set(namespace, doc === undefined ? null : doc);
        return doc;
    }

    async deleteDocument(namespace) {
        assertNamespace(namespace);
        return this.delete(namespace);
    }

    async listNamespaces() {
        const keys = await this.getKeys();
        const set = new Set();
        for (const key of keys) set.add(String(key).split(':')[0]);
        return [...set];
    }

    async transaction(fn) {
        this._guard();
        if (typeof fn !== 'function') {
            throw new Error('transaction() membutuhkan fungsi callback');
        }
        return this._withRetry(() => this._transaction(fn), { operation: 'transaction' });
    }

    async _transaction(fn) {
        const snapshot = await this.getAll();
        const writable = {
            get: (key) => {
                const parts = this._parseKey(key);
                const doc = snapshot[parts.namespace];
                if (parts.subKey === null) return doc === undefined ? null : doc;
                return doc && typeof doc === 'object' && parts.subKey in doc ? doc[parts.subKey] : null;
            },
            set: (key, value) => {
                const parts = this._parseKey(key);
                assertValue(value);
                if (parts.subKey === null) snapshot[parts.namespace] = value;
                else {
                    if (!snapshot[parts.namespace] || typeof snapshot[parts.namespace] !== 'object') {
                        snapshot[parts.namespace] = {};
                    }
                    snapshot[parts.namespace][parts.subKey] = value;
                }
                return true;
            },
            delete: (key) => {
                const parts = this._parseKey(key);
                if (parts.subKey === null) delete snapshot[parts.namespace];
                else if (snapshot[parts.namespace] && typeof snapshot[parts.namespace] === 'object') {
                    delete snapshot[parts.namespace][parts.subKey];
                }
                return true;
            }
        };
        const result = await fn(writable);
        for (const [ns, doc] of Object.entries(snapshot)) {
            await this.saveDocument(ns, doc);
        }
        return result;
    }

    async healthCheck() {
        const start = Date.now();
        try {
            if (!this.connected) {
                return { healthy: false, driver: this.type, latency: 0, error: 'belum terhubung' };
            }
            await this._ping();
            const latency = Date.now() - start;
            return { healthy: true, driver: this.type, latency, error: null };
        } catch (err) {
            const wrapped = wrapError(err, { driver: this.type });
            return { healthy: false, driver: this.type, latency: Date.now() - start, error: wrapped.message };
        }
    }

    async _ping() {
        return true;
    }

    getStats() {
        const avg = this.metrics.queries > 0 ? Math.round(this.metrics.totalQueryMs / this.metrics.queries) : 0;
        return {
            type: this.type,
            connected: this.connected,
            metrics: {
                ...this.metrics,
                avgQueryMs: avg
            }
        };
    }

    async exportAll() {
        const data = {};
        const namespaces = await this.listNamespaces();
        for (const ns of namespaces) {
            data[ns] = await this.getDocument(ns);
        }
        return data;
    }

    async importAll(data, options = {}) {
        const replace = options.replace !== false;
        if (replace) await this.clear();
        let count = 0;
        for (const [ns, doc] of Object.entries(data || {})) {
            if (doc === null || doc === undefined) continue;
            await this.saveDocument(ns, doc);
            count += 1;
        }
        return count;
    }

    async countRecords(namespace) {
        const doc = await this.getDocument(namespace);
        if (doc === null || doc === undefined) return 0;
        if (Array.isArray(doc)) return doc.length;
        if (typeof doc === 'object') return Object.keys(doc).length;
        return 1;
    }
}

module.exports = BaseDriver;

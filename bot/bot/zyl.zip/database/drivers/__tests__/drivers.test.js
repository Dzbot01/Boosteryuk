const path = require('path');
const fs = require('fs');

const BaseDriver = require('../../drivers/base');
const JSONDriver = require('../../drivers/json');
const SQLiteDriver = require('../../drivers/sqlite');
const PostgreSQLDriver = require('../../drivers/postgresql');
const MySQLDriver = require('../../drivers/mysql');

const TMP = path.join('/tmp/x7-jest', `drivers-${Date.now()}`);

function makeJsonDriver(extraConfig = {}) {
    const dir = path.join(TMP, 'json');
    fs.mkdirSync(dir, { recursive: true });
    return new JSONDriver({ config: { path: dir, immediate: true, ...extraConfig } });
}

function makeSqliteDriver() {
    const dir = path.join(TMP, 'sqlite');
    fs.mkdirSync(dir, { recursive: true });
    return new SQLiteDriver({ config: { path: path.join(dir, 'test.db') } });
}

async function exerciseCRUD(driver) {
    await driver.connect();

    await driver.set('user', { 'a@s.whatsapp.net': { limit: 30, money: 0 } });
    await driver.set('user:a@s.whatsapp.net', { limit: 25 });
    const sub = await driver.get('user:a@s.whatsapp.net');
    expect(sub.limit).toBe(25);

    const doc = await driver.get('user');
    expect(Object.keys(doc)).toContain('a@s.whatsapp.net');

    expect(await driver.exists('user:a@s.whatsapp.net')).toBe(true);
    expect(await driver.exists('user:missing@s.whatsapp.net')).toBe(false);

    await driver.set('premium', [{ id: 'p1@s.whatsapp.net', expired: 123456 }]);
    await driver.set('premium:p2@s.whatsapp.net', { expired: 654321 });
    const premium = await driver.get('premium');
    expect(premium.length).toBe(2);
    expect(premium.find((x) => x.id === 'p2@s.whatsapp.net').expired).toBe(654321);

    await driver.delete('premium:p1@s.whatsapp.net');
    expect((await driver.get('premium')).length).toBe(1);

    await driver.set('maintenance', { enabled: true, reason: 'test', duration: 5, updatedAt: 1 });
    expect((await driver.get('maintenance')).enabled).toBe(true);

    await driver.set('generic_ns', { anything: [1, 2, 3] });
    expect(await driver.get('generic_ns')).toEqual({ anything: [1, 2, 3] });

    const all = await driver.getAll();
    expect(Object.keys(all)).toEqual(expect.arrayContaining(['user', 'premium', 'maintenance', 'generic_ns']));

    const keys = await driver.getKeys('user*');
    expect(keys).toEqual(expect.arrayContaining(['user', 'user:a@s.whatsapp.net']));

    const result = await driver.transaction(async (tx) => {
        const user = tx.get('user:a@s.whatsapp.net');
        user.money = 500;
        tx.set('user:a@s.whatsapp.net', user);
        return 'committed';
    });
    expect(result).toBe('committed');
    expect((await driver.get('user:a@s.whatsapp.net')).money).toBe(500);

    const health = await driver.healthCheck();
    expect(health.healthy).toBe(true);

    await driver.delete('user');
    expect(await driver.get('user')).toBeNull();

    await driver.disconnect();
}

describe('BaseDriver', () => {
    test('harus throw saat method abstrak dipanggil', async () => {
        const base = new BaseDriver();
        await expect(base.connect()).rejects.toThrow();
        await expect(base.get('x')).rejects.toThrow();
    });

    test('getSub/setSub/deleteSub menangani object dan array', () => {
        const base = new BaseDriver();
        const obj = { a: 1 };
        expect(base.getSub(obj, 'a')).toBe(1);
        base.setSub(obj, 'b', 2);
        expect(obj.b).toBe(2);
        expect(base.deleteSub(obj, 'b').changed).toBe(true);

        const arr = [{ id: 'x', expired: 1 }];
        expect(base.getSub(arr, 'x').expired).toBe(1);
        base.setSub(arr, 'y', { expired: 2 });
        expect(arr.length).toBe(2);
        expect(base.deleteSub(arr, 'x').changed).toBe(true);
        expect(arr.length).toBe(1);
    });

    test('_parseKey memisahkan namespace jadibot', () => {
        const base = new BaseDriver();
        expect(base._parseKey('user:abc')).toEqual({ namespace: 'user', subKey: 'abc' });
        expect(base._parseKey('jadibot:6281:sewa:gid@g.us')).toEqual({
            namespace: 'jadibot:6281:sewa',
            subKey: 'gid@g.us'
        });
        expect(base._parseKey('jadibot:6281:sewa')).toEqual({ namespace: 'jadibot:6281:sewa', subKey: null });
    });
});

describe('JSONDriver', () => {
    test('CRUD lengkap + transaksi + healthCheck', async () => {
        await exerciseCRUD(makeJsonDriver());
    });

    test('menulis file JSON dengan format asli', async () => {
        const driver = makeJsonDriver();
        await driver.connect();
        await driver.saveDocument('premium', [{ id: 'x@s.whatsapp.net', expired: 1 }]);
        await driver.flushAll();
        const raw = JSON.parse(fs.readFileSync(path.join(TMP, 'json', 'premium.json'), 'utf8'));
        expect(Array.isArray(raw)).toBe(true);
        await driver.disconnect();
    });

    test('namespace jadibot routing ke folder session', async () => {
        const driver = makeJsonDriver();
        await driver.connect();
        await driver.saveDocument('jadibot:628999:sewa', { 'g@g.us': { expired: 1 } });
        await driver.flushAll();
        expect(fs.existsSync(path.join(TMP, 'json', 'jadibot_sessions', '628999', 'sewa.json'))).toBe(true);
        await driver.disconnect();
    });

    test('data korup pada file menghasilkan null, bukan crash', async () => {
        const dir = path.join(TMP, 'corrupt');
        fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(path.join(dir, 'broken.json'), '{ini bukan json');
        const driver = new JSONDriver({ config: { path: dir } });
        await driver.connect();
        expect(await driver.getDocument('broken')).toBeNull();
        await driver.disconnect();
    });
});

describe('SQLiteDriver', () => {
    let available = true;
    beforeAll(() => {
        try {
            require('better-sqlite3');
        } catch {
            available = false;
        }
    });

    beforeEach(() => {
        if (!available) return;
        const dir = path.join(TMP, 'sqlite-test');
        fs.mkdirSync(dir, { recursive: true });
    });

    test('CRUD lengkap + skema normal + transaksi', async () => {
        if (!available) return;
        const dir = path.join(TMP, 'sqlite-test', `t${Date.now()}`);
        fs.mkdirSync(dir, { recursive: true });
        await exerciseCRUD(new SQLiteDriver({ config: { path: path.join(dir, 'test.db') } }));
    });

    test('tabel normal users dan chat_stats terisi', async () => {
        if (!available) return;
        const dir = path.join(TMP, 'sqlite-test', `n${Date.now()}`);
        fs.mkdirSync(dir, { recursive: true });
        const driver = new SQLiteDriver({ config: { path: path.join(dir, 'test.db') } });
        await driver.connect();

        await driver.set('user', {
            'u1@s.whatsapp.net': { limit: 30, money: 100, role: 'vip', level_user: 2 },
            'u2@s.whatsapp.net': { limit: 10, money: 5 }
        });

        const stats = driver.getStats();
        expect(stats.tables.users).toBe(2);

        await driver.set('userDB', {
            groups: { 'g@g.us': { users: { 'u1@s.whatsapp.net': { totalChat: 9, lastChat: 1 } } } }
        });
        expect(stats.tables.chat_stats).toBe(0);
        expect(driver.getStats().tables.chat_stats).toBe(1);

        const doc = await driver.getDocument('user');
        expect(doc['u1@s.whatsapp.net'].role).toBe('vip');
        expect(doc['u1@s.whatsapp.net'].limit).toBe(30);

        await driver.disconnect();
    });

    test('scoped premium jadibot terisolasi', async () => {
        if (!available) return;
        const dir = path.join(TMP, 'sqlite-test', `s${Date.now()}`);
        fs.mkdirSync(dir, { recursive: true });
        const driver = new SQLiteDriver({ config: { path: path.join(dir, 'test.db') } });
        await driver.connect();

        await driver.set('premium', [{ id: 'main@s.whatsapp.net', expired: 1 }]);
        await driver.set('jadibot:628888:premium', [{ id: 'bot@s.whatsapp.net', expired: 2 }]);

        expect((await driver.get('premium')).map((x) => x.id)).toEqual(['main@s.whatsapp.net']);
        expect((await driver.get('jadibot:628888:premium')).map((x) => x.id)).toEqual(['bot@s.whatsapp.net']);

        await driver.disconnect();
    });

    test('pg/mysql gracefully dilewati jika server tidak tersedia', async () => {
        for (const [Cls, config] of [
            [PostgreSQLDriver, { host: '127.0.0.1', port: 5432, database: 'x7_test', user: 'postgres', password: 'x' }],
            [
                MySQLDriver,
                {
                    host: '127.0.0.1',
                    port: 3306,
                    database: 'x7_test',
                    user: 'root',
                    password: 'x',
                    connectTimeout: 2000
                }
            ]
        ]) {
            const driver = new Cls({ config });
            const health = { connected: false };
            try {
                await driver.connect();
                health.connected = driver.connected;
            } catch (err) {
                health.connected = false;
            }
            if (health.connected) {
                await driver.disconnect();
            }
            expect(health.connected === true || health.connected === false).toBe(true);
        }
    });
});

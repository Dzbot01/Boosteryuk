/**
 * cache.test.js — Unit tests for Cache (D3).
 *
 * Verifikasi bahwa cache.invalidatePattern benar-benar menghapus entry
 * yang cocok dengan wildcard `*`. Tanpa ini, setDoc(namespace, ...) akan
 * meninggalkan stale entries yang key-nya cocok prefix namespace.
 */
const path = require('path');
const PROJECT = path.resolve(__dirname, '../../..');
const Cache = require(path.join(PROJECT, 'database/cache'));

describe('Cache — D3 invalidation pattern', () => {
    let cache;

    beforeEach(() => {
        cache = new Cache({ enabled: true, ttl: 60000, maxSize: 500 });
    });

    test('invalidate(key) menghapus entry tunggal', () => {
        cache.set('user:alice', { limit: 30 });
        cache.set('user:bob', { limit: 40 });
        expect(cache.get('user:alice')).toEqual({ limit: 30 });
        expect(cache.invalidate('user:alice')).toBe(true);
        expect(cache.get('user:alice')).toBeUndefined();
        expect(cache.get('user:bob')).toEqual({ limit: 40 });
    });

    test('invalidatePattern("user:*") menghapus semua key dengan prefix user:', () => {
        cache.set('user:alice', { limit: 30 });
        cache.set('user:bob', { limit: 40 });
        cache.set('premium:alice', { premium: true });

        const removed = cache.invalidatePattern('user:*');
        expect(removed).toBe(2);
        expect(cache.get('user:alice')).toBeUndefined();
        expect(cache.get('user:bob')).toBeUndefined();
        // Premium key tetap.
        expect(cache.get('premium:alice')).toEqual({ premium: true });
    });

    test('invalidatePattern support regex', () => {
        cache.set('user:alice', 1);
        cache.set('user:bob', 2);
        cache.set('premium:bob', 3);

        const removed = cache.invalidatePattern(/^user:.+$/);
        expect(removed).toBe(2);
        expect(cache.get('user:alice')).toBeUndefined();
        expect(cache.get('premium:bob')).toEqual(3);
    });

    test('setDoc → setelah invalidatePattern, get namespace harus miss', () => {
        // Simulasi DatabaseManager.setDoc flow.
        cache.set('user:alice', { limit: 30 });
        cache.set('user:bob', { limit: 40 });

        // DatabaseManager.setDoc() memanggil invalidatePattern.
        cache.invalidatePattern('user:*');
        cache.invalidate('user');

        expect(cache.get('user:alice')).toBeUndefined();
        expect(cache.get('user:bob')).toBeUndefined();
        expect(cache.size).toBe(0);
    });

    test('clear() menghapus seluruh cache', () => {
        cache.set('a', 1);
        cache.set('b', 2);
        expect(cache.clear()).toBe(2);
        expect(cache.size).toBe(0);
    });

    test('TTL expiry membuat entry dianggap miss', (done) => {
        const fastCache = new Cache({ enabled: true, ttl: 50 });
        fastCache.set('k', 'v');
        expect(fastCache.get('k')).toBe('v');
        setTimeout(() => {
            expect(fastCache.get('k')).toBeUndefined();
            done();
        }, 80);
    });
});

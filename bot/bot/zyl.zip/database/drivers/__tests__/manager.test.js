const path = require('path');
const fs = require('fs');

const PROJECT = path.resolve(__dirname, '../../..');
const TMP = path.join('/tmp/x7-jest', `manager-${Date.now()}`);

describe('DatabaseManager', () => {
    let manager;

    beforeAll(() => {
        fs.mkdirSync(TMP, { recursive: true });
        jest.resetModules();
        manager = require(path.join(PROJECT, 'database/index'));
        manager.config.type = 'json';
        manager.config.json = { path: path.join(TMP, 'Storage') };
        manager.config.sqlite = { path: path.join(TMP, 'bot.db') };
        manager.config.debug = false;
    });

    test('singleton pattern', () => {
        const { getInstance } = require(path.join(PROJECT, 'database/index'));
        expect(getInstance()).toBe(manager);
    });

    test('connect, sync API, flush ke file', async () => {
        await manager.connect();
        expect(manager.type).toBe('json');
        expect(manager.getDriver()).not.toBeNull();
        expect(manager.getDriver().connected).toBe(true);

        manager.setDoc('user', { 'u@s.whatsapp.net': { limit: 30 } });
        manager.setSub('user', 'v@s.whatsapp.net', { limit: 10 });
        expect(manager.getSub('user', 'u@s.whatsapp.net').limit).toBe(30);

        await manager.flushAll();
        const raw = JSON.parse(fs.readFileSync(path.join(TMP, 'Storage', 'user.json'), 'utf8'));
        expect(raw['v@s.whatsapp.net'].limit).toBe(10);
    });

    test('switchType ke sqlite mempertahankan seluruh data', async () => {
        manager.setSub('user', 'w@s.whatsapp.net', { limit: 77 });
        await manager.flushAll();

        await manager.switchType('sqlite');
        expect(manager.type).toBe('sqlite');
        expect(manager.getSub('user', 'u@s.whatsapp.net').limit).toBe(30);
        expect(manager.getSub('user', 'w@s.whatsapp.net').limit).toBe(77);

        const count = await manager.getDriver().countRecords('user');
        expect(count).toBe(3);
    });

    test('switchType kembali ke json', async () => {
        await manager.switchType('json');
        expect(manager.type).toBe('json');
        expect(manager.getSub('user', 'w@s.whatsapp.net').limit).toBe(77);
        const raw = JSON.parse(fs.readFileSync(path.join(TMP, 'Storage', 'user.json'), 'utf8'));
        expect(raw['w@s.whatsapp.net'].limit).toBe(77);
    });

    test('healthCheck dan getStats', async () => {
        const health = await manager.healthCheck();
        expect(health.manager.healthy).toBe(true);
        expect(health.driver.healthy).toBe(true);
        expect(health.store.namespaces).toBeGreaterThan(0);

        const stats = manager.getStats();
        expect(stats.type).toBe('json');
        expect(stats.uptimeMs).toBeGreaterThanOrEqual(0);
    });

    test('transaction manager-level', async () => {
        await manager.transaction(async (tx) => {
            const user = tx.get('user:u@s.whatsapp.net');
            user.money = 999;
            tx.set('user:u@s.whatsapp.net', user);
        });
        expect(manager.getSub('user', 'u@s.whatsapp.net').money).toBe(999);
        await manager.flushAll();
    });

    test('deleteDoc dan deleteSub', async () => {
        expect(manager.deleteSub('user', 'v@s.whatsapp.net')).toBe(true);
        expect(manager.getSub('user', 'v@s.whatsapp.net')).toBeNull();
        manager.setDoc('temp_ns', { a: 1 });
        expect(manager.deleteDoc('temp_ns')).toBe(true);
        expect(manager.getDoc('temp_ns')).toBeNull();
    });

    test('fallbackToJson saat driver gagal', async () => {
        manager.config.type = 'postgresql';
        manager.config.postgresql = {
            host: '127.0.0.1',
            port: 5499,
            database: 'nope',
            user: 'nope',
            password: 'nope',
            acquireTimeoutMillis: 800
        };
        manager.config.fallbackToJson = true;
        manager.bootPromise = null;
        manager.driver = null;
        manager.driverType = null;

        const driver = await manager.connect();
        expect(driver.type).toBe('json');
        expect(manager.degraded).toBe(true);

        manager.config.type = 'json';
        manager.config.fallbackToJson = true;
    });

    afterAll(async () => {
        if (manager && manager.driver) {
            await manager.disconnect().catch(() => {});
        }
    });
});

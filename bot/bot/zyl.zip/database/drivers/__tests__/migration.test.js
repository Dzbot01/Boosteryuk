const path = require('path');
const fs = require('fs');

const PROJECT = path.resolve(__dirname, '../../..');
const TMP = path.join('/tmp/x7-jest', `migration-${Date.now()}`);

const { MigrationEngine, createDriver } = require(path.join(PROJECT, 'database/utils/migration'));
const { createBackup, restoreBackup, listBackups } = require(path.join(PROJECT, 'database/utils/backup'));

function seedJsonStorage(dir) {
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(
        path.join(dir, 'user.json'),
        JSON.stringify(
            {
                'u1@s.whatsapp.net': {
                    limit: 30,
                    money: 100,
                    role: '-',
                    level_user: 1,
                    level_cache: 0,
                    lastReset: 1,
                    lastClaimLimit: 0
                },
                'u2@s.whatsapp.net': {
                    limit: 10,
                    money: 5,
                    role: 'vip',
                    level_user: 3,
                    level_cache: 12,
                    lastReset: 1,
                    lastClaimLimit: 2
                }
            },
            null,
            2
        )
    );
    fs.writeFileSync(
        path.join(dir, 'premium.json'),
        JSON.stringify(
            [
                { id: 'p1@s.whatsapp.net', expired: 9999999999999 },
                { id: 'p2@s.whatsapp.net', expired: 1234 }
            ],
            null,
            2
        )
    );
    fs.writeFileSync(
        path.join(dir, 'sewa.json'),
        JSON.stringify(
            {
                'gc@g.us': { namegrup: 'Grup', start: '2026-01-01T00:00:00.000Z', expired: 9999999999999 }
            },
            null,
            2
        )
    );
    fs.writeFileSync(path.join(dir, 'redeem.json'), JSON.stringify({ CODE1: { type: 'premium' } }, null, 2));
    fs.mkdirSync(path.join(dir, 'jadibot_sessions', '628111'), { recursive: true });
    fs.writeFileSync(
        path.join(dir, 'jadibot_sessions', '628111', 'sewa.json'),
        JSON.stringify(
            {
                'gj@g.us': { namegrup: 'Jadibot Group', start: '2026-01-01T00:00:00.000Z', expired: 8888888888888 }
            },
            null,
            2
        )
    );
}

describe('MigrationEngine', () => {
    let engine;
    let jsonPath;
    let sqlitePath;

    beforeAll(() => {
        fs.mkdirSync(TMP, { recursive: true });
        engine = new MigrationEngine({
            logger: { info: () => {}, success: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
        });
        jsonPath = path.join(TMP, 'Storage');
        sqlitePath = path.join(TMP, 'bot.db');
        seedJsonStorage(jsonPath);
    });

    test('json -> sqlite memindahkan semua namespace termasuk scoped jadibot', async () => {
        const result = await engine.migrate('json', 'sqlite', {
            sourceOverrides: { path: jsonPath },
            targetOverrides: { path: sqlitePath }
        });

        expect(result.migrated).toBeGreaterThanOrEqual(5);
        expect(result.report.passed).toBe(result.report.total);
        expect(fs.existsSync(sqlitePath)).toBe(true);
    });

    test('validasi sqlite vs json identik', async () => {
        const report = await engine.validate('json', 'sqlite', { path: jsonPath }, { path: sqlitePath });
        expect(report.failed).toEqual([]);
        expect(report.passed).toBe(report.total);
    });

    test('sqlite -> json roundtrip mempertahankan data', async () => {
        const outPath = path.join(TMP, 'Storage-out');
        const result = await engine.migrate('sqlite', 'json', {
            sourceOverrides: { path: sqlitePath },
            targetOverrides: { path: outPath },
            strict: false
        });
        expect(result.migrated).toBeGreaterThanOrEqual(5);

        const user = JSON.parse(fs.readFileSync(path.join(outPath, 'user.json'), 'utf8'));
        expect(user['u1@s.whatsapp.net'].money).toBe(100);
        expect(user['u1@s.whatsapp.net'].limit).toBe(30);

        const premium = JSON.parse(fs.readFileSync(path.join(outPath, 'premium.json'), 'utf8'));
        expect(premium.map((p) => p.id).sort()).toEqual(['p1@s.whatsapp.net', 'p2@s.whatsapp.net']);

        const sewa = JSON.parse(fs.readFileSync(path.join(outPath, 'sewa.json'), 'utf8'));
        expect(sewa['gc@g.us'].namegrup).toBe('Grup');

        const scoped = JSON.parse(
            fs.readFileSync(path.join(outPath, 'jadibot_sessions', '628111', 'sewa.json'), 'utf8')
        );
        expect(scoped['gj@g.us'].namegrup).toBe('Jadibot Group');

        const redeem = JSON.parse(fs.readFileSync(path.join(outPath, 'redeem.json'), 'utf8'));
        expect(redeem['CODE1'].type).toBe('premium');
    });

    test('source === target ditolak', async () => {
        await expect(engine.migrate('json', 'json')).rejects.toThrow();
    });

    test('backup dan restore sqlite', async () => {
        const backupDir = path.join(TMP, 'backups');
        const backup = await createBackup('sqlite', {
            overrides: { path: sqlitePath },
            backupDir
        });
        expect(backup.namespaces).toBeGreaterThanOrEqual(5);
        expect(fs.existsSync(backup.path)).toBe(true);
        expect(listBackups(backupDir).length).toBe(1);

        const emptyTarget = path.join(TMP, 'restore-target.db');
        const restore = await restoreBackup(backup.path, 'sqlite', { overrides: { path: emptyTarget } });
        expect(restore.restored).toBeGreaterThanOrEqual(5);
    });

    test('tipe tidak dikenal ditolak', async () => {
        expect(() => createDriver('oracle')).toThrow();
    });
});

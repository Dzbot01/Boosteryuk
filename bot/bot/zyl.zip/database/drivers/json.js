const fs = require('fs');
const path = require('path');
const BaseDriver = require('./base');
const registry = require('../registry');
const { safeParse, patternToRegex, deepClone } = require('../utils/validator');
const { QueryError, ValidationError } = require('../errors');

class JSONDriver extends BaseDriver {
    constructor(options = {}) {
        super({ ...options, type: 'json' });
        const cfg = options.config || {};
        this.basePath = path.resolve(cfg.path || './Storage');
        this.debounceMs = cfg.debounceMs !== undefined ? cfg.debounceMs : 300;
        this.pretty = cfg.pretty !== false;
        this.readCache = new Map();
        this.cacheTtl = cfg.cacheTtl !== undefined ? cfg.cacheTtl : 1000;
        this.pendingWrites = new Map();
        this.writeTimers = new Map();
        this.flushing = new Set();
        if (cfg.immediate !== undefined) this.immediate = Boolean(cfg.immediate);
        else this.immediate = false;
    }

    async _doDisconnect() {
        await this.flushAll();
        return true;
    }

    async _doConnect() {
        try {
            fs.mkdirSync(this.basePath, { recursive: true });
        } catch (err) {
            throw new QueryError(`Tidak dapat membuat direktori Storage: ${err.message}`, {
                driver: 'json',
                cause: err
            });
        }
        this._scanExisting();
    }

    _scanExisting() {
        let entries = [];
        try {
            entries = fs.readdirSync(this.basePath);
        } catch {
            return;
        }
        for (const entry of entries) {
            if (!entry.endsWith('.json')) continue;
            const full = path.join(this.basePath, entry);
            try {
                const stat = fs.statSync(full);
                if (!stat.isFile()) continue;
                const rel = path.relative(this.basePath, full);
                const parts = rel.split(path.sep);
                if (parts[0] === 'jadibot_sessions' && parts.length >= 3) {
                    continue;
                }
            } catch {}
        }
    }

    _fileFor(namespace) {
        try {
            const globalPath = registry.fileForNamespace(namespace);
            const rel = path.relative(registry.STORAGE_DIR, globalPath);
            if (rel && !rel.startsWith('..') && !path.isAbsolute(rel)) {
                return path.join(this.basePath, rel);
            }
        } catch {}
        return path.join(this.basePath, `${namespace.replace(/[^\w:-]/g, '_')}.json`);
    }

    _ensureDir(filePath) {
        const dir = path.dirname(filePath);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    }

    _readFile(filePath) {
        let cached = this.readCache.get(filePath);
        try {
            const stat = fs.statSync(filePath);
            if (cached && cached.mtime === stat.mtimeMs && stat.mtimeMs + this.cacheTtl > Date.now()) {
                return cached.data;
            }
            const raw = fs.readFileSync(filePath, 'utf-8');
            const data = safeParse(raw, null);
            this.readCache.set(filePath, { data, mtime: stat.mtimeMs, cachedAt: Date.now() });
            return data;
        } catch (err) {
            if (err.code === 'ENOENT') return null;
            if (cached) return cached.data;
            return null;
        }
    }

    _writeFileAtomic(filePath, data) {
        this._ensureDir(filePath);
        const json = this.pretty ? JSON.stringify(data, null, 2) : JSON.stringify(data);
        const tmp = `${filePath}.${process.pid}.tmp`;
        fs.writeFileSync(tmp, json, 'utf-8');
        fs.renameSync(tmp, filePath);
        try {
            const stat = fs.statSync(filePath);
            this.readCache.set(filePath, { data, mtime: stat.mtimeMs, cachedAt: Date.now() });
        } catch {}
    }

    _scheduleWrite(namespace, doc) {
        const filePath = this._fileFor(namespace);
        this.pendingWrites.set(namespace, { filePath, doc });
        if (this.immediate) {
            this._flushNamespace(namespace).catch(() => {});
            return;
        }
        if (this.writeTimers.has(namespace)) clearTimeout(this.writeTimers.get(namespace));
        const timer = setTimeout(() => {
            this.writeTimers.delete(namespace);
            this._flushNamespace(namespace).catch(() => {});
        }, this.debounceMs);
        timer.unref?.();
        this.writeTimers.set(namespace, timer);
    }

    async _flushNamespace(namespace) {
        if (this.flushing.has(namespace)) return;
        const pending = this.pendingWrites.get(namespace);
        if (!pending) return;
        this.flushing.add(namespace);
        try {
            this._writeFileAtomic(pending.filePath, pending.doc);
            this.pendingWrites.delete(namespace);
        } finally {
            this.flushing.delete(namespace);
        }
    }

    async flushAll() {
        for (const timer of this.writeTimers.values()) clearTimeout(timer);
        this.writeTimers.clear();
        const namespaces = [...this.pendingWrites.keys()];
        for (const ns of namespaces) {
            await this._flushNamespace(ns);
        }
        return namespaces.length;
    }

    async _get({ namespace, subKey }) {
        const doc = await this.getDocument(namespace);
        if (doc === null || doc === undefined) return null;
        if (subKey === null) return deepClone(doc);
        return this.getSub(doc, subKey);
    }

    async _set({ namespace, subKey }, value) {
        let doc = await this.getDocument(namespace);
        if (doc === null || doc === undefined) {
            doc = this._defaultFor(namespace);
        }
        if (subKey === null) {
            doc = value;
        } else {
            doc = this.setSub(deepClone(doc), subKey, value);
        }
        await this.saveDocument(namespace, doc);
        return true;
    }

    _defaultFor(namespace) {
        const meta = registry.resolveNamespace(namespace);
        if (meta.generic && meta.dynamic) return {};
        if (meta.name.startsWith('jadibot:')) {
            const sub = meta.name.split(':')[2] || 'sewa';
            const base = registry.DATASETS[sub];
            return base ? deepClone(base.defaults) : {};
        }
        return deepClone(meta.defaults || {});
    }

    async _delete({ namespace, subKey }) {
        const doc = await this.getDocument(namespace);
        if (doc === null) return false;
        let changed = false;
        if (subKey === null) {
            const filePath = this._fileFor(namespace);
            try {
                fs.rmSync(filePath, { force: true });
                this.readCache.delete(filePath);
                changed = true;
            } catch {}
        } else {
            const result = this.deleteSub(deepClone(doc), subKey);
            if (result.changed) {
                await this.saveDocument(namespace, result.doc);
                changed = true;
            }
        }
        return changed;
    }

    async _getAll() {
        const result = {};
        const namespaces = await this._getNamespacesFromDisk();
        for (const ns of namespaces) {
            const doc = await this.getDocument(ns);
            if (doc !== null) result[ns] = deepClone(doc);
        }
        for (const ns of this.pendingWrites.keys()) {
            if (!(ns in result)) {
                const pending = this.pendingWrites.get(ns);
                result[ns] = deepClone(pending.doc);
            }
        }
        return result;
    }

    async _getNamespacesFromDisk() {
        const namespaces = new Set();
        const walk = (dir, prefix) => {
            let entries = [];
            try {
                entries = fs.readdirSync(dir, { withFileTypes: true });
            } catch {
                return;
            }
            for (const entry of entries) {
                const full = path.join(dir, entry.name);
                if (entry.isDirectory()) {
                    if (entry.name === 'jadibot_sessions') {
                        let sessions = [];
                        try {
                            sessions = fs.readdirSync(full, { withFileTypes: true });
                        } catch {}
                        for (const s of sessions) {
                            if (!s.isDirectory()) continue;
                            let files = [];
                            try {
                                files = fs.readdirSync(path.join(full, s.name));
                            } catch {}
                            for (const f of files) {
                                if (!f.endsWith('.json')) continue;
                                const sub = f.replace(/\.json$/, '');
                                namespaces.add(`jadibot:${s.name}:${sub}`);
                            }
                        }
                        continue;
                    }
                    walk(full, `${prefix}${entry.name}:`);
                    continue;
                }
                if (!entry.name.endsWith('.json')) continue;
                const rel = prefix + entry.name.replace(/\.json$/, '');
                namespaces.add(rel.replace(/\//g, ':'));
            }
        };
        walk(this.basePath, '');
        return [...namespaces];
    }

    async _getKeys() {
        const keys = [];
        const namespaces = await this._getNamespacesFromDisk();
        for (const ns of namespaces) {
            keys.push(ns);
            const doc = await this.getDocument(ns);
            if (doc && typeof doc === 'object' && !Array.isArray(doc)) {
                for (const sub of Object.keys(doc)) keys.push(`${ns}:${sub}`);
            }
        }
        return keys;
    }

    async _clear() {
        await this.flushAll();
        let removed = 0;
        const walk = (dir) => {
            let entries = [];
            try {
                entries = fs.readdirSync(dir, { withFileTypes: true });
            } catch {
                return;
            }
            for (const entry of entries) {
                const full = path.join(dir, entry.name);
                if (entry.isDirectory()) {
                    if (entry.name === 'jadibot_sessions') continue;
                    walk(full);
                    continue;
                }
                if (!entry.name.endsWith('.json') || entry.name.endsWith('.bak')) continue;
                try {
                    fs.rmSync(full, { force: true });
                    this.readCache.delete(full);
                    removed += 1;
                } catch {}
            }
        };
        walk(this.basePath);
        this.pendingWrites.clear();
        for (const t of this.writeTimers.values()) clearTimeout(t);
        this.writeTimers.clear();
        return removed;
    }

    async _transaction(fn) {
        const snapshot = {};
        const namespaces = await this._getNamespacesFromDisk();
        for (const ns of namespaces) {
            snapshot[ns] = await this.getDocument(ns);
        }
        const writable = {
            get: (key) => {
                const parts = this._parseKey(key);
                const doc = snapshot[parts.namespace];
                if (parts.subKey === null) return doc === undefined || doc === null ? null : deepClone(doc);
                return doc && typeof doc === 'object' && parts.subKey in doc ? deepClone(doc[parts.subKey]) : null;
            },
            set: (key, value) => {
                const parts = this._parseKey(key);
                if (typeof value === 'undefined') {
                    throw new ValidationError('Value tidak boleh undefined', { field: 'value' });
                }
                if (parts.subKey === null) snapshot[parts.namespace] = value;
                else {
                    if (!snapshot[parts.namespace] || typeof snapshot[parts.namespace] !== 'object') {
                        snapshot[parts.namespace] = {};
                    }
                    snapshot[parts.namespace][parts.subKey] = value;
                }
                return true;
            },
            delete: (key) => {
                const parts = this._parseKey(key);
                if (parts.subKey === null) delete snapshot[parts.namespace];
                else if (snapshot[parts.namespace] && typeof snapshot[parts.namespace] === 'object') {
                    delete snapshot[parts.namespace][parts.subKey];
                }
                return true;
            }
        };
        const result = await fn(writable);
        for (const [ns, doc] of Object.entries(snapshot)) {
            if (doc === undefined) continue;
            await this.saveDocument(ns, doc);
        }
        return result;
    }

    async saveDocument(namespace, doc, options = {}) {
        const value = doc === undefined ? null : doc;
        if (options.immediate) {
            if (this.writeTimers.has(namespace)) {
                clearTimeout(this.writeTimers.get(namespace));
                this.writeTimers.delete(namespace);
            }
            const filePath = this._fileFor(namespace);
            this._writeFileAtomic(filePath, value);
            this.pendingWrites.delete(namespace);
            return value;
        }
        this._scheduleWrite(namespace, value);
        return value;
    }

    async getDocument(namespace) {
        const filePath = this._fileFor(namespace);
        return this._readFile(filePath);
    }

    async listNamespaces() {
        return this._getNamespacesFromDisk();
    }

    async _ping() {
        try {
            fs.accessSync(this.basePath, fs.constants.W_OK);
            return true;
        } catch (err) {
            throw new QueryError(`Direktori Storage tidak dapat ditulis: ${err.message}`, {
                driver: 'json',
                cause: err
            });
        }
    }

    getStats() {
        const base = super.getStats();
        return {
            ...base,
            path: this.basePath,
            pendingWrites: this.pendingWrites.size,
            cachedFiles: this.readCache.size
        };
    }
}

module.exports = JSONDriver;

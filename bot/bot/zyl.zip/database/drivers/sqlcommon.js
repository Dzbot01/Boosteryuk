const registry = require('../registry');
const { safeParse, deepClone } = require('../utils/validator');
const { QueryError, ConnectionError } = require('../errors');

const SCHEMA_VERSION = 1;

function q(dialect, ident) {
    if (dialect === 'postgresql') return `"${ident}"`;
    if (dialect === 'mysql') return `\`${ident}\``;
    return `"${ident}"`;
}

function colType(dialect, kind) {
    const isMysql = dialect === 'mysql';
    switch (kind) {
        case 'pk_auto':
            return isMysql ? 'INT AUTO_INCREMENT PRIMARY KEY' : 'SERIAL PRIMARY KEY';
        case 'text_pk':
            return isMysql ? 'VARCHAR(191) PRIMARY KEY' : 'TEXT PRIMARY KEY';
        case 'text':
            return isMysql ? 'TEXT' : 'TEXT';
        case 'longtext':
            return isMysql ? 'LONGTEXT' : 'TEXT';
        case 'varchar_pk':
            return isMysql ? 'VARCHAR(191)' : 'TEXT';
        case 'int':
            return isMysql ? 'BIGINT' : 'BIGINT';
        case 'bool':
            return 'SMALLINT DEFAULT 0';
        default:
            return isMysql ? 'TEXT' : 'TEXT';
    }
}

function buildTables(dialect) {
    const T = (k) => colType(dialect, k);
    const mysqlOpts = dialect === 'mysql' ? ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci' : '';
    const wrap = (sql) => (dialect === 'mysql' ? sql + mysqlOpts : sql);

    return {
        users: wrap(`CREATE TABLE IF NOT EXISTS users (
      jid ${T('text_pk')},
      ${q(dialect, 'limit')} ${T('int')} DEFAULT 30,
      money ${T('int')} DEFAULT 0,
      role ${T('varchar_pk')} DEFAULT '-',
      level_user ${T('int')} DEFAULT 1,
      level_cache ${T('int')} DEFAULT 0,
      last_reset ${T('int')},
      last_claim_limit ${T('int')},
      extra ${T('longtext')},
      created_at ${T('int')},
      updated_at ${T('int')}
    )`),
        chat_stats: wrap(`CREATE TABLE IF NOT EXISTS chat_stats (
      id ${T('pk_auto')},
      group_id ${T('varchar_pk')} NOT NULL,
      user_id ${T('varchar_pk')} NOT NULL,
      total_chat ${T('int')} DEFAULT 0,
      last_chat ${T('int')},
      created_at ${T('int')},
      updated_at ${T('int')},
      UNIQUE(group_id, user_id)
    )`),
        premium_users: wrap(`CREATE TABLE IF NOT EXISTS premium_users (
      id ${T('pk_auto')},
      scope ${T('varchar_pk')} NOT NULL DEFAULT 'main',
      user_id ${T('varchar_pk')} NOT NULL,
      expired ${T('int')} NOT NULL,
      created_at ${T('int')},
      updated_at ${T('int')},
      UNIQUE(scope, user_id)
    )`),
        bot_sewa: wrap(`CREATE TABLE IF NOT EXISTS bot_sewa (
      id ${T('pk_auto')},
      scope ${T('varchar_pk')} NOT NULL DEFAULT 'main',
      group_id ${T('varchar_pk')} NOT NULL,
      group_name ${T('text')},
      start ${T('text')},
      expired ${T('int')},
      created_at ${T('int')},
      updated_at ${T('int')},
      UNIQUE(scope, group_id)
    )`),
        banned_users: wrap(`CREATE TABLE IF NOT EXISTS banned_users (
      user_id ${T('text_pk')},
      reason ${T('text')},
      banned_at ${T('text')},
      expired_at ${T('text')},
      permanent SMALLINT DEFAULT 0,
      created_at ${T('int')}
    )`),
        maintenance_mode: wrap(`CREATE TABLE IF NOT EXISTS maintenance_mode (
      id INT PRIMARY KEY,
      enabled SMALLINT DEFAULT 0,
      reason ${T('text')},
      start_at ${T('int')},
      end_at ${T('int')},
      duration ${T('int')} DEFAULT 0,
      updated_at ${T('int')}
    )`),
        payment_transactions: wrap(`CREATE TABLE IF NOT EXISTS payment_transactions (
      id ${T('pk_auto')},
      order_id ${T('varchar_pk')} NOT NULL UNIQUE,
      user_id ${T('text')},
      amount ${T('int')} DEFAULT 0,
      status ${T('varchar_pk')} DEFAULT 'pending',
      data ${T('longtext')},
      created_at ${T('int')},
      updated_at ${T('int')}
    )`),
        game_sessions: wrap(`CREATE TABLE IF NOT EXISTS game_sessions (
      id ${T('pk_auto')},
      game_type ${T('varchar_pk')},
      group_id ${T('text')},
      user_id ${T('text')},
      state ${T('longtext')},
      created_at ${T('int')},
      updated_at ${T('int')}
    )`),
        bot_settings: wrap(`CREATE TABLE IF NOT EXISTS bot_settings (
      namespace ${T('varchar_pk')} NOT NULL,
      key ${T('varchar_pk')} NOT NULL,
      value ${T('longtext')},
      created_at ${T('int')},
      updated_at ${T('int')},
      PRIMARY KEY (namespace, key)
    )`),
        afk_status: wrap(`CREATE TABLE IF NOT EXISTS afk_status (
      id ${T('pk_auto')},
      group_id ${T('varchar_pk')},
      user_id ${T('varchar_pk')},
      reason ${T('text')},
      started_at ${T('int')},
      mentioned ${T('int')} DEFAULT 0,
      created_at ${T('int')},
      updated_at ${T('int')},
      UNIQUE(group_id, user_id)
    )`),
        pterodactyl_users: wrap(`CREATE TABLE IF NOT EXISTS pterodactyl_users (
      user_id ${T('text_pk')},
      api_key ${T('text')},
      data ${T('longtext')},
      created_at ${T('int')}
    )`),
        pterodactyl_servers: wrap(`CREATE TABLE IF NOT EXISTS pterodactyl_servers (
      server_id ${T('text_pk')},
      user_id ${T('text')},
      server_name ${T('text')},
      data ${T('longtext')},
      created_at ${T('int')}
    )`),
        generic_data: wrap(`CREATE TABLE IF NOT EXISTS generic_data (
      id ${T('pk_auto')},
      namespace ${T('varchar_pk')} NOT NULL,
      key ${T('varchar_pk')} NOT NULL DEFAULT '__doc__',
      value ${T('longtext')},
      created_at ${T('int')},
      updated_at ${T('int')},
      UNIQUE(namespace, key)
    )`),
        db_meta: wrap(`CREATE TABLE IF NOT EXISTS db_meta (
      key ${T('varchar_pk')} PRIMARY KEY,
      value ${T('text')}
    )`)
    };
}

function buildIndexes(dialect) {
    const idx = (name, table, cols) =>
        dialect === 'mysql'
            ? `CREATE INDEX ${name} ON ${table} (${cols.join(', ')})`
            : `CREATE INDEX IF NOT EXISTS ${name} ON ${table} (${cols.join(', ')})`;
    return [
        idx('idx_chat_stats_group', 'chat_stats', ['group_id']),
        idx('idx_chat_stats_user', 'chat_stats', ['user_id']),
        idx('idx_premium_user', 'premium_users', ['user_id']),
        idx('idx_premium_scope', 'premium_users', ['scope']),
        idx('idx_sewa_scope', 'bot_sewa', ['scope']),
        idx('idx_settings_namespace', 'bot_settings', ['namespace']),
        idx('idx_generic_namespace', 'generic_data', ['namespace']),
        idx('idx_payment_status', 'payment_transactions', ['status'])
    ];
}

const BATCH_SIZE = 120;

class SQLAdapter {
    constructor(dialect, executer, logger) {
        this.dialect = dialect;
        this.exec = executer;
        this.logger = logger;
    }

    ph(n) {
        return this.dialect === 'postgresql' ? `$${n}` : '?';
    }

    placeholders(count, offset = 0) {
        if (this.dialect === 'postgresql') {
            return Array.from({ length: count }, (_, i) => `$${i + 1 + offset}`).join(', ');
        }
        return Array.from({ length: count }, () => '?').join(', ');
    }

    upsert(table, uniqueCols, cols) {
        const quoted = cols.map((c) => q(this.dialect, c));
        if (this.dialect === 'postgresql') {
            return `INSERT INTO ${table} (${quoted.join(', ')}) VALUES (${this.placeholders(cols.length)})
        ON CONFLICT (${uniqueCols.map((c) => q(this.dialect, c)).join(', ')}) DO UPDATE SET ${cols
            .filter((c) => !uniqueCols.includes(c))
            .map((c) => `${q(this.dialect, c)} = EXCLUDED.${q(this.dialect, c)}`)
            .join(', ')}`;
        }
        return `INSERT INTO ${table} (${quoted.join(', ')}) VALUES (${this.placeholders(cols.length)})
      ON DUPLICATE KEY UPDATE ${cols
          .filter((c) => !uniqueCols.includes(c))
          .map((c) => `${q(this.dialect, c)} = VALUES(${q(this.dialect, c)})`)
          .join(', ')}`;
    }

    async ensureSchema() {
        const tables = buildTables(this.dialect);
        for (const ddl of Object.values(tables)) {
            await this.exec(ddl);
        }
        for (const ddl of buildIndexes(this.dialect)) {
            try {
                await this.exec(ddl);
            } catch (err) {
                if (this.dialect === 'mysql' && /duplicate key name/i.test(err.message)) continue;
                throw err;
            }
        }
        const metaTable = 'db_meta';
        const sqlVersion = `SELECT value FROM ${metaTable} WHERE ${q(this.dialect, 'key')} = 'schema_version'`;
        const res = await this.exec(sqlVersion);
        const row = Array.isArray(res) && Array.isArray(res[0]) ? res[0][0] : res.rows ? res.rows[0] : res[0];
        if (!row) {
            await this.exec(
                `INSERT INTO ${metaTable} (${q(this.dialect, 'key')}, value) VALUES ('schema_version', ${this.ph(1)})`,
                [String(SCHEMA_VERSION)]
            );
        }
    }

    async transactional(work) {
        if (this.txRunner) return work();
        return this.txRunnerImpl(work);
    }

    async insertRows(table, cols, rows) {
        if (!rows.length) return;
        for (let start = 0; start < rows.length; start += BATCH_SIZE) {
            const chunk = rows.slice(start, start + BATCH_SIZE);
            const values = [];
            const tuples = chunk.map((r) => {
                values.push(...cols.map((c) => (r[c] === undefined ? null : r[c])));
                return `(${this.placeholders(cols.length, values.length - cols.length)})`;
            });
            const sql = `INSERT INTO ${table} (${cols.map((c) => q(this.dialect, c)).join(', ')}) VALUES ${tuples.join(', ')}`;
            await this.exec(sql, values);
        }
    }

    async insertRowsTx(table, cols, rows) {
        await this.transactional(async () => {
            await this.exec(`DELETE FROM ${table}${this.whereDelete(table)}`);
            await this.insertRows(table, cols, rows);
        });
    }

    whereDelete() {
        return '';
    }

    async loadGenericDoc(namespace) {
        const sql = `SELECT value FROM generic_data WHERE namespace = ${this.ph(1)} AND ${q(this.dialect, 'key')} = ${this.ph(2)}`;
        const res = await this.exec(sql, [namespace, '__doc__']);
        const row = Array.isArray(res) && Array.isArray(res[0]) ? res[0][0] : res.rows ? res.rows[0] : res[0];
        return row ? safeParse(row.value, null) : null;
    }

    async saveGenericDoc(namespace, doc) {
        const now = Date.now();
        const json = JSON.stringify(doc === undefined ? null : doc);
        if (this.dialect === 'postgresql') {
            await this.exec(
                `INSERT INTO generic_data (namespace, ${q(this.dialect, 'key')}, value, created_at, updated_at)
         VALUES ($1, '__doc__', $2, $3, $4)
         ON CONFLICT (namespace, ${q(this.dialect, 'key')}) DO UPDATE SET value = EXCLUDED.value, updated_at = EXCLUDED.updated_at`,
                [namespace, json, now, now]
            );
        } else {
            await this.exec(
                `INSERT INTO generic_data (namespace, ${q(this.dialect, 'key')}, value, created_at, updated_at)
         VALUES (?, '__doc__', ?, ?, ?)
         ON DUPLICATE KEY UPDATE value = VALUES(value), updated_at = VALUES(updated_at)`,
                [namespace, json, now, now]
            );
        }
        return true;
    }

    async listNamespaces() {
        const namespaces = new Set();
        const add = (rows) => {
            for (const r of rows || []) namespaces.add(r.namespace);
        };
        const resP = await this.exec(`SELECT DISTINCT scope AS namespace FROM premium_users`);
        const resS = await this.exec(`SELECT DISTINCT scope AS namespace FROM bot_sewa`);
        const resB = await this.exec(`SELECT DISTINCT namespace FROM bot_settings`);
        const resG = await this.exec(`SELECT DISTINCT namespace FROM generic_data`);
        const pick = (res) => (Array.isArray(res) && Array.isArray(res[0]) ? res[0] : res.rows ? res.rows : res);
        for (const r of pick(resP))
            namespaces.add(r.namespace === 'main' ? 'premium' : `jadibot:${r.namespace}:premium`);
        for (const r of pick(resS)) namespaces.add(r.namespace === 'main' ? 'sewa' : `jadibot:${r.namespace}:sewa`);
        add(pick(resB));
        add(pick(resG));

        for (const [ns, table] of [
            ['user', 'users'],
            ['userDB', 'chat_stats'],
            ['bannedDB', 'banned_users'],
            ['maintenance', 'maintenance_mode'],
            ['afk', 'afk_status'],
            ['payment', 'payment_transactions']
        ]) {
            const res = await this.exec(`SELECT COUNT(*) AS c FROM ${table}`);
            const rows = Array.isArray(res) && Array.isArray(res[0]) ? res[0] : res.rows ? res.rows : res;
            if (Number(rows[0].c) > 0) namespaces.add(ns);
        }

        const resU = await this.exec(`SELECT COUNT(*) AS c FROM pterodactyl_users`);
        const resV = await this.exec(`SELECT COUNT(*) AS c FROM pterodactyl_servers`);
        const cu = Number(pick(resU)[0].c) + Number(pick(resV)[0].c);
        if (cu > 0) namespaces.add('ptreodactyl');
        return [...namespaces];
    }

    async loadDoc(namespace) {
        const meta = registry.resolveNamespace(namespace);
        if (meta.name.startsWith('jadibot:')) {
            const parts = meta.name.split(':');
            const scope = parts[1];
            const dataset = parts[2] || 'sewa';
            if (dataset === 'premium') {
                const res = await this.exec(`SELECT * FROM premium_users WHERE scope = ${this.ph(1)}`, [scope]);
                const rows = Array.isArray(res) && Array.isArray(res[0]) ? res[0] : res.rows ? res.rows : res;
                return rows.length ? registry.normalizeForLoad('premium', { single: rows }, scope) : null;
            }
            if (dataset === 'sewa') {
                const res = await this.exec(`SELECT * FROM bot_sewa WHERE scope = ${this.ph(1)}`, [scope]);
                const rows = Array.isArray(res) && Array.isArray(res[0]) ? res[0] : res.rows ? res.rows : res;
                return rows.length ? registry.normalizeForLoad('sewa', { single: rows }, scope) : null;
            }
            return this.loadGenericDoc(meta.name);
        }

        switch (namespace) {
            case 'user': {
                const res = await this.exec(`SELECT * FROM users`);
                const rows = Array.isArray(res) && Array.isArray(res[0]) ? res[0] : res.rows ? res.rows : res;
                return rows.length ? registry.normalizeForLoad('user', { single: rows }) : null;
            }
            case 'userDB': {
                const res = await this.exec(`SELECT * FROM chat_stats`);
                const rows = Array.isArray(res) && Array.isArray(res[0]) ? res[0] : res.rows ? res.rows : res;
                return rows.length ? registry.normalizeForLoad('userDB', { single: rows }) : null;
            }
            case 'premium': {
                const res = await this.exec(`SELECT * FROM premium_users WHERE scope = ${this.ph(1)}`, ['main']);
                const rows = Array.isArray(res) && Array.isArray(res[0]) ? res[0] : res.rows ? res.rows : res;
                return rows.length ? registry.normalizeForLoad('premium', { single: rows }, 'main') : null;
            }
            case 'sewa': {
                const res = await this.exec(`SELECT * FROM bot_sewa WHERE scope = ${this.ph(1)}`, ['main']);
                const rows = Array.isArray(res) && Array.isArray(res[0]) ? res[0] : res.rows ? res.rows : res;
                return rows.length ? registry.normalizeForLoad('sewa', { single: rows }, 'main') : null;
            }
            case 'bannedDB': {
                const res = await this.exec(`SELECT * FROM banned_users`);
                const rows = Array.isArray(res) && Array.isArray(res[0]) ? res[0] : res.rows ? res.rows : res;
                return rows.length ? registry.normalizeForLoad('bannedDB', { single: rows }) : null;
            }
            case 'maintenance': {
                const res = await this.exec(`SELECT * FROM maintenance_mode WHERE id = 1`);
                const rows = Array.isArray(res) && Array.isArray(res[0]) ? res[0] : res.rows ? res.rows : res;
                return rows.length ? registry.normalizeForLoad('maintenance', { maintenance: rows[0] }) : null;
            }
            case 'afk': {
                const res = await this.exec(`SELECT * FROM afk_status`);
                const rows = Array.isArray(res) && Array.isArray(res[0]) ? res[0] : res.rows ? res.rows : res;
                return rows.length ? registry.normalizeForLoad('afk', { single: rows }) : null;
            }
            case 'payment': {
                const res = await this.exec(`SELECT * FROM payment_transactions`);
                const rows = Array.isArray(res) && Array.isArray(res[0]) ? res[0] : res.rows ? res.rows : res;
                return rows.length ? registry.normalizeForLoad('payment', { single: rows }) : null;
            }
            case 'ptreodactyl': {
                const resU = await this.exec(`SELECT * FROM pterodactyl_users`);
                const resS = await this.exec(`SELECT * FROM pterodactyl_servers`);
                const users = Array.isArray(resU) && Array.isArray(resU[0]) ? resU[0] : resU.rows ? resU.rows : resU;
                const servers = Array.isArray(resS) && Array.isArray(resS[0]) ? resS[0] : resS.rows ? resS.rows : resS;
                if (!users.length && !servers.length) return null;
                return registry.normalizeForLoad('ptreodactyl', { users, servers });
            }
            case 'welcome':
            case 'left': {
                const res = await this.exec(`SELECT * FROM bot_settings WHERE namespace = ${this.ph(1)}`, [namespace]);
                const rows = Array.isArray(res) && Array.isArray(res[0]) ? res[0] : res.rows ? res.rows : res;
                return rows.length ? registry.normalizeForLoad(namespace, { single: rows }) : null;
            }
            default:
                return this.loadGenericDoc(namespace);
        }
    }

    async saveDoc(namespace, doc) {
        const meta = registry.resolveNamespace(namespace);
        if (meta.name.startsWith('jadibot:')) {
            const parts = meta.name.split(':');
            const scope = parts[1];
            const dataset = parts[2] || 'sewa';
            if (dataset === 'premium') {
                const rows = registry.normalizeForSave('premium', doc, scope).rows.single;
                await this.transactional(async () => {
                    await this.exec(`DELETE FROM premium_users WHERE scope = ${this.ph(1)}`, [scope]);
                    await this.insertRows(
                        'premium_users',
                        ['scope', 'user_id', 'expired', 'created_at', 'updated_at'],
                        rows
                    );
                });
                return;
            }
            if (dataset === 'sewa') {
                const rows = registry.normalizeForSave('sewa', doc, scope).rows.single;
                await this.transactional(async () => {
                    await this.exec(`DELETE FROM bot_sewa WHERE scope = ${this.ph(1)}`, [scope]);
                    await this.insertRows(
                        'bot_sewa',
                        ['scope', 'group_id', 'group_name', 'start', 'expired', 'created_at', 'updated_at'],
                        rows
                    );
                });
                return;
            }
            await this.saveGenericDoc(meta.name, doc);
            return;
        }

        switch (namespace) {
            case 'user': {
                const rows = registry.normalizeForSave('user', doc).rows.single;
                await this.transactional(async () => {
                    await this.exec(`DELETE FROM users`);
                    await this.insertRows(
                        'users',
                        [
                            'jid',
                            'limit',
                            'money',
                            'role',
                            'level_user',
                            'level_cache',
                            'last_reset',
                            'last_claim_limit',
                            'extra',
                            'created_at',
                            'updated_at'
                        ],
                        rows.map((r) => ({ ...r, extra: JSON.stringify(r.extra || {}) }))
                    );
                });
                return;
            }
            case 'userDB': {
                const rows = registry.normalizeForSave('userDB', doc).rows.single;
                await this.transactional(async () => {
                    await this.exec(`DELETE FROM chat_stats`);
                    await this.insertRows(
                        'chat_stats',
                        ['group_id', 'user_id', 'total_chat', 'last_chat', 'created_at', 'updated_at'],
                        rows
                    );
                });
                return;
            }
            case 'premium': {
                const rows = registry.normalizeForSave('premium', doc, 'main').rows.single;
                await this.transactional(async () => {
                    await this.exec(`DELETE FROM premium_users WHERE scope = ${this.ph(1)}`, ['main']);
                    await this.insertRows(
                        'premium_users',
                        ['scope', 'user_id', 'expired', 'created_at', 'updated_at'],
                        rows
                    );
                });
                return;
            }
            case 'sewa': {
                const rows = registry.normalizeForSave('sewa', doc, 'main').rows.single;
                await this.transactional(async () => {
                    await this.exec(`DELETE FROM bot_sewa WHERE scope = ${this.ph(1)}`, ['main']);
                    await this.insertRows(
                        'bot_sewa',
                        ['scope', 'group_id', 'group_name', 'start', 'expired', 'created_at', 'updated_at'],
                        rows
                    );
                });
                return;
            }
            case 'bannedDB': {
                const rows = registry.normalizeForSave('bannedDB', doc).rows.single;
                await this.transactional(async () => {
                    await this.exec(`DELETE FROM banned_users`);
                    await this.insertRows(
                        'banned_users',
                        ['user_id', 'reason', 'banned_at', 'expired_at', 'permanent', 'created_at'],
                        rows
                    );
                });
                return;
            }
            case 'maintenance': {
                const row = registry.normalizeForSave('maintenance', doc).rows.maintenance;
                const cols = ['id', 'enabled', 'reason', 'start_at', 'end_at', 'duration', 'updated_at'];
                const sql = this.upsert('maintenance_mode', ['id'], cols);
                await this.exec(
                    sql,
                    cols.map((c) => row[c])
                );
                return;
            }
            case 'afk': {
                const rows = registry.normalizeForSave('afk', doc).rows.single;
                await this.transactional(async () => {
                    await this.exec(`DELETE FROM afk_status`);
                    await this.insertRows(
                        'afk_status',
                        ['group_id', 'user_id', 'reason', 'started_at', 'mentioned', 'created_at', 'updated_at'],
                        rows
                    );
                });
                return;
            }
            case 'payment': {
                const rows = registry.normalizeForSave('payment', doc).rows.single;
                await this.transactional(async () => {
                    await this.exec(`DELETE FROM payment_transactions`);
                    await this.insertRows(
                        'payment_transactions',
                        ['order_id', 'user_id', 'amount', 'status', 'data', 'created_at', 'updated_at'],
                        rows
                    );
                });
                return;
            }
            case 'ptreodactyl': {
                const norm = registry.normalizeForSave('ptreodactyl', doc);
                await this.transactional(async () => {
                    await this.exec(`DELETE FROM pterodactyl_users`);
                    await this.exec(`DELETE FROM pterodactyl_servers`);
                    await this.insertRows(
                        'pterodactyl_users',
                        ['user_id', 'api_key', 'data', 'created_at'],
                        norm.rows.userRows
                    );
                    await this.insertRows(
                        'pterodactyl_servers',
                        ['server_id', 'user_id', 'server_name', 'data', 'created_at'],
                        norm.rows.serverRows
                    );
                });
                return;
            }
            case 'welcome':
            case 'left': {
                const rows = registry.normalizeForSave(namespace, doc).rows.single;
                await this.transactional(async () => {
                    await this.exec(`DELETE FROM bot_settings WHERE namespace = ${this.ph(1)}`, [namespace]);
                    await this.insertRows(
                        'bot_settings',
                        ['namespace', 'key', 'value', 'created_at', 'updated_at'],
                        rows
                    );
                });
                return;
            }
            default:
                await this.saveGenericDoc(namespace, doc);
        }
    }

    async deleteNamespace(namespace) {
        const meta = registry.resolveNamespace(namespace);
        if (meta.name.startsWith('jadibot:')) {
            const parts = meta.name.split(':');
            const scope = parts[1];
            const dataset = parts[2] || 'sewa';
            if (dataset === 'premium') {
                await this.exec(`DELETE FROM premium_users WHERE scope = ${this.ph(1)}`, [scope]);
                return true;
            }
            if (dataset === 'sewa') {
                await this.exec(`DELETE FROM bot_sewa WHERE scope = ${this.ph(1)}`, [scope]);
                return true;
            }
            await this.exec(`DELETE FROM generic_data WHERE namespace = ${this.ph(1)}`, [meta.name]);
            return true;
        }
        switch (namespace) {
            case 'user':
                await this.exec(`DELETE FROM users`);
                return true;
            case 'userDB':
                await this.exec(`DELETE FROM chat_stats`);
                return true;
            case 'premium':
                await this.exec(`DELETE FROM premium_users WHERE scope = ${this.ph(1)}`, ['main']);
                return true;
            case 'sewa':
                await this.exec(`DELETE FROM bot_sewa WHERE scope = ${this.ph(1)}`, ['main']);
                return true;
            case 'bannedDB':
                await this.exec(`DELETE FROM banned_users`);
                return true;
            case 'maintenance':
                await this.exec(`DELETE FROM maintenance_mode`);
                return true;
            case 'afk':
                await this.exec(`DELETE FROM afk_status`);
                return true;
            case 'payment':
                await this.exec(`DELETE FROM payment_transactions`);
                return true;
            case 'ptreodactyl':
                await this.exec(`DELETE FROM pterodactyl_users`);
                await this.exec(`DELETE FROM pterodactyl_servers`);
                return true;
            case 'welcome':
            case 'left':
                await this.exec(`DELETE FROM bot_settings WHERE namespace = ${this.ph(1)}`, [namespace]);
                return true;
            default:
                await this.exec(`DELETE FROM generic_data WHERE namespace = ${this.ph(1)}`, [namespace]);
                return true;
        }
    }

    async countNamespace(namespace) {
        const doc = await this.loadDoc(namespace);
        if (doc === null || doc === undefined) return 0;
        if (Array.isArray(doc)) return doc.length;
        if (typeof doc === 'object') return Object.keys(doc).length;
        return 1;
    }
}

module.exports = { SQLAdapter, buildTables, buildIndexes, SCHEMA_VERSION, q };

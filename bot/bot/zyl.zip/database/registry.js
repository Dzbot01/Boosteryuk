const path = require('path');

const STORAGE_DIR = path.resolve(__dirname, '../Storage');

const MAIN_SCOPES = 'main';

const DATASETS = {
    user: {
        file: 'user.json',
        table: 'users',
        normalize: true,
        defaults: {},
        document: true
    },
    userDB: {
        file: 'userDB.json',
        table: 'chat_stats',
        normalize: true,
        defaults: { groups: {} },
        document: true
    },
    premium: {
        file: 'premium.json',
        table: 'premium_users',
        normalize: true,
        scoped: true,
        defaults: [],
        document: false
    },
    sewa: {
        file: 'sewa.json',
        table: 'bot_sewa',
        normalize: true,
        scoped: true,
        defaults: {},
        document: true
    },
    bannedDB: {
        file: 'bannedDB.json',
        table: 'banned_users',
        normalize: true,
        defaults: { users: {} },
        document: true
    },
    maintenance: {
        file: 'maintenance.json',
        table: 'maintenance_mode',
        normalize: true,
        defaults: {
            enabled: false,
            reason: '',
            startAt: null,
            endAt: null,
            duration: 0,
            updatedAt: null
        },
        document: false
    },
    afk: {
        file: 'afk.json',
        table: 'afk_status',
        normalize: true,
        defaults: { groups: {} },
        document: true
    },
    payment: {
        file: 'payment.json',
        table: 'payment_transactions',
        normalize: true,
        defaults: { transactions: [] },
        document: false
    },
    ptreodactyl: {
        file: 'ptreodactyl.json',
        table: 'pterodactyl',
        normalize: true,
        defaults: { users: {}, servers: {} },
        document: true
    },
    welcome: {
        file: 'welcome.json',
        table: 'bot_settings',
        normalize: true,
        defaults: {},
        document: true
    },
    left: {
        file: 'left.json',
        table: 'bot_settings',
        normalize: true,
        defaults: {},
        document: true
    }
};

const GENERIC_DATASETS = {
    database: {
        file: 'database.json',
        defaults: {
            users: {},
            chats: {},
            database: {},
            groups: {},
            game: {},
            settings: {},
            others: {},
            sticker: {}
        }
    },
    owner: { file: 'owner.json', defaults: [] },
    blacklistgc: { file: 'blacklistgc.json', defaults: [] },
    blacklistplugins: { file: 'blacklistplugins.json', defaults: {} },
    groupSettings: { file: 'groupSettings.json', defaults: {} },
    antipromo: { file: 'antipromo.json', defaults: {} },
    toxic: { file: 'toxic.json', defaults: [] },
    redeem: { file: 'redeem.json', defaults: {} },
    jpm: { file: 'jpm.json', defaults: {} },
    orders: { file: 'orders.json', defaults: { orders: [] } },
    groupSchedule: { file: 'groupSchedule.json', defaults: {} },
    store_template: { file: 'store_template.json', defaults: {} },
    jadibot: { file: 'jadibot.json', defaults: {} }
};

function resolveNamespace(ns) {
    if (DATASETS[ns]) return { name: ns, ...DATASETS[ns], generic: false, scope: MAIN_SCOPES };
    if (GENERIC_DATASETS[ns]) {
        return { name: ns, ...GENERIC_DATASETS[ns], generic: true, table: 'generic_data', scope: MAIN_SCOPES };
    }
    if (ns.startsWith('jadibot:')) {
        const rest = ns.slice('jadibot:'.length);
        const [scope, sub] = rest.split(':');
        const target = sub || 'sewa';
        if (DATASETS[target]) {
            return { name: ns, ...DATASETS[target], generic: false, scope: scope || MAIN_SCOPES };
        }
    }
    const clean = ns.replace(/^jadibot:/, '');
    return {
        name: ns,
        file: `${clean}.json`,
        table: 'generic_data',
        generic: true,
        scope: MAIN_SCOPES,
        defaults: {},
        dynamic: true
    };
}

function isKnownNamespace(ns) {
    return Boolean(DATASETS[ns] || GENERIC_DATASETS[ns] || ns.startsWith('jadibot:'));
}

function normalizeNamespaceForFile(filePath) {
    const abs = path.resolve(filePath);
    const rel = path.relative(STORAGE_DIR, abs);
    if (rel && !rel.startsWith('..') && !path.isAbsolute(rel)) {
        const base = rel
            .split(path.sep)
            .join('/')
            .replace(/\.json$/i, '');
        if (base.startsWith('jadibot_sessions/')) {
            const parts = base.split('/');
            if (parts.length >= 2) return `jadibot:${parts[1]}:${parts.slice(2).join('/')}`;
        }
        return base.replace(/\//g, ':');
    }
    const normalized = abs.split(path.sep).join('/');
    const marker = '/jadibot_sessions/';
    const idx = normalized.indexOf(marker);
    if (idx !== -1) {
        const rest = normalized.slice(idx + marker.length).replace(/\.json$/i, '');
        const parts = rest.split('/').filter(Boolean);
        if (parts.length >= 2) return `jadibot:${parts[0]}:${parts.slice(1).join('/')}`;
    }
    const base = path.basename(filePath).replace(/\.json$/i, '');
    return base || 'unnamed';
}

function fileForNamespace(ns) {
    const meta = resolveNamespace(ns);
    if (meta.name.startsWith('jadibot:')) {
        const rest = meta.name.slice('jadibot:'.length);
        const [scope, ...subParts] = rest.split(':');
        const sub = subParts.length ? subParts.join('/') : 'sewa';
        return path.join(STORAGE_DIR, 'jadibot_sessions', scope, `${sub}.json`);
    }
    return path.join(STORAGE_DIR, meta.file || `${ns}.json`);
}

function docToUsersRows(doc) {
    const rows = [];
    const now = Date.now();
    const users = doc && typeof doc === 'object' ? doc : {};
    for (const [jid, v] of Object.entries(users)) {
        if (!v || typeof v !== 'object') continue;
        rows.push({
            jid,
            limit: Number(v.limit) || 0,
            money: Number(v.money) || 0,
            role: String(v.role || '-'),
            level_user: Number(v.level_user) || 1,
            level_cache: Number(v.level_cache) || 0,
            last_reset: Number(v.lastReset) || null,
            last_claim_limit: Number(v.lastClaimLimit) || null,
            extra: v,
            created_at: now,
            updated_at: now
        });
    }
    return rows;
}

function usersRowsToDoc(rows) {
    const doc = {};
    for (const r of rows) {
        let extra = {};
        try {
            extra = typeof r.extra === 'string' ? JSON.parse(r.extra) : r.extra || {};
        } catch {
            extra = {};
        }
        doc[r.jid] = {
            ...extra,
            limit: Number(r.limit) || 0,
            money: Number(r.money) || 0,
            role: r.role || '-',
            level_user: Number(r.level_user) || 1,
            level_cache: Number(r.level_cache) || 0,
            lastReset: Number(r.last_reset) || Date.now(),
            lastClaimLimit: Number(r.last_claim_limit) || 0
        };
    }
    return doc;
}

function docToChatStatsRows(doc) {
    const rows = [];
    const now = Date.now();
    const groups = (doc && doc.groups) || {};
    for (const [gid, g] of Object.entries(groups)) {
        const users = (g && g.users) || {};
        for (const [uid, u] of Object.entries(users)) {
            rows.push({
                group_id: gid,
                user_id: uid,
                total_chat: Number(u && u.totalChat) || 0,
                last_chat: Number(u && u.lastChat) || null,
                created_at: now,
                updated_at: now
            });
        }
    }
    return rows;
}

function chatStatsRowsToDoc(rows) {
    const doc = { groups: {} };
    for (const r of rows) {
        if (!doc.groups[r.group_id]) doc.groups[r.group_id] = { users: {} };
        doc.groups[r.group_id].users[r.user_id] = {
            totalChat: Number(r.total_chat) || 0,
            lastChat: Number(r.last_chat) || 0
        };
    }
    return doc;
}

function docToPremiumRows(doc, scope) {
    const rows = [];
    const now = Date.now();
    const list = Array.isArray(doc) ? doc : [];
    for (const item of list) {
        if (!item || typeof item.id !== 'string') continue;
        rows.push({
            scope: scope || MAIN_SCOPES,
            user_id: item.id,
            expired: Number(item.expired) || 0,
            created_at: now,
            updated_at: now
        });
    }
    return rows;
}

function premiumRowsToDoc(rows) {
    return rows.map((r) => ({ id: r.user_id, expired: Number(r.expired) || 0 }));
}

function docToSewaRows(doc, scope) {
    const rows = [];
    const now = Date.now();
    const entries = doc && typeof doc === 'object' ? Object.entries(doc) : [];
    for (const [gid, v] of entries) {
        if (!v || typeof v !== 'object') continue;
        rows.push({
            scope: scope || MAIN_SCOPES,
            group_id: gid,
            group_name: v.namegrup || '',
            start: String(v.start || ''),
            expired: Number(v.expired) || 0,
            created_at: now,
            updated_at: now
        });
    }
    return rows;
}

function sewaRowsToDoc(rows) {
    const doc = {};
    for (const r of rows) {
        doc[r.group_id] = {
            namegrup: r.group_name || '',
            start: r.start || new Date().toISOString(),
            expired: Number(r.expired) || 0
        };
    }
    return doc;
}

function docToBannedRows(doc) {
    const rows = [];
    const now = Date.now();
    const users = (doc && doc.users) || {};
    for (const [uid, v] of Object.entries(users)) {
        if (!v || typeof v !== 'object') continue;
        rows.push({
            user_id: uid,
            reason: v.reason || '',
            banned_at: v.bannedAt ? String(v.bannedAt) : null,
            expired_at: v.expiredAt ? String(v.expiredAt) : null,
            permanent: v.permanent ? 1 : 0,
            created_at: now
        });
    }
    return rows;
}

function bannedRowsToDoc(rows) {
    const doc = { users: {} };
    for (const r of rows) {
        const entry = { reason: r.reason || '' };
        if (r.permanent) {
            entry.permanent = true;
        } else {
            entry.bannedAt = r.banned_at || undefined;
            entry.expiredAt = r.expired_at || undefined;
            entry.permanent = false;
        }
        doc.users[r.user_id] = entry;
    }
    return doc;
}

function docToMaintenanceRow(doc) {
    const v = doc && typeof doc === 'object' ? doc : {};
    return {
        id: 1,
        enabled: v.enabled ? 1 : 0,
        reason: v.reason || '',
        start_at: v.startAt || null,
        end_at: v.endAt || null,
        duration: Number(v.duration) || 0,
        updated_at: v.updatedAt || Date.now()
    };
}

function maintenanceRowToDoc(row) {
    if (!row) {
        return {
            enabled: false,
            reason: '',
            startAt: null,
            endAt: null,
            duration: 0,
            updatedAt: null
        };
    }
    return {
        enabled: Boolean(row.enabled),
        reason: row.reason || '',
        startAt: row.start_at === null ? null : Number(row.start_at),
        endAt: row.end_at === null ? null : Number(row.end_at),
        duration: Number(row.duration) || 0,
        updatedAt: row.updated_at === null ? null : Number(row.updated_at)
    };
}

function docToAfkRows(doc) {
    const rows = [];
    const now = Date.now();
    const groups = (doc && doc.groups) || {};
    for (const [gid, g] of Object.entries(groups)) {
        const users = (g && g.users) || {};
        for (const [uid, u] of Object.entries(users)) {
            rows.push({
                group_id: gid,
                user_id: uid,
                reason: (u && u.reason) || '',
                started_at: Number(u && u.since) || now,
                mentioned: Number(u && u.mentioned) || 0,
                created_at: now,
                updated_at: now
            });
        }
    }
    return rows;
}

function afkRowsToDoc(rows) {
    const doc = { groups: {} };
    for (const r of rows) {
        if (!doc.groups[r.group_id]) doc.groups[r.group_id] = { users: {} };
        doc.groups[r.group_id].users[r.user_id] = {
            afk: true,
            reason: r.reason || '',
            since: Number(r.started_at) || Date.now(),
            mentioned: Number(r.mentioned) || 0
        };
    }
    return doc;
}

function docToPaymentRows(doc) {
    const rows = [];
    const now = Date.now();
    const list = doc && Array.isArray(doc.transactions) ? doc.transactions : [];
    for (const t of list) {
        if (!t || typeof t !== 'object' || !t.order_id) continue;
        rows.push({
            order_id: String(t.order_id),
            user_id: t.user_id || t.buyer || null,
            amount: Number(t.amount) || 0,
            status: String(t.status || 'pending'),
            data: JSON.stringify(t),
            created_at: Number(t.createdAt) || now,
            updated_at: now
        });
    }
    return rows;
}

function paymentRowsToDoc(rows) {
    const transactions = [];
    for (const r of rows) {
        let data = {};
        try {
            data = typeof r.data === 'string' ? JSON.parse(r.data) : r.data || {};
        } catch {
            data = {};
        }
        transactions.push({
            ...data,
            order_id: r.order_id,
            amount: Number(r.amount) || data.amount || 0,
            status: r.status || data.status || 'pending'
        });
    }
    return { transactions };
}

function docToPteroRows(doc) {
    const now = Date.now();
    const users = (doc && doc.users) || {};
    const servers = (doc && doc.servers) || {};
    const userRows = Object.entries(users).map(([uid, v]) => ({
        user_id: uid,
        api_key: typeof v === 'string' ? v : null,
        data: JSON.stringify(v === undefined ? null : v),
        created_at: now
    }));
    const serverRows = Object.entries(servers).map(([sid, v]) => ({
        server_id: sid,
        user_id: (v && (v.user_id || v.userId)) || null,
        server_name: (v && v.server_name) || null,
        data: JSON.stringify(v === undefined ? null : v),
        created_at: now
    }));
    return { userRows, serverRows };
}

function pteroRowsToDoc(userRows, serverRows) {
    const users = {};
    const servers = {};
    for (const r of userRows || []) {
        let v = null;
        try {
            v = typeof r.data === 'string' ? JSON.parse(r.data) : r.data;
        } catch {
            v = null;
        }
        if (v === null || v === undefined) v = r.api_key || '';
        users[r.user_id] = v;
    }
    for (const r of serverRows || []) {
        let v = null;
        try {
            v = typeof r.data === 'string' ? JSON.parse(r.data) : r.data;
        } catch {
            v = null;
        }
        if (v === null || v === undefined) v = {};
        servers[r.server_id] = v;
    }
    return { users, servers };
}

function docToBotSettingsRows(doc, namespace) {
    const rows = [];
    const now = Date.now();
    if (doc && typeof doc === 'object' && !Array.isArray(doc)) {
        for (const [key, value] of Object.entries(doc)) {
            rows.push({
                namespace,
                key,
                value: typeof value === 'string' ? value : JSON.stringify(value),
                created_at: now,
                updated_at: now
            });
        }
    }
    return rows;
}

function botSettingsRowsToDoc(rows) {
    const doc = {};
    for (const r of rows) {
        let value = r.value;
        try {
            const parsed = JSON.parse(r.value);
            value = typeof parsed === 'string' ? parsed : parsed;
        } catch {
            value = r.value;
        }
        doc[r.key] = value;
    }
    return doc;
}

const NORMALIZERS = {
    user: { toRows: (doc) => ({ single: docToUsersRows(doc) }), toDoc: (rows) => usersRowsToDoc(rows.single) },
    userDB: {
        toRows: (doc) => ({ single: docToChatStatsRows(doc) }),
        toDoc: (rows) => chatStatsRowsToDoc(rows.single)
    },
    premium: {
        toRows: (doc, scope) => ({ single: docToPremiumRows(doc, scope) }),
        toDoc: (rows) => premiumRowsToDoc(rows.single)
    },
    sewa: {
        toRows: (doc, scope) => ({ single: docToSewaRows(doc, scope) }),
        toDoc: (rows) => sewaRowsToDoc(rows.single)
    },
    bannedDB: { toRows: (doc) => ({ single: docToBannedRows(doc) }), toDoc: (rows) => bannedRowsToDoc(rows.single) },
    maintenance: {
        toRows: (doc) => ({ maintenance: docToMaintenanceRow(doc) }),
        toDoc: (rows) => maintenanceRowToDoc(rows.maintenance)
    },
    afk: { toRows: (doc) => ({ single: docToAfkRows(doc) }), toDoc: (rows) => afkRowsToDoc(rows.single) },
    payment: { toRows: (doc) => ({ single: docToPaymentRows(doc) }), toDoc: (rows) => paymentRowsToDoc(rows.single) },
    ptreodactyl: { toRows: (doc) => docToPteroRows(doc), toDoc: (rows) => pteroRowsToDoc(rows.users, rows.servers) },
    welcome: {
        toRows: (doc) => ({ single: docToBotSettingsRows(doc, 'welcome') }),
        toDoc: (rows) => botSettingsRowsToDoc(rows.single)
    },
    left: {
        toRows: (doc) => ({ single: docToBotSettingsRows(doc, 'left') }),
        toDoc: (rows) => botSettingsRowsToDoc(rows.single)
    }
};

function normalizeForSave(ns, doc, scope) {
    const meta = resolveNamespace(ns);
    if (meta.generic || !meta.normalize) {
        return { table: 'generic_data', rows: null, docJson: JSON.stringify(doc === undefined ? null : doc) };
    }
    const key = meta.name.startsWith('jadibot:') ? meta.name.split(':')[2] || 'sewa' : meta.name;
    const normalizer = NORMALIZERS[key];
    if (!normalizer) {
        return { table: 'generic_data', rows: null, docJson: JSON.stringify(doc === undefined ? null : doc) };
    }
    return { table: meta.table, rows: normalizer.toRows(doc, scope || meta.scope), docJson: null };
}

function normalizeForLoad(ns, rawRows, scope) {
    const meta = resolveNamespace(ns);
    if (meta.generic || !meta.normalize) {
        return rawRows && rawRows.docJson !== undefined ? safeParseDoc(rawRows.docJson) : null;
    }
    const key = meta.name.startsWith('jadibot:') ? meta.name.split(':')[2] || 'sewa' : meta.name;
    const normalizer = NORMALIZERS[key];
    if (!normalizer) return null;
    return normalizer.toDoc(rawRows);
}

function safeParseDoc(json) {
    if (json === null || json === undefined) return null;
    try {
        return JSON.parse(json);
    } catch {
        return null;
    }
}

function listKnownNamespaces() {
    return [...Object.keys(DATASETS), ...Object.keys(GENERIC_DATASETS)];
}

module.exports = {
    STORAGE_DIR,
    MAIN_SCOPES,
    DATASETS,
    GENERIC_DATASETS,
    resolveNamespace,
    isKnownNamespace,
    normalizeNamespaceForFile,
    fileForNamespace,
    normalizeForSave,
    normalizeForLoad,
    listKnownNamespaces,
    docToUsersRows,
    usersRowsToDoc
};

const manager = require('../index');

class TimeFormatter {
    static formatDuration(ms) {
        const seconds = Math.floor(ms / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);
        const months = Math.floor(days / 30);

        const parts = [];

        if (months > 0) parts.push(`${months} bulan`);
        if (days % 30 > 0) parts.push(`${days % 30} hari`);
        if (hours % 24 > 0) parts.push(`${hours % 24} jam`);
        if (minutes % 60 > 0) parts.push(`${minutes % 60} menit`);

        if (parts.length === 0) return 'Baru saja';
        return parts.join(', ');
    }
}

function readDoc() {
    let doc = manager.getDoc('afk');
    if (doc === null || doc === undefined || typeof doc !== 'object' || Array.isArray(doc)) {
        manager.setDoc('afk', { groups: {} });
        doc = { groups: {} };
    }
    if (!doc.groups) doc.groups = {};
    return doc;
}

function writeDoc(doc) {
    manager.setDoc('afk', doc);
}

class AFKController {
    constructor() {}

    _read() {
        return readDoc();
    }

    _save(doc) {
        writeDoc(doc);
    }

    _ensureGroup(doc, groupId) {
        if (!doc.groups[groupId]) {
            doc.groups[groupId] = { users: {} };
        }
    }

    setAFK(groupId, userId, reason = 'AFK') {
        const doc = this._read();
        this._ensureGroup(doc, groupId);
        doc.groups[groupId].users[userId] = {
            afk: true,
            reason,
            since: Date.now(),
            mentioned: 0
        };
        this._save(doc);
    }

    unsetAFK(groupId, userId) {
        const doc = this._read();
        if (!doc.groups[groupId]?.users[userId]) return null;
        const userData = doc.groups[groupId].users[userId];
        delete doc.groups[groupId].users[userId];

        if (Object.keys(doc.groups[groupId].users).length === 0) {
            delete doc.groups[groupId];
        }
        this._save(doc);
        return userData;
    }

    getAFK(groupId, userId) {
        const doc = this._read();
        return doc.groups[groupId]?.users[userId] || null;
    }

    addMention(groupId, userId) {
        const doc = this._read();
        if (!doc.groups[groupId]?.users[userId]) return false;
        doc.groups[groupId].users[userId].mentioned++;
        this._save(doc);
        return true;
    }
}

const afkController = new AFKController();

async function handleAFK({ Yudzxml, m }) {
    const groupId = m.chat;
    const sender = m.sender;

    if (m.fromMe) return;

    const senderAFK = afkController.getAFK(groupId, sender);
    if (senderAFK) {
        const duration = TimeFormatter.formatDuration(Date.now() - senderAFK.since);
        afkController.unsetAFK(groupId, sender);

        await m.reply(
            `🕊️ @${sender.split('@')[0]} telah kembali dari AFK\n` +
                `⏳ Sejak _*${duration}*_\n\n` +
                `❏ ${senderAFK.reason || 'Tidak ada alasan yang dicatat.'}`
        );
    }

    const targets = new Set();

    if (m.mentionedJid?.length) {
        m.mentionedJid.forEach((jid) => targets.add(jid));
    }

    if (m.quoted?.sender) {
        targets.add(m.quoted.sender);
    }

    for (const userId of targets) {
        const afkData = afkController.getAFK(groupId, userId);
        if (!afkData) continue;

        afkController.addMention(groupId, userId);

        const duration = TimeFormatter.formatDuration(Date.now() - afkData.since);
        const username = userId.split('@')[0];

        await m.reply(
            `🚫 *Jangan Tag Dia!*\n\n_🌙 @${username} sedang AFK!_\n` +
                `⏳ Sejak _*${duration}*_\n\n` +
                `❏ ${afkData.reason || 'Tanpa alasan'}`
        );
    }
}

module.exports = {
    handleAFK,

    setAFK: function (gid, uid, reason) {
        return afkController.setAFK(gid, uid, reason);
    },
    unsetAFK: function (gid, uid) {
        return afkController.unsetAFK(gid, uid);
    },
    getAFK: function (gid, uid) {
        return afkController.getAFK(gid, uid);
    },
    addMention: function (gid, uid) {
        return afkController.addMention(gid, uid);
    },
    AFKController,
    TimeFormatter
};

const ms = require('ms');
const manager = require('../index');
const registry = require('../registry');

function namespaceForStore(storePath) {
    if (!storePath) return 'premium';
    return registry.normalizeNamespaceForFile(storePath);
}

function loadPremium(namespace) {
    let doc = manager.getDoc(namespace);
    if (doc === null || doc === undefined) {
        manager.setDoc(namespace, []);
        return [];
    }
    if (!Array.isArray(doc)) return [];
    return doc.filter((u) => u && typeof u.id === 'string' && typeof u.expired === 'number');
}

function savePremium(namespace, data) {
    manager.setDoc(namespace, data);
}

const createPremiumStore = (storePath = null) => {
    const namespace = namespaceForStore(storePath);

    const addPremiumUser = (userId, duration, conn) => {
        const time = ms(duration);
        if (!time) throw new Error('Invalid duration format');

        const premium = loadPremium(namespace);
        const now = Date.now();
        const user = premium.find((u) => u.id === userId);

        let expiredTimestamp;

        if (user) {
            user.expired = Math.max(user.expired, now) + time;
            expiredTimestamp = user.expired;
        } else {
            expiredTimestamp = now + time;
            premium.push({
                id: userId,
                expired: expiredTimestamp
            });
        }

        savePremium(namespace, premium);
        return expiredTimestamp;
    };

    const checkPremiumUser = (userId) => {
        const premium = loadPremium(namespace);
        const user = premium.find((u) => u.id === userId);
        return Boolean(user && Date.now() < user.expired);
    };

    const getPremiumExpired = (userId) => {
        const premium = loadPremium(namespace);
        const user = premium.find((u) => u.id === userId);
        return user ? user.expired : null;
    };

    const getPremiumPosition = (userId) => {
        const premium = loadPremium(namespace);
        return premium.findIndex((u) => u.id === userId);
    };

    const delPremiumUser = (userId) => {
        const premium = loadPremium(namespace);
        const index = premium.findIndex((u) => u.id === userId);

        if (index === -1) {
            throw new Error('User tidak ditemukan di database premium');
        }

        const removedUser = premium.splice(index, 1)[0];
        savePremium(namespace, premium);

        return {
            success: true,
            message: 'User premium berhasil dihapus',
            data: removedUser
        };
    };

    const _expiredTimers = (global.__premiumExpiredTimers = global.__premiumExpiredTimers || new Set());

    const expiredCheck = (Yudzxml) => {
        if (_expiredTimers.has(namespace)) return;
        _expiredTimers.add(namespace);

        const timer = setInterval(() => {
            try {
                let data = loadPremium(namespace);
                const now = Date.now();

                const expiredUsers = data.filter(
                    (u) => typeof u.id === 'string' && typeof u.expired === 'number' && now >= u.expired
                );

                if (!expiredUsers.length) return;

                expiredUsers.forEach((user) => {
                    console.log(`Premium expired: ${user.id}`);
                });

                data = data.filter((u) => now < u.expired);
                savePremium(namespace, data);
            } catch (err) {
                console.error('expiredCheck error:', err.message);
            }
        }, 30_000);
        timer.unref?.();
    };

    const getAllPremiumUser = () => {
        const premium = loadPremium(namespace);
        const now = Date.now();

        return premium.map((user) => ({
            id: user.id,
            expired: user.expired,
            status: now < user.expired ? 'active' : 'expired',
            remaining: Math.max(user.expired - now, 0)
        }));
    };

    return {
        addPremiumUser,
        checkPremiumUser,
        getPremiumExpired,
        getPremiumPosition,
        delPremiumUser,
        expiredCheck,
        getAllPremiumUser
    };
};

const mainStore = createPremiumStore();

module.exports = mainStore;
module.exports.createPremiumStore = createPremiumStore;

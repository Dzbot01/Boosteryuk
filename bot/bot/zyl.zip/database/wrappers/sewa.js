const manager = require('../index');
const registry = require('../registry');

function namespaceForStore(dbPath) {
    if (!dbPath) return 'sewa';
    return registry.normalizeNamespaceForFile(dbPath);
}

function loadDatabase(namespace) {
    let doc = manager.getDoc(namespace);
    if (doc === null || doc === undefined || typeof doc !== 'object' || Array.isArray(doc)) {
        manager.setDoc(namespace, {});
        return {};
    }
    return doc;
}

const createSewaStore = (dbPath = null) => {
    const namespace = namespaceForStore(dbPath);

    const getSewa = (groupId = null) => {
        const db = loadDatabase(namespace);
        if (!groupId) return db;
        return db[groupId] || null;
    };

    const addSewa = (groupId, groupName, durationDays) => {
        const db = loadDatabase(namespace);
        const now = Date.now();
        const durationMs = durationDays * 24 * 60 * 60 * 1000;

        let startDate = now;
        let expiredDate = now + durationMs;

        if (db[groupId] && db[groupId].expired > now) {
            expiredDate = db[groupId].expired + durationMs;
            startDate = db[groupId].start;
        }

        db[groupId] = {
            namegrup: groupName,
            start: new Date(startDate).toISOString(),
            expired: expiredDate
        };

        return saveDatabase(db);
    };

    const saveDatabase = (data) => {
        manager.setDoc(namespace, data);
        return true;
    };

    const deleteSewa = (groupId) => {
        const db = loadDatabase(namespace);
        if (!db[groupId]) return false;
        delete db[groupId];
        return saveDatabase(db);
    };

    const listActiveSewa = () => {
        const db = loadDatabase(namespace);
        const now = Date.now();
        return Object.entries(db)
            .filter(([, v]) => v.expired > now)
            .map(([groupId, v]) => ({ groupId, ...v, remaining: v.expired - now }));
    };

    return { getSewa, addSewa, deleteSewa, listActiveSewa };
};

const mainStore = createSewaStore();

module.exports = mainStore;
module.exports.createSewaStore = createSewaStore;

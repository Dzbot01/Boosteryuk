const manager = require('../index');

const DEFAULT_USER = {
    limit: 30,
    money: 0,
    role: '-',
    level_user: 1,
    level_cache: 0,
    lastReset: Date.now(),
    lastClaimLimit: 0
};

const ONE_DAY = 24 * 60 * 60 * 1000;

function loadDB() {
    let doc = manager.getDoc('user');
    if (doc === null || doc === undefined) {
        manager.setDoc('user', {});
        doc = {};
    }
    return doc;
}

function saveDB(data) {
    manager.setDoc('user', data);
}

function checkDailyReset(user) {
    const now = Date.now();
    if (now - user.lastReset >= ONE_DAY) {
        if (user.limit <= DEFAULT_USER.limit) {
            user.limit = DEFAULT_USER.limit;
        }
        user.lastReset = now;
    }
}

function addUser(jid) {
    const db = loadDB();
    if (db[jid]) return false;

    db[jid] = { ...DEFAULT_USER };
    saveDB(db);
    return true;
}

function getUser(jid) {
    const db = loadDB();
    if (!db[jid]) return false;
    checkDailyReset(db[jid]);
    saveDB(db);
    return db[jid];
}

function reduceLimit(jid, amount = 1) {
    if (amount <= 0) return false;
    const db = loadDB();
    if (!db[jid]) return false;
    checkDailyReset(db[jid]);
    const user = db[jid];
    user.limit = Number(user.limit || 0);
    if (user.limit < amount) {
        return false;
    }
    user.limit -= amount;
    saveDB(db);
    return true;
}

function addLimit(jid, amount = 1) {
    if (amount <= 0) return false;
    const db = loadDB();
    if (!db[jid]) return false;

    checkDailyReset(db[jid]);
    db[jid].limit += amount;
    saveDB(db);
    return true;
}

function claimLimit(jid, waktu_menit = 240) {
    const db = loadDB();
    if (!db[jid]) return { success: false, message: 'User tidak ditemukan!' };

    const user = db[jid];
    const now = Date.now();

    const cooldownTime = waktu_menit * 60 * 1000;

    if (now - user.lastClaimLimit < cooldownTime) {
        const timeLeft = cooldownTime - (now - user.lastClaimLimit);

        const hours = Math.floor(timeLeft / (1000 * 60 * 60));
        const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);

        return {
            success: false,
            message: `Cooldown! Tunggu ${hours} jam ${minutes} menit ${seconds} detik lagi.`
        };
    }

    const randomAmount = Math.floor(Math.random() * 10) + 1;

    user.limit += randomAmount;
    user.lastClaimLimit = now;

    saveDB(db);
    return {
        success: true,
        message: `Berhasil claim! Kamu mendapatkan ${randomAmount} limit.`,
        amount: randomAmount
    };
}

function resetLimit(jid) {
    const db = loadDB();
    if (!db[jid]) return false;

    db[jid].limit = DEFAULT_USER.limit;
    db[jid].lastReset = Date.now();
    saveDB(db);
    return true;
}

function addLevel(jid, amount = 1) {
    if (amount <= 0) return false;
    const db = loadDB();
    if (!db[jid]) return false;

    db[jid].level_user += amount;
    saveDB(db);
    return true;
}

function addLevelCache(jid, amount = 1) {
    if (amount <= 0) return false;
    const db = loadDB();
    if (!db[jid]) return false;

    const user = db[jid];
    user.level_cache += amount;
    if (user.level_cache >= 100) {
        const levelUp = Math.floor(user.level_cache / 100);
        user.level_user += levelUp;
        user.level_cache = user.level_cache % 100 || 1;
    }
    saveDB(db);
    return true;
}

function editRole(jid, role) {
    const db = loadDB();
    if (!db[jid]) return false;

    db[jid].role = role;
    saveDB(db);
    return true;
}

function addMoney(jid, amount = 0) {
    if (amount <= 0) return false;
    const db = loadDB();
    if (!db[jid]) return false;

    db[jid].money += amount;
    saveDB(db);
    return true;
}

function reduceMoney(jid, amount = 0) {
    if (amount <= 0) return false;
    const db = loadDB();
    if (!db[jid]) return false;

    db[jid].money = Math.max(0, db[jid].money - amount);
    saveDB(db);
    return true;
}

function getAllUsers() {
    const db = loadDB();
    return Object.entries(db).map(([jid, data]) => ({ jid, ...data }));
}

function getUserStatistics() {
    const users = getAllUsers();
    const totalUsers = users.length;

    const topLimit = [...users]
        .sort((a, b) => b.limit - a.limit)
        .slice(0, 3)
        .map((u, i) => ({
            rank: i + 1,
            jid: u.jid,
            limit: u.limit
        }));

    const topLevel = [...users]
        .sort((a, b) => b.level_user - a.level_user)
        .slice(0, 5)
        .map((u, i) => ({
            rank: i + 1,
            jid: u.jid,
            level: u.level_user
        }));

    const topMoney = [...users]
        .sort((a, b) => b.money - a.money)
        .slice(0, 6)
        .map((u, i) => ({
            rank: i + 1,
            jid: u.jid,
            money: u.money
        }));

    return {
        totalUsers,
        topLimit,
        topLevel,
        topMoney
    };
}

module.exports = {
    addUser,
    getUser,
    reduceLimit,
    addLimit,
    claimLimit,
    resetLimit,
    addLevel,
    addLevelCache,
    editRole,
    addMoney,
    reduceMoney,
    getUserStatistics
};

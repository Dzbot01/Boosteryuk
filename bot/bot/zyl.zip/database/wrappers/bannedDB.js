const moment = require('moment-timezone');
const manager = require('../index');

const TIMEZONE = 'Asia/Jakarta';

moment.locale('id');

function loadDB() {
    let doc = manager.getDoc('bannedDB');
    if (doc === null || doc === undefined || typeof doc !== 'object' || Array.isArray(doc)) {
        manager.setDoc('bannedDB', { users: {} });
        doc = { users: {} };
    }
    if (!doc.users) doc.users = {};
    return doc;
}

function saveDB(db) {
    manager.setDoc('bannedDB', db);
}

function parseDuration(input) {
    if (!input) return null;
    if (input.toLowerCase() === 'permanent') return 'permanent';

    const regex = /^(\d+)\s*(minute|hour|day|month|year)$/i;
    const match = input.match(regex);
    if (!match) return null;

    const value = parseInt(match[1]);
    const unit = match[2].toLowerCase();

    return { value, unit };
}

function formatRemaining(expiredAt) {
    const now = moment().tz(TIMEZONE);
    const end = moment(expiredAt).tz(TIMEZONE);

    if (now.isAfter(end)) return 'Sudah berakhir';

    const duration = moment.duration(end.diff(now));

    const days = Math.floor(duration.asDays());
    const hours = duration.hours();
    const minutes = duration.minutes();

    const parts = [];

    if (days > 0) parts.push(`${days} Hari`);
    if (hours > 0) parts.push(`${hours} Jam`);
    if (minutes > 0) parts.push(`${minutes} Menit`);

    return parts.length ? parts.join(' ') : 'Kurang dari 1 Menit';
}

function BannedDB({ userId, action = 'check', duration = null, reason = 'Tidak ada alasan' }) {
    if (!userId) return null;

    const db = loadDB();
    const now = moment().tz(TIMEZONE);

    if (action === 'check') {
        const user = db.users[userId];
        if (!user) return { banned: false };

        if (user.permanent) {
            return {
                banned: true,
                reason: user.reason,
                expiredAt: 'Permanent',
                remaining: 'Permanent'
            };
        }

        const expired = moment(user.expiredAt).tz(TIMEZONE);

        if (now.isAfter(expired)) {
            delete db.users[userId];
            saveDB(db);
            return { banned: false };
        }

        const info = {
            banned: true,
            reason: user.reason,
            bannedAt: moment(user.bannedAt).tz(TIMEZONE).format('DD MMMM YYYY HH:mm:ss'),
            expiredAt: expired.format('DD MMMM YYYY HH:mm:ss'),
            remaining: formatRemaining(user.expiredAt)
        };

        return {
            banned: info.banned,
            msg: `🚫 *AKSES DITOLAK*

📌 *Status:* Dibanned
📝 *Alasan:* ${info.reason}
🕒 *Dibanned:* ${info.bannedAt || '-'}
⏳ *Berakhir:* ${info.expiredAt}
⌛ *Sisa Waktu:* ${info.remaining}

Silakan hubungi owner jika merasa ini kesalahan.`
        };
    }

    if (action === 'ban') {
        const parsed = parseDuration(duration);
        if (!parsed) return { error: 'Format durasi tidak valid' };

        if (parsed === 'permanent') {
            db.users[userId] = {
                reason,
                bannedAt: now.format(),
                permanent: true
            };
        } else {
            const expiredAt = now.clone().add(parsed.value, parsed.unit);

            db.users[userId] = {
                reason,
                bannedAt: now.format(),
                expiredAt: expiredAt.format(),
                permanent: false
            };
        }

        saveDB(db);

        return {
            banned: true,
            message: 'User berhasil dibanned'
        };
    }

    if (action === 'unban') {
        if (!db.users[userId]) return { banned: false };

        delete db.users[userId];
        saveDB(db);

        return {
            banned: false,
            message: 'User berhasil diunban'
        };
    }

    return null;
}

module.exports = BannedDB;

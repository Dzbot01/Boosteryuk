const manager = require('../index');

function loadDB() {
    let doc = manager.getDoc('userDB');
    if (doc === null || doc === undefined) {
        manager.setDoc('userDB', { groups: {} });
        doc = { groups: {} };
    }
    if (!doc.groups) doc.groups = {};
    return doc;
}

function saveDB(db) {
    manager.setDoc('userDB', db);
}

function ChatDB({ groupId, userId, action = 'add', count = 1 }) {
    if (!groupId) return null;

    const db = loadDB();

    if (!db.groups[groupId]) {
        db.groups[groupId] = { users: {} };
    }

    const group = db.groups[groupId];

    if (action === 'get') {
        return Object.entries(group.users).map(([uid, data]) => ({
            userId: uid,
            totalChat: data.totalChat,
            lastChat: data.lastChat
        }));
    }

    if (!userId) return null;

    if (!group.users[userId]) {
        group.users[userId] = {
            totalChat: 0,
            lastChat: 0
        };
    }

    const user = group.users[userId];

    switch (action) {
        case 'add':
            user.totalChat += count;
            user.lastChat = Date.now();
            break;

        case 'reset':
            user.totalChat = 0;
            user.lastChat = Date.now();
            break;
    }

    saveDB(db);

    return {
        groupId,
        userId,
        totalChat: user.totalChat,
        lastChat: user.lastChat
    };
}

module.exports = ChatDB;

const manager = require('../index');
const registry = require('../registry');
const fs = require('fs');

function namespaceFor(filePath) {
    return registry.normalizeNamespaceForFile(filePath);
}

function readJsonFileSync(filePath) {
    try {
        if (!fs.existsSync(filePath)) return null;
        return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    } catch {
        return null;
    }
}

function loadDB(filePath, defaultValue) {
    const ns = namespaceFor(filePath);
    if (manager.store.has(ns)) {
        const doc = manager.getDoc(ns);
        if (doc !== null && doc !== undefined) return doc;
        return defaultValue === undefined ? null : defaultValue;
    }
    const fromFile = readJsonFileSync(filePath);
    if (fromFile !== null && fromFile !== undefined) {
        manager.setDoc(ns, fromFile);
        return manager.getDoc(ns);
    }
    const initial = defaultValue === undefined ? null : defaultValue;
    manager.setDoc(ns, initial);
    return manager.getDoc(ns);
}

function saveDB(filePath, data) {
    const ns = namespaceFor(filePath);
    manager.setDoc(ns, data === undefined ? null : data);
    return true;
}

function deleteDB(filePath) {
    const ns = namespaceFor(filePath);
    return manager.deleteDoc(ns);
}

function existsDB(filePath) {
    const ns = namespaceFor(filePath);
    return manager.store.has(ns);
}

module.exports = { loadDB, saveDB, deleteDB, existsDB, namespaceFor };

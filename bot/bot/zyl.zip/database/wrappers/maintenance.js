const manager = require('../index');
const { requireProject } = require('../utils/requireProject');

const logger = requireProject('App/function/logger');

const DEFAULT_DB = {
    enabled: false,
    reason: '',
    startAt: null,
    endAt: null,
    duration: 0,
    updatedAt: null
};

function readDB() {
    let doc = manager.getDoc('maintenance');
    if (doc === null || doc === undefined || typeof doc !== 'object' || Array.isArray(doc)) {
        manager.setDoc('maintenance', { ...DEFAULT_DB });
        return { ...DEFAULT_DB };
    }
    return { ...DEFAULT_DB, ...doc };
}

function saveDB(data) {
    manager.setDoc('maintenance', data);
}

function formatDuration(ms) {
    if (!ms || ms <= 0) return '0 Detik';

    const sec = Math.floor(ms / 1000);

    const day = Math.floor(sec / 86400);
    const hour = Math.floor((sec % 86400) / 3600);
    const min = Math.floor((sec % 3600) / 60);
    const second = sec % 60;

    const result = [];

    if (day) result.push(`${day} Hari`);
    if (hour) result.push(`${hour} Jam`);
    if (min) result.push(`${min} Menit`);
    if (second || !result.length) result.push(`${second} Detik`);

    return result.join(' ');
}

function formatDate(time) {
    if (!time) return '-';

    return new Date(time).toLocaleString('id-ID', {
        day: '2-digit',
        month: 'long',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
}

const maintenanceCooldown = new Map();

async function isMaintenance(owner, m) {
    const db = readDB();

    if (!db.enabled) return false;
    if (owner) return false;

    if (db.endAt && Date.now() >= db.endAt) {
        db.enabled = false;
        db.updatedAt = Date.now();
        saveDB(db);
        maintenanceCooldown.clear();
        return false;
    }

    const remaining = db.endAt ? Math.max(0, db.endAt - Date.now()) : 0;

    const text = `🚧 *BOT SEDANG MAINTENANCE*

Mohon maaf, saat ini bot sedang dalam proses maintenance.

*📌 Alasan*
${db.reason || 'Tidak ada'}

*🕒 Dimulai*
${formatDate(db.startAt)}

*⏰ Estimasi Selesai*
${db.endAt ? formatDate(db.endAt) : 'Belum ditentukan'}

*⌛ Sisa Waktu*
${db.endAt ? formatDuration(remaining) : 'Tidak diketahui'}

Silakan coba kembali beberapa saat lagi.
Terima kasih atas pengertian dan kesabarannya. 🙏`;

    const jid = m.chat;
    const now = Date.now();
    const cooldown = 1_800_000;

    const last = maintenanceCooldown.get(jid) || 0;

    if (now - last >= cooldown) {
        maintenanceCooldown.set(jid, now);
        logger.warning(text);
        await m.reply(text);
    }

    return true;
}

function enableMaintenance({ duration = 0, reason = 'Maintenance' } = {}) {
    const now = Date.now();

    const db = {
        enabled: true,
        reason,
        startAt: now,
        endAt: duration > 0 ? now + duration : null,
        duration,
        updatedAt: now
    };

    saveDB(db);

    logger.success(`Maintenance diaktifkan (${reason})${duration ? ` selama ${formatDuration(duration)}` : ''}`);

    return db;
}

function disableMaintenance() {
    const db = readDB();

    db.enabled = false;
    db.reason = '';
    db.startAt = null;
    db.endAt = null;
    db.duration = 0;
    db.updatedAt = Date.now();

    saveDB(db);

    logger.success('Maintenance dinonaktifkan.');

    return db;
}

function updateMaintenance(data = {}) {
    const db = readDB();

    Object.assign(db, data);

    if (typeof data.duration === 'number') {
        db.endAt = data.duration > 0 ? Date.now() + data.duration : null;
    }

    db.updatedAt = Date.now();

    saveDB(db);

    logger.info('Data maintenance berhasil diperbarui.');

    return db;
}

function getMaintenanceInfo() {
    const db = readDB();

    const remaining = db.enabled && db.endAt ? Math.max(0, db.endAt - Date.now()) : 0;

    return {
        enabled: db.enabled,
        reason: db.reason,
        startAt: db.startAt,
        startAtText: formatDate(db.startAt),
        endAt: db.endAt,
        endAtText: formatDate(db.endAt),
        duration: db.duration,
        durationText: formatDuration(db.duration),
        remaining,
        remainingText: db.endAt ? formatDuration(remaining) : 'Tidak diketahui',
        updatedAt: db.updatedAt,
        updatedAtText: formatDate(db.updatedAt)
    };
}

module.exports = {
    isMaintenance,
    enableMaintenance,
    disableMaintenance,
    updateMaintenance,
    getMaintenanceInfo,
    formatDuration,
    formatDate
};

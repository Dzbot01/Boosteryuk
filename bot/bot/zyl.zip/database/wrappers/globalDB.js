const _ = require('lodash');
const manager = require('../index');

const DEFAULT_DATA = {
    users: {},
    chats: {},
    database: {},
    groups: {},
    game: {},
    settings: {},
    others: {},
    sticker: {}
};

class LowDBCompat {
    constructor() {
        this.data = null;
        this.READ = false;
        this.chain = null;
        this._writeQueue = Promise.resolve();
    }

    async read() {
        let doc = manager.getDoc('database');
        if (doc === null || doc === undefined) {
            doc = {};
            manager.setDoc('database', doc);
        }
        this.data = {
            ...DEFAULT_DATA,
            ...doc
        };
        this.chain = _.chain(this.data);
        return this.data;
    }

    async write() {
        if (this.data === null) return false;
        const payload = this.data;
        this._writeQueue = this._writeQueue
            .then(() => {
                manager.setDoc('database', payload);
            })
            .catch(() => {});
        await this._writeQueue;
        return true;
    }

    reload() {
        this.data = null;
        return this.read();
    }
}

async function createGlobalDB() {
    const db = new LowDBCompat();
    await db.read();
    return db;
}

module.exports = { LowDBCompat, createGlobalDB, DEFAULT_DATA };

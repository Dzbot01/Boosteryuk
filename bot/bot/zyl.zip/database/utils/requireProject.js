const path = require('path');

const PROJECT_ROOT = path.resolve(__dirname, '../..');

function requireProject(projectPath) {
    try {
        return require(path.join(PROJECT_ROOT, projectPath));
    } catch (err) {
        const err2 = err;
        if (projectPath.startsWith('App/')) {
            return require(path.join(PROJECT_ROOT, projectPath));
        }
        throw err2;
    }
}

module.exports = { requireProject, PROJECT_ROOT };

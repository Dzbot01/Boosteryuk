const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { DbLogger } = require('./logger');

const BACKUP_DIR = path.resolve(process.cwd(), 'Storage/backups');

/**
 * Cek apakah gzip compression diaktifkan.
 * - Default true (D5 — backup tidak di-compress sebelumnya, boros disk).
 * - Bisa di-override via `options.compress` atau `config.database.backupCompress`.
 */
function shouldCompress(options = {}) {
    if (typeof options.compress === 'boolean') return options.compress;
    try {
        const cfg = require('../../config');
        return cfg?.database?.backupCompress !== false;
    } catch {
        return true;
    }
}

function listBackups(backupDir = BACKUP_DIR) {
    try {
        return fs
            .readdirSync(backupDir)
            .filter((f) => f.endsWith('.json') || f.endsWith('.json.gz') || f.endsWith('.zip'))
            .map((f) => {
                const full = path.join(backupDir, f);
                const stat = fs.statSync(full);
                return { name: f, path: full, bytes: stat.size, createdAt: stat.mtime.toISOString() };
            })
            .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    } catch {
        return [];
    }
}

async function createBackup(sourceType, options = {}) {
    const engine = options.engine || null;
    let data;
    if (engine) {
        data = await engine.exportFrom(sourceType, options.overrides || {});
    } else {
        const { createDriver } = require('./migration');
        const driver = createDriver(sourceType, options.overrides || {});
        await driver.connect();
        try {
            data = await driver.exportAll();
        } finally {
            await driver.disconnect().catch(() => {});
        }
    }

    const backupDir = options.backupDir || BACKUP_DIR;
    fs.mkdirSync(backupDir, { recursive: true });
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const jsonStr = JSON.stringify(data, null, 2);

    const compress = shouldCompress(options);
    const ext = compress ? '.json.gz' : '.json';
    const backupPath = path.join(backupDir, `backup-${sourceType}-${stamp}${ext}`);

    if (compress) {
        const gz = zlib.gzipSync(jsonStr, { level: 9 });
        fs.writeFileSync(backupPath, gz);
    } else {
        fs.writeFileSync(backupPath, jsonStr, 'utf-8');
    }

    const stats = fs.statSync(backupPath);
    return {
        path: backupPath,
        type: sourceType,
        compressed: compress,
        namespaces: Object.keys(data).length,
        bytes: stats.size,
        rawBytes: Buffer.byteLength(jsonStr),
        createdAt: new Date().toISOString(),
        restore: async (restoreOptions) => restoreBackup(backupPath, sourceType, restoreOptions || options)
    };
}

async function restoreBackup(backupPath, targetType, options = {}) {
    if (!fs.existsSync(backupPath)) {
        throw new Error(`File backup tidak ditemukan: ${backupPath}`);
    }

    // Auto-detect format gzip
    const isGzip = backupPath.endsWith('.gz');
    let data;
    if (isGzip) {
        const gz = fs.readFileSync(backupPath);
        const json = zlib.gunzipSync(gz).toString('utf-8');
        data = JSON.parse(json);
    } else {
        data = JSON.parse(fs.readFileSync(backupPath, 'utf-8'));
    }

    const { createDriver } = require('./migration');
    const driver = createDriver(targetType, options.overrides || {});
    await driver.connect();
    try {
        let count = 0;
        for (const [ns, doc] of Object.entries(data)) {
            if (doc === null || doc === undefined) continue;
            await driver.saveDocument(ns, doc);
            count += 1;
        }
        return { restored: count, target: targetType, sourceCompressed: isGzip };
    } finally {
        await driver.disconnect().catch(() => {});
    }
}

function startScheduleBackup(types = ['json'], intervalHours = 24, options = {}) {
    const logger = options.logger || new DbLogger({ tag: 'BACKUP' });
    const intervalMs = Math.max(1, intervalHours) * 60 * 60 * 1000;
    const timer = setInterval(async () => {
        for (const type of types) {
            try {
                const result = await createBackup(type, options);
                const ratio = result.rawBytes ? ((1 - result.bytes / result.rawBytes) * 100).toFixed(1) : '0';
                logger.success(
                    `Backup terjadwal ${type}: ${result.path} (${result.namespaces} namespace, ${result.bytes} bytes` +
                        (result.compressed ? `, compress ${ratio}%` : '') + ')'
                );
            } catch (err) {
                logger.error(`Backup terjadwal ${type} gagal: ${err.message}`);
            }
        }
    }, intervalMs);
    if (typeof timer.unref === 'function') timer.unref();
    logger.info(`Schedule backup aktif setiap ${intervalHours} jam untuk: ${types.join(', ')}`);
    return timer;
}

function pruneBackups(keep = 10, backupDir = BACKUP_DIR) {
    const backups = listBackups(backupDir);
    const removed = [];
    for (const backup of backups.slice(keep)) {
        try {
            fs.rmSync(backup.path, { force: true });
            removed.push(backup.name);
        } catch {}
    }
    return removed;
}

module.exports = { createBackup, restoreBackup, listBackups, startScheduleBackup, pruneBackups, BACKUP_DIR };

if (require.main === module) {
    const args = process.argv.slice(2);
    const logger = new DbLogger({ tag: 'BACKUP' });

    (async () => {
        if (args[0] === 'list') {
            const backups = listBackups();
            if (!backups.length) {
                console.log('Belum ada backup.');
                return;
            }
            for (const b of backups) {
                console.log(`${b.name}  ${(b.bytes / 1024).toFixed(1)} KB  ${b.createdAt}`);
            }
            return;
        }

        if (args[0] === 'restore') {
            const backupPath = args[1];
            const target = args[2] || 'json';
            if (!backupPath) {
                console.log('Penggunaan: node database/utils/backup.js restore <path-backup> [target-type]');
                process.exit(1);
            }
            const result = await restoreBackup(backupPath, target);
            logger.success(`Restore ${result.restored} namespace ke ${result.target}`);
            return;
        }

        if (args[0] === 'prune') {
            const removed = pruneBackups(Number(args[1]) || 10);
            logger.info(`Dihapus ${removed.length} backup lama`);
            return;
        }

        const type = args[0] || 'json';
        const result = await createBackup(type);
        const ratio = result.rawBytes ? ((1 - result.bytes / result.rawBytes) * 100).toFixed(1) : '0';
        logger.success(
            `Backup ${type} dibuat: ${result.path} (${result.namespaces} namespace, ${(result.bytes / 1024).toFixed(1)} KB` +
                (result.compressed ? `, compress ${ratio}%` : '') + ')'
        );
    })().catch((err) => {
        logger.error(err.message);
        process.exit(1);
    });
}

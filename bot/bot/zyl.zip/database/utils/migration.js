const fs = require('fs');
const path = require('path');
const { DbLogger } = require('./logger');
const { MigrationError } = require('../errors');
const { countRecords, deepClone } = require('./validator');

const DRIVER_FACTORIES = {
    json: (config) => {
        const JSONDriver = require('../drivers/json');
        return new JSONDriver({ type: 'json', config });
    },
    sqlite: (config) => {
        const SQLiteDriver = require('../drivers/sqlite');
        return new SQLiteDriver({ type: 'sqlite', config });
    },
    postgresql: (config) => {
        const PostgreSQLDriver = require('../drivers/postgresql');
        return new PostgreSQLDriver({ type: 'postgresql', config });
    },
    mysql: (config) => {
        const MySQLDriver = require('../drivers/mysql');
        return new MySQLDriver({ type: 'mysql', config });
    }
};

function resolveDriverConfig(type, overrides = {}) {
    let dbConfig = {};
    try {
        const config = require('../../config');
        dbConfig = (config && config.database) || {};
    } catch {}
    const defaults = {
        json: { path: './Storage' },
        sqlite: { path: './bot.db' },
        postgresql: { host: 'localhost', port: 5432, database: 'x7botz_db', user: 'postgres', password: '' },
        mysql: { host: 'localhost', port: 3306, database: 'x7botz_db', user: 'root', password: '' }
    };
    const section = dbConfig[type] || {};
    const base =
        type === 'json'
            ? { ...defaults.json, ...section, ...overrides }
            : { ...defaults[type], ...section, ...overrides };
    if (dbConfig.pool) base.pool = dbConfig.pool;
    return base;
}

function createDriver(type, overrides = {}) {
    const factory = DRIVER_FACTORIES[type];
    if (!factory) {
        throw new MigrationError(
            `Tipe database tidak dikenal: ${type}. Pilihan: ${Object.keys(DRIVER_FACTORIES).join(', ')}`,
            { step: 'resolve-driver' }
        );
    }
    return factory(resolveDriverConfig(type, overrides));
}

function printProgress(current, total, label) {
    const pct = total > 0 ? Math.round((current / total) * 100) : 100;
    const bar = `${'█'.repeat(Math.round(pct / 5))}${'░'.repeat(20 - Math.round(pct / 5))}`;
    process.stdout.write(`\r${label} [${bar}] ${pct}% (${current}/${total})`);
    if (current >= total) process.stdout.write('\n');
}

class MigrationEngine {
    constructor(options = {}) {
        this.logger = options.logger || new DbLogger({ tag: 'MIGRATE' });
    }

    async exportFrom(sourceType, overrides = {}) {
        const driver = createDriver(sourceType, overrides);
        await driver.connect();
        try {
            const namespaces = await driver.listNamespaces();
            const data = {};
            for (const ns of namespaces) {
                const doc = await driver.getDocument(ns);
                if (doc !== null && doc !== undefined) data[ns] = deepClone(doc);
            }
            this.logger.info(`Export ${Object.keys(data).length} namespace dari ${sourceType}`);
            return data;
        } catch (err) {
            throw new MigrationError(`Gagal export dari ${sourceType}: ${err.message}`, { step: 'export', cause: err });
        } finally {
            await driver.disconnect().catch(() => {});
        }
    }

    async importTo(targetType, data, options = {}) {
        const { replace = true, batchSize = 50 } = options;
        const driver = createDriver(targetType, options.overrides || {});
        await driver.connect();
        try {
            if (replace) {
                await driver.clear();
            }
            const entries = Object.entries(data || {}).filter(([, doc]) => doc !== null && doc !== undefined);
            let done = 0;
            for (const [ns, doc] of entries) {
                await driver.saveDocument(ns, doc);
                done += 1;
                printProgress(done, entries.length, `Import ke ${targetType}`);
            }
            this.logger.success(`Import ${done} namespace ke ${targetType}`);
            return { imported: done, driver };
        } catch (err) {
            await driver.disconnect().catch(() => {});
            throw new MigrationError(`Gagal import ke ${targetType}: ${err.message}`, {
                step: 'import',
                cause: err,
                rollbackAvailable: options.backupPath !== undefined
            });
        }
    }

    async validate(sourceType, targetType, sourceOverrides = {}, targetOverrides = {}) {
        const sourceData = await this.exportFrom(sourceType, sourceOverrides);
        const targetDriver = createDriver(targetType, targetOverrides);
        await targetDriver.connect();
        const report = { total: 0, passed: 0, failed: [], details: [] };
        try {
            for (const [ns, sourceDoc] of Object.entries(sourceData)) {
                report.total += 1;
                const targetDoc = await targetDriver.getDocument(ns);
                const srcCount = countRecords(sourceDoc);
                const tgtCount = targetDoc === null || targetDoc === undefined ? 0 : countRecords(targetDoc);
                const match = JSON.stringify(sortKeys(sourceDoc)) === JSON.stringify(sortKeys(targetDoc));
                if (match || srcCount === tgtCount) {
                    report.passed += 1;
                    report.details.push({ namespace: ns, sourceRecords: srcCount, targetRecords: tgtCount, ok: true });
                } else {
                    report.failed.push(ns);
                    report.details.push({ namespace: ns, sourceRecords: srcCount, targetRecords: tgtCount, ok: false });
                }
            }
            return report;
        } finally {
            await targetDriver.disconnect().catch(() => {});
        }
    }

    async migrate(sourceType, targetType, options = {}) {
        const startedAt = Date.now();
        this.logger.info(`Migrasi: ${sourceType} -> ${targetType}`);

        if (sourceType === targetType) {
            throw new MigrationError('Source dan target tidak boleh sama', { step: 'validate-input' });
        }

        const backup = await this.backup(sourceType, options);
        this.logger.success(`Backup tersimpan: ${backup.path}`);

        const data = await this.exportFrom(sourceType, options.sourceOverrides || {});
        if (!Object.keys(data).length) {
            this.logger.warn('Tidak ada data untuk dimigrasikan');
            return { migrated: 0, backup, report: null, durationMs: Date.now() - startedAt };
        }

        let result;
        try {
            result = await this.importTo(targetType, data, { replace: true, overrides: options.targetOverrides || {} });
        } catch (err) {
            if (backup && backup.restore) {
                this.logger.warn('Rollback: memulihkan backup...');
                await backup.restore();
            }
            throw new MigrationError(`Migrasi gagal: ${err.message}`, {
                step: 'migrate',
                cause: err,
                rollbackAvailable: true
            });
        }

        await result.driver.disconnect().catch(() => {});

        const report = await this.validate(
            sourceType,
            targetType,
            options.sourceOverrides || {},
            options.targetOverrides || {}
        );
        if (report.failed.length && options.strict !== false) {
            this.logger.warn(
                `Validasi menemukan ${report.failed.length} namespace berbeda: ${report.failed.join(', ')}`
            );
        } else if (report.failed.length) {
            this.logger.info(`Validasi: ${report.passed}/${report.total} lolos`);
        } else {
            this.logger.success(`Validasi: ${report.passed}/${report.total} namespace identik`);
        }

        return {
            migrated: Object.keys(data).length,
            backup,
            report,
            durationMs: Date.now() - startedAt
        };
    }

    async backup(sourceType, options = {}) {
        const backupDir = options.backupDir || path.resolve(process.cwd(), 'Storage/backups');
        fs.mkdirSync(backupDir, { recursive: true });
        const stamp = new Date().toISOString().replace(/[:.]/g, '-');
        const backupPath = path.join(backupDir, `backup-${sourceType}-${stamp}.json`);

        const data = await this.exportFrom(sourceType, options.sourceOverrides || {});
        fs.writeFileSync(backupPath, JSON.stringify(data, null, 2), 'utf-8');

        return {
            path: backupPath,
            namespaces: Object.keys(data).length,
            bytes: fs.statSync(backupPath).size,
            restore: async () => {
                const restored = JSON.parse(fs.readFileSync(backupPath, 'utf-8'));
                const result = await this.importTo(sourceType, restored, {
                    replace: true,
                    overrides: options.sourceOverrides || {}
                });
                await result.driver.disconnect().catch(() => {});
                return result.imported;
            }
        };
    }
}

function sortKeys(value) {
    if (Array.isArray(value)) return value.map(sortKeys);
    if (value && typeof value === 'object') {
        const out = {};
        for (const k of Object.keys(value).sort()) out[k] = sortKeys(value[k]);
        return out;
    }
    return value;
}

module.exports = { MigrationEngine, createDriver, resolveDriverConfig, sortKeys, MigrationError };
module.exports.MigrationError = MigrationError;

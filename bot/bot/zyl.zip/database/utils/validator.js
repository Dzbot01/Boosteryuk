const { ValidationError } = require('../errors');

const NAMESPACE_RE = /^[a-zA-Z0-9_-]{1,64}(:[a-zA-Z0-9_.-]{1,128})*$/;
const JID_RE = /^[\w.\-+@:]{1,128}$/;

function assertNamespace(ns) {
    if (typeof ns !== 'string' || ns.length === 0 || ns.length > 200) {
        throw new ValidationError(`Namespace tidak valid: "${ns}"`, { field: 'namespace' });
    }
    if (ns.startsWith('jadibot:')) {
        const segments = ns.split(':');
        if (segments.length < 2 || segments.slice(1).some((s) => !/^[\w.-]{1,128}$/.test(s))) {
            throw new ValidationError(`Namespace jadibot tidak valid: "${ns}"`, { field: 'namespace' });
        }
        return ns;
    }
    if (!NAMESPACE_RE.test(ns)) {
        throw new ValidationError(`Namespace tidak valid: "${ns}"`, { field: 'namespace' });
    }
    return ns;
}

function assertKey(key) {
    if (key === undefined || key === null) return key;
    if (typeof key !== 'string') {
        throw new ValidationError('Key harus berupa string', { field: 'key' });
    }
    if (key.length > 256) {
        throw new ValidationError('Key terlalu panjang (maks 256 karakter)', { field: 'key' });
    }
    return key;
}

function assertValue(value) {
    if (value === undefined) {
        throw new ValidationError('Value tidak boleh undefined (gunakan null)', { field: 'value' });
    }
    const json = JSON.stringify(value);
    if (json === undefined) {
        throw new ValidationError('Value tidak dapat di-serialisasi ke JSON', { field: 'value' });
    }
    return value;
}

function safeParse(raw, fallback = null) {
    if (raw === undefined || raw === null) return fallback;
    if (typeof raw === 'object') return raw;
    try {
        return JSON.parse(raw);
    } catch {
        return fallback;
    }
}

function isPlainObject(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value) && !(value instanceof Date);
}

function deepClone(value) {
    if (value === undefined || value === null) return value;
    return JSON.parse(JSON.stringify(value));
}

function mergeDefaults(target, defaults) {
    if (!isPlainObject(target) || !isPlainObject(defaults)) return target;
    const out = { ...target };
    for (const [k, v] of Object.entries(defaults)) {
        if (out[k] === undefined) out[k] = deepClone(v);
        else if (isPlainObject(v)) out[k] = mergeDefaults(out[k], v);
    }
    return out;
}

function looksLikeJid(str) {
    return typeof str === 'string' && JID_RE.test(str) && str.includes('@');
}

function countRecords(doc) {
    if (doc === null || doc === undefined) return 0;
    if (Array.isArray(doc)) return doc.length;
    if (isPlainObject(doc)) {
        if (doc.groups && isPlainObject(doc.groups)) {
            let total = 0;
            for (const g of Object.values(doc.groups)) {
                if (g && isPlainObject(g.users)) total += Object.keys(g.users).length;
                else if (g && isPlainObject(g)) total += Object.keys(g).filter((k) => k !== 'users').length;
            }
            return total || Object.keys(doc.groups).length;
        }
        if (doc.users && isPlainObject(doc.users)) return Object.keys(doc.users).length;
        if (Array.isArray(doc.transactions)) return doc.transactions.length;
        return Object.keys(doc).length;
    }
    return 1;
}

function sanitizeFilename(name) {
    return String(name)
        .replace(/[^\w.-]/g, '_')
        .slice(0, 128);
}

function patternToRegex(pattern) {
    if (!pattern) return null;
    if (pattern instanceof RegExp) return pattern;
    const escaped = String(pattern)
        .replace(/[.+?^${}()|[\]\\]/g, '\\$&')
        .replace(/\*/g, '.*')
        .replace(/\?/g, '.');
    return new RegExp(`^${escaped}$`);
}

module.exports = {
    assertNamespace,
    assertKey,
    assertValue,
    safeParse,
    isPlainObject,
    deepClone,
    mergeDefaults,
    looksLikeJid,
    countRecords,
    sanitizeFilename,
    patternToRegex
};

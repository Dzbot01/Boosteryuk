let config = null;
try {
    config = require('@Config');
} catch {
    try {
        config = require('../../config');
    } catch {
        config = {};
    }
}

const LEVELS = { debug: 10, info: 20, warn: 30, error: 40, silent: 100 };

let projectLogger = null;
try {
    projectLogger = require('@App/function/logger');
} catch {
    try {
        projectLogger = require('../../App/function/logger');
    } catch {
        projectLogger = null;
    }
}

function fallbackLog(level, tag, msg) {
    const line = String(msg).toUpperCase();
    if (level === 'error') console.error(`[DB:${tag}] ${line}`);
    else if (level === 'warn') console.warn(`[DB:${tag}] ${line}`);
    else console.log(`[DB:${tag}] ${line}`);
}

function write(level, tag, msg, meta) {
    const text = meta !== undefined ? `${msg} ${typeof meta === 'string' ? meta : JSON.stringify(meta)}` : msg;
    if (projectLogger && typeof projectLogger[level] === 'function') {
        try {
            projectLogger[level](text);
            return;
        } catch {}
    }
    fallbackLog(level, tag, text);
}

class DbLogger {
    constructor(context = {}) {
        this.context = context;
        this.debugEnabled = Boolean(
            context.debug !== undefined ? context.debug : (config.database && config.database.debug) || false
        );
    }

    setDebug(value) {
        this.debugEnabled = Boolean(value);
    }

    child(extra = {}) {
        return new DbLogger({ ...this.context, ...extra, debug: this.debugEnabled });
    }

    debug(msg, meta) {
        if (!this.debugEnabled) return;
        write('debug', this.context.tag || 'DEBUG', msg, meta);
    }

    info(msg, meta) {
        write('info', this.context.tag || 'INFO', msg, meta);
    }

    success(msg, meta) {
        // Satu baris bersih, misal: DATABASE ACTIVE ( JSON ) — tanpa prefix berantakan.
        if (projectLogger && typeof projectLogger.success === 'function') {
            try {
                projectLogger.success(msg);
                return;
            } catch {}
        }
        write('info', this.context.tag || 'INFO', msg, meta);
    }

    warn(msg, meta) {
        write('warn', this.context.tag || 'WARN', msg, meta);
    }

    error(msg, meta) {
        write('error', this.context.tag || 'ERROR', msg, meta);
    }
}

module.exports = { DbLogger };

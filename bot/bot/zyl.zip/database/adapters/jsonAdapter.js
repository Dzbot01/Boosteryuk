const storage = require('../wrappers/storage');

class JsonCompatAdapter {
    constructor(filePath, defaultValue = {}) {
        this.filePath = filePath;
        this.defaultValue = defaultValue;
        this.namespace = storage.namespaceFor(filePath);
    }

    loadDB() {
        return storage.loadDB(this.filePath, this.defaultValue);
    }

    saveDB(data) {
        return storage.saveDB(this.filePath, data);
    }

    deleteDB() {
        return storage.deleteDB(this.filePath);
    }

    existsDB() {
        return storage.existsDB(this.filePath);
    }

    update(mutator) {
        const data = this.loadDB();
        const result = mutator(data);
        this.saveDB(result === undefined ? data : result);
        return result === undefined ? data : result;
    }
}

function createAdapter(filePath, defaultValue = {}) {
    return new JsonCompatAdapter(filePath, defaultValue);
}

module.exports = JsonCompatAdapter;
module.exports.createAdapter = createAdapter;
module.exports.JsonCompatAdapter = JsonCompatAdapter;

const { deepClone } = require('./utils/validator');

class Cache {
    constructor(options = {}) {
        this.maxSize = options.maxSize || 500;
        this.ttl = options.ttl !== undefined ? options.ttl : 30000;
        this.enabled = options.enabled !== false;
        this.store = new Map();
        this.hits = 0;
        this.misses = 0;
        this.evictions = 0;
    }

    _isExpired(entry) {
        return entry.expiresAt !== null && Date.now() > entry.expiresAt;
    }

    get(key) {
        if (!this.enabled) return undefined;
        const entry = this.store.get(key);
        if (!entry) {
            this.misses += 1;
            return undefined;
        }
        if (this._isExpired(entry)) {
            this.store.delete(key);
            this.misses += 1;
            return undefined;
        }
        entry.accessedAt = Date.now();
        this.hits += 1;
        return entry.value;
    }

    set(key, value, ttl) {
        if (!this.enabled) return false;
        if (this.store.size >= this.maxSize) {
            this._evict();
        }
        const effectiveTtl = ttl !== undefined ? ttl : this.ttl;
        this.store.set(key, {
            value: deepClone(value),
            expiresAt: effectiveTtl > 0 ? Date.now() + effectiveTtl : null,
            accessedAt: Date.now()
        });
        return true;
    }

    _evict() {
        let oldestKey = null;
        let oldestTime = Infinity;
        for (const [key, entry] of this.store) {
            if (this._isExpired(entry)) {
                this.store.delete(key);
                this.evictions += 1;
                continue;
            }
            if (entry.accessedAt < oldestTime) {
                oldestTime = entry.accessedAt;
                oldestKey = key;
            }
        }
        if (oldestKey !== null && this.store.size >= this.maxSize) {
            this.store.delete(oldestKey);
            this.evictions += 1;
        }
    }

    invalidate(key) {
        return this.store.delete(key);
    }

    invalidatePattern(pattern) {
        const regex =
            pattern instanceof RegExp
                ? pattern
                : new RegExp(
                      `^${String(pattern)
                          .replace(/[.+?^${}()|[\]\\]/g, '\\$&')
                          .replace(/\*/g, '.*')}$`
                  );
        let count = 0;
        for (const key of this.store.keys()) {
            if (regex.test(key)) {
                this.store.delete(key);
                count += 1;
            }
        }
        return count;
    }

    clear() {
        const size = this.store.size;
        this.store.clear();
        return size;
    }

    get size() {
        return this.store.size;
    }

    getStats() {
        const total = this.hits + this.misses;
        return {
            enabled: this.enabled,
            size: this.store.size,
            maxSize: this.maxSize,
            hits: this.hits,
            misses: this.misses,
            evictions: this.evictions,
            hitRate: total > 0 ? Number((this.hits / total).toFixed(4)) : 0
        };
    }
}

module.exports = Cache;

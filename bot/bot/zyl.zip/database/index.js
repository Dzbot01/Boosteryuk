const fs = require('fs');
const path = require('path');
const { DbLogger } = require('./utils/logger');
const MemoryStore = require('./store');
const Cache = require('./cache');
const { DatabaseError, ConnectionError, DriverNotFoundError, wrapError } = require('./errors');
const { assertNamespace, deepClone } = require('./utils/validator');

const DRIVER_PATHS = {
    json: './drivers/json',
    sqlite: './drivers/sqlite',
    postgresql: './drivers/postgresql',
    postgres: './drivers/postgresql',
    mysql: './drivers/mysql',
    mariadb: './drivers/mysql'
};

const TYPE_ALIASES = {
    postgres: 'postgresql',
    mariadb: 'mysql'
};

class DatabaseManager {
    constructor() {
        if (DatabaseManager.instance) {
            return DatabaseManager.instance;
        }
        DatabaseManager.instance = this;
        this.logger = new DbLogger({ tag: 'MANAGER' });
        this.config = this._loadDbConfig();
        this.driver = null;
        this.driverType = null;
        this.store = new MemoryStore({
            flushIntervalMs: this.config.flushIntervalMs,
            onFlush: (payload) => this._persistDirty(payload)
        });
        this.cache = new Cache({ enabled: this.config.cacheEnabled !== false, ttl: this.config.cacheTtl });
        this.ready = null;
        this.switching = false;
        this.reconnectTimer = null;
        this.reconnectAttempts = 0;
        this.watcher = null;
        this.watchFileRef = null;
        this.degraded = false;
        this.startedAt = Date.now();
        this.bootPromise = null;
    }

    static getInstance() {
        if (!DatabaseManager.instance) {
            DatabaseManager.instance = new DatabaseManager();
        }
        return DatabaseManager.instance;
    }

    _loadDbConfig() {
        let cfg = {};
        try {
            // PENTING: JANGAN delete require.cache di sini. Menghapus cache
            // membuat config.js di-evaluasi ulang → tercipta OBJEK config BARU,
            // sementara modul yang sudah jalan masih memegang objek lama
            // (config "berpecah") — mutasi debug/apikey dll tidak tersinkron.
            // require() biasa (cached) + hot-reload watcher config.js sudah cukup.
            const config = require('../config');
            cfg = (config && config.database) || {};
        } catch (err) {
            cfg = {};
        }
        return {
            type: TYPE_ALIASES[cfg.type] || cfg.type || 'json',
            json: cfg.json || {},
            sqlite: cfg.sqlite || {},
            postgresql: cfg.postgresql || {},
            mysql: cfg.mysql || {},
            pool: cfg.pool || {},
            debug: Boolean(cfg.debug),
            autoMigrate: cfg.autoMigrate !== false,
            fallbackToJson: cfg.fallbackToJson !== false,
            flushIntervalMs: cfg.flushIntervalMs !== undefined ? cfg.flushIntervalMs : 300,
            cacheEnabled: cfg.cacheEnabled,
            cacheTtl: cfg.cacheTtl,
            configPath: cfg.configPath
        };
    }

    _resolveConfigPath() {
        if (this.config.configPath) return path.resolve(this.config.configPath);
        try {
            return require.resolve('../config');
        } catch {
            return path.resolve(process.cwd(), 'config.js');
        }
    }

    _createDriver(type) {
        const normalized = TYPE_ALIASES[type] || type;
        const driverPath = DRIVER_PATHS[normalized];
        if (!driverPath) {
            throw new DriverNotFoundError(type, Object.keys(DRIVER_PATHS));
        }
        const DriverClass = require(driverPath);
        const driverConfig =
            {
                json: { ...this.config.json, debug: this.config.debug },
                sqlite: { ...this.config.sqlite },
                postgresql: { ...this.config.postgresql },
                mysql: { ...this.config.mysql }
            }[normalized] || {};
        return new DriverClass({
            type: normalized,
            config: driverConfig,
            pool: this.config.pool,
            debug: this.config.debug,
            logger: this.logger.child({ tag: normalized.toUpperCase() }),
            maxRetries: this.config.maxRetries,
            baseDelay: this.config.baseDelay
        });
    }

    async connect() {
        if (this.bootPromise) return this.bootPromise;
        this.bootPromise = this._connectInternal();
        return this.bootPromise;
    }

    async _connectInternal() {
        const type = this.config.type;
        try {
            await this._activateDriver(type, { seedFromJson: this.config.autoMigrate && type !== 'json' });
            this.degraded = false;
            this._startConfigWatcher();
            return this.driver;
        } catch (err) {
            if (type !== 'json' && this.config.fallbackToJson) {
                this.logger.error(`DRIVER ${type} GAGAL: ${err.message}. FALLBACK KE JSON.`);
                this.degraded = true;
                await this._activateDriver('json', { seedFromJson: false });
                this._startConfigWatcher();
                return this.driver;
            }
            throw err;
        }
    }

    async _activateDriver(type, options = {}) {
        const driver = this._createDriver(type);
        await driver.connect();

        if (options.seedFromJson) {
            const namespaces = await driver.listNamespaces().catch(() => []);
            if (!namespaces.length) {
                this.logger.info(`AUTO-MIGRATE: Storage/*.json -> ${type}`);
                await this._seedFromJson(driver);
            }
        }

        const snapshot = await driver.exportAll();
        this.store.loadAll(snapshot);

        if (this.driver && this.driver !== driver) {
            await this.driver.disconnect().catch(() => {});
        }

        this.driver = driver;
        this.driverType = type;
        this.reconnectAttempts = 0;
        this.logger.success(`DATABASE ACTIVE ( ${String(type).toUpperCase()} )`);
    }

    async _seedFromJson(targetDriver) {
        const JsonDriver = require('./drivers/json');
        const jsonDriver = new JsonDriver({
            type: 'json',
            config: this.config.json,
            logger: this.logger.child({ tag: 'SEED' })
        });
        await jsonDriver.connect();
        try {
            const data = await jsonDriver.exportAll();
            const count = await targetDriver.importAll(data, { replace: false });
            this.logger.success(`Migrasi otomatis: ${count} namespace dipindahkan ke ${targetDriver.type}`);
        } finally {
            await jsonDriver.disconnect().catch(() => {});
        }
    }

    async _persistDirty(payload) {
        if (!this.driver) return;
        for (const [ns, doc] of Object.entries(payload)) {
            try {
                if (doc === null) {
                    await this.driver.deleteDocument(ns);
                } else {
                    await this.driver.saveDocument(ns, doc, { immediate: true });
                }
                this.cache.invalidatePattern(`${ns}:*`);
                this.cache.invalidate(ns);
            } catch (err) {
                const wrapped = wrapError(err, { driver: this.driverType, namespace: ns });
                this.logger.error(`Gagal persist namespace ${ns}: ${wrapped.message}`);
                this._handleConnectionLoss(wrapped, ns);
                throw wrapped;
            }
        }
    }

    _handleConnectionLoss(err, namespace) {
        if (!(err instanceof ConnectionError) || this.reconnectTimer) return;
        const delay = Math.min(1000 * 2 ** this.reconnectAttempts, 30000);
        this.reconnectAttempts += 1;
        this.logger.warn(
            `Koneksi database terputus. Reconnect dalam ${delay}ms (percobaan ${this.reconnectAttempts})...`
        );
        this.reconnectTimer = setTimeout(async () => {
            this.reconnectTimer = null;
            try {
                await this.reconnect();
            } catch (reconnectErr) {
                this.logger.error(`Reconnect gagal: ${reconnectErr.message}`);
                this._handleConnectionLoss(reconnectErr, namespace);
            }
        }, delay);
        if (typeof this.reconnectTimer.unref === 'function') this.reconnectTimer.unref();
    }

    async ensureReady() {
        if (this.driver && this.driver.connected) return this.driver;
        await this.connect();
        return this.driver;
    }

    async disconnect() {
        this._stopConfigWatcher();
        if (this.reconnectTimer) {
            clearTimeout(this.reconnectTimer);
            this.reconnectTimer = null;
        }
        try {
            await this.store.flushAll();
        } catch (err) {
            this.logger.error(`Gagal flush saat disconnect: ${err.message}`);
        }
        if (this.driver) {
            await this.driver.disconnect().catch(() => {});
            this.driver = null;
            this.driverType = null;
        }
        this.bootPromise = null;
    }

    async reconnect() {
        this.logger.info('Reconnect database...');
        if (this.driver) {
            await this.driver.reconnect().catch((err) => {
                throw wrapError(err, { driver: this.driverType });
            });
            this.reconnectAttempts = 0;
            this.logger.success('Reconnect berhasil');
            return this.driver;
        }
        this.bootPromise = null;
        return this.connect();
    }

    getDriver() {
        return this.driver;
    }

    get type() {
        return this.driverType || this.config.type;
    }

    async switchType(newType, options = {}) {
        const target = TYPE_ALIASES[newType] || newType;
        if (!DRIVER_PATHS[target]) {
            throw new DriverNotFoundError(newType, Object.keys(DRIVER_PATHS));
        }
        if (this.switching)
            throw new DatabaseError('Sedang ada proses switch database lain', { code: 'SWITCH_IN_PROGRESS' });
        this.switching = true;
        const previousType = this.driverType;
        try {
            this.logger.info(`Switch database: ${previousType || this.config.type} -> ${target}`);
            await this.store.flushAll();

            const probe = this._createDriver(target);
            await probe.connect();
            const existingNamespaces = await probe.listNamespaces().catch(() => []);

            if (options.migrate !== false && this.driver && !existingNamespaces.length) {
                this.logger.info('Target database kosong, memindahkan data dari driver sebelumnya...');
                const data = await this.driver.exportAll();
                let count = 0;
                for (const [ns, doc] of Object.entries(data)) {
                    if (doc === null || doc === undefined) continue;
                    await probe.saveDocument(ns, doc, { immediate: true });
                    count += 1;
                }
                this.logger.success(`${count} namespace dipindahkan ke ${target}`);
            } else if (this.driver) {
                const memorySnapshot = this.store.getSnapshot();
                let synced = 0;
                for (const [ns, doc] of Object.entries(memorySnapshot)) {
                    if (doc === null || doc === undefined) continue;
                    await probe.saveDocument(ns, doc, { immediate: true });
                    synced += 1;
                }
                if (synced) this.logger.debug(`Sinkronisasi ${synced} namespace dari memory ke ${target}`);
            }

            if (this.driver) await this.driver.disconnect().catch(() => {});

            const snapshot = await probe.exportAll();
            this.store.loadAll(snapshot);
            this.driver = probe;
            this.driverType = target;
            this.config.type = target;
            this.reconnectAttempts = 0;
            this.degraded = false;
            this.logger.success(`Database sekarang: ${target}`);
            return { from: previousType, to: target, migrated: options.migrate !== false };
        } catch (err) {
            const wrapped = wrapError(err, { driver: target });
            this.logger.error(`Switch ke ${target} gagal: ${wrapped.message}`);
            if (this.driver && !this.driver.connected) {
                try {
                    await this.driver.connect();
                } catch {}
            }
            throw wrapped;
        } finally {
            this.switching = false;
        }
    }

    async reloadConfig() {
        const previousType = this.config.type;
        const previousDebug = this.config.debug;
        this.config = this._loadDbConfig();
        this.logger.setDebug(this.config.debug);
        if (this.driver) this.driver.debug = this.config.debug;
        this.store.flushIntervalMs = this.config.flushIntervalMs;

        const target = this.degraded ? previousType : this.config.type;
        if (this.config.type !== previousType && this.config.type !== this.driverType) {
            await this.switchType(this.config.type);
            return { changed: true, type: this.driverType };
        }
        if (this.config.debug !== previousDebug) {
            this.logger.debug(`Debug mode: ${this.config.debug}`);
        }
        return { changed: false, type: this.driverType || target };
    }

    _startConfigWatcher() {
        this._stopConfigWatcher();
        const configPath = this._resolveConfigPath();
        try {
            const chokidar = require('chokidar');
            this.watcher = chokidar.watch(configPath, {
                ignoreInitial: true,
                awaitWriteFinish: { stabilityThreshold: 300 }
            });
            this.watcher.on('change', () => {
                this.logger.info('config.js berubah, reload konfigurasi database...');
                this.reloadConfig().catch((err) => this.logger.error(`Reload config gagal: ${err.message}`));
            });
            this.logger.debug(`Config watcher aktif (chokidar): ${configPath}`);
            return;
        } catch {
            try {
                let timer = null;
                let lastMtime = 0;
                this.watchFileRef = fs.watchFile(configPath, { interval: 2000 }, (curr, prev) => {
                    if (curr.mtimeMs === prev.mtimeMs) return;
                    if (Date.now() - lastMtime < 500) return;
                    lastMtime = Date.now();
                    if (timer) clearTimeout(timer);
                    timer = setTimeout(() => {
                        this.logger.info('config.js berubah, reload konfigurasi database...');
                        this.reloadConfig().catch((err) => this.logger.error(`Reload config gagal: ${err.message}`));
                    }, 300);
                });
                this.logger.debug(`Config watcher aktif (fs.watchFile): ${configPath}`);
            } catch {}
        }
    }

    _stopConfigWatcher() {
        if (this.watcher) {
            this.watcher.close().catch(() => {});
            this.watcher = null;
        }
        if (this.watchFileRef) {
            try {
                fs.unwatchFile(this._resolveConfigPath());
            } catch {}
            this.watchFileRef = null;
        }
    }

    async _persistDirtyNoop() {}

    async get(key) {
        await this.ensureReady();
        const parsed = this.driver._parseKey(key);
        const cached = this.cache.get(key);
        if (cached !== undefined) return cached;
        const doc = this.store.getDoc(parsed.namespace);
        let value;
        if (doc === null) {
            value = await this.driver.get(key);
        } else if (parsed.subKey === null) {
            value = doc;
        } else {
            value = this.store.getSub(parsed.namespace, parsed.subKey);
        }
        this.cache.set(key, value);
        return value;
    }

    async set(key, value) {
        await this.ensureReady();
        const parsed = this.driver._parseKey(key);
        let result;
        if (parsed.subKey === null) {
            this.store.setDoc(parsed.namespace, value);
            result = value;
        } else {
            result = this.store.setSub(parsed.namespace, parsed.subKey, value);
        }
        this.cache.invalidate(key);
        return result;
    }

    async delete(key) {
        await this.ensureReady();
        const parsed = this.driver._parseKey(key);
        let result;
        if (parsed.subKey === null) {
            result = this.store.deleteDoc(parsed.namespace);
        } else {
            result = this.store.deleteSub(parsed.namespace, parsed.subKey);
        }
        this.cache.invalidate(key);
        return result;
    }

    getDoc(namespace) {
        assertNamespace(namespace);
        return this.store.getDoc(namespace);
    }

    getSub(namespace, subKey) {
        assertNamespace(namespace);
        return this.store.getSub(namespace, subKey);
    }

    setDoc(namespace, doc) {
        assertNamespace(namespace);
        this.store.setDoc(namespace, doc);
        this.cache.invalidatePattern(`${namespace}:*`);
        this.cache.invalidate(namespace);
        return true;
    }

    setSub(namespace, subKey, value) {
        assertNamespace(namespace);
        const result = this.store.setSub(namespace, subKey, value);
        this.cache.invalidatePattern(`${namespace}:*`);
        this.cache.invalidate(namespace);
        return result;
    }

    deleteDoc(namespace) {
        assertNamespace(namespace);
        const result = this.store.deleteDoc(namespace);
        this.cache.invalidatePattern(`${namespace}:*`);
        this.cache.invalidate(namespace);
        return result;
    }

    deleteSub(namespace, subKey) {
        assertNamespace(namespace);
        const result = this.store.deleteSub(namespace, subKey);
        this.cache.invalidatePattern(`${namespace}:*`);
        this.cache.invalidate(namespace);
        return result;
    }

    async flushAll() {
        if (!this.driver) return 0;
        return this.store.flushAll();
    }

    async exportBackup(options = {}) {
        const { createBackup } = require('./utils/backup');
        await this.ensureReady();
        await this.store.flushAll();
        const driverType = this.driverType || this.config.type || 'json';
        const data = await this.driver.exportAll();
        return createBackup(driverType, {
            ...options,
            engine: {
                exportFrom: async () => data
            }
        });
    }

    async healthCheck() {
        const result = {
            manager: {
                healthy: Boolean(this.driver && this.driver.connected),
                type: this.driverType || this.config.type,
                degraded: this.degraded,
                uptimeMs: Date.now() - this.startedAt
            },
            driver: null,
            store: this.store.getStats(),
            cache: this.cache.getStats()
        };
        if (this.driver) {
            result.driver = await this.driver.healthCheck();
            result.manager.healthy = result.driver.healthy;
        } else {
            result.driver = { healthy: false, driver: this.config.type, latency: 0, error: 'belum terhubung' };
        }
        return result;
    }

    getStats() {
        return {
            type: this.driverType || this.config.type,
            degraded: this.degraded,
            driver: this.driver ? this.driver.getStats() : null,
            store: this.store.getStats(),
            cache: this.cache.getStats(),
            uptimeMs: Date.now() - this.startedAt
        };
    }

    /**
     * Menjalankan serangkaian operasi secara atomic.
     *
     * Untuk SQL driver (MySQL / PostgreSQL / SQLite): mendelegasikan ke
     * `driver.transaction()` yang memakai `BEGIN; ...fn...; COMMIT;` (atau
     * `ROLLBACK` on error). Inilah atomicity yang sesungguhnya di level DB.
     *
     * Untuk JSON driver: memakai snapshot di memory + per-namespace file lock
     * via `proper-lockfile` (jika terinstall). Bila `proper-lockfile` tidak
     * ada, fallback ke serial write via `_writeQueue` per namespace.
     */
    async transaction(fn) {
        await this.ensureReady();

        // Path 1: Driver SQL — atomic di level DB.
        if (typeof this.driver.transaction === 'function') {
            const touched = new Set();
            try {
                const result = await this.driver.transaction(async (txCtx) => {
                    // Bridge agar ctx driver-compatible bisa dipanggil seperti
                    // ctx.set('namespace:subKey', value).
                    const bridge = {
                        get: (key) => {
                            try {
                                touched.add(this.driver._parseKey(key).namespace);
                            } catch (_) {}
                            return txCtx.get(key);
                        },
                        set: (key, value) => {
                            try {
                                touched.add(this.driver._parseKey(key).namespace);
                            } catch (_) {}
                            return txCtx.set(key, value);
                        },
                        delete: (key) => {
                            try {
                                touched.add(this.driver._parseKey(key).namespace);
                            } catch (_) {}
                            return txCtx.delete(key);
                        }
                    };
                    return fn(bridge);
                });

                // FIX: driver-level commit (mis. JSON driver) menulis ke file,
                // BUKAN ke MemoryStore — tanpa sinkron ini, getSub/getDoc
                // membaca data stale setelah transaction.
                for (const ns of touched) {
                    const fresh = await this.driver.getDocument(ns).catch(() => null);
                    if (fresh !== null && fresh !== undefined) this.store.setDoc(ns, fresh);
                    else this.store.deleteDoc(ns);
                }
                // Cache kemungkinan stale setelah commit — invalidate semua.
                this.cache.clear();
                return result;
            } catch (err) {
                this.logger.error(`[transaction] driver-level gagal: ${err.message}`);
                throw err;
            }
        }

        // Path 2: JSON driver (atau driver tanpa transaction native) —
        // fallback snapshot + serial write.
        this.logger.debug('[transaction] driver tanpa native tx, pakai memory snapshot fallback.');
        const snapshot = this.store.getSnapshot();
        const writable = {
            get: (key) => {
                const parsed = this.driver._parseKey(key);
                const doc = snapshot[parsed.namespace];
                if (parsed.subKey === null) return doc === undefined || doc === null ? null : deepClone(doc);
                if (Array.isArray(doc)) {
                    const item = doc.find((it) => it && (it.id === parsed.subKey || it.user_id === parsed.subKey));
                    return item === undefined ? null : deepClone(item);
                }
                return doc && typeof doc === 'object' && parsed.subKey in doc ? deepClone(doc[parsed.subKey]) : null;
            },
            set: (key, value) => {
                const parsed = this.driver._parseKey(key);
                if (parsed.subKey === null) snapshot[parsed.namespace] = value;
                else {
                    if (!snapshot[parsed.namespace] || typeof snapshot[parsed.namespace] !== 'object') {
                        snapshot[parsed.namespace] = {};
                    }
                    snapshot[parsed.namespace][parsed.subKey] = value;
                }
                return true;
            },
            delete: (key) => {
                const parsed = this.driver._parseKey(key);
                if (parsed.subKey === null) delete snapshot[parsed.namespace];
                else if (snapshot[parsed.namespace] && typeof snapshot[parsed.namespace] === 'object') {
                    delete snapshot[parsed.namespace][parsed.subKey];
                }
                return true;
            }
        };
        const result = await fn(writable);
        for (const [ns, doc] of Object.entries(snapshot)) {
            if (doc === undefined) continue;
            this.store.setDoc(ns, doc);
        }
        this.cache.clear();
        return result;
    }
}

DatabaseManager.instance = null;

const manager = DatabaseManager.getInstance();

module.exports = manager;
module.exports.DatabaseManager = DatabaseManager;
module.exports.getInstance = () => DatabaseManager.getInstance();
module.exports.BaseDriver = require('./drivers/base');
module.exports.errors = require('./errors');
module.exports.registry = require('./registry');
module.exports.Cache = Cache;
module.exports.MemoryStore = MemoryStore;

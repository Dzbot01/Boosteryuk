const { deepClone } = require('./utils/validator');

class MemoryStore {
    constructor(options = {}) {
        this.docs = new Map();
        this.dirty = new Set();
        this.flushIntervalMs = options.flushIntervalMs !== undefined ? options.flushIntervalMs : 300;
        this.autoFlush = options.autoFlush !== false;
        this.onFlush = options.onFlush || null;
        this.flushTimer = null;
        this.flushing = false;
        this.stats = { flushes: 0, flushedNamespaces: 0, lastFlushAt: null, lastFlushCount: 0, lastFlushMs: 0 };
    }

    has(namespace) {
        return this.docs.has(namespace);
    }

    getDoc(namespace) {
        const doc = this.docs.get(namespace);
        if (doc === undefined) return null;
        return deepClone(doc);
    }

    getSub(namespace, subKey) {
        const doc = this.docs.get(namespace);
        if (doc === undefined || doc === null) return null;
        if (Array.isArray(doc)) {
            const item = doc.find((it) => it && (it.id === subKey || it.user_id === subKey));
            return item === undefined ? null : deepClone(item);
        }
        if (typeof doc !== 'object') return null;
        if (!(subKey in doc)) return null;
        return deepClone(doc[subKey]);
    }

    setDoc(namespace, doc) {
        this.docs.set(namespace, deepClone(doc));
        this.dirty.add(namespace);
        this._scheduleFlush();
    }

    setSub(namespace, subKey, value) {
        let doc = this.docs.get(namespace);
        if (doc === undefined || doc === null) doc = {};
        if (Array.isArray(doc)) {
            const idx = doc.findIndex((it) => it && (it.id === subKey || it.user_id === subKey));
            if (idx === -1) {
                doc.push({ ...(typeof value === 'object' && value !== null ? value : { value }), id: subKey });
            } else if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
                doc[idx] = { ...doc[idx], ...value };
            } else {
                doc[idx] = value;
            }
        } else {
            if (typeof doc !== 'object') doc = {};
            doc[subKey] = deepClone(value);
        }
        this.docs.set(namespace, doc);
        this.dirty.add(namespace);
        this._scheduleFlush();
        return deepClone(value);
    }

    deleteDoc(namespace) {
        const existed = this.docs.delete(namespace);
        if (existed) this.dirty.add(namespace);
        return existed;
    }

    deleteSub(namespace, subKey) {
        const doc = this.docs.get(namespace);
        if (doc === undefined || doc === null) return false;
        let changed = false;
        if (Array.isArray(doc)) {
            const idx = doc.findIndex((it) => it && (it.id === subKey || it.user_id === subKey));
            if (idx !== -1) {
                doc.splice(idx, 1);
                changed = true;
            }
        } else if (typeof doc === 'object' && subKey in doc) {
            delete doc[subKey];
            changed = true;
        }
        if (changed) {
            this.docs.set(namespace, doc);
            this.dirty.add(namespace);
            this._scheduleFlush();
        }
        return changed;
    }

    loadAll(namespaceDocs) {
        for (const [ns, doc] of Object.entries(namespaceDocs || {})) {
            if (doc === undefined) continue;
            this.docs.set(ns, deepClone(doc));
        }
    }

    getSnapshot() {
        const out = {};
        for (const [ns, doc] of this.docs) out[ns] = deepClone(doc);
        return out;
    }

    getDirtyNamespaces() {
        return [...this.dirty];
    }

    markClean(namespaces = null) {
        if (namespaces === null) {
            this.dirty.clear();
            return;
        }
        for (const ns of namespaces) this.dirty.delete(ns);
    }

    _scheduleFlush() {
        if (!this.autoFlush || this.flushTimer) return;
        this.flushTimer = setTimeout(() => {
            this.flushTimer = null;
            this.flush().catch(() => {});
        }, this.flushIntervalMs);
        if (typeof this.flushTimer.unref === 'function') this.flushTimer.unref();
    }

    async flush(namespaces = null) {
        if (!this.onFlush) {
            this.markClean(namespaces);
            return 0;
        }
        if (this.flushing) return 0;
        this.flushing = true;
        const start = Date.now();
        try {
            const targets = namespaces || [...this.dirty];
            if (!targets.length) return 0;
            const payload = {};
            for (const ns of targets) {
                if (this.docs.has(ns)) {
                    payload[ns] = this.docs.get(ns);
                } else {
                    payload[ns] = null;
                }
            }
            const count = Object.keys(payload).length;
            await this.onFlush(payload);
            this.markClean(targets);
            this.stats.flushes += 1;
            this.stats.flushedNamespaces += count;
            this.stats.lastFlushAt = Date.now();
            this.stats.lastFlushCount = count;
            this.stats.lastFlushMs = Date.now() - start;
            return count;
        } finally {
            this.flushing = false;
        }
    }

    async flushAll() {
        if (this.flushTimer) {
            clearTimeout(this.flushTimer);
            this.flushTimer = null;
        }
        return this.flush();
    }

    getStats() {
        return {
            namespaces: this.docs.size,
            dirty: this.dirty.size,
            ...this.stats
        };
    }

    dispose() {
        if (this.flushTimer) {
            clearTimeout(this.flushTimer);
            this.flushTimer = null;
        }
        this.docs.clear();
        this.dirty.clear();
    }
}

module.exports = MemoryStore;

class DatabaseError extends Error {
    constructor(message, options = {}) {
        super(message);
        this.name = 'DatabaseError';
        this.code = options.code || 'DATABASE_ERROR';
        this.driver = options.driver || null;
        this.namespace = options.namespace || null;
        this.key = options.key || null;
        this.cause = options.cause || null;
        this.retryable = Boolean(options.retryable);
        this.timestamp = Date.now();
    }

    toJSON() {
        return {
            name: this.name,
            code: this.code,
            message: this.message,
            driver: this.driver,
            namespace: this.namespace,
            key: this.key,
            retryable: this.retryable,
            timestamp: this.timestamp
        };
    }
}

class ConnectionError extends DatabaseError {
    constructor(message, options = {}) {
        super(message, {
            ...options,
            code: options.code || 'CONNECTION_ERROR',
            retryable: options.retryable !== false
        });
        this.name = 'ConnectionError';
    }
}

class QueryError extends DatabaseError {
    constructor(message, options = {}) {
        super(message, { ...options, code: options.code || 'QUERY_ERROR' });
        this.name = 'QueryError';
        this.sql = options.sql || null;
        this.params = options.params || null;
    }
}

class MigrationError extends DatabaseError {
    constructor(message, options = {}) {
        super(message, { ...options, code: options.code || 'MIGRATION_ERROR' });
        this.name = 'MigrationError';
        this.step = options.step || null;
        this.rollbackAvailable = Boolean(options.rollbackAvailable);
    }
}

class ValidationError extends DatabaseError {
    constructor(message, options = {}) {
        super(message, { ...options, code: options.code || 'VALIDATION_ERROR' });
        this.name = 'ValidationError';
        this.field = options.field || null;
    }
}

class DriverNotFoundError extends DatabaseError {
    constructor(type, available = []) {
        super(`Database driver "${type}" tidak tersedia. Driver terdaftar: ${available.join(', ') || 'tidak ada'}`, {
            code: 'DRIVER_NOT_FOUND'
        });
        this.name = 'DriverNotFoundError';
        this.type = type;
    }
}

const ERROR_PATTERNS = {
    connection: [
        /ECONNREFUSED/i,
        /ECONNRESET/i,
        /ETIMEDOUT/i,
        /EHOSTUNREACH/i,
        /ENETUNREACH/i,
        /EPIPE/i,
        /connection (terminated|ended|closed|refused)/i,
        /server has gone away/i,
        /connection pool (is )?(closed|destroyed)/i,
        /the database connection is not open/i,
        /terminating connection/i,
        /client has encountered a connection error/i,
        /can't reach database server/i
    ],
    duplicate: [/duplicate key/i, /UNIQUE constraint failed/i, /ER_DUP_ENTRY/i, /SQLITE_CONSTRAINT_UNIQUE/i],
    notFound: [/does not exist/i, /no such table/i, /no such column/i, /ER_NO_SUCH_TABLE/i, /42P01/i],
    deadlock: [/deadlock/i, /ER_LOCK_DEADLOCK/i, /SQLITE_BUSY/i, /database is locked/i, /40P01/i]
};

function classifyError(err) {
    const msg = String(err && (err.message || err));
    if (ERROR_PATTERNS.connection.some((rx) => rx.test(msg))) return 'connection';
    if (ERROR_PATTERNS.duplicate.some((rx) => rx.test(msg))) return 'duplicate';
    if (ERROR_PATTERNS.notFound.some((rx) => rx.test(msg))) return 'notFound';
    if (ERROR_PATTERNS.deadlock.some((rx) => rx.test(msg))) return 'deadlock';
    return 'unknown';
}

function wrapError(err, context = {}) {
    if (err instanceof DatabaseError) {
        for (const [k, v] of Object.entries(context)) {
            if (v !== undefined && v !== null && err[k] === null) err[k] = v;
        }
        return err;
    }
    const kind = classifyError(err);
    const opts = {
        cause: err,
        driver: context.driver,
        namespace: context.namespace,
        key: context.key
    };
    if (kind === 'connection') return new ConnectionError(err.message, opts);
    if (kind === 'notFound') return new QueryError(err.message, { ...opts, code: 'SCHEMA_NOT_FOUND' });
    if (kind === 'deadlock') return new QueryError(err.message, { ...opts, code: 'DEADLOCK', retryable: true });
    return new QueryError(err.message, opts);
}

module.exports = {
    DatabaseError,
    ConnectionError,
    QueryError,
    MigrationError,
    ValidationError,
    DriverNotFoundError,
    classifyError,
    wrapError
};

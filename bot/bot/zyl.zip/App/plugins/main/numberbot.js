module.exports = {
    name: 'numberbot',
    category: 'main',
    commands: ['numberbot', 'botnumber'],
    description: 'Menampilkan nomor WhatsApp bot',
    isGroup: false,

    async execute({ m, Yudzxml }) {
        try {
            const botJid = Yudzxml.user.id;
            const botNumber = botJid.split(':')[0].replace(/[^0-9]/g, '');

            const text =
                `🤖 *INFORMASI BOT*\n` +
                `────────────────────────\n` +
                `📞 Nomor Bot : ${botNumber}\n` +
                `🆔 JID      : ${botJid}\n` +
                `────────────────────────\n` +
                `Gunakan nomor ini sesuai kebutuhan integrasi.`;

            m.reply(text);
        } catch (err) {
            console.error('[NUMBERBOT ERROR]', err);
            m.reply('❌ Gagal mengambil nomor bot.');
        }
    }
};

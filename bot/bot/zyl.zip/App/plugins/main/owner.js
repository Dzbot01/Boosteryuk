module.exports = {
    name: 'owner',
    category: 'main',
    commands: ['owner', 'creator'],
    description: 'Menampilkan kontak owner bot',
    isOwner: false,
    isSuperOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,

    async execute({ Yudzxml, m, config, db_owner }) {
        const allOwners = Array.from(new Set([config.superowner, ...db_owner]));

        const vcardTemplate = (name, contact) =>
            'BEGIN:VCARD\n' +
            'VERSION:3.0\n' +
            `N:${name};;;;\n` +
            `FN:${name}\n` +
            `TEL;type=CELL;type=VOICE;waid=${contact}:${contact}\n` +
            `EMAIL;type=INTERNET:${config.email}\n` +
            `ADR;type=HOME:;;${config.region};;;;\n` +
            'URL:https://yydz.biz.id\n' +
            'END:VCARD';

        const list = await Promise.all(
            allOwners.map(async (kontakowner) => {
                const jid = kontakowner + '@s.whatsapp.net';
                const name = await Yudzxml.getName(jid);

                return {
                    displayName: name,
                    vcard: vcardTemplate(name, kontakowner)
                };
            })
        );

        await Yudzxml.sendMessage(
            m.chat,
            {
                contacts: {
                    displayName: `${db_owner.length} Owner`,
                    contacts: list
                },
                contextInfo: {
                    forwardingScore: 7,
                    isForwarded: true,
                    mentionedJid: [m.sender]
                }
            },
            { quoted: m }
        );

        const media = 'https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/5f797812.webp';
        await Yudzxml.sendImageAsSticker(m.chat, media, m, {
            packname: Yudzxml.identity.packname,
            author: Yudzxml.identity.author
        });
    }
};

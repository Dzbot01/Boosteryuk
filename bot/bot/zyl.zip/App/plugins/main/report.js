module.exports = {
    name: 'report',
    category: 'main',
    commands: ['report', 'lapor'],
    description: 'Mengirim laporan ke owner',

    async execute({ m, Yudzxml }) {
        try {
            const owner = ['6285184112705@s.whatsapp.net'];
            const text = m.text.split(' ').slice(1).join(' ');

            if (!text) {
                return m.reply('Contoh:\n.report bot error bang');
            }

            const sender = m.sender;
            const pushname = m.pushName || 'Tanpa Nama';

            const laporan = `
📨 *REPORT MASUK*

👤 Nama : ${pushname}
📱 Nomor : ${sender}

💬 Pesan :
${text}

📍 Chat :
https://wa.me/${sender.split('@')[0]}
`.trim();

            for (let number of owner) {
                await m.reply(laporan, number);
            }

            m.reply(
                '✅ Laporan Anda telah berhasil diteruskan kepada owner. Tim kami akan segera melakukan peninjauan.'
            );
        } catch (err) {
            console.error('[REPORT ERROR]', err);
            m.reply('❌ Gagal mengirim laporan.');
        }
    }
};

const { setUserLang, isSupported, listSupported, t, DEFAULT_LANG } = require('@App/function/i18n');

module.exports = {
    name: 'setlang',
    category: 'main',
    commands: ['setlang', 'language', 'lang'],
    description: 'Set bot language for current user (id/en)',
    isPrivate: false,

    /**
     * Set bot language for current user (F3).
     *
     * @param {Object} ctx - Plugin context
     */
    async execute(ctx) {
        const { m, args } = ctx;
        const lang = String(args[0] || '').toLowerCase().trim();

        if (!lang) {
            const supported = listSupported().join(', ');
            return m.reply(
                `🌐 *Set Language*\n\n` +
                    `Usage: .setlang <lang>\n\n` +
                    `Supported: ${supported}\n` +
                    `Default: ${DEFAULT_LANG}\n\n` +
                    `Example: .setlang en`
            );
        }

        if (!isSupported(lang)) {
            return m.reply(
                `❌ Language '${lang}' not supported.\n\n` +
                    `Supported: ${listSupported().join(', ')}`
            );
        }

        const ok = setUserLang(m.sender, lang);
        if (!ok) {
            return m.reply(`❌ Failed to set language. Try again later.`);
        }

        const msg = t(lang, 'common.language_set', { lang });
        return m.reply(`✅ ${msg}`);
    }
};

module.exports = {
    name: 'setidch',
    category: 'owner',
    commands: ['setidch', 'delidch'],
    description: 'Pasang/hapus ID channel bot (owner jadibot; support ID, link saluran, atau kode invite)',
    jadibotOnly: true,
    isOwner: true,

    async execute({ m, Yudzxml, args, text, isSuperOwner, command, config }) {
        const jadibotManager = require('../../../src/core/jadibot');

        // Tentukan instance target:
        //  - di bot jadibot            → instance itu sendiri
        //  - di bot utama (owner jadibot) → instance milik pengirim
        //  - superowner di bot utama   → bisa target nomor: .setidch 628xxx <nilai>
        let targetJid = null;
        let targetNumber = '';

        if (Yudzxml.isJadibot) {
            targetJid = Yudzxml.jadibotJid;
            targetNumber = (Yudzxml.jadibotEntry?.number || '').replace(/[^0-9]/g, '');
        } else {
            const owned = jadibotManager.findByOwner(m.sender);
            if (args[0] && /^\d{8,15}$/.test(args[0].replace(/[^0-9]/g, '')) && isSuperOwner) {
                const target = jadibotManager.getByNumber(args[0].replace(/[^0-9]/g, ''));
                if (!target) return m.reply('❌ Nomor tersebut tidak terdaftar sebagai jadibot.');
                targetJid = target.jid;
                targetNumber = target.number;
                args = args.slice(1);
            } else if (owned) {
                targetJid = owned.jid;
                targetNumber = owned.number;
            } else {
                return m.reply(
                    '*_FITUR KHUSUS BOT JADIBOT !!_*\n\n_Daftarkan bot kamu terlebih dahulu lewat website._'
                );
            }
        }

        const value = args.join(' ').trim();

        if (command === 'delidch') {
            await jadibotManager.updateSettings(targetJid, { idch: 'off' });
            return m.reply(`🗑️ *ID channel bot +${targetNumber} dihapus.*\nFitur upch/playch perlu idch dipasang lagi.`);
        }

        if (!value) {
            const current = jadibotManager.getSettings(targetJid)?.idch;
            return m.reply(
                `📡 *ATUR CHANNEL BOT*\n\n` +
                    `Status: ${current ? `terpasang → \`${current}\`` : '_belum dipasang_'}\n\n` +
                    `📌 *Cara pakai:*\n` +
                    `• ${'`.setidch <link saluran>'} — otomatis ambil ID\n` +
                    `• ${'`.setidch <kode invite>'} — ambil dari kode\n` +
                    `• ${'`.setidch <id>@newsletter'} — langsung ID\n` +
                    `• ${'`.delidch'} — hapus\n\n` +
                    `💡 _Ambil link: buka saluranmu → titik tiga → bagikan tautan._\n` +
                    `_Kamu juga bisa cek info saluran: .cekidch <link>_`
            );
        }

        try {
            const settings = await jadibotManager.updateSettings(targetJid, { idch: value });
            return m.reply(
                `✅ *ID channel bot +${targetNumber} terpasang!*\n\n🆔 \`${settings.idch}\`\n\n` +
                    `_Fitur .upch & .playch sekarang mengirim ke saluran ini._`
            );
        } catch (err) {
            return m.reply('❌ ' + (err?.message || 'Gagal memasang idch.'));
        }
    }
};

module.exports = {
    name: 'leaderboard',
    category: 'main',
    commands: ['leaderboard'],
    async execute({ m, getUserStatistics, hariini }) {
        const { totalUsers, topLimit, topLevel, topMoney } = getUserStatistics();

        const line = '━━━━━━━━━━━━━━━━━━━━';

        let text = `🏆 *GLOBAL LEADERBOARD*\n`;
        text += `${line}\n`;
        text += `👥 *Total Pengguna* : ${totalUsers}\n`;
        text += `⏱️ *Update*         : ${hariini}\n`;
        text += `${line}\n\n`;

        text += `🔥 *TOP LIMIT USER*\n`;
        text += `╭───────────────────\n`;
        topLimit.length
            ? topLimit.forEach((u) => {
                  text += `│ ${u.rank}. @${u.jid.split('@')[0]}\n`;
                  text += `│    ➤ Limit : *${u.limit}*\n`;
              })
            : (text += `│ - Data belum tersedia\n`);
        text += `╰───────────────────\n\n`;

        text += `🏅 *TOP LEVEL USER*\n`;
        text += `╭───────────────────\n`;
        topLevel.length
            ? topLevel.forEach((u) => {
                  text += `│ ${u.rank}. @${u.jid.split('@')[0]}\n`;
                  text += `│    ➤ Level : *Lv ${u.level}*\n`;
              })
            : (text += `│ - Data belum tersedia\n`);
        text += `╰───────────────────\n\n`;

        text += `💰 *TOP MONEY USER*\n`;
        text += `╭───────────────────\n`;
        topMoney.length
            ? topMoney.forEach((u) => {
                  text += `│ ${u.rank}. @${u.jid.split('@')[0]}\n`;
                  text += `│    ➤ Balance : *${u.money.toLocaleString()}*\n`;
              })
            : (text += `│ - Data belum tersedia\n`);
        text += `╰───────────────────\n\n`;

        return m.reply(text);
    }
};

const os = require('os');
const { performance } = require('perf_hooks');
const checkDiskSpace = require('check-disk-space').default;

module.exports = {
    name: 'statusbot',
    category: 'main',
    commands: ['infosystem'],
    description: 'Menampilkan status dan performa bot',

    async execute({ m, Yudzxml, runtime, formatSize, formatp, checkBandwidth }) {
        try {
            const mem = process.memoryUsage();
            const totalRAM = os.totalmem();
            const freeRAM = os.freemem();
            const usedRAM = totalRAM - freeRAM;
            const ramPercent = ((usedRAM / totalRAM) * 100).toFixed(2);

            const memDetail = Object.entries(mem)
                .map(([k, v]) => `• ${k.padEnd(12)}: ${formatp(v)}`)
                .join('\n');

            const cpus = os.cpus().map((cpu) => {
                cpu.total = Object.values(cpu.times).reduce((a, b) => a + b, 0);
                return cpu;
            });

            const cpuAgg = cpus.reduce(
                (acc, cpu) => {
                    acc.total += cpu.total;
                    for (const k in cpu.times) acc.times[k] += cpu.times[k];
                    return acc;
                },
                {
                    total: 0,
                    times: { user: 0, nice: 0, sys: 0, idle: 0, irq: 0 }
                }
            );

            const cpuUsageTotal = Object.entries(cpuAgg.times)
                .map(([k, v]) => `• ${k.padEnd(6)}: ${((100 * v) / cpuAgg.total).toFixed(2)}%`)
                .join('\n');

            const cpuCoreDetail = cpus
                .map((cpu, i) => {
                    const usage = Object.entries(cpu.times)
                        .map(([k, v]) => `   • ${k.padEnd(5)}: ${((100 * v) / cpu.total).toFixed(2)}%`)
                        .join('\n');
                    return `🧩 Core ${i + 1}\n${usage}`;
                })
                .join('\n\n');

            const loadAvg = os.loadavg();
            const loadInfo = `
• Load 1m  : ${loadAvg[0].toFixed(2)}
• Load 5m  : ${loadAvg[1].toFixed(2)}
• Load 15m : ${loadAvg[2].toFixed(2)}
`.trim();

            const disk = await checkDiskSpace(process.cwd());
            const diskUsed = disk.size - disk.free;
            const diskPercent = ((diskUsed / disk.size) * 100).toFixed(2);

            let upload = 'N/A';
            let download = 'N/A';
            let uploadSpeed = 'N/A';
            let downloadSpeed = 'N/A';
            try {
                const bw = (await checkBandwidth()) || {};
                upload = bw.upload || '0 Bytes';
                download = bw.download || '0 Bytes';
                uploadSpeed = bw.uploadSpeed || '0 Mb/s';
                downloadSpeed = bw.downloadSpeed || '0 Mb/s';
            } catch {}

            const responseTime = Date.now() - m.messageTimestamp * 1000 + ' ms';

            const timeServer = new Date().toLocaleTimeString('id-ID');

            const response = `
╭───〔 📊 *BOT SYSTEM STATUS* 〕───╮

⚡ *Bot Response*   : ${responseTime}
⏱ *Uptime*         : ${runtime(process.uptime())}
🕒 *Server Time*    : ${timeServer}

🖥️ *System*
• Platform         : ${os.platform()}
• Hostname         : ${os.hostname()}
• OS Version       : ${os.version()}
• NodeJS           : ${process.version}

🌐 *Network*
• Total Upload     : ${upload}
• Total Download   : ${download}
• Upload Speed     : ${uploadSpeed}
• Download Speed   : ${downloadSpeed}

🧠 *Memory*
• RAM Usage        : ${formatSize(usedRAM)} / ${formatSize(totalRAM)} (${ramPercent}%)

📦 *NodeJS Heap*
${memDetail}

💾 *Disk*
• Used             : ${formatSize(diskUsed)} / ${formatSize(disk.size)} (${diskPercent}%)

⚙️ *CPU Overview*
• Model            : ${cpus[0].model.trim()}
• Allocated Cores  : ${cpus.length}

📈 *CPU Load Average*
${loadInfo}

🧠 *CPU Usage (Total)*
${cpuUsageTotal}

🔩 *CPU Core Detail*
${cpuCoreDetail}

╰────────────────────────────────╯
`.trim();

            await Yudzxml.sendMessage(m.chat, { text: response }, { quoted: m });
        } catch (err) {
            console.error('[STATUSBOT ERROR]', err);
            m.reply('❌ Gagal mengambil status bot.');
        }
    }
};

const axios = require('axios');

module.exports = {
    name: 'ping',
    category: 'main',
    commands: ['ping'],
    description: 'Menampilkan response time bot',
    isGroup: false,

    async execute({ m }) {
        const url = 'https://www.google.com';

        const start = process.hrtime.bigint();

        try {
            await axios.get(url, {
                timeout: 10000
            });

            const end = process.hrtime.bigint();
            const ms = Number(end - start) / 1e6;

            return m.reply(`⌬ Response Time: ${ms.toFixed(2)} ms\n⌬ Ping: ${url}`);
        } catch (err) {
            const end = process.hrtime.bigint();
            const ms = Number(end - start) / 1e6;

            return m.reply(`⚠️ Ping Error\n⌬ Message: ${err.message}\n⌬ Time: ${ms.toFixed(2)} ms`);
        }
    }
};

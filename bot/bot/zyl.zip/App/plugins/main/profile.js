module.exports = {
    name: 'profile',
    category: 'main',
    commands: ['me'],
    description: 'Menampilkan profil pengguna (ringkas & detail)',
    isRateLimit: true,
    async execute({ Yudzxml, m, getUser, config, ppuser, isSuperOwner, isOwner, isPremium, pushname }) {
        const user = getUser(m.sender);
        if (!user) {
            return m.reply('❗ Kamu belum terdaftar. Silakan daftar terlebih dahulu.');
        }

        const status = isSuperOwner ? 'SuperOwner' : isOwner ? 'Owner' : isPremium ? 'Premium' : 'User';

        const { limit = 0, money = 0, role = 'Unknown', level_user = 0, level_cache = 0 } = user;

        const limit_meadd = isSuperOwner || isOwner || isPremium ? `Unlimited (${limit})` : String(limit);

        const userId = m.sender.split('@')[0];

        const imageUrl = `${config.apikey.endpoint}/api/canvas/profil?name=${encodeURIComponent(pushname)}&id=${userId}&status=${encodeURIComponent(status)}&limit=${encodeURIComponent(limit_meadd)}&role=${role}&money=${money}&level=${level_user}&level_cache=${level_cache}&pp=${encodeURIComponent(ppuser)}&bgUrl=${encodeURIComponent('https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/7bf93708.jpg')}&apikey=${config.apikey.key}`;

        await Yudzxml.sendMessage(m.chat, { image: { url: imageUrl } }, { quoted: m });
    }
};

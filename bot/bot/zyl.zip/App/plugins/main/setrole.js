module.exports = {
    name: 'setrole',
    category: 'main',
    commands: ['setrole'],
    isGroup: false,
    isAdmin: false,
    isBotAdmins: false,
    isOwner: false,
    isSuperOwner: false,
    isPremium: false,

    async execute({ m, text, getUser, editRole }) {
        const sender = m.sender;
        const role = text.trim();

        const userData = getUser(sender);
        if (!userData) {
            return m.reply(
                '❌ Kamu belum terdaftar.\n' + '📌 Silakan daftar terlebih dahulu dengan perintah:\n' + '➡️ *.daftar*'
            );
        }

        const userLevel = userData.level_user || 0;
        if (userLevel < 5) {
            return m.reply(
                '❌ *AKSES DITOLAK*\n\n' +
                    '🔒 Fitur ini membutuhkan *minimal level 5*.\n' +
                    `📊 Level kamu saat ini: ${userLevel}`
            );
        }

        if (!role) {
            return m.reply('❌ Role tidak boleh kosong.\n' + '📌 Contoh penggunaan:\n' + '➡️ *.setrole Programmer*');
        }

        if (role.length > 20) return m.reply('❌ Role terlalu panjang (maks. 20 karakter).');

        const blacklist = ['superowner', 'owner', 'admin', 'premium'];
        const roleLower = role.toLowerCase();

        if (blacklist.includes(roleLower)) {
            return m.reply(
                '❌ *ROLE TIDAK DIIZINKAN*\n\n' +
                    '🚫 Role tersebut termasuk role khusus sistem.\n' +
                    '📌 Silakan gunakan role lain yang bersifat umum.'
            );
        }

        editRole(sender, role);

        return m.reply(`✅ *ROLE BERHASIL DIUBAH*\n\n` + `🏷️ Role baru : ${role}`);
    }
};

const { getMonthlyStats, getCommandStats, getTopErrors } = require('@App/function/tracker');

module.exports = {
    name: 'stats',
    category: 'owner',
    commands: ['stats', 'statistik', 'botstats'],
    isOwner: true,

    async execute({ m }) {
        const stats = getMonthlyStats();
        const commands = getCommandStats();
        const errors = getTopErrors(5);

        const topCommands = commands
            .slice(0, 8)
            .map((cmd, index) => {
                return `${index + 1}. ${cmd.command}
   📥 ${cmd.total.toLocaleString()} request
   ✅ ${cmd.success.toLocaleString()}  •  ❌ ${cmd.error.toLocaleString()}
   ⚡ ${cmd.averageResponseTime}ms`;
            })
            .join('\n\n');

        const topErrors = errors
            .map((error, index) => {
                return `${index + 1}. ${error.command}
   ❌ ${error.error}
   🔢 ${error.count.toLocaleString()}x`;
            })
            .join('\n\n');

        return m.reply(
            `╭━━━〔 📊 BOT STATISTICS 〕━━━╮
┃
┃ 📅 Periode
┃ └ ${stats.month}
┃
┃ 📥 Total Request
┃ └ ${stats.total.toLocaleString()}
┃
┃ ✅ Berhasil
┃ └ ${stats.success.toLocaleString()}
┃
┃ ❌ Error
┃ └ ${stats.error.toLocaleString()}
┃
┃ 📈 Success Rate
┃ └ ${stats.successRate}%
┃
┃ 📉 Error Rate
┃ └ ${stats.errorRate}%
┃
┃ ⚡ Avg Response
┃ └ ${stats.averageResponseTime}ms
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯

╭━━━〔 🔥 TOP COMMAND 〕━━━╮

${topCommands || 'Belum ada data request.'}

╰━━━━━━━━━━━━━━━━━━━━━━╯

╭━━━〔 ⚠️ TOP ERROR 〕━━━╮

${topErrors || 'Tidak ada error.'}

╰━━━━━━━━━━━━━━━━━━━━━━╯`.trim()
        );
    }
};

module.exports = {
    name: 'menu',
    category: 'main',
    commands: ['menu'],
    description: 'Menampilkan menu bot',
    isOwner: false,
    isSuperOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,
    async execute({ Yudzxml, m, args, prefix, replyimage, buildMenuJSON, config, ucapanWaktu, pushname, emojiwaktu }) {
        const menuData = await buildMenuJSON();
        if (!menuData || !menuData.menu) {
            return m.reply('❌ Error: Data menu tidak dapat dimuat.');
        }

        const inputCategory = args[0] ? args[0].toLowerCase().replace(/\s/g, '') : null;

        let teksMenu = '';

        if (inputCategory) {
            const foundCategory = menuData.menu.find(
                (item) => item.kategori_nostyle.toLowerCase().replace(/\s/g, '') === inputCategory
            );

            if (foundCategory) {
                const listCommand = foundCategory.commands
                    .split(',')
                    .map((cmd) => `│  ˖ ࣪ ݂ ✤ ${cmd.trim()}`)
                    .join('\n');

                teksMenu = `
┌───〔 *ᴍᴇɴᴜ ${foundCategory.kategori}* 〕
│
${listCommand}
╰────────────────────
`;
            } else {
                const listKategori = menuData.menu.map((item) => `│  ˖ ࣪ ݂ ✤ ᴍᴇɴᴜ ${item.kategori}`).join('\n');

                teksMenu = `
┌───〔 *ᴍᴇɴᴜ ᴄᴀᴛᴇɢᴏʀʏ* 〕
│
${listKategori}
╰────────────────────
_ᴋᴇᴛɪᴋ *${prefix}ᴀʟʟᴍᴇɴᴜ* ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ʟɪꜱᴛ ᴀʟʟ ꜰɪᴛᴜʀ_
`;
            }
        } else {
            const listKategori = menuData.menu.map((item) => `│ ˖ ࣪ ݂ ✤ ᴍᴇɴᴜ ${item.kategori}`).join('\n');

            teksMenu = `
┌───〔 *ᴍᴇɴᴜ ᴄᴀᴛᴇɢᴏʀʏ* 〕
│
${listKategori}
╰────────────────────
_ᴋᴇᴛɪᴋ *${prefix}ᴀʟʟᴍᴇɴᴜ* ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ʟɪꜱᴛ ᴀʟʟ ꜰɪᴛᴜʀ_
`;
        }
        await m.reply(teksMenu);
    }
};

module.exports = {
    name: 'play',
    category: 'main',
    commands: ['play'],
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, config, prefix, command, fetchJson }) {
        if (!text) {
            return m.reply(`❌ *Masukkan judul lagu!*\n\n` + `📝 *Contoh:* ${prefix + command} duka last child`);
        }

        try {
            const { endpoint, key } = config.apikey;

            const ytSearch = await fetchJson(
                `${endpoint}/api/search/youtube?q=${encodeURIComponent(text)}&apikey=${key}`
            );

            if (!ytSearch?.status || !ytSearch?.data?.length) {
                return m.reply('❌ *Lagu tidak ditemukan di YouTube.*');
            }

            const yt = ytSearch.data[0];

            let scloud = null;
            try {
                const scSearch = await fetchJson(
                    `${endpoint}/api/search/soundcloud?q=${encodeURIComponent(text)}&apikey=${key}`
                );
                if (scSearch?.status && scSearch?.data?.length && scSearch.data[0]?.link) {
                    scloud = scSearch.data[0];
                }
            } catch {}

            let spotify = null;
            try {
                const spSearch = await fetchJson(
                    `${endpoint}/api/search/spotify?q=${encodeURIComponent(text)}&apikey=${key}`
                );
                if (spSearch?.status && spSearch?.data?.length && spSearch.data[0]?.url) {
                    spotify = spSearch.data[0];
                }
            } catch {}

            const buttons = [];

            buttons.push({
                buttonId: `${prefix}ytmp3 ${yt.url}`,
                buttonText: { displayText: '🎵 YouTube Audio' },
                type: 1
            });

            if (scloud) {
                buttons.push({
                    buttonId: `${prefix}scdl ${scloud.link}`,
                    buttonText: { displayText: '☁️ SoundCloud' },
                    type: 1
                });
            }

            if (spotify) {
                buttons.push({
                    buttonId: `${prefix}spotifydl ${spotify.url}`,
                    buttonText: { displayText: '🎧 Spotify' },
                    type: 1
                });
            }

            const templateMessage = {
                image: { url: yt.thumbnail },
                caption:
                    `*${yt.title}*\n\n` +
                    `👤 *Artist:* ${yt.author || 'Unknown'}\n` +
                    `⏱️ *Durasi:* ${yt.duration || 'Unknown'}\n` +
                    `📌 *Platform tersedia:* ${['YouTube', scloud && 'SoundCloud', spotify && 'Spotify']
                        .filter(Boolean)
                        .join(', ')}`,
                footer: ``,
                buttons,
                headerType: 4,
                contextInfo: {
                    mentionedJid: [m.sender],
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.idch || '120363041436601418@newsletter',
                        newsletterName: config.ownername || 'Music Updates'
                    }
                }
            };

            await Yudzxml.sendMessage(m.chat, templateMessage);
        } catch (err) {
            console.error('[PLAY ERROR]', err);
            m.reply('❌ *Terjadi gangguan sistem.*\nSilakan coba lagi nanti.');
        }
    }
};

module.exports = {
    name: 'source',
    category: 'main',
    commands: ['source', 'script'],
    description: 'Menampilkan informasi source code',

    async execute({ Yudzxml, m, loadPlugins, groupByCategory, prefix, config }) {
        try {
            const pkg = require('../../../package.json');
            const version = pkg.version || 'unknown';

            const getSystemStats = async () => {
                try {
                    const groupedPlugins = await groupByCategory(await loadPlugins());

                    let totalCommands = 0;

                    groupedPlugins.forEach((cat) => {
                        if (Array.isArray(cat.commands)) {
                            totalCommands += cat.commands.length;
                        }
                    });

                    return {
                        cmd: totalCommands,
                        cat: groupedPlugins.length
                    };
                } catch {
                    return {
                        cmd: '?',
                        cat: '?'
                    };
                }
            };

            const stats = await getSystemStats();

            const buttons = [
                {
                    buttonId: `${prefix}owner`,
                    buttonText: {
                        displayText: '👤 Hubungi Owner'
                    },
                    type: 1
                }
            ];

            const thumbnailUrl = 'https://cdn.dyxzy.my.id/files/cda9726a.jpg';

            const captionText = `
╭─「 *X7BOTZ - MD* 」
│
│ ✨ *Version*  : ${version}
│ 🧬 *Engine*   : Node.js + Baileys
│ ⚡ *Commands* : ${stats.cmd} Fitur
│ 📦 *Modules*  : ${stats.cat} Kategori
│ 👤 *Developer*: Yudzxml
│
├─ *SUPPORT*
│ 💎 Premium User
│ 🌐 Rest API ( sewabot, jadibot, premium )
│ 🔘 Button & Rich Message
│ 💳 Payment Gateway
│ 🖥️ Multi Session ( MD )
│
├─ *DATABASE*
│ 🗄️ SQLite
│ 🗄️ MySQL
│ 🗄️ JSON
│ 🗄️ PostgreSQL
│
├─ *FEATURE*
│ 🛡️ Anticall
│ 👁️ Auto Read
│ 💾 Auto Backup
│ 📡 Bot Destination (Group, Private, All)
│ ♻️ Auto Restart
│ 🔐 Auto Block
│ 🧹 Auto Delete
│ 📨 Auto Read Message
│ ⏱️ Auto Typing
│ 🎙️ Auto Recording
│ 🟢 Auto Online
│ 📌 Auto Save Contact
│ 📥 Auto Download Media
│ 🔄 Auto Reconnect
│ 🗂️ Session Management
│ ⚙️ Custom Prefix
│ 🌐 Multi-Device Support
│ 🔌 Plugin System
│ 🧩 Modular System
│ 🚀 Hot Reload
│
├─ *DEVELOPMENT*
│ 💻 JavaScript + TypeScript
│ ⚡ 80% Fitur tersedia via API
│
├─ *SOURCE CODE*
│
│ 💰 *Rp 50.000*
│ ├ Free API Key 1 Bulan
│ ├ No enc
│ └ Tanpa Update
│
│ 💎 *Rp 80.000 — RECOMMENDED*
│ ├ Free API Key 1 Bulan
│ ├ No enc
│ └ Free Update Lifetime
│
╰─ © 2026 *YudzDev* ✨
            `.trim();

            const templateMessage = {
                image: {
                    url: thumbnailUrl
                },
                caption: captionText,
                buttons,
                headerType: 4,
                viewOnce: true,
                contextInfo: {
                    mentionedJid: [m.sender],
                    forwardingScore: 5,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.idch,
                        newsletterName: config.ownername
                    }
                }
            };

            await Yudzxml.sendMessage(m.chat, templateMessage);
        } catch {
            await Yudzxml.sendMessage(
                m.chat,
                {
                    text: '❌ Maaf, terjadi kesalahan internal saat memuat data.'
                },
                {
                    quoted: m
                }
            );
        }
    }
};
module.exports = {
    name: 'profile2',
    category: 'main',
    commands: ['me2'],
    description: 'Menampilkan profil pengguna (text only + external adreply)',

    async execute({ m, Yudzxml, getUser, isSuperOwner, isOwner, isPremium, pushname, ppuser, jammenit, config }) {
        const user = getUser(m.sender);
        if (!user) {
            return m.reply('❗ Kamu belum terdaftar. Silakan daftar terlebih dahulu.');
        }

        const status = isSuperOwner ? 'SuperOwner' : isOwner ? 'Owner' : isPremium ? 'Premium' : 'User';

        const { limit = 0, money = 0, role = 'Unknown', level_user = 0, level_cache = 0 } = user;

        const limit_meadd = isSuperOwner || isOwner || isPremium ? `Unlimited (${limit})` : String(limit);

        const userId = m.sender.split('@')[0];

        const text = `
👤 *PROFIL PENGGUNA*

• Nama: ${pushname || 'User'}
• ID: ${userId}
• Status: ${status}
• Role: ${role}

📊 *STATISTIK*
• Level: ${level_user}
• Level Cache: ${level_cache}
• Money: ${money}
• Limit: ${limit_meadd}
        `;

        return m.reply(text);
    }
};

const more = String.fromCharCode(8206);
const readmore = more.repeat(4001);

module.exports = {
    name: 'allmenu',
    category: 'main',
    commands: ['allmenu'],
    description: 'Menampilkan menu bot',

    isOwner: false,
    isSuperOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,

    async execute({
        Yudzxml,
        m,
        pushname,
        ucapanWaktu,
        emojiwaktu,
        fotomenunya,
        audiomenu,
        config,
        replyimage,
        prefix,
        buildMenuJSON,
        getUserStatistics,
        isSuperOwner,
        isOwner,
        isPremium,
        hariini
    }) {
        const status = isSuperOwner ? '*SuperOwner*' : isOwner ? '*Owner*' : isPremium ? '*Premium*' : '*User*';

        const { total_kategori, total_commands, menu } = await buildMenuJSON();

        let allMenuText = menu
            .map((category) => {
                const listCommand = category.commands
                    .split(',')
                    .map((cmd) => `│  ˖ ࣪ ݂ ✤ ${cmd.trim()}`)
                    .join('\n');

                return `
┌───〔 *${category.kategori}* 〕
│
${listCommand}
╰────────────────────`;
            })
            .join('\n');

        const kategoriRows = menu.map((k) => ({
            title: `˖ ࣪ ݂ ❥  ${k.kategori} ᴍᴇɴᴜ`,
            description: `ʟɪꜱᴛ ᴍᴇɴᴜ ${k.kategori}`,
            id: `${prefix}menu ${k.kategori_nostyle}`
        }));

        const menunya = `
*ʜᴀʟᴏ ᴋᴀᴋ ${pushname}✨, ꜱᴀʏᴀ ʙᴏᴛ ᴀꜱɪꜱᴛᴇɴ ᴄᴇʀᴅᴀꜱ ʙᴇʀʙᴀꜱɪꜱ ᴡʜᴀᴛꜱᴀᴘᴘ ʏᴀɴɢ ᴅɪᴋᴇᴍʙᴀɴɢᴋᴀɴ ᴏʟᴇʜ ᴅᴇᴠ ʙᴇʀɴᴀᴍᴀ ʏᴜᴅᴢxᴍʟ*

*ᴡʜᴀᴛ ᴄᴀɴ ɪ ᴅᴏ ꜰᴏʀ ʏᴏᴜ? ɪ ᴡᴀꜱ ᴄʀᴇᴀᴛᴇᴅ ꜰᴏʀ ᴘʀᴏᴠɪᴅɪɴɢ ɪɴꜰᴏʀᴍᴀᴛɪᴏɴ ᴀɴᴅ ꜱᴜᴘᴘᴏʀᴛ ᴠɪᴀ ᴡʜᴀᴛꜱᴀᴘᴘ ᴍᴇꜱꜱᴀɢᴇ 🍃*

╭──〔 *ᴅᴀꜱʜʙᴏᴀʀᴅ* 〕
├❥
├⌬ ɴᴀᴍᴀ : *${pushname}*
├⌬ ꜱᴛᴀᴛᴜꜱ : ${status}
├⌬ ᴅᴀᴛᴇ : *${hariini}*
├❥
╰───────────────────
${readmore}
${allMenuText}
`;

        await Yudzxml.sendMessage(m.chat, {
            image: { url: fotomenunya },
            fileName: config.ownername,
            mimetype: 'image/png',
            caption: menunya,
            headerType: 4,
            viewOnce: true,
            buttons: [
                {
                    buttonId: 'action',
                    buttonText: { displayText: '📂 Lihat Menu' },
                    type: 4,
                    nativeFlowInfo: {
                        name: 'single_select',
                        paramsJson: JSON.stringify({
                            title: '˖ ࣪ ݂ ✤ ʟɪꜱᴛ ᴍᴇɴᴜ',
                            sections: [
                                {
                                    title: '📚 ᴄᴀᴛᴇɢᴏʀʏ',
                                    rows: kategoriRows
                                }
                            ]
                        })
                    }
                }
            ],
            contextInfo: {
                mentionedJid: [m.sender],
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: config.idch,
                    newsletterName: config.ownername
                }
            }
        });

        if (audiomenu) {
            await Yudzxml.sendMessage(
                m.chat,
                {
                    audio: { url: audiomenu },
                    mimetype: 'audio/ogg; codecs=opus',
                    ptt: true
                },
                { quoted: m }
            );
        }
    }
};

module.exports = {
    name: 'register',
    category: 'main',
    commands: ['daftar', 'register'],
    description: 'Mendaftar untuk menggunakan bot',

    async execute({
        Yudzxml,
        m,
        text,
        args,
        prefix,
        addUser,
        getUser,
        prepareWAMessageMedia,
        proto,
        fotomenunya,
        config
    }) {
        try {
            const isUser = getUser(m.sender);

            if (isUser) {
                return Yudzxml.sendMessage(
                    m.chat,
                    {
                        text: `⚠️ Kamu sudah terdaftar di database bot!`
                    },
                    { quoted: m }
                );
            }

            addUser(m.sender);

            function getWelcomeMessage({ name = 'User', phone = '-' }) {
                const now = new Date();

                const time = now.toLocaleString('id-ID', {
                    dateStyle: 'medium',
                    timeStyle: 'short'
                });

                return `
*✨ PENDAFTARAN BERHASIL*

Halo *${name}* 👋

Data Anda telah berhasil terdaftar
ke dalam sistem kami dengan detail:

👤 Nama        : ${name}
📱 Nomor HP    : ${phone}
🕒 Waktu Daftar: ${time}
📡 Status      : AKTIF

🚀 Seluruh fitur kini dapat digunakan.
⚙️ Sistem siap membantu Anda kapan saja.

Gunakan layanan dengan bijak dan maksimal.
Terima kasih telah bergabung 🤝
`;
            }

            const textMessage = getWelcomeMessage({
                name: m.pushName || 'User',
                phone: m.sender.split('@')[0]
            });

            const media = await prepareWAMessageMedia(
                {
                    image: { url: fotomenunya }
                },
                {
                    upload: Yudzxml.waUploadToServer
                }
            );

            const interactiveMsg = proto.Message.InteractiveMessage.fromObject({
                contextInfo: {
                    mentionedJid: [m.sender],
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.idch,
                        newsletterName: config.ownername
                    }
                },

                header: proto.Message.InteractiveMessage.Header.fromObject({
                    hasMediaAttachment: true,
                    ...media
                }),

                body: proto.Message.InteractiveMessage.Body.fromObject({
                    text: textMessage
                }),

                footer: proto.Message.InteractiveMessage.Footer.fromObject({
                    text: ''
                }),

                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                    buttons: [
                        {
                            name: 'quick_reply',
                            buttonParamsJson: JSON.stringify({
                                display_text: 'MY PROFILE',
                                id: `${prefix}me`
                            })
                        }
                    ]
                })
            });

            await Yudzxml.relayMessage(
                m.chat,
                {
                    viewOnceMessageV2Extension: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadata: {},
                                deviceListMetadataVersion: 2
                            },
                            interactiveMessage: interactiveMsg
                        }
                    }
                },
                {
                    quoted: m
                }
            );
        } catch (error) {
            console.error(`[ERROR] Daftar Plugin:`, error);

            await Yudzxml.sendMessage(
                m.chat,
                {
                    text: 'Maaf, terjadi kesalahan saat memproses pendaftaran Anda.'
                },
                { quoted: m }
            );
        }
    }
};

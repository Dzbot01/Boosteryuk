module.exports = {
    name: 'mute',
    category: 'admin',
    commands: ['mute', 'unmute'],
    isRateLimit: true,
    async execute({ Yudzxml, m, groupSettings, saveGroupSettings, command, prefix, isAdmins, isOwner }) {
        if (!isAdmins && !isOwner) {
            return m.reply('⛔ Perintah ini hanya untuk *Admin Grup* atau *Owner Bot*.');
        }

        const groupId = m.chat;

        if (!groupSettings[groupId]) {
            groupSettings[groupId] = { mute: false };
        }

        const db = groupSettings[groupId];

        if (command === 'mute') {
            if (db.mute) {
                return m.reply('🔇 Grup sudah dalam kondisi *mute*.');
            }

            db.mute = true;
            saveGroupSettings(groupSettings);

            return m.reply(
                '🔕 *Mode Mute Aktif*\n\n' +
                    'Bot akan menahan semua respons otomatis di grup ini.\n' +
                    `Gunakan *${prefix}unmute* untuk mengaktifkan kembali.`
            );
        }

        if (command === 'unmute') {
            if (!db.mute) {
                return m.reply('🔊 Grup sudah dalam kondisi *aktif*.');
            }

            db.mute = false;
            saveGroupSettings(groupSettings);

            return m.reply('🔔 *Mode Mute Dinonaktifkan*\n\n' + 'Bot kembali aktif dan siap melayani grup ini.');
        }
    }
};

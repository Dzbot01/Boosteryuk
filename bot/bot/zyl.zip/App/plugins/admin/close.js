const {
    addSchedule,
    updateSchedule,
    deleteSchedule,
    checkGroupSchedule,
    getTextSettings,
    setTextSettings
} = require('../../function/autoCloseHandler');

module.exports = {
    name: 'close',
    category: 'group',
    commands: ['close'],
    isAdmins: true,
    isBotAdmins: true,
    isGroup: true,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, args, prefix, config }) {
        const textSettings = getTextSettings(m.chat);
        const textClose = textSettings.textClose || config.singlemess.close_grub || '🔒 Grup telah ditutup oleh admin.';

        if (!args[0]) {
            await Yudzxml.groupSettingUpdate(m.chat, 'announcement');
            await m.reply(textClose);
            return;
        }
        const TIME_REGEX = /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/;
        const timeInput = args[0];

        if (!TIME_REGEX.test(timeInput)) {
            return m.reply(
                `❌ *Format waktu tidak valid!*\n\nGunakan format 24 jam:\n🕒 HH:MM\n\nContoh:\n.close 19:00`
            );
        }

        const scheduleResult = addSchedule(m.chat, 'close', timeInput, textClose);

        if (scheduleResult.success) {
            await m.reply(
                `✅ *Jadwal Penutupan Grup Berhasil Disimpan!*\n\n` +
                    `📅 Waktu : ${timeInput} WIB\n` +
                    `⏰ Aksi : Tutup Grup Otomatis\n` +
                    `📝 Pesan : Custom Text / Config\n\n` +
                    `🤖 Bot akan menutup grup dan mengirim pesan sesuai jadwal.`
            );
        }
    }
};

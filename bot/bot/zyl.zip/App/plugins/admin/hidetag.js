module.exports = {
    name: 'hidetag',
    category: 'group',
    commands: ['hidetag', 'ht', 'h'],
    isGroup: true,
    isAdmins: true,
    isRateLimit: true,

    async execute({ m, Yudzxml, groupMetadata, text, YudzCdn, isImage, isVideo, isSticker, isAudio, isMedia, config }) {
        try {
            const texthidetag = m.quoted?.text || text || '';

            const participants =
                groupMetadata?.participants?.flatMap((p) => {
                    const list = [];
                    if (p.id) list.push(p.id);
                    if (p.lid) list.push(p.lid);
                    return list;
                }) || [];

            if (isMedia || isImage || isVideo || isSticker || isAudio) {
                const mediaMessage = m.quoted || m.msg;

                let buffer;

                try {
                    buffer = m.quoted ? await m.quoted.download() : await m.download();
                } catch {
                    buffer = await m.download();
                }

                const url = await YudzCdn(buffer, 'expired');
                const type = mediaMessage.mtype.replace('Message', '');

                await Yudzxml.sendMessage(
                    m.chat,
                    {
                        [type]: { url },
                        caption: texthidetag,
                        mentions: participants
                    },
                    { quoted: m }
                );
            } else {
                await m.reply(texthidetag, m.chat, {
                    mentionedJid: participants
                });
            }
        } catch (err) {
            console.error('Hidetag Error:', err);
            return m.reply(config.mess.error);
        }
    }
};

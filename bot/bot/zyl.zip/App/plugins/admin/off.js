const { listTextToxic } = require('@App/function/toxicHandler');

module.exports = {
    name: 'off',
    category: 'admin',
    commands: ['off'],
    description: 'Menonaktifkan fitur grup',
    isOwner: false,
    isSuperOwner: false,
    isGroup: true,
    isAdmins: true,
    isPremium: false,
    isBotAdmins: true,
    isRateLimit: true,

    async execute({
        Yudzxml,
        m,
        config,
        groupSettings,
        getGroupSettings,
        saveGroupSettings,
        replyimage,
        fotomenunya,
        prefix,
        args,
        welcomeDB,
        leftDB
    }) {
        const thumbUrl = replyimage;

        const featuresList = [
            { id: 'antilink', name: 'ᴀɴᴛɪʟɪɴᴋ' },
            { id: 'antilinkv2', name: 'ᴀɴᴛɪʟɪɴᴋᴠ2' },
            { id: 'antilinkwa', name: 'ᴀɴᴛɪʟɪɴᴋᴡᴀ' },
            { id: 'antilinkwav2', name: 'ᴀɴᴛɪʟɪɴᴋᴡᴀᴠ2' },
            { id: 'antilinktt', name: 'ᴀɴᴛɪʟɪɴᴋᴛɪᴋᴛᴏᴋ' },
            { id: 'antilinkttv2', name: 'ᴀɴᴛɪʟɪɴᴋᴛɪᴋᴛᴏᴋᴠ2' },
            { id: 'antinsfw', name: 'ᴀɴᴛɪɴꜱꜰᴡ' },
            { id: 'antinsfwv2', name: 'ᴀɴᴛɪɴꜱꜰᴡᴠ2' },
            { id: 'antitoxic', name: 'ᴀɴᴛɪᴛᴏxɪᴄ' },
            { id: 'antispamchat', name: 'ᴀɴᴛɪꜱᴘᴀᴍ' },
            { id: 'antipromosi', name: 'ᴀɴᴛɪᴘʀᴏᴍᴏꜱɪ' },
            { id: 'antipromosiv2', name: 'ᴀɴᴛɪᴘʀᴏᴍᴏꜱɪᴠ2' },
            { id: 'antipromosiv3', name: 'ᴀɴᴛɪᴘʀᴏᴍᴏꜱɪᴠ3' },
            { id: 'antidocument', name: 'ᴀɴᴛɪᴅᴏᴄᴜᴍᴇɴᴛ' },
            { id: 'antigambar', name: 'ᴀɴᴛɪɢᴀᴍʙᴀʀ' },
            { id: 'antivideo', name: 'ᴀɴᴛɪᴠɪᴅᴇᴏ' },
            { id: 'antisticker', name: 'ᴀɴᴛɪꜱᴛɪᴄᴋᴇʀ' },
            { id: 'antiaudio', name: 'ᴀɴᴛɪᴀᴜᴅɪᴏ' },
            { id: 'antikontak', name: 'ᴀɴᴛɪᴋᴏɴᴛᴀᴋ' },
            { id: 'antipolling', name: 'ᴀɴᴛɪᴘᴏʟʟɪɴɢ' },
            { id: 'antisw', name: 'ᴀɴᴛɪᴛᴀɢꜱᴡ' },
            { id: 'antiswv2', name: 'ᴀɴᴛɪᴛᴀɢꜱᴡᴠ2' },
            { id: 'antigame', name: 'ᴀɴᴛɪɢᴀᴍᴇ' },
            { id: 'onlyadmin', name: 'ᴏɴʟʏᴀᴅᴍɪɴ' },
            { id: 'antibot', name: 'ᴀɴᴛɪʙᴏᴛ' },
            { id: 'autodownload', name: 'ᴀᴜᴛᴏᴅᴏᴡɴʟᴏᴀᴅ' },
            { id: 'welcome', name: 'ᴡᴇʟᴄᴏᴍᴇ' },
            { id: 'left', name: 'ɢᴏᴏᴅʙʏᴇ' },
            { id: 'autoai', name: 'ᴀᴜᴛᴏᴀɪ' }
        ];

        const generateMenuList = () => {
            let text = `ʟɪsᴛ ꜰɪᴛᴜʀ ɢʀᴏᴜᴘ\n\n`;

            const SMALL_CAPS_MAP = {
                a: 'ᴀ',
                b: 'ʙ',
                c: 'ᴄ',
                d: 'ᴅ',
                e: 'ᴇ',
                f: 'ꜰ',
                g: 'ɢ',
                h: 'ʜ',
                i: 'ɪ',
                j: 'ᴊ',
                k: 'ᴋ',
                l: 'ʟ',
                m: 'ᴍ',
                n: 'ɴ',
                o: 'ᴏ',
                p: 'ᴘ',
                q: 'ǫ',
                r: 'ʀ',
                s: 'ꜱ',
                t: 'ᴛ',
                u: 'ᴜ',
                v: 'ᴠ',
                w: 'ᴡ',
                x: 'x',
                y: 'ʏ',
                z: 'ᴢ'
            };

            const toSmallCaps = (text = '') =>
                text
                    .toLowerCase()
                    .replace(/wa/gi, 'ᴡᴀ')
                    .replace(/v2/gi, 'ᴠ2')
                    .replace(/v3/gi, 'ᴠ3')
                    .split('')
                    .map((c) => SMALL_CAPS_MAP[c] || c)
                    .join('');

            featuresList.forEach((feat) => {
                let icon = config.icon_off;
                let isSetup = false;

                if (feat.id === 'welcome' || feat.id === 'left') {
                    const dbData = feat.id === 'welcome' ? welcomeDB.get(m.chat) : leftDB.get(m.chat);

                    if (dbData && dbData.status === 'on') {
                        icon = config.icon_on;
                    } else if (dbData && dbData.status === 'off') {
                        isSetup = true;
                    }
                } else {
                    const isActive = groupSettings?.[m.chat]?.[feat.id] ?? false;
                    if (isActive) icon = config.icon_on;
                }

                text += `[${icon}] ${toSmallCaps(feat.id)}${isSetup ? ' (Ready)' : ''}\n`;
            });

            text += `\nᴋᴇᴛᴇʀᴀɴɢᴀɴ:\n${config.icon_on} = ꜰɪᴛᴜʀ ᴀᴋᴛɪꜰ\n📌 = ꜰɪᴛᴜʀ ꜱɪᴀᴘ (ᴛᴇᴋꜱ ᴛᴇʀꜱᴇᴅɪᴀ, ᴛᴀᴘɪ ʙᴇʟᴜᴍ ᴅɪ-ᴏɴ)\n${config.icon_off} = ꜰɪᴛᴜʀ ᴍᴀᴛɪ/ʙᴇʟᴜᴍ ꜱᴇᴛᴜᴘ\n\nᴄᴏɴᴛᴏʜ ᴘᴇɴɢɢᴜɴᴀᴀɴ:\n*.ᴏꜰꜰ ᴡᴇʟᴄᴏᴍᴇ* ᴜɴᴛᴜᴋ ᴍᴇɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ ꜰɪᴛᴜʀ`;

            return text;
        };

        if (!args[0]) {
            const sections = featuresList.map((feat) => ({
                title: `˖ ࣪ ݂ ❥  ${feat.name}`,
                description: `ɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ ${feat.name}`,
                id: `${prefix}off ${feat.id}`
            }));

            const menuText = generateMenuList();

            await Yudzxml.sendMessage(m.chat, {
                footer: '',
                buttons: [
                    {
                        buttonId: 'action',
                        buttonText: { displayText: '🛑 NONAKTIFKAN FITUR' },
                        type: 4,
                        nativeFlowInfo: {
                            name: 'single_select',
                            paramsJson: JSON.stringify({
                                title: `ᴄʟɪᴄᴋ ʜᴇʀᴇ`,
                                sections: [
                                    {
                                        title: 'ꜱᴇʟᴇᴄᴛ ꜰᴇᴀᴛᴜʀᴇꜱ',
                                        rows: sections
                                    }
                                ]
                            })
                        }
                    }
                ],
                headerType: 1,
                viewOnce: true,
                image: {
                    url: fotomenunya || 'https://i.imgur.com/6xJmC2I.png'
                },
                fileName: config.ownername,
                mimetype: 'image/png',
                fileLength: 30000,
                caption: menuText,
                contextInfo: {
                    mentionedJid: [m.sender],
                    forwardingScore: 50,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.idch,
                        serverMessageId: 20,
                        newsletterName: config.ownername
                    }
                }
            });
            return;
        }

        const inputFeature = args[0].toLowerCase();
        const featureData = featuresList.find((f) => f.id === inputFeature);

        if (!featureData) {
            return m.reply(
                `❌ Fitur *${inputFeature}* tidak ditemukan!\n\nKetik *${prefix}off* tanpa argumen untuk melihat daftar fitur.`
            );
        }

        if (!groupSettings[m.chat]) {
            groupSettings[m.chat] = {};
        }

        const db = groupSettings[m.chat];

        if (inputFeature === 'antitoxic') {
            const { total } = listTextToxic(m.chat);
            if (!total)
                return m.reply(
                    `⚠️ *ɢᴀɢᴀʟ ᴍᴇɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ ${featureData.name}!*

ᴀɴᴅᴀ ʙᴇʟᴜᴍ ᴍᴇɴɢᴀᴛᴜʀ ᴘᴇꜱᴀɴ ${featureData.name}.
ꜱɪʟᴀᴋᴀɴ ᴀᴛᴜʀ ᴛᴇʀʟᴇʙɪʜ ᴅᴀʜᴜʟᴜ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ᴄᴏᴍᴍᴀɴᴅ:

*${prefix}ᴀᴅᴅᴛᴏxɪᴄ <ᴛᴇᴋꜱ>*`
                );
        }
        if (inputFeature === 'welcome' || inputFeature === 'left') {
            const specificDB = inputFeature === 'welcome' ? welcomeDB : leftDB;
            const data = specificDB.get(m.chat);

            if (!data) {
                return m.reply(
                    `⚠️ *ɢᴀɢᴀʟ ᴍᴇɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ ${featureData.name}!*

ᴅᴀᴛᴀ ${featureData.name} ᴛɪᴅᴀᴋ ᴅɪᴛᴇᴍᴜᴋᴀɴ.
ᴀɴᴅᴀ ᴘᴇʀʟᴜ ᴍᴇɴɢᴀᴛᴜʀ ᴘᴇꜱᴀɴɴʏᴀ ᴛᴇʀʟᴇʙɪʜ ᴅᴀʜᴜʟᴜ (${inputFeature === 'welcome' ? 'ꜱᴇᴛᴡᴇʟᴄᴏᴍᴇ' : 'ꜱᴇᴛʟᴇꜰᴛ'}) ꜱᴇʙᴇʟᴜᴍ ʙɪꜱᴀ ᴅɪᴍᴀᴛɪᴋᴀɴ ᴀᴛᴀᴜ ᴅɪʜɪᴅᴜᴘᴋᴀɴ.`
                );
            }

            if (data.status === 'off') {
                return m.reply(`⚠️ ꜰɪᴛᴜʀ *${featureData.name}* ꜱᴜᴅᴀʜ ɴᴏɴᴀᴋᴛɪꜰ ꜱᴇʙᴇʟᴜᴍɴʏᴀ.`);
            }
        } else {
            if (db[featureData.id] === false) {
                return m.reply(`⚠️ Fitur *${featureData.name}* sudah nonaktif sebelumnya.`);
            }
        }

        if (inputFeature === 'welcome' || inputFeature === 'left') {
            const specificDB = inputFeature === 'welcome' ? welcomeDB : leftDB;
            const currentData = specificDB.get(m.chat);

            specificDB.set(m.chat, {
                ...currentData,
                status: 'off'
            });
        } else {
            db[featureData.id] = false;
            saveGroupSettings(groupSettings);
        }

        const replyMsg = `🚫 *ʙᴇʀʜᴀꜱɪʟ ᴍᴇɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ ${featureData.name}*\n\nꜰɪᴛᴜʀ ɪɴɪ ꜱᴇᴋᴀʀᴀɴɢ ᴛɪᴅᴀᴋ ᴀᴋᴛɪꜰ ᴅɪ ɢʀᴜᴘ.`;
        await m.reply(replyMsg);
    }
};

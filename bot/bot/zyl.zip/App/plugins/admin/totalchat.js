module.exports = {
    name: 'totalchat',
    category: 'admin',
    commands: ['totalchat'],
    description: 'Menampilkan statistik total chat seluruh user grup',
    isGroup: true,
    isAdmins: true,
    isBotAdmins: false,
    isOwner: false,
    isSuperOwner: false,
    isPremium: false,
    isRateLimit: true,

    async execute({ m, ChatDB }) {
        const groupStats = ChatDB({
            groupId: m.chat,
            action: 'get'
        });

        if (!Array.isArray(groupStats) || groupStats.length === 0) {
            return m.reply('📭 Belum ada aktivitas chat yang tercatat di grup ini.');
        }

        const sortedStats = groupStats.filter((v) => v.totalChat > 0).sort((a, b) => b.totalChat - a.totalChat);

        if (sortedStats.length === 0) {
            return m.reply('📭 Data tersedia, namun belum ada chat yang valid.');
        }

        let text = `📊 *TOTAL CHAT GRUP*\n`;
        text += `────────────────────────\n`;

        const mentions = [];

        sortedStats.forEach((user, index) => {
            const jid = user.userId;
            const number = jid.split('@')[0];

            mentions.push(jid);

            const lastChat = user.lastChat > 0 ? new Date(user.lastChat).toLocaleString('id-ID') : '-';

            text +=
                `#${index + 1}\n` +
                `👤 User   : @${number}\n` +
                `💬 Chat   : ${user.totalChat}\n` +
                `🕒 Aktif  : ${lastChat}\n` +
                `────────────────────────\n`;
        });

        text += `📌 Statistik ini bersifat internal grup`;

        await m.reply(text, m.chat, {
            mentionedJid: mentions
        });
    }
};

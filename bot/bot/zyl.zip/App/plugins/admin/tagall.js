module.exports = {
    name: 'tagall',
    category: 'group',
    commands: ['tagall'],
    isGroup: true,
    isRateLimit: true,

    async execute({ m, Yudzxml, participants, pushname, isAdmins, isOwner, text: inputText }) {
        if (!participants || !participants.length) {
            return m.reply('❌ Member grup tidak ditemukan.');
        }

        if (!isAdmins && !isOwner) {
            return m.reply('❌ Perintah ini hanya untuk Admin atau Owner.');
        }

        const mentions = participants.map((p) => p.id);
        const memberList = participants.map((p, i) => `┃ ${i + 1}. @${p.id.split('@')[0]}`).join('\n');

        let message = '';
        let media = null;
        let type = null;

        if (m.quoted) {
            message = m.quoted.text || m.quoted.caption || '';
            if (m.quoted.mimetype) {
                media = await m.quoted.download();
                type = m.quoted.mimetype.split('/')[0];
            }
        } else {
            message = inputText || '';
        }

        const header = `╭─〔 📢 *TAG ALL MEMBER* 〕
┃ Admin menandai seluruh anggota
┃ Admin : ${pushname || 'Admin'}
╰───────────────\n`;

        const body = message ? `📌 *Pesan:*\n${message}\n\n` : '';

        const footer = `╭─〔 👥 *Daftar Member* 〕
${memberList}
╰───────────────`;

        const finalText = header + body + footer;

        if (media && type) {
            await Yudzxml.sendMessage(m.chat, {
                [type]: media,
                caption: finalText,
                mentions
            });
        } else {
            await Yudzxml.sendMessage(m.chat, {
                text: finalText,
                mentions
            });
        }
    }
};

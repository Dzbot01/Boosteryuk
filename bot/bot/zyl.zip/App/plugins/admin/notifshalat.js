const axios = require('axios');

function minusMinutes(time, minutes) {
    const [h, m] = time.split(':').map(Number);
    const date = new Date();
    date.setHours(h);
    date.setMinutes(m - minutes);

    const hh = String(date.getHours()).padStart(2, '0');
    const mm = String(date.getMinutes()).padStart(2, '0');
    return `${hh}:${mm}`;
}

module.exports = {
    commands: ['notifshalat'],
    isGroup: true,
    isAdmins: true,
    isRateLimit: true,
    async execute({ m, args, groupSettings, saveGroupSettings, prefix, command, config }) {
        const chatId = m.chat;
        const firstArg = (args[0] || '').toLowerCase();

        if (!args.length) {
            return m.reply(
                `📌 *Cara penggunaan Notif Sholat*\n\n` +
                    `Aktifkan:\n` +
                    `• ${prefix + command} jakarta\n` +
                    `• ${prefix + command} on jakarta\n\n` +
                    `Nonaktifkan:\n` +
                    `• ${prefix + command} off`
            );
        }

        if (!groupSettings[chatId]) {
            groupSettings[chatId] = {};
        }

        if (firstArg === 'off') {
            if (!groupSettings[chatId].notifSholat?.isActive) {
                return m.reply('ℹ️ Notifikasi sholat sudah nonaktif.');
            }

            groupSettings[chatId].notifSholat.isActive = false;
            saveGroupSettings(groupSettings);

            return m.reply('🛑 Notifikasi sholat berhasil dinonaktifkan.');
        }

        let city = firstArg === 'on' ? args[1] : args[0];

        if (!city) {
            return m.reply(
                `❌ Nama kota belum ditentukan.\n\n` +
                    `Contoh:\n` +
                    `• ${prefix + command} jakarta\n` +
                    `• ${prefix + command} on jakarta`
            );
        }

        try {
            const res = await axios.get(`${config.apikey.endpoint}/api/islami/jadwalshalat`, {
                params: {
                    kota: city,
                    apikey: config.apikey.key
                }
            });

            const json = res.data;

            if (json.status !== 200 || !json?.data?.jadwal) {
                return m.reply(`❌ Jadwal sholat kota *${city}* tidak ditemukan.`);
            }

            const { kota, periode, jadwal } = json.data;

            const result = {
                subuh: jadwal.Shubuh,
                dhuhur: jadwal.Dzuhur,
                ashar: jadwal.Ashr,
                maghrib: jadwal.Maghrib,
                isha: jadwal.Isya,
                imsak: jadwal.Imsyak,
                tanggal: jadwal.Tanggal
            };

            result.buka = minusMinutes(result.maghrib, 5);
            result.sahur = minusMinutes(result.imsak, 60);

            groupSettings[chatId].notifSholat = {
                city: kota.toLowerCase(),
                isActive: true
            };

            saveGroupSettings(groupSettings);

            const teks =
                `✅ *Notifikasi Sholat Aktif*\n\n` +
                `🏙️ Kota     : *${kota.toUpperCase()}*\n` +
                `📆 Periode  : ${periode}\n` +
                `📅 Tanggal  : ${result.tanggal}\n\n` +
                `🕋 Jadwal Sholat:\n` +
                `• Subuh   : ${result.subuh}\n` +
                `• Dzuhur  : ${result.dhuhur}\n` +
                `• Ashar   : ${result.ashar}\n` +
                `• Maghrib : ${result.maghrib}\n` +
                `• Isya    : ${result.isha}\n\n` +
                `🌙 Imsak  : ${result.imsak}\n` +
                `🥣 Sahur  : ${result.sahur}\n` +
                `🍽️ Buka   : ${result.buka}\n\n` +
                `📢 Pengingat otomatis akan dikirim sesuai jadwal.`;

            return m.reply(teks);
        } catch (err) {
            return m.reply('⚠️ Gagal mengambil data jadwal sholat dari server API.');
        }
    }
};

module.exports = {
    name: 'del',
    category: 'admin',
    commands: ['del', 'delete'],
    isGroup: true,
    isAdmins: true,
    isBotAdmins: true,
    isOwner: false,
    isSuperOwner: false,
    isPremium: false,
    isRateLimit: true,

    async execute({ m, Yudzxml }) {
        if (!m.quoted) {
            return m.reply('❌ Reply pesan yang ingin dihapus.');
        }

        await Yudzxml.sendMessage(m.chat, {
            delete: {
                remoteJid: m.chat,
                fromMe: m.quoted.fromMe,
                id: m.quoted.id,
                participant: m.quoted.sender
            }
        });
    }
};

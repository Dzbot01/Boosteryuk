const {
    addSchedule,
    updateSchedule,
    deleteSchedule,
    checkGroupSchedule,
    getTextSettings,
    setTextSettings
} = require('../../function/autoCloseHandler');

module.exports = {
    name: 'setopen',
    category: 'group',
    commands: ['setopen'],
    isAdmins: true,
    isGroup: true,
    isRateLimit: true,
    async execute({ Yudzxml, m, text }) {
        if (!text) {
            return Yudzxml.sendMessage(
                m.chat,
                {
                    text: `⏱️ *Format Penggunaan:*\n\n.setopen Pesan grup dibuka\n\n_Contoh: .setopen Pagi all, grup udah dibuka ya_`
                },
                { quoted: m }
            );
        }

        const result = setTextSettings(m.chat, 'open', text);

        if (result.success) {
            await Yudzxml.sendMessage(
                m.chat,
                {
                    text: `✅ *Teks Open Berhasil Disimpan!*\n\n📝 Pesan: ${text}\n\n_Pesan ini akan digunakan saat grup dibuka otomatis atau manual._`
                },
                { quoted: m }
            );
        }
    }
};

module.exports = {
    name: 'swgc',
    category: 'admin',
    commands: ['swgc'],
    isGroup: true,
    isAdmins: true,
    isRateLimit: true,

    async execute({ Yudzxml, m, text, args, isImage, isVideo, isAudio, config }) {
        const caption = text || args.join(' ') || m.quoted?.text || '';

        let buffer = null;

        try {
            buffer = await m.download();
        } catch {
            try {
                buffer = await m.quoted?.download();
            } catch {
                buffer = null;
            }
        }

        const backgroundColors = [
            '#FF5E5E',
            '#00BFA5',
            '#0296E5',
            '#8E24AA',
            '#E91E63',
            '#00E676',
            '#FF9800',
            '#1A237E',
            '#1ABC9C',
            '#2ECC71',
            '#3498DB',
            '#9B59B6',
            '#E67E22',
            '#E74C3C',
            '#F39C12',
            '#D35400'
        ];

        const randomColor = backgroundColors[Math.floor(Math.random() * backgroundColors.length)];

        const type = isImage ? 'image' : isVideo ? 'video' : isAudio ? 'audio' : text ? 'text' : null;

        if (!buffer || type === 'text') {
            await Yudzxml.sendMessage(m.chat, {
                groupStatusMessage: {
                    text: caption || ' ',
                    backgroundColor: randomColor
                }
            });

            return m.reply(config.mess.success);
        }

        if (type === 'image') {
            await Yudzxml.sendMessage(m.chat, {
                groupStatusMessage: {
                    image: buffer,
                    caption: caption || ''
                }
            });

            return m.reply(config.mess.success);
        }

        if (type === 'video') {
            await Yudzxml.sendMessage(m.chat, {
                groupStatusMessage: {
                    video: buffer,
                    caption: caption || ''
                }
            });

            return m.reply(config.mess.success);
        }

        if (type === 'audio') {
            await Yudzxml.sendMessage(m.chat, {
                groupStatusMessage: {
                    audio: buffer,
                    mimetype: 'audio/ogg; codecs=opus',
                    ptt: true
                }
            });

            return m.reply(config.mess.success);
        }
    }
};

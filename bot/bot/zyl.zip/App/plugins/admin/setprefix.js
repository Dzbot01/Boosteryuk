module.exports = {
    name: 'setprefix',
    commands: ['prefix'],
    isRateLimit: true,

    async execute({ m, args, prefix, command, groupSettings, saveGroupSettings, config, isAdmins, isOwner }) {
        if (!args[0]) {
            return m.reply(`Penggunaan:\n` + `${prefix + command} on\n` + `${prefix + command} off`);
        }

        const option = args[0].toLowerCase();

        if (!['on', 'off'].includes(option)) {
            return m.reply('⚠️ Opsi tidak valid. Gunakan: on / off');
        }

        const value = option === 'on';

        if (!m.isGroup) {
            if (!isOwner) {
                return m.reply('❌ Fitur ini hanya dapat digunakan oleh Owner.');
            }

            config.prefix = value;
            return m.reply(`✅ Prefix global ${value ? 'diaktifkan' : 'dinonaktifkan'}.`);
        }

        if (m.isGroup) {
            if (!isAdmins) {
                return m.reply('❌ Perintah ini hanya dapat digunakan oleh admin grup.');
            }

            if (!groupSettings[m.chat]) {
                groupSettings[m.chat] = {};
            }

            groupSettings[m.chat].prefix = value;
            saveGroupSettings(groupSettings);

            return m.reply(`✅ Prefix grup ${value ? 'diaktifkan' : 'dinonaktifkan'}.`);
        }
    }
};

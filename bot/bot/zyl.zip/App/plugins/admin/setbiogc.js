module.exports = {
    name: 'setbiogc',
    category: 'admin',
    commands: ['setbiogc', 'setdescgc'],
    description: 'Mengubah deskripsi grup',
    isGroup: true,
    isAdmins: true,
    isBotAdmins: true,
    isRateLimit: true,

    async execute({ m, Yudzxml }) {
        if (!m.text) {
            return m.reply('❌ Masukkan deskripsi grup.');
        }

        await Yudzxml.groupUpdateDescription(m.chat, m.text);
        m.reply('✅ Deskripsi grup berhasil diperbarui.');
    }
};

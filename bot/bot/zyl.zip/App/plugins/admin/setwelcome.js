module.exports = {
    name: 'setwelcome',
    category: 'admin',
    commands: ['setwelcome'],
    isGroup: true,
    isAdmins: true,
    isRateLimit: true,

    async execute({ Yudzxml, m, args, prefix, welcomeDB, isImage, YudzCdn }) {
        try {
            let imageUrl = null;

            const typeWelcome = parseInt(args[0]);
            const welcomeText = args.slice(1).join(' ');

            if (isNaN(typeWelcome) || typeWelcome < 1 || typeWelcome > 8) {
                return m.reply(
                    `❌ *Type Welcome tidak valid!*

📝 *Penggunaan:*
${prefix}setwelcome <type> <teks>

🔢 *List Type:*
1 - 7 : Random foto bot
3     : Text only (tanpa foto)
8     : Wajib menggunakan foto pribadi

✨ *Placeholders:*
@NAME  : Nama Member
@GROUP : Nama Grup
@DESC  : Deskripsi Grup

📌 *Contoh:*
${prefix}setwelcome 1 Halo @NAME selamat datang`
                );
            }

            if (!welcomeText) {
                return m.reply(
                    '❌ *Teks welcome tidak boleh kosong.*\nSilakan masukkan teks sambutan setelah angka type.'
                );
            }

            if (typeWelcome === 8) {
                if (!isImage) {
                    return m.reply(
                        `❌ *Type 8 membutuhkan gambar!*

👉 Silakan reply sebuah gambar dengan caption command ini.

Contoh:
Reply gambar ➜ ketik:
${prefix}setwelcome 8 Halo @NAME`
                    );
                }

                try {
                    let buffer;

                    try {
                        buffer = m.quoted ? await m.quoted.download() : await m.download();
                    } catch {
                        buffer = await m.download();
                    }

                    imageUrl = await YudzCdn(buffer, 'expired');
                } catch (err) {
                    console.error('[WELCOME UPLOAD ERROR]', err);

                    return m.reply(
                        '❌ *Gagal mengupload gambar.*\nPastikan koneksi internet stabil atau coba gambar lain.'
                    );
                }
            }

            welcomeDB.set(m.chat, {
                status: 'on',
                typeWelcome,
                text: welcomeText,
                imageUrl
            });

            const imgStatus = typeWelcome === 8 ? '✅ Terupload (CDN)' : '❌ Tidak digunakan';

            await m.reply(
                `✅ *WELCOME MESSAGE BERHASIL DISET*
━━━━━━━━━━━━━━━━━━━━━
🔢 *Type Style* : ${typeWelcome}
📝 *Pesan*      : Tersimpan
🖼️ *Gambar*     : ${imgStatus}
━━━━━━━━━━━━━━━━━━━━━

👋 *Bot siap menyambut member baru!*
_Pesan akan otomatis terkirim saat ada member join._`
            );
        } catch (err) {
            console.error('[SETWELCOME ERROR]', err);

            await m.reply('❌ Terjadi kesalahan saat mengatur welcome message.');
        }
    }
};

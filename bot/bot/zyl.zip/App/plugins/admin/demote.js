module.exports = {
    name: 'demote',
    category: 'admin',
    commands: ['demote'],
    description: 'Menurunkan admin menjadi member',
    isGroup: true,
    isAdmins: true,
    isBotAdmins: true,
    isRateLimit: true,

    async execute({ m, Yudzxml, groupMetadata }) {
        const target = m.mentionedJid?.[0] || m.quoted?.sender;

        if (!target) {
            return m.reply('❌ Reply atau mention admin yang ingin diturunkan.');
        }

        const owner = groupMetadata.owner;
        if (target === owner) {
            return m.reply('⚠️ Owner grup tidak dapat didemote.');
        }

        await Yudzxml.groupParticipantsUpdate(m.chat, [target], 'demote');

        await m.reply(
            `⬇️ *DEMOTE BERHASIL*\n` +
                `────────────────────────\n` +
                `👤 User : @${target.split('@')[0]}\n` +
                `📌 Status: Member`,
            m.chat,
            {
                mentionedJid: [target]
            }
        );
    }
};

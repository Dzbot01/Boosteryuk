module.exports = {
    name: 'kickall',
    category: 'admin',
    commands: ['kickall'],
    description: 'Mengeluarkan seluruh member non-admin',
    isGroup: true,
    isAdmins: true,
    isBotAdmins: true,
    isRateLimit: true,

    async execute({ m, Yudzxml, groupMetadata, args, proto, prefix }) {
        if (args[0] !== '-y') {
            const interactiveMsg = proto.Message.InteractiveMessage.fromObject({
                body: proto.Message.InteractiveMessage.Body.fromObject({
                    text:
                        `⚠️ *PERINGATAN TINDAKAN EKSTREM*\n` +
                        `────────────────────────\n` +
                        `Perintah ini akan *mengeluarkan SELURUH member non-admin* dari grup.\n\n` +
                        `📌 Dampak:\n` +
                        `• Grup akan tersisa admin saja\n` +
                        `• Tidak dapat dibatalkan\n` +
                        `• Berisiko salah pakai\n\n` +
                        `Gunakan hanya jika Anda *benar-benar yakin*.`
                }),

                footer: proto.Message.InteractiveMessage.Footer.fromObject({
                    text: 'Konfirmasi diperlukan'
                }),

                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                    buttons: [
                        {
                            name: 'quick_reply',
                            buttonParamsJson: JSON.stringify({
                                display_text: '✅ Ya, Kick Semua Member',
                                id: `${prefix}kickall -y`
                            })
                        }
                    ]
                })
            });

            await Yudzxml.relayMessage(
                m.chat,
                {
                    viewOnceMessageV2Extension: {
                        message: { interactiveMessage: interactiveMsg }
                    }
                },
                { quoted: m }
            );

            return;
        }

        const targets = groupMetadata.participants.filter((p) => !p.admin).map((p) => p.jid);

        if (targets.length === 0) {
            return m.reply('✅ Tidak ada member non-admin untuk dikeluarkan.');
        }

        for (const user of targets) {
            await Yudzxml.groupParticipantsUpdate(m.chat, [user], 'remove');
        }

        m.reply(
            `🥾 *KICK ALL BERHASIL*\n` +
                `────────────────────────\n` +
                `👥 Total dikeluarkan : ${targets.length}\n` +
                `🛡️ Mode              : Konfirmasi (-y)\n` +
                `⚠️ Risiko            : Tinggi\n` +
                `────────────────────────\n` +
                `Grup kini steril. Tinggal admin, tanpa penonton.`
        );
    }
};

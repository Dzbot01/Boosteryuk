module.exports = {
    name: 'resetlinkgc',
    category: 'admin',
    commands: ['resetlinkgc', 'resetlink'],
    description: 'Mereset link undangan grup',
    isGroup: true,
    isAdmins: true,
    isBotAdmins: true,
    isRateLimit: true,
    async execute({ m, Yudzxml, groupMetadata }) {
        await Yudzxml.groupRevokeInvite(m.chat);

        const newLink = await Yudzxml.groupInviteCode(m.chat);
        const totalMember = groupMetadata.participants.length;

        m.reply(
            `♻️ *RESET LINK BERHASIL*\n` +
                `────────────────────────\n` +
                `👥 Total Member : ${totalMember}\n` +
                `🔐 Link Baru    : https://chat.whatsapp.com/${newLink}\n` +
                `────────────────────────\n` +
                `Link lama telah dinonaktifkan.`
        );
    }
};

module.exports = {
    name: 'add',
    category: 'admin',
    commands: ['add'],
    isGroup: true,
    isAdmins: true,
    isBotAdmins: true,
    isRateLimit: true,

    async execute({ m, Yudzxml, text }) {
        try {
            const number = m.quoted ? m.quoted.sender : text?.replace(/[^0-9]/g, '');

            if (!number) {
                return m.reply(
                    `❌ Masukkan nomor.

Contoh:
.add 62812xxxx`
                );
            }

            const jid = number.includes('@s.whatsapp.net') ? number : `${number}@s.whatsapp.net`;

            await Yudzxml.groupParticipantsUpdate(m.chat, [jid], 'add');
        } catch (err) {
            console.error('[ADD ERROR]', err);
            await m.reply('❌ Gagal menambahkan anggota.');
        }
    }
};

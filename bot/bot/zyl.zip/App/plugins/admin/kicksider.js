const ONE_DAY = 1000 * 60 * 60 * 24;
const INACTIVE_DAYS = 7;
const MIN_CHAT = 2;

module.exports = {
    name: 'kicksider',
    category: 'admin',
    commands: ['kicksider'],
    description: 'Mengeluarkan seluruh member yang diperkirakan sider',
    isGroup: true,
    isAdmins: true,
    isBotAdmins: true,
    isRateLimit: true,

    async execute({ m, ChatDB, groupMetadata, Yudzxml, args, proto, prefix }) {
        if (args[0] !== '-y') {
            const interactiveMsg = proto.Message.InteractiveMessage.fromObject({
                body: proto.Message.InteractiveMessage.Body.fromObject({
                    text:
                        `⚠️ *PERINGATAN TINDAKAN MASSAL*\n` +
                        `────────────────────────\n` +
                        `Perintah ini akan *mengeluarkan seluruh member* yang diperkirakan tidak aktif berdasarkan histori chat.\n\n` +
                        `📌 Kriteria Evaluasi:\n` +
                        `• Tidak pernah chat\n` +
                        `• Total chat ≤ ${MIN_CHAT}\n` +
                        `• Tidak aktif ≥ ${INACTIVE_DAYS} hari\n\n` +
                        `Tindakan ini *tidak dapat dibatalkan*.\n` +
                        `Silakan konfirmasi untuk melanjutkan.`
                }),

                footer: proto.Message.InteractiveMessage.Footer.fromObject({
                    text: ''
                }),

                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                    buttons: [
                        {
                            name: 'quick_reply',
                            buttonParamsJson: JSON.stringify({
                                display_text: '✅ Ya, Lanjutkan Kick',
                                id: `${prefix}kicksider -y`
                            })
                        }
                    ]
                })
            });

            await Yudzxml.relayMessage(
                m.chat,
                {
                    viewOnceMessageV2Extension: {
                        message: {
                            interactiveMessage: interactiveMsg
                        }
                    }
                },
                { quoted: m }
            );

            return;
        }

        const members = groupMetadata.participants.filter((p) => !p.admin).map((p) => p.id);

        const groupStats =
            ChatDB({
                groupId: m.chat,
                action: 'get'
            }) || [];

        const now = Date.now();
        const targetKick = [];

        for (const userId of members) {
            const data = groupStats.find((v) => v.userId === userId);

            if (!data) {
                targetKick.push(userId);
                continue;
            }

            const inactiveDays = (now - data.lastChat) / ONE_DAY;

            if (data.totalChat <= MIN_CHAT || inactiveDays >= INACTIVE_DAYS) {
                targetKick.push(userId);
            }
        }

        if (targetKick.length === 0) {
            return m.reply('✅ Tidak ada member yang memenuhi kriteria kick.');
        }

        for (const user of targetKick) {
            await Yudzxml.groupParticipantsUpdate(m.chat, [user], 'remove');
        }

        m.reply(
            `🥾 *KICK SIDER BERHASIL*\n` +
                `────────────────────────\n` +
                `👥 Total dikeluarkan : ${targetKick.length}\n` +
                `📌 Alasan            : Tidak aktif / minim interaksi\n` +
                `🛡️ Mode              : Konfirmasi Manual (-y)\n` +
                `────────────────────────\n` +
                `Grup kini lebih fokus, bukan sekadar ramai penonton.`
        );
    }
};

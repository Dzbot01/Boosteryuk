module.exports = {
    name: 'promote',
    category: 'admin',
    commands: ['promote'],
    description: 'Menjadikan member sebagai admin',
    isGroup: true,
    isAdmins: true,
    isBotAdmins: true,
    isRateLimit: true,

    async execute({ m, Yudzxml }) {
        const target = m.mentionedJid?.[0] || m.quoted?.sender;

        if (!target) {
            return m.reply('❌ Reply atau mention member yang ingin dipromosikan.');
        }

        await Yudzxml.groupParticipantsUpdate(m.chat, [target], 'promote');

        m.reply(
            `🛡️ *PROMOTE BERHASIL*\n` +
                `────────────────────────\n` +
                `👤 User : @${target.split('@')[0]}\n` +
                `📌 Status: Admin`,
            m.chat,
            {
                mentionedJid: [target]
            }
        );
    }
};

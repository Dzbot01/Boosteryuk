const {
    addSchedule,
    updateSchedule,
    deleteSchedule,
    checkGroupSchedule,
    getTextSettings,
    setTextSettings
} = require('../../function/autoCloseHandler');

module.exports = {
    name: 'setclose',
    category: 'group',
    commands: ['setclose'],
    isAdmins: true,
    isGroup: true,
    isRateLimit: true,
    async execute({ Yudzxml, m, text }) {
        if (!text) {
            return Yudzxml.sendMessage(
                m.chat,
                {
                    text: `⏱️ *Format Penggunaan:*\n\n.setclose Pesan grup ditutup\n\n_Contoh: .setclose Malam all, grup ditutup dulu ya_`
                },
                { quoted: m }
            );
        }

        const result = setTextSettings(m.chat, 'close', text);

        if (result.success) {
            await Yudzxml.sendMessage(
                m.chat,
                {
                    text: `✅ *Teks Close Berhasil Disimpan!*\n\n📝 Pesan: ${text}\n\n_Pesan ini akan digunakan saat grup ditutup otomatis atau manual._`
                },
                { quoted: m }
            );
        }
    }
};

const {
    addSchedule,
    updateSchedule,
    deleteSchedule,
    checkGroupSchedule,
    getTextSettings,
    setTextSettings
} = require('../../function/autoCloseHandler');

module.exports = {
    name: 'open',
    category: 'group',
    commands: ['open'],
    isAdmins: true,
    isBotAdmins: true,
    isGroup: true,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, args, prefix, config }) {
        const textSettings = getTextSettings(m.chat);
        const textOpen = textSettings.textOpen || config.singlemess.open_grub || '🔓 Grup telah dibuka oleh admin.';

        if (!args[0]) {
            await Yudzxml.groupSettingUpdate(m.chat, 'not_announcement');
            await m.reply(textOpen);
            return;
        }

        const TIME_REGEX = /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/;

        const timeInput = args[0];

        if (!TIME_REGEX.test(timeInput)) {
            return m.reply(
                `❌ *Format waktu tidak valid!*\n\nGunakan format 24 jam:\n🕒 HH:MM\n\nContoh:\n.open 19:00`
            );
        }

        const scheduleResult = addSchedule(m.chat, 'open', timeInput, textOpen);

        if (scheduleResult.success) {
            await m.reply(
                `✅ *Jadwal Pembukaan Grup Berhasil Disimpan!*\n\n` +
                    `📅 Waktu : ${timeInput} WIB\n` +
                    `⏰ Aksi : Buka Grup Otomatis\n` +
                    `📝 Pesan : Custom Text / Config\n\n` +
                    `🤖 Bot akan membuka grup dan mengirim pesan sesuai jadwal.`
            );
        }
    }
};

module.exports = {
    name: 'kick',
    category: 'admin',
    commands: ['kick'],
    isGroup: true,
    isAdmins: true,
    isBotAdmins: true,
    isRateLimit: true,

    async execute({ m, Yudzxml }) {
        try {
            if (!m.mentionedJid?.length && !m.quoted) {
                return m.reply('❌ Tag atau reply member yang ingin di-kick.');
            }

            const targets = m.mentionedJid?.length ? [...new Set(m.mentionedJid)] : [m.quoted?.sender].filter(Boolean);

            if (!targets.length) {
                return m.reply('❌ User tidak ditemukan.');
            }

            const botId = Yudzxml.user?.id?.split(':')[0];

            const isBotTargeted = targets.some((jid) => {
                const jidNumber = jid.split('@')[0];
                return jidNumber === botId;
            });

            if (isBotTargeted) {
                return m.reply('❌ Bot tidak bisa kick diri sendiri.');
            }

            await Yudzxml.groupParticipantsUpdate(m.chat, targets, 'remove');
        } catch (err) {
            console.error('Kick Error:', err);
            return m.reply('❌ Gagal mengeluarkan member.');
        }
    }
};

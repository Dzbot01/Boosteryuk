const ONE_DAY = 1000 * 60 * 60 * 24;
const INACTIVE_DAYS = 7;
const MIN_CHAT = 2;

module.exports = {
    name: 'sider',
    category: 'admin',
    commands: ['sider'],
    description: 'Menampilkan daftar member yang diperkirakan tidak aktif',
    isGroup: true,
    isAdmins: true,
    isBotAdmins: false,
    isRateLimit: true,

    async execute({ m, ChatDB, groupMetadata }) {
        const members = groupMetadata.participants.filter((p) => !p.admin).map((p) => p.jid || p.id);

        const groupStats =
            ChatDB({
                groupId: m.chat,
                action: 'get'
            }) || [];

        const now = Date.now();
        const siderList = [];

        for (const userId of members) {
            const data = groupStats.find((v) => v.userId === userId);

            if (!data) {
                siderList.push({
                    userId,
                    reason: 'Tidak pernah tercatat berinteraksi'
                });
                continue;
            }

            const lastChatDiff = (now - data.lastChat) / ONE_DAY;

            if (data.totalChat <= MIN_CHAT || lastChatDiff >= INACTIVE_DAYS) {
                siderList.push({
                    userId,
                    reason:
                        lastChatDiff >= INACTIVE_DAYS
                            ? `Tidak aktif selama ${Math.floor(lastChatDiff)} hari`
                            : 'Jarang berpartisipasi'
                });
            }
        }

        if (siderList.length === 0) {
            return m.reply('✅ Seluruh member terpantau aktif. Grup sehat, lanjutkan.');
        }

        let text = `📉 *LAPORAN MEMBER TIDAK AKTIF*\n`;
        text += `────────────────────────\n`;
        text += `📌 Kriteria: Tidak aktif ≥ ${INACTIVE_DAYS} hari / minim interaksi\n`;
        text += `────────────────────────\n\n`;

        siderList.forEach((v, i) => {
            const number = v.userId.replace('@s.whatsapp.net', '');
            text +=
                `#${i + 1}\n` + `👤 User   : ${number}\n` + `📄 Status : ${v.reason}\n` + `────────────────────────\n`;
        });

        text += `⚠️ Data bersifat estimasi berdasarkan histori chat`;

        await m.reply(text);
    }
};

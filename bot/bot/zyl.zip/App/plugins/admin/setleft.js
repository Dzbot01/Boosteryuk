module.exports = {
    name: 'setleft',
    category: 'admin',
    commands: ['setleft'],
    isGroup: true,
    isAdmins: true,
    isRateLimit: true,

    async execute({ m, args, prefix, leftDB, isImage, YudzCdn }) {
        try {
            let imageUrl = null;

            const typeLeft = parseInt(args[0]);
            const leftText = args.slice(1).join(' ');

            if (isNaN(typeLeft) || typeLeft < 1 || typeLeft > 8) {
                return m.reply(
                    `❌ *Type Left tidak valid!*

📝 *Penggunaan:*
${prefix}setleft <type> <teks>

🔢 *List Type:*
1 - 7 : Hanya teks (tanpa foto)
8     : Wajib menggunakan foto

✨ *Placeholders:*
@NAME  : Nama Member
@GROUP : Nama Grup
@DESC  : Deskripsi Grup

📌 *Contoh:*
${prefix}setleft 1 Selamat tinggal @NAME`
                );
            }

            if (!leftText) {
                return m.reply(
                    '❌ *Teks left tidak boleh kosong.*\nSilakan masukkan teks perpisahan setelah angka type.'
                );
            }

            if (typeLeft === 8) {
                if (!isImage) {
                    return m.reply(
                        `❌ *Type 8 membutuhkan gambar!*

👉 Silakan reply sebuah gambar dengan caption command ini.

Contoh:
Reply gambar ➜ ketik:
${prefix}setleft 8 Sampai jumpa @NAME`
                    );
                }

                try {
                    let buffer;

                    try {
                        buffer = m.quoted ? await m.quoted.download() : await m.download();
                    } catch {
                        buffer = await m.download();
                    }

                    imageUrl = await YudzCdn(buffer, 'expired');
                } catch (err) {
                    console.error('[LEFT UPLOAD ERROR]', err);

                    return m.reply(
                        '❌ *Gagal mengupload gambar.*\nPastikan koneksi internet stabil atau coba gambar lain.'
                    );
                }
            }

            leftDB.set(m.chat, {
                status: 'on',
                typeLeft,
                text: leftText,
                imageUrl
            });

            const imgStatus = typeLeft === 8 ? '✅ Terupload (CDN)' : '❌ Tidak digunakan';

            await m.reply(
                `✅ *GOODBYE MESSAGE BERHASIL DISET*
━━━━━━━━━━━━━━━━━━━━━
🔢 *Type Style* : ${typeLeft}
📝 *Pesan*      : Tersimpan
🖼️ *Gambar*     : ${imgStatus}
━━━━━━━━━━━━━━━━━━━━━

👋 *Bot siap menyapa member keluar!*
_Pesan akan otomatis terkirim saat ada member keluar._`
            );
        } catch (err) {
            console.error('[SETLEFT ERROR]', err);

            await m.reply('❌ Terjadi kesalahan saat mengatur goodbye message.');
        }
    }
};

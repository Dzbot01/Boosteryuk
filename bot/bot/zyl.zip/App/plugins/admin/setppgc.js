module.exports = {
    name: 'setppgc',
    category: 'admin',
    commands: ['setppgc', 'setppgroup'],
    description: 'Mengubah foto profil grup',
    isGroup: true,
    isAdmins: true,
    isBotAdmins: true,
    isRateLimit: true,

    async execute({ m, Yudzxml, isImage, YudzCdn }) {
        try {
            if (!isImage) {
                return m.reply('❌ Reply atau kirim gambar untuk dijadikan foto grup.');
            }

            let buffer = null;

            try {
                buffer = m.quoted ? await m.quoted.download() : await m.download();
            } catch {
                buffer = await m.download();
            }

            const url = await YudzCdn(buffer, 'expired');

            await Yudzxml.updateProfilePicture(m.chat, { url });

            m.reply('✅ Foto profil grup berhasil diperbarui.');
        } catch (err) {
            console.error('[SETPPGC ERROR]', err);
            m.reply('❌ Gagal mengubah foto profil grup.');
        }
    }
};

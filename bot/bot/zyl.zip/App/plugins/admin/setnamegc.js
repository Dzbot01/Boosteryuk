module.exports = {
    name: 'setnamegc',
    category: 'admin',
    commands: ['setnamegc'],
    description: 'Mengubah nama grup',
    isGroup: true,
    isAdmin: true,
    isBotAdmins: true,
    isRateLimit: true,

    async execute({ m, Yudzxml }) {
        if (!m.text) {
            return m.reply('❌ Masukkan nama grup baru.');
        }

        await Yudzxml.groupUpdateSubject(m.chat, m.text);
        m.reply('✅ Nama grup berhasil diperbarui.');
    }
};

const { addTextToxic, delTextToxic, listTextToxic } = require('@App/function/toxicHandler');

module.exports = {
    name: 'toxic',
    category: 'group',
    commands: ['addtoxic', 'deltoxic', 'listtoxic'],
    isAdmins: true,
    isBotAdmins: true,
    isGroup: true,
    isRateLimit: true,
    async execute({ m, text, prefix, command }) {
        if (command === 'addtoxic') {
            if (!text) {
                return m.reply(`❌ Format salah!\n\nContoh:\n${prefix}addtoxic anjing`);
            }

            const res = addTextToxic(m.chat, text);

            return m.reply(res.status ? `✅ Berhasil ditambahkan\n\nKata toxic:\n• ${text}` : `⚠️ ${res.message}`);
        }

        if (command === 'deltoxic') {
            if (!text) {
                return m.reply(`❌ Format salah!\n\nContoh:\n${prefix}deltoxic anjing`);
            }

            const res = delTextToxic(m.chat, text);

            return m.reply(res.status ? `✅ Berhasil dihapus\n\nKata toxic:\n• ${text}` : `⚠️ ${res.message}`);
        }

        if (command === 'listtoxic') {
            const { total, data } = listTextToxic(m.chat);

            if (!total) {
                return m.reply(`📭 Database toxic masih kosong.`);
            }

            const list = data.map((v, i) => `${i + 1}. ${v}`).join('\n');

            return m.reply(
                `🧪 DAFTAR KATA TOXIC
━━━━━━━━━━━━━━━
Total: ${total}

${list}`
            );
        }
    }
};

const axios = require('axios');

module.exports = {
    name: 'robloxstalk',
    category: 'stalk',
    commands: ['robloxstalk'],
    isOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ m, text, config, Yudzxml }) {
        try {
            if (!text) {
                return m.reply('❌ Masukkan username Roblox.\nContoh: robloxstalk sskaastti');
            }

            const { endpoint, key } = config.apikey;
            const apiUrl = `${endpoint}/api/stalk/roblox?username=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await axios.get(apiUrl);
            const result = res.data;

            if (!result || result.status !== 200 || !result.data) {
                return m.reply('❌ Akun Roblox tidak ditemukan.');
            }

            const data = result.data;
            const basic = data.basic;
            const social = data.social;
            const presence = data.presence?.userPresences?.[0];
            const avatar = data.avatar?.fullBody?.data?.[0]?.imageUrl || data.avatar?.headshot?.data?.[0]?.imageUrl;

            const statusMap = {
                0: 'Offline',
                1: 'Online',
                2: 'In Game',
                3: 'In Studio'
            };

            const caption = `🎮 *ROBLOX STALKER*

👤 *Username*   : ${basic.name}
🪪 *Display*    : ${basic.displayName}
🆔 *User ID*    : ${basic.id}
📝 *Bio*        : ${basic.description || '-'}

📅 *Created*    : ${new Date(basic.created).toLocaleString('id-ID')}
🚫 *Banned*     : ${basic.isBanned ? 'Yes' : 'No'}
✔️ *Verified*   : ${basic.hasVerifiedBadge ? 'Yes' : 'No'}

📡 *STATUS*
• ${statusMap[presence?.userPresenceType] || 'Unknown'}
• Location: ${presence?.lastLocation || '-'}

👥 *SOCIAL*
🤝 Friends   : ${social.friends?.count ?? 0}
👤 Followers : ${social.followers?.count ?? 0}
➕ Following : ${social.following?.count ?? 0}
`;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: avatar },
                    caption
                },
                { quoted: m }
            );
        } catch (err) {
            console.error('[ROBLOX STALK ERROR]', err);
            m.reply('⚠️ Gagal mengambil data Roblox.');
        }
    }
};

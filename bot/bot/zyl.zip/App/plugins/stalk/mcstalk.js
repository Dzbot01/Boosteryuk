const axios = require('axios');

module.exports = {
    name: 'mcstalk',
    category: 'stalk',
    commands: ['mcstalk'],
    isOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ m, text, config, Yudzxml }) {
        try {
            if (!text) {
                return m.reply('❌ Masukkan username Minecraft.\nContoh: mcstalk Warden');
            }

            const { endpoint, key } = config.apikey;
            const apiUrl = `${endpoint}/api/stalk/minecraft?username=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await axios.get(apiUrl);
            const result = res.data;

            if (!result || result.status !== 200 || !result.data) {
                return m.reply('❌ Data Minecraft tidak ditemukan.');
            }

            const data = result.data;
            const stats = data.stats || {};
            const player = data.playerInfo || {};
            const history = data.usernameHistory || [];

            let caption = `⛏️ *MINECRAFT STALKER*

👤 *Username* : ${data.username}
🆔 *UUID*     : ${player.uuid || '-'}
📌 *Status*   : ${player.status || '-'}

📝 *Bio*
${data.bio || '-'}

📊 *STATISTICS*
👁️ Views     : ${stats.views || 0}
👍 Upvotes   : ${stats.upvotes || 0}
🗓️ Joined    : ${stats.date || '-'}

🧾 *USERNAME HISTORY*
`;

            if (history.length) {
                caption += history.map((h, i) => ` ${i + 1}. ${h.username} (${h.date})`).join('\n');
            } else {
                caption += ' -';
            }

            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: data.profile },
                    caption
                },
                { quoted: m }
            );
        } catch (err) {
            console.error('[MINECRAFT STALK ERROR]', err);
            m.reply('⚠️ Terjadi kesalahan saat mengambil data Minecraft.');
        }
    }
};

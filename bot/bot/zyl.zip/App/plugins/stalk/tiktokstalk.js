const axios = require('axios');

module.exports = {
    name: 'tiktokstalk',
    category: 'stalk',
    commands: ['ttstalk'],
    isOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,
    async execute({ m, text, config, Yudzxml }) {
        try {
            if (!text) {
                return m.reply('❌ Masukkan username TikTok.\nContoh: ttstalk yudzxml.store');
            }

            const { endpoint, key } = config.apikey;
            const url = `${endpoint}/api/stalk/tiktok?username=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await axios.get(url);
            const result = res.data;

            if (!result || result.status !== 200 || !result.data?.profile) {
                return m.reply('❌ Gagal mengambil data TikTok.');
            }

            const profile = result.data.profile;
            const videos = result.data.videos || [];

            let caption = `🎵 *TIKTOK STALKER*

👤 *Username*  : ${profile.username}
🏷️ *Name*      : ${profile.displayName}
🆔 *User ID*   : ${profile.id}
✔️ *Verified*  : ${profile.verified ? 'Yes' : 'No'}

📝 *Bio*
${profile.bio || '-'}

📊 *STATISTICS*
👥 Followers : ${profile.followers}
➕ Following : ${profile.following}
❤️ Likes     : ${profile.likes}
🎬 Videos    : ${profile.videoCount}

🕒 *Last Update*
${new Date(profile.lastUpdated).toLocaleString('id-ID')}
`;

            if (videos.length) {
                caption += `\n🔥 *RECENT VIDEOS*\n`;
                videos.slice(0, 3).forEach((v, i) => {
                    caption += `
${i + 1}. 👀 ${v.views} | ❤️ ${v.likes} | 💬 ${v.comments}
⏱️ ${v.duration}s
📝 ${v.description ? v.description.slice(0, 60) + '…' : '-'}
`;
                });
            }

            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: profile.avatar },
                    caption
                },
                { quoted: m }
            );
        } catch (err) {
            console.error('[TIKTOK STALK ERROR]', err);
            m.reply('⚠️ Terjadi kesalahan saat mengambil data TikTok.');
        }
    }
};

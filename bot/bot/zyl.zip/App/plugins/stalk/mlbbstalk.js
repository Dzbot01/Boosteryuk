const axios = require('axios');

module.exports = {
    name: 'mlbbstalk',
    category: 'stalk',
    commands: ['mlbbstalk'],
    isOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ m, text, config }) {
        try {
            if (!text || !text.includes('|')) {
                return m.reply('❌ Format salah.\nContoh: mlbbstalk 12345678|4321');
            }

            const [id, server] = text.split('|').map((v) => v.trim());
            if (!id || !server) {
                return m.reply('❌ ID atau Server tidak valid.');
            }

            const { endpoint, key } = config.apikey;
            const apiUrl = `${endpoint}/api/stalk/mlbb?id=${id}&server=${server}&apikey=${key}`;

            const res = await axios.get(apiUrl);
            const result = res.data;

            if (!result || result.status !== 200 || !result.data || result.data.code !== 200) {
                return m.reply('❌ Gagal memverifikasi akun MLBB.');
            }

            const data = result.data.data;

            const message = `🎮 *MOBILE LEGENDS STALKER*

👤 *Username* : ${data.username}
🌍 *Region*   : ${data.country_of_origin.toUpperCase()}

✅ *Status*   : Account Verified
`;

            m.reply(message);
        } catch (err) {
            console.error('[MLBB STALK ERROR]', err);
            m.reply('⚠️ Terjadi kesalahan saat mengambil data MLBB.');
        }
    }
};

const axios = require('axios');

module.exports = {
    name: 'twitterstalk',
    category: 'stalk',
    commands: ['twitterstalk'],
    isOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,
    async execute({ m, text, config, Yudzxml }) {
        try {
            if (!text) {
                return m.reply('❌ Masukkan username Twitter.\nContoh: twitterstalk prabowo');
            }

            const { endpoint, key } = config.apikey;
            const twitterUrl = `${endpoint}/api/stalk/twitter?username=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await axios.get(twitterUrl);
            const data = res.data?.data;

            if (!data || !data.username) {
                return m.reply('❌ Akun Twitter tidak ditemukan.');
            }

            const caption = `🐦 *TWITTER STALKER*

👤 *Name*      : ${data.name}
📎 *Username*  : @${data.username}
✔️ *Verified*  : ${data.verified ? 'Ya' : 'Tidak'}${data.verified_type ? ` (${data.verified_type})` : ''}
🗺️ *Location*  : ${data.location || '-'}

📝 *Bio*
${data.description || '-'}

📊 *STATISTICS*
🐦 Tweets     : ${data.stats.tweets}
👥 Followers  : ${data.stats.followers}
➕ Following  : ${data.stats.following}
❤️ Likes      : ${data.stats.likes}
🖼️ Media      : ${data.stats.media}

📅 *Created*  : ${data.created_at}
`;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: data.profile.image },
                    caption
                },
                { quoted: m }
            );
        } catch (err) {
            console.error('[TWITTER STALK ERROR]', err);
            m.reply('⚠️ Gagal mengambil data Twitter.');
        }
    }
};

const axios = require('axios');

module.exports = {
    name: 'genshinstalk',
    category: 'stalk',
    commands: ['genshinstalk'],
    isOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,
    async execute({ m, text, config, Yudzxml }) {
        try {
            if (!text) {
                return m.reply('❌ Masukkan UID Genshin.\nContoh: genshinstalk 800123456');
            }

            const { endpoint, key } = config.apikey;
            const apiUrl = `${endpoint}/api/stalk/genshin?id=${text}&apikey=${key}`;

            const res = await axios.get(apiUrl);
            const api = res.data;

            if (!api.data || !api.data.player) {
                return m.reply('❌ Gagal mengambil data player.');
            }

            const player = api.data.player;
            const stats = api.data.playerStatistics;
            const avatars = api.data.avatars || [];

            let caption = `🎮 *GENSHIN STALKER*
_${player.server}_

👤 *Nickname*     : ${player.nickname}
🆔 *UID*          : ${player.uid}
⚔️ *Adventure Lv* : ${player.level}
🌍 *World Level*  : ${player.worldLevel}

📊 *STATISTICS*
🏆 Achievements : ${stats.achievements.current}
🧑‍🎤 Characters  : ${stats.characters.current}
🗄️ Chests       : ${stats.chests.current}
📅 Active Days  : ${player.detail.activeDays}

✨ *AVATARS (${avatars.length})*`;

            const avatarText = avatars
                .slice(0, 10)
                .map((av, i) => ` ${i + 1}. ${av.element} • Lv.${av.level} • ⭐${av.rarity}`)
                .join('\n');

            caption += `\n${avatarText}`;

            if (avatars.length > 10) {
                caption += `\n\n…dan ${avatars.length - 10} avatar lainnya`;
            }

            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: player.iconUrl },
                    caption
                },
                { quoted: m }
            );
        } catch (err) {
            console.error('[GENSHIN STALK ERROR]', err);
            m.reply('⚠️ Terjadi kesalahan saat mengambil data Genshin.');
        }
    }
};

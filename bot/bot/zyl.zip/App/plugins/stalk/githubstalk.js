const axios = require('axios');

function formatDate(date) {
    if (!date) return '-';
    return new Date(date).toLocaleDateString('id-ID', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    });
}

module.exports = {
    name: 'githubstalk',
    category: 'stalk',
    commands: ['githubstalk'],
    isOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ m, text, config, Yudzxml }) {
        try {
            if (!text) {
                return m.reply('❌ Masukkan username GitHub.\nContoh: githubstalk Yudzxml');
            }

            const { endpoint, key } = config.apikey;
            const apiUrl = `${endpoint}/api/stalk/github?username=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await axios.get(apiUrl);
            const result = res.data;

            if (!result || result.status !== 200 || !result.data) {
                return m.reply('❌ Data GitHub tidak ditemukan.');
            }

            const data = result.data;

            const caption = `🐙 *GITHUB STALKER*

👤 *Username*   : ${data.username}
📝 *Nickname*   : ${data.nickname || '-'}
📌 *Bio*        : ${data.bio || '-'}
🏢 *Company*    : ${data.company || '-'}
📍 *Location*   : ${data.location || '-'}
🔗 *Profile*    : ${data.url}

📊 *STATISTICS*
📦 Public Repo  : ${data.public_repo}
🧩 Gists        : ${data.public_gists}
👥 Followers    : ${data.followers}
➕ Following    : ${data.following}

⏳ *Account Info*
🗓️ Created At   : ${formatDate(data.created_at)}
🔄 Updated At   : ${formatDate(data.updated_at)}
`;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: data.profile_pic },
                    caption
                },
                { quoted: m }
            );
        } catch (err) {
            console.error('[GITHUB STALK ERROR]', err);
            m.reply('⚠️ Terjadi kesalahan saat mengambil data GitHub.');
        }
    }
};

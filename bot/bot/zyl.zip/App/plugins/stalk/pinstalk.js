const axios = require('axios');

module.exports = {
    name: 'pinstal',
    category: 'stalk',
    commands: ['pinstalk'],
    isOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,
    async execute({ m, text, config, Yudzxml }) {
        try {
            if (!text) {
                return m.reply('❌ Masukkan username Pinterest.\nContoh: pinstalk YudzXml');
            }

            const { endpoint, key } = config.apikey;
            const apiUrl = `${endpoint}/api/stalk/pinterest?username=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await axios.get(apiUrl);
            const result = res.data;

            if (!result || result.status !== 200 || !result.data || !result.data.status || !result.data.result) {
                return m.reply('❌ Data Pinterest tidak ditemukan.');
            }

            const data = result.data.result;
            const stats = data.stats || {};
            const image = data.image?.large || data.image?.original || data.image?.medium || data.image?.small;

            const caption = `📌 *PINTEREST STALKER*

👤 *Username* : ${data.username}
📝 *Name*     : ${data.full_name || '-'}
🆔 *User ID*  : ${data.id}
🔗 *Profile*  : ${data.profile_url}

📊 *STATISTICS*
📌 Pins       : ${stats.pins ?? 0}
👥 Followers  : ${stats.followers ?? 0}
➕ Following  : ${stats.following ?? 0}
`;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: image },
                    caption
                },
                { quoted: m }
            );
        } catch (err) {
            console.error('[PINTEREST STALK ERROR]', err);
            m.reply('⚠️ Terjadi kesalahan saat mengambil data Pinterest.');
        }
    }
};

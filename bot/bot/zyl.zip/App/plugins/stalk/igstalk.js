const axios = require('axios');

function formatDate(date) {
    if (!date) return '-';
    return new Date(date).toLocaleDateString('id-ID', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    });
}

module.exports = {
    name: 'igstalk',
    category: 'stalk',
    commands: ['igstalk'],
    isOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,
    async execute({ m, text, config, Yudzxml }) {
        try {
            if (!text) {
                return m.reply('❌ Masukkan username Instagram.\nContoh: igstalk Yudzxml');
            }

            const { endpoint, key } = config.apikey;
            const apiUrl = `${endpoint}/api/stalk/instagram?username=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await axios.get(apiUrl);
            const result = res.data;

            if (!result || result.status !== 200) {
                return m.reply(`❌ ${result?.message || 'Gagal mengambil data dari API.'}`);
            }

            const posts = result.data.posts || [];

            if (!posts.length) {
                return m.reply('⚠️ Akun ditemukan, tapi tidak ada posting publik.');
            }

            const sourcePost = posts[0];
            const userProfile = sourcePost.caption?.user;

            const username = userProfile?.username || text;
            const fullName = userProfile?.full_name || '-';
            const bio = userProfile?.biography || '-';
            const profilePic =
                userProfile?.profile_pic_url ||
                userProfile?.profile_pic_url_original ||
                'https://i.imgur.com/AlpGJfT.png';

            const latestPost = posts[0];
            const postCaption = latestPost.caption?.text || latestPost.caption || '-';
            const postDate = formatDate(latestPost.taken_at);
            const postType = latestPost.is_video ? 'Video' : 'Image';

            const postThumbnail =
                latestPost.thumbnail ||
                (latestPost.images && latestPost.images[0]) ||
                'https://i.imgur.com/AlpGJfT.png';

            const igCaption = `📸 *INSTAGRAM STALKER*

👤 *Profile User*
🔖 *Username* : ${username}
📝 *Name*     : ${fullName}
🔗 *Bio*      : ${bio}

🖼️ *Latest Post*
🗓️ *Date*     : ${postDate}
🎥 *Type*      : ${postType}
💬 *Caption*   : ${postCaption}

🔍 *Note*
Data ditampilkan berdasarkan postingan terakhir.
`;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: postThumbnail },
                    caption: igCaption
                },
                { quoted: m }
            );
        } catch (err) {
            console.error('[INSTAGRAM STALK ERROR]', err);
            m.reply('⚠️ Terjadi kesalahan saat mengambil data Instagram.');
        }
    }
};

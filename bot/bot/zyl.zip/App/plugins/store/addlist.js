module.exports = {
    name: 'addlist',
    category: 'store',
    commands: ['addlist'],

    async execute({
        m,
        args,
        config,
        Yudzxml,
        quoted,
        isImage,
        isAudio,
        isDocument,
        YudzCdn,
        addList,
        getList,
        isAdmins,
        isOwner
    }) {
        try {
            if (!isAdmins && !isOwner) return m.reply(config.mess.admin);

            const chatTarget = m.isGroup ? m.chat : config?.superowner + '@s.whatsapp.net';

            const rawInput = args.join(' ');
            if (!rawInput.includes(',')) {
                return m.reply(`❌ Format salah.\n\n` + `Gunakan:\n` + `.addlist id, text`);
            }

            const [rawId, ...rawText] = rawInput.split(',');
            const id = rawId.trim().toLowerCase();
            const text = rawText.join(',').trim();

            if (!id) {
                return m.reply('❌ ID tidak boleh kosong.');
            }

            if (!text) {
                return m.reply('❌ Text tidak boleh kosong.');
            }

            const existData = getList(chatTarget, id);
            if (existData) {
                return m.reply(`❌ ID *${id}* sudah digunakan.`);
            }

            let type = 'text';
            if (isImage) type = 'image';
            else if (isAudio) type = 'audio';
            else if (isDocument) type = 'document';

            let url = null;

            if (type !== 'text') {
                if (!quoted) {
                    return m.reply('❌ Reply media yang ingin disimpan.');
                }

                const media = await Yudzxml.downloadAndSaveMediaMessage(quoted);
                if (!media) {
                    return m.reply('❌ Gagal mengambil media.');
                }

                url = await YudzCdn(media, 'permanent');
                if (!url) {
                    return m.reply('❌ Gagal upload media.');
                }
            }

            const result = addList(chatTarget, {
                id,
                type,
                text,
                url
            });

            return m.reply(
                `✅ *List berhasil ditambahkan!*\n\n` +
                    `📌 ID: ${result.id}\n` +
                    `📂 Type: ${result.type}\n` +
                    `📝 ${result.text}\n` +
                    (result.url ? `🔗 ${result.url}` : '')
            );
        } catch (err) {
            console.error('[ADDLIST ERROR]', err);
            return m.reply(`❌ ${err.message}`);
        }
    }
};

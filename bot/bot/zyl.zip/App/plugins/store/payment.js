module.exports = {
    name: 'payment',
    category: 'store',
    commands: ['addpay', 'delpay', 'listpay', 'settextpay', 'deltextpay'],

    async execute({
        m,
        Yudzxml,
        args,
        prefix,
        isOwner,
        isAdmins,
        groupSettings,
        config,
        YudzCdn,
        command,
        isImage,
        quoted,
        saveGroupSettings,
        prepareWAMessageMedia,
        proto,
        text,
        logger,
        isJadibot,
        jadibotJid
    }) {
        try {
            const isGroup = m.chat.endsWith('@g.us');

            if (isGroup) {
                if (!groupSettings[m.chat]) groupSettings[m.chat] = {};
                if (!groupSettings[m.chat].payment) groupSettings[m.chat].payment = {};

                if (typeof groupSettings[m.chat].paymentText === 'undefined') {
                    groupSettings[m.chat].paymentText = '';
                }
            }

            if (!config.payment) config.payment = {};
        } catch (err) {
            logger.error('[PAYMENT-INIT] ' + (err?.message || err));
            return m.reply('❌ *Sistem Error*: Gagal memuat data.');
        }

        const isGroup = m.chat.endsWith('@g.us');

        // Bot jadibot + private chat → payment milik INSTANCE (bukan bot utama).
        // Disimpan di registry jadibot (settings.payment) sehingga tidak bocor
        // ke/dari bot utama & aman di-reset via website.
        let instancePaymentStore = null;
        if (isJadibot && jadibotJid && !isGroup) {
            try {
                const jadibotManager = require('../../../src/core/jadibot');
                instancePaymentStore = {
                    get: () => ({ ...(jadibotManager.getSettings(jadibotJid)?.payment || {}) }),
                    set: async (obj) => jadibotManager.updateSettings(jadibotJid, { payment: obj })
                };
            } catch (_) {
                instancePaymentStore = null;
            }
        }

        const groupPayment = isGroup ? groupSettings[m.chat].payment : {};
        const globalPayment = config.payment;
        const cmd = command.toLowerCase();

        const isAuthorized = isOwner || isAdmins;

        const requireAdmin = () => {
            if (!isAuthorized) return m.reply('❌ *Akses Ditolak*: Perintah ini khusus Administrator Grup.');
            return false;
        };

        const logger2 = (action, detail, status = 'INFO') => {
            const timestamp = new Date().toLocaleTimeString();
            const sender = m.sender.split('@')[0];
            let colorCode = '\x1b[0m';

            switch (status) {
                case 'SUCCESS':
                    colorCode = '\x1b[32m';
                    break;
                case 'ERROR':
                    colorCode = '\x1b[31m';
                    break;
                case 'WARN':
                    colorCode = '\x1b[33m';
                    break;
                default:
                    colorCode = '\x1b[36m';
                    break;
            }
            console.log(`${colorCode}[${timestamp}] [PAYMENT-${status}] ${action} by @${sender}: ${detail}\x1b[0m`);
        };

        const formatKey = (str) => str.toUpperCase().trim();

        const uploadQris = async (media) => {
            try {
                logger2('UPLOAD_QRIS', 'Memulai upload media...', 'INFO');
                const tempPath = await Yudzxml.downloadAndSaveMediaMessage(media);
                const cdnUrl = await YudzCdn(tempPath, 'permanent');
                logger2('UPLOAD_QRIS', `Berhasil upload: ${cdnUrl}`, 'SUCCESS');
                return { success: true, url: cdnUrl };
            } catch (err) {
                logger2('UPLOAD_QRIS', err.message, 'ERROR');
                return { success: false, error: err.message };
            }
        };

        try {
            switch (cmd) {
                case 'addpay': {
                    if (isGroup) {
                        if (requireAdmin()) return;

                        if (isOwner) {
                            return m.reply(
                                `⚠️ *Perhatian Owner*\n\n` +
                                    `Untuk mengatur *Global Payment*, silakan edit langsung di file \`config.js\`.\n\n` +
                                    `Command ini digunakan untuk menambah metode pembayaran spesifik *GRUP INI*.`
                            );
                        }

                        if (args[0]?.toUpperCase() === 'QRIS' && isImage && quoted) {
                            await m.reply('⏳ *Sedang mengupload QRIS ke Server CDN...*');
                            const upload = await uploadQris(quoted);
                            if (!upload.success) return m.reply(`❌ *Gagal Upload:* ${upload.error}`);
                            groupPayment.QRIS = upload.url;
                            saveGroupSettings(groupSettings);
                            return m.reply(`✅ *QRIS Berhasil Disimpan!*\n\n🔗 *URL:* ${upload.url}`);
                        }

                        if (args[0]?.toUpperCase() === 'QRIS' && args[1]?.match(/^https?:\/\//)) {
                            groupPayment.QRIS = args[1];
                            saveGroupSettings(groupSettings);
                            return m.reply(`✅ *URL QRIS Berhasil Disimpan.*`);
                        }

                        if (args.length === 0) {
                            return m.reply(
                                `📖 *Panduan Penggunaan Payment*\n\n` +
                                    `1. *Metode Umum:* ${prefix}addpay dana=08123456789\n` +
                                    `2. *Multiple:* ${prefix}addpay dana=0812 gopay=0898\n` +
                                    `3. *QRIS (Gambar):* Reply gambar + ${prefix}addpay qris\n` +
                                    `4. *QRIS (Link):* ${prefix}addpay qris https://link.com/qris.jpg`
                            );
                        }

                        const hasBatchInput = args.some((arg) => arg.includes('='));
                        if (hasBatchInput) {
                            let processed = 0;
                            args.forEach((item) => {
                                const [key, ...valParts] = item.split('=');
                                const value = valParts.join('=').trim();
                                const method = formatKey(key);
                                if (method && value) {
                                    groupPayment[method] = value;
                                    processed++;
                                }
                            });

                            if (processed > 0) {
                                saveGroupSettings(groupSettings);
                                logger2('BATCH_ADD', `${processed} methods updated (Group)`, 'SUCCESS');
                                return m.reply(`✅ *Update Berhasil!*\n\n${processed} metode pembayaran ditambahkan.`);
                            }
                            return m.reply('❌ *Format Salah.* Contoh: `dana=0812 gopay=0822`');
                        }

                        const method = formatKey(args[0]);
                        const value = args.slice(1).join(' ').trim();
                        if (!value)
                            return m.reply(
                                `⚠️ *Nilai kosong.*\nContoh: ${prefix}addpay ${method.toLowerCase()} 0812345678`
                            );

                        groupPayment[method] = value;
                        saveGroupSettings(groupSettings);
                        return m.reply(`✅ *Metode Ditambahkan:*\n\n💳 *${method}*\n📝 ${value}`);
                    }

                    // PRIVATE CHAT + BOT JADIBOT → simpan ke payment milik instance.
                    if (instancePaymentStore) {
                        if (!isOwner && !isAdmins) {
                            return m.reply('❌ *Akses Ditolak*: Hanya owner bot ini.');
                        }

                        if (args.length === 0) {
                            return m.reply(
                                `📖 *Atur Payment Bot Kamu (private)*\n\n` +
                                    `1. *Metode Umum:* ${prefix}addpay dana=08123456789\n` +
                                    `2. *Multiple:* ${prefix}addpay dana=0812 gopay=0898 mandiri=1300012345678\n` +
                                    `3. *QRIS (Link):* ${prefix}addpay qris https://link.com/qris.jpg\n\n` +
                                    `_Metode bebas: QRIS, DANA, GOPAY, MANDIRI, BCA, OVO, dll._`
                            );
                        }

                        const current = instancePaymentStore.get();
                        let processed = 0;
                        const pairs = args.some((arg) => arg.includes('='))
                            ? args
                            : [args.length >= 2 ? `${args[0]}=${args.slice(1).join(' ')}` : args[0]];

                        for (const item of pairs) {
                            if (!item || !item.includes('=')) continue;
                            const [key, ...valParts] = item.split('=');
                            const value = valParts.join('=').trim();
                            const method = formatKey(key);
                            if (method && value) {
                                if (method === 'QRIS' && value === '-' ) {
                                    delete current.QRIS;
                                } else {
                                    current[method] = value;
                                }
                                processed++;
                            }
                        }

                        if (processed === 0) {
                            return m.reply('❌ *Format Salah.* Contoh: `dana=0812 gopay=0822 mandiri=1300012345678`');
                        }

                        await instancePaymentStore.set(current);
                        return m.reply(
                            `✅ *Payment Bot Kamu Diperbarui!*\n\n${processed} metode ditambahkan.\nCek: ${prefix}listpay`
                        );
                    }

                    return m.reply('❌ Perintah ini hanya tersedia di dalam grup.');
                }

                case 'delpay': {
                    if (isGroup) {
                        if (requireAdmin()) return;
                        if (isOwner) return m.reply('⚠️ *Owner Info:* Hapus metode Global langsung di `config.js`.');

                        if (!args[0]) return m.reply(`⚠️ *Tentukan metode.*\nContoh: ${prefix}delpay dana`);

                        const method = formatKey(args[0]);
                        if (!groupPayment.hasOwnProperty(method)) {
                            return m.reply(`❌ *Metode tidak ditemukan:* ${method}`);
                        }

                        delete groupPayment[method];
                        saveGroupSettings(groupSettings);
                        return m.reply(`🗑️ *Berhasil menghapus:* ${method}`);
                    }

                    // PRIVATE CHAT + BOT JADIBOT → hapus dari payment instance.
                    if (instancePaymentStore) {
                        if (!isOwner && !isAdmins) {
                            return m.reply('❌ *Akses Ditolak*: Hanya owner bot ini.');
                        }
                        if (!args[0]) return m.reply(`⚠️ *Tentukan metode.*\nContoh: ${prefix}delpay dana`);

                        const method = formatKey(args[0]);
                        const current = instancePaymentStore.get();
                        if (!current.hasOwnProperty(method)) {
                            return m.reply(`❌ *Metode tidak ditemukan:* ${method}`);
                        }

                        delete current[method];
                        await instancePaymentStore.set(current);
                        return m.reply(`🗑️ *Berhasil menghapus:* ${method}`);
                    }

                    return m.reply('❌ Perintah ini hanya tersedia di dalam grup.');
                }

                case 'settextpay': {
                    if (!isGroup) return m.reply('❌ Perintah ini hanya tersedia di dalam grup.');
                    if (requireAdmin()) return;
                    if (isOwner) return m.reply('⚠️ Gunakan config.js untuk pesan Global.');

                    if (!text) return m.reply(`📝 *Panduan:* ${prefix}settextpay Silahkan transfer sesuai nominal.`);

                    groupSettings[m.chat].paymentText = text;
                    saveGroupSettings(groupSettings);
                    return m.reply(`✅ *Teks Pembayaran Berhasil Diatur!*`);
                }

                case 'deltextpay': {
                    if (!isGroup) return m.reply('❌ Perintah ini hanya tersedia di dalam grup.');
                    if (requireAdmin()) return;

                    if (!groupSettings[m.chat].paymentText) {
                        return m.reply('⚠️ *Teks pembayaran belum diatur sebelumnya.*');
                    }

                    delete groupSettings[m.chat].paymentText;
                    saveGroupSettings(groupSettings);
                    return m.reply(`🗑️ *Teks pembayaran berhasil dihapus.*`);
                }

                case 'listpay': {
                    logger2('LISTPAY', 'Request received', 'INFO');

                    let finalData = {};
                    let headerText = '';
                    let sourceInfo = '';

                    if (isGroup) {
                        const groupKeys = Object.keys(groupPayment);

                        if (groupKeys.length > 0) {
                            finalData = groupPayment;
                            headerText = groupSettings[m.chat].paymentText || `💳 *PAYMENT GRUP*`;
                            sourceInfo = 'GROUP_DB';
                            logger2('LISTPAY', 'Showing Group Payment', 'INFO');
                        } else {
                            if (isOwner) {
                                finalData = globalPayment;
                                headerText = config.mess.payment || `💳 *GLOBAL PAYMENT (OWNER)*`;
                                sourceInfo = 'GLOBAL_DB (OWNER FALLBACK)';
                                logger2('LISTPAY', 'Group empty, Owner seeing Global', 'INFO');
                            } else {
                                return m.reply('❌ *Payment belum diatur* oleh admin grup ini.');
                            }
                        }
                    } else if (instancePaymentStore) {
                        // Private chat di bot jadibot → TUNJUKKAN payment milik
                        // instance, BUKAN payment bot utama (isolasi data).
                        finalData = instancePaymentStore.get();
                        headerText = `💳 *PAYMENT ${config.botname || 'BOT'}*`;
                        sourceInfo = 'INSTANCE_DB';
                        logger2('LISTPAY', 'Showing Instance Payment (jadibot private)', 'INFO');
                    } else {
                        finalData = globalPayment;
                        headerText = config.mess.payment || `💳 *METODE PEMBAYARAN*`;
                        sourceInfo = 'GLOBAL_DB (PRIVATE)';
                        logger2('LISTPAY', 'Private chat, showing Global Payment', 'INFO');
                    }

                    if (Object.keys(finalData).length === 0) {
                        return m.reply('🚫 *Belum ada metode pembayaran* yang tersedia saat ini.');
                    }

                    const buttons = [];
                    let qrisImage = null;
                    let bodyTextList = '';

                    for (const [key, val] of Object.entries(finalData)) {
                        try {
                            const method = formatKey(key);

                            if (method === 'QRIS' && val.match(/^https?:\/\/.+\.(jpg|jpeg|png|webp)$/i)) {
                                qrisImage = val;
                                buttons.push({
                                    name: 'cta_url',
                                    buttonParamsJson: JSON.stringify({
                                        display_text: '🖼️ Lihat QRIS Full',
                                        url: val,
                                        merchant_url: val
                                    })
                                });
                            } else if (val.match(/^https?:\/\//)) {
                                buttons.push({
                                    name: 'cta_url',
                                    buttonParamsJson: JSON.stringify({
                                        display_text: `🔗 Link ${method}`,
                                        url: val,
                                        merchant_url: val
                                    })
                                });
                            } else {
                                buttons.push({
                                    name: 'cta_copy',
                                    buttonParamsJson: JSON.stringify({
                                        display_text: `📋 Salin ${method}`,
                                        id: val,
                                        copy_code: val
                                    })
                                });
                            }
                            bodyTextList += `▫️ *${method}:* ${val}\n`;
                        } catch (loopErr) {
                            logger2('LISTPAY', `Error processing item ${key}: ${loopErr.message}`, 'WARN');
                        }
                    }

                    const messageBody = `${headerText}\n\n${bodyTextList}`;

                    let media = null;
                    if (qrisImage) {
                        try {
                            media = await prepareWAMessageMedia(
                                { image: { url: qrisImage } },
                                { upload: Yudzxml.waUploadToServer }
                            );
                        } catch (error) {
                            logger2('LISTPAY', `Gagal upload media QRIS: ${error.message}`, 'ERROR');
                            qrisImage = null;
                        }
                    }

                    const interactiveMsg = proto.Message.InteractiveMessage.fromObject({
                        body: proto.Message.InteractiveMessage.Body.fromObject({
                            text: media ? messageBody : bodyTextList
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.fromObject({
                            text:
                                isGroup && sourceInfo.includes('GLOBAL') ? '🔒 Showing Owner Payment (Group Empty)' : ``
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                            buttons: buttons
                        })
                    });

                    if (media) {
                        interactiveMsg.header = proto.Message.InteractiveMessage.Header.fromObject({
                            hasMediaAttachment: true,
                            ...media
                        });
                    }

                    try {
                        await Yudzxml.relayMessage(
                            m.chat,
                            {
                                viewOnceMessageV2Extension: {
                                    message: {
                                        interactiveMessage: interactiveMsg
                                    }
                                }
                            },
                            { quoted: m }
                        );
                        logger2('LISTPAY', `Sent successfully (${sourceInfo})`, 'SUCCESS');
                    } catch (sendErr) {
                        logger2('LISTPAY', `Gagal mengirim: ${sendErr.message}`, 'ERROR');
                        m.reply(bodyTextList);
                    }

                    break;
                }

                default:
                    break;
            }
        } catch (globalError) {
            logger2('GLOBAL_ERROR', globalError.stack, 'ERROR');
            m.reply('❌ *Terjadi kesalahan sistem.*\n```' + globalError.message + '```');
        }
    }
};

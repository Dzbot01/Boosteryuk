const config = require('@Config');
const orderManager = require('@App/function/orderManager');
const createTemplateQris = require('@App/function/createTemplateQris');
const logger = require('@App/function/logger');
const jadibotManager = require('../../../src/core/jadibot');

const formatCurrency = (number) =>
    new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0
    }).format(number);

module.exports = {
    name: 'buyprem',
    category: 'store',
    commands: ['buyprem', 'buypremium'],
    description: 'Beli premium user otomatis via payment gateway (pricelist dari config.js)',
    isOwner: false,
    isSuperOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,

    buildPricelistText(cfg, prefix) {
        const packages = cfg.premium?.packages || [];

        const list = packages
            .map((p) => {
                const durasi = p.days >= 3650 ? 'Selamanya' : `${p.days} Hari`;
                return `⭐ *${p.name}*\n💰 Harga  : ${formatCurrency(p.price)}\n⏳ Durasi : ${durasi}\n`;
            })
            .join('\n');

        return (
            `━━━━━━━━━━━━━━━━━━━\n🌟 *PRICELIST PREMIUM USER*\n━━━━━━━━━━━━━━━━━━━\n\n` +
            `💡 _Premium = bebas limit, akses fitur khusus premium, prioritas antrean._\n\n` +
            list +
            `\n━━━━━━━━━━━━━━━━━━━\n🛒 *CARA PEMBELIAN*\n━━━━━━━━━━━━━━━━━━━\n\n` +
            `📝 *Format:*\n ${prefix}buyprem <nama paket>\n\n` +
            `☕ *Contoh:*\n ${packages[0] ? `${prefix}buyprem ${packages[0].name}` : `${prefix}buyprem 1 BULAN`}\n\n` +
            `_Premium diaktifkan OTOMATIS untuk nomormu setelah pembayaran terverifikasi._\n` +
            `_Pembayaran via *${cfg.pakasir?.slug ? 'Pakasir (' + cfg.pakasir.slug + ')' : 'Payment Gateway'}* — QRIS dinamis._\n\n` +
            `━━━━━━━━━━━━━━━━━━━`
        );
    },

    async execute({ Yudzxml, m, args, prefix, config: instanceConfig }) {
        // Config per-instance: bot jadibot bisa punya pricelist premium sendiri
        // (settings.premium di-merge oleh resolveConfig di atas config global).
        const cfg = instanceConfig || require('@Config');
        const reply = (text) => Yudzxml.sendMessage(m.chat, { text }, { quoted: m });

        const isJadi = Boolean(Yudzxml.isJadibot);
        const jadiJid = isJadi ? Yudzxml.jadibotJid : null;
        const jadiEntry = isJadi && jadiJid ? jadibotManager.get(jadiJid) : null;
        const jadiPakasir = jadiEntry?.credentials?.pakasir || null;

        if (cfg.premium?.enabled === false) {
            return reply(
                '❌ *PEMBELIAN PREMIUM OTOMATIS NONAKTIF.*\n\n' + '_Hubungi owner untuk aktivasi premium manual._'
            );
        }

        const packages = cfg.premium?.packages || [];

        if (!packages.length) {
            return reply(
                '❌ *Belum ada paket premium.*\n\n' +
                    '_Owner belum mengisi paket premium (config.premium.packages atau settings premium bot)._'
            );
        }

        if (args.length < 1) {
            return reply(this.buildPricelistText(cfg, prefix));
        }

        const inputName = args.join(' ').trim();

        const pkg = packages.find((p) => p.name.toLowerCase() === inputName.toLowerCase());

        if (!pkg) {
            return reply(
                `❌ *Paket "${inputName}" tidak ditemukan.*\n\n` +
                    `📋 *Paket tersedia:*\n` +
                    `${packages.map((p) => `• ${p.name} — ${formatCurrency(p.price)}`).join('\n')}\n\n` +
                    `_Ketik ${prefix}buyprem untuk detail lengkap._`
            );
        }

        if (isJadi && (!jadiPakasir || !jadiPakasir.key || !jadiPakasir.slug)) {
            return reply(
                '❌ *GATEWAY PEMBAYARAN BELUM DIPASANG*\n\n' +
                    '_Bot jadibot kamu belum punya kredensial payment sendiri._\n' +
                    '_Pasang dulu agar pembayaran masuk ke kamu (bukan bot utama):_\n\n' +
                    '• Pasang kredensial pakasir kamu lewat *website* (menu kredensial bot jadibot)'
            );
        }

        try {
            await reply('⏳ *Membuat tagihan via payment gateway...*');

            const order = await orderManager.createPremiumOrder({
                number: m.sender.split('@')[0],
                packageName: pkg.name,
                buyerJid: m.sender,
                source: 'whatsapp',
                instanceJid: jadiJid
            });

            const invoiceText =
                `*「  INVOICE PREMIUM 」*\n\n` +
                `⭐ *Paket:* ${order.package}\n` +
                `⏳ *Durasi:* ${order.days >= 3650 ? 'Selamanya' : order.days + ' Hari'}\n` +
                `💰 *Total:* ${formatCurrency(order.amount)}\n` +
                (order.fee
                    ? `➕ *Fee gateway:* ${formatCurrency(order.fee)}\n` +
                      `🧾 *Total bayar:* ${formatCurrency(order.totalPayment)}\n`
                    : '') +
                `🆔 *Order ID:* ${order.id}\n` +
                `👤 *Untuk nomor:* @${m.sender.split('@')[0]}\n\n` +
                `━━━━━━━━━━━━━━━━━━\n` +
                `*PEMBAYARAN (QRIS GATEWAY)*\n` +
                `_Scan QR di atas — nominal terkunci sesuai tagihan._\n` +
                `_QR ini dinamis dari gateway, BUKAN QRIS statis._\n\n` +
                `*_⚡ Pembayaran dicek otomatis tiap 5 detik._*\n` +
                `_Premium langsung aktif setelah lunas._\n` +
                `_Cek status: ${prefix}orderstatus ${order.id}_`;

            let qrBuffer = null;
            const payString = order.qrString || order.paymentNumber || null;

            if (payString) {
                try {
                    qrBuffer = await createTemplateQris(payString, cfg.pakasir?.frameQr, cfg);
                } catch (err) {
                    logger.error('[Buyprem] QR render gagal: ' + (err?.message || err));
                }
            }

            const buttons = [
                {
                    buttonId: `${prefix}orderstatus ${order.id}`,
                    buttonText: {
                        displayText: '📋 Order Status'
                    },
                    type: 1
                },
                {
                    buttonId: `${prefix}cancelorder ${order.id}`,
                    buttonText: {
                        displayText: '❌ Cancel Order'
                    },
                    type: 1
                }
            ];

            const sentMsg = await Yudzxml.sendMessage(
                m.chat,
                {
                    ...(qrBuffer
                        ? {
                              image: qrBuffer,
                              caption: invoiceText
                          }
                        : {
                              text:
                                  `${invoiceText}\n\n` +
                                  (payString
                                      ? `🔗 *QRIS String (scan manual lewat aplikasi bank/e-wallet):*\n${payString}`
                                      : `❌ *QRIS belum tersedia — cek beberapa detik lagi dengan ${prefix}orderstatus ${order.id}*`)
                          }),
                    footer: '',
                    buttons,
                    headerType: 4,
                    contextInfo: {
                        mentionedJid: [m.sender],
                        forwardingScore: 0,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: cfg.idch || '120363316461058483@newsletter',
                            serverMessageId: 0,
                            newsletterName: Yudzxml.identity?.storename || 'Info Bot'
                        }
                    }
                },
                { quoted: m }
            );

            const msgId = sentMsg?.key?.id || null;

            const onCompleted = async () => {
                const fresh = orderManager.getOrder(order.id);

                const successText =
                    `✅ *PEMBAYARAN BERHASIL!*\n\n` +
                    `⭐ *Paket:* ${order.package}\n` +
                    `🆔 *Order ID:* ${order.id}\n` +
                    `👤 *Nomor:* +${order.number}\n` +
                    `📅 *Premium aktif hingga:* ${
                        fresh?.premiumExpired ? new Date(fresh.premiumExpired).toLocaleString('id-ID') : '-'
                    }\n\n` +
                    `🎉 _Selamat! Nikmati fitur premium tanpa limit._\n` +
                    `_Cek: ${prefix}premium_`;

                try {
                    if (msgId) {
                        await Yudzxml.sendMessage(m.chat, {
                            text: successText,
                            edit: msgId
                        });
                    } else {
                        await Yudzxml.sendMessage(m.chat, { text: successText });
                    }
                } catch (_) {
                    await Yudzxml.sendMessage(m.chat, { text: successText }).catch(() => {});
                }
            };

            const onFailed = async ({ reason }) => {
                const failedText =
                    `❌ *TRANSAKSI GAGAL / EXPIRED*\n\n` +
                    `🆔 *Order ID:* ${order.id}\n` +
                    `📝 *Keterangan:* ${reason}\n\n` +
                    `_Jika kamu sudah membayar, hubungi owner untuk diproses manual._`;

                try {
                    if (msgId) {
                        await Yudzxml.sendMessage(m.chat, {
                            text: failedText,
                            edit: msgId
                        });
                    } else {
                        await Yudzxml.sendMessage(m.chat, { text: failedText });
                    }
                } catch (_) {
                    await Yudzxml.sendMessage(m.chat, { text: failedText }).catch(() => {});
                }
            };

            orderManager.once(`completed:${order.id}`, onCompleted);

            orderManager.once(`failed:${order.id}`, onFailed);

            setTimeout(
                () => {
                    orderManager.off(`completed:${order.id}`, onCompleted);

                    orderManager.off(`failed:${order.id}`, onFailed);
                },
                24 * 60 * 60 * 1000
            ).unref?.();

            return;
        } catch (error) {
            logger.error('[Buyprem] Order error: ' + (error?.message || error));

            return reply(`❌ *Gagal membuat order:*\n${error.message}`);
        }
    }
};

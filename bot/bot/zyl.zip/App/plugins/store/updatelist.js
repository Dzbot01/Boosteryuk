module.exports = {
    name: 'updatelist',
    category: 'store',
    commands: ['updatelist'],

    async execute({
        m,
        args,
        config,
        Yudzxml,
        quoted,
        isImage,
        isAudio,
        isDocument,
        YudzCdn,
        updateList,
        isAdmins,
        isOwner
    }) {
        try {
            if (!isAdmins && !isOwner) return m.reply(config.mess.admin);
            const chatTarget = m.isGroup ? m.chat : config?.superowner + '@s.whatsapp.net';

            const rawInput = args.join(' ');
            if (!rawInput.includes(',')) {
                return m.reply(`❌ Format salah.\n\nGunakan:\n.updatelist id, text`);
            }

            const [rawId, ...rawText] = rawInput.split(',');
            const id = rawId.trim().toLowerCase();
            const text = rawText.join(',').trim();

            if (!id) return m.reply('❌ ID tidak boleh kosong.');
            if (!text && !quoted) {
                return m.reply('❌ Text atau media wajib diisi.');
            }

            let type = null;
            let url = undefined;

            if (isImage) type = 'image';
            else if (isAudio) type = 'audio';
            else if (isDocument) type = 'document';

            if (type) {
                if (!quoted) {
                    return m.reply('❌ Reply media yang ingin diupdate.');
                }

                const media = await Yudzxml.downloadAndSaveMediaMessage(quoted);
                url = await YudzCdn(media, 'permanent');
            }

            const result = updateList(chatTarget, {
                id,
                type,
                text,
                url
            });

            return m.reply(
                `✅ *List berhasil diperbarui!*\n\n` +
                    `📌 ID: ${result.id}\n` +
                    `📂 Type: ${result.type}\n` +
                    `🕒 Updated: ${result.updatedAt}`
            );
        } catch (err) {
            console.error('[UPDATELIST ERROR]', err);
            return m.reply(`❌ ${err.message}`);
        }
    }
};

module.exports = {
    name: 'clearlist',
    category: 'store',
    commands: ['clearlist'],

    async execute({ m, config, clearList, isAdmins, isOwner }) {
        try {
            if (!isAdmins && !isOwner) return m.reply(config.mess.admin);
            const chatTarget = m.isGroup ? m.chat : config?.superowner + '@s.whatsapp.net';

            const success = clearList(chatTarget);
            if (!success) {
                return m.reply('❌ Tidak ada list untuk dihapus.');
            }

            return m.reply('✅ Semua list berhasil dibersihkan.');
        } catch (err) {
            console.error('[CLEARLIST ERROR]', err);
            return m.reply(`❌ ${err.message}`);
        }
    }
};

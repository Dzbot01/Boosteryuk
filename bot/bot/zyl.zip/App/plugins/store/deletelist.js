module.exports = {
    name: 'dellist',
    category: 'store',
    commands: ['dellist', 'deletelist'],

    async execute({ m, args, config, deleteList, isAdmins, isOwner }) {
        try {
            if (!isAdmins && !isOwner) return m.reply(config.mess.admin);
            const chatTarget = m.isGroup ? m.chat : config?.superowner + '@s.whatsapp.net';

            const id = args.join(' ').trim().toLowerCase();
            if (!id) {
                return m.reply('❌ ID wajib diisi.');
            }

            const success = deleteList(chatTarget, id);
            if (!success) {
                return m.reply(`❌ ID *${id}* tidak ditemukan.`);
            }

            return m.reply(`✅ List dengan ID *${id}* berhasil dihapus.`);
        } catch (err) {
            console.error('[DELLIST ERROR]', err);
            return m.reply(`❌ ${err.message}`);
        }
    }
};

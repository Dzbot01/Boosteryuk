const store = require('../../function/templateStore');

module.exports = {
    name: 'pending',
    category: 'store',
    commands: ['pending'],

    async execute({ m, args, text, config, Yudzxml, quoted, isSticker, YudzCdn, isAdmins, isOwner }) {
        try {
            if (!isAdmins && !isOwner) {
                return m.reply(config.mess.admin);
            }

            const chatTarget = m.isGroup ? m.chat : config?.superowner + '@s.whatsapp.net';

            const template = store.getTemplate(chatTarget, 'pending');
            if (!template) {
                return m.reply('Template pending belum diset.');
            }

            const catatan = text ? text.trim() : '-';

            const targetUser = (m.mentionedJid && m.mentionedJid[0]) || (m.quoted && m.quoted.sender) || m.sender;

            const links = store.getLinks(chatTarget) || {};
            const groupLink = links.group || '-';
            const saluranLink = links.saluran || '-';

            const renderedText = store.renderTemplate(template, {
                catatan,
                userTag: targetUser.split('@')[0],
                group: groupLink,
                saluran: saluranLink
            });

            await m.reply(renderedText, m.chat, {
                mentionedJid: [targetUser]
            });

            const stickerUrl = store.getSticker(chatTarget, 'pending');

            if (stickerUrl) {
                await Yudzxml.sendImageAsSticker(m.chat, stickerUrl, m, {
                    packname: Yudzxml.identity.packname,
                    author: Yudzxml.identity.author
                });
            }
        } catch (err) {
            console.error('[pending ERROR]', err);
            return m.reply(`❌ ${err.message}`);
        }
    }
};

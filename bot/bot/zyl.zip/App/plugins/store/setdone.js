const store = require('../../function/templateStore');

module.exports = {
    name: 'setdone',
    category: 'store',
    commands: ['setdone'],

    async execute({ m, args, text, config, Yudzxml, quoted, isSticker, YudzCdn, isAdmins, isOwner }) {
        try {
            if (!isAdmins && !isOwner) {
                return m.reply(config.mess.admin);
            }

            const chatTarget = m.isGroup ? m.chat : config?.superowner + '@s.whatsapp.net';

            if (!text) {
                return m.reply(`
Cara penggunaan:

Gunakan @time untuk waktu
Gunakan @tanggal untuk tanggal
Gunakan @group untuk nama grup
Gunakan @catatan untuk catatan
Gunakan @saluran untuk saluran
Gunakan @user untuk tag user

*Reply sticker + caption* jika ingin menyertakan sticker

_text dibawah hanya contoh silahkan ubah sesuai kebutuhan ✨_

Contoh:

TRANSAKSI BERHASIL「 ✅ 」

⏰ Jam      : @time
📅 Tanggal  : @tanggal
📝 Catatan  : @catatan

🌐 GROUP & SALURAN
📋 SALURAN: @saluran=https://whatsapp.com/channel/xxx
🏰 GRUP: @group=https://chat.whatsapp.com/xxx

✨ @user Terima kasih sudah order!
`);
            }

            let groupLink = null;
            let saluranLink = null;

            const groupMatch = text.match(/@group=(https?:\/\/\S+)/i);
            const saluranMatch = text.match(/@saluran=(https?:\/\/\S+)/i);

            if (groupMatch) {
                groupLink = groupMatch[1].trim();
                store.setGroupLink(chatTarget, groupLink);
            }

            if (saluranMatch) {
                saluranLink = saluranMatch[1].trim();
                store.setSaluranLink(chatTarget, saluranLink);
            }

            let cleanTemplate = text
                .replace(/@group=https?:\/\/\S+/gi, '@group')
                .replace(/@saluran=https?:\/\/\S+/gi, '@saluran')
                .trim();

            let stickerUrl = null;

            if (isSticker) {
                try {
                    const buffer = m.quoted ? await m.quoted.download() : await m.download();

                    stickerUrl = await YudzCdn(buffer, 'permanent');
                    store.setSticker(chatTarget, 'done', stickerUrl);
                } catch (err) {
                    console.error('[STICKER ERROR]', err);
                }
            }

            store.setTemplate(chatTarget, 'done', cleanTemplate);

            return m.reply('✅ Template DONE berhasil disimpan.');
        } catch (err) {
            console.error('[SETDONE ERROR]', err);
            return m.reply(`❌ ${err.message}`);
        }
    }
};

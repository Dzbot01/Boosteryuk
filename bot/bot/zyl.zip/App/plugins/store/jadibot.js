const { buildWebsiteNotice } = require('@App/function/jadibotWebsite');

module.exports = {
    name: 'jadibot',
    category: 'store',
    commands: ['jadibot', 'buymybot'],
    description: 'Order jadibot baru & lihat paket lewat website',
    isGroup: false,
    isPrivate: false,

    async execute({ m }) {
        return m.reply(
            buildWebsiteNotice(
                'Untuk order jadibot baru, perpanjang paket, atau aktivasi ulang bot, buka website kami.'
            )
        );
    }
};

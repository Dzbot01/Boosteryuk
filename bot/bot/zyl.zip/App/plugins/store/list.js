module.exports = {
    name: 'list',
    category: 'store',
    commands: ['list'],

    async execute({ m, config, getList, Yudzxml, prefix, replyimage, fotomenunya, text }) {
        try {
            if (!config) {
                return m.reply('⚠️ Konfigurasi bot belum siap. Hubungi owner.');
            }

            const targetChat = m.isGroup ? m.chat : config.superowner ? `${config.superowner}@s.whatsapp.net` : m.chat;

            if (text) {
                const data = await getList(targetChat, text.toLowerCase());

                if (!data) {
                    return m.reply('❌ Data tidak ditemukan.');
                }

                if (data.type === 'text') {
                    return m.reply(`${data.text}`);
                }

                if (data.type === 'image' && data.url) {
                    return Yudzxml.sendMessage(
                        m.chat,
                        {
                            image: { url: data.url },
                            caption: data.text || ''
                        },
                        { quoted: m }
                    );
                }

                if (data.type === 'video' && data.url) {
                    return Yudzxml.sendMessage(
                        m.chat,
                        {
                            video: { url: data.url },
                            caption: data.text || ''
                        },
                        { quoted: m }
                    );
                }

                if (data.type === 'document' && data.url) {
                    return Yudzxml.sendMessage(
                        m.chat,
                        {
                            document: { url: data.url },
                            mimetype: data.mimetype || 'application/octet-stream',
                            fileName: data.filename || `${data.id}`,
                            caption: data.text || ''
                        },
                        { quoted: m }
                    );
                }

                return m.reply('⚠️ Tipe data tidak dikenali atau file tidak tersedia.');
            }

            const listData = await getList(targetChat);

            if (!Array.isArray(listData) || listData.length === 0) {
                return m.reply('📭 *List masih kosong.*\nSilakan tambahkan produk terlebih dahulu.');
            }

            const kategoriRows = listData.map((item) => ({
                title: `✨ ${item.id || 'Tanpa ID'}`,
                description: 'Klik untuk melihat detail',
                id: `${prefix}list ${item.id}`
            }));

            const messageContent = {
                footer: '',
                buttons: [
                    {
                        buttonId: 'action',
                        buttonText: { displayText: '📂 Buka Katalog' },
                        type: 4,
                        nativeFlowInfo: {
                            name: 'single_select',
                            paramsJson: JSON.stringify({
                                title: 'ʟɪꜱᴛ ᴘʀᴏᴅᴜᴋ',
                                sections: [
                                    {
                                        title: `Katalog: ${config.botname || 'Store'}`,
                                        rows: kategoriRows
                                    }
                                ]
                            })
                        }
                    }
                ],
                headerType: 1,
                viewOnce: true,
                image: {
                    url: fotomenunya || 'https://i.imgur.com/6xJmC2I.png'
                },
                fileName: `${config.botname || 'Store'}.png`,
                mimetype: 'image/png',
                fileLength: 30000,
                caption: `📋 *DAFTAR PRODUK*\n\nHalo *@${m.sender.split('@')[0]}*, silakan pilih produk melalui tombol di bawah.`,
                contextInfo: {
                    mentionedJid: [m.sender],
                    forwardingScore: 50,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.idch,
                        serverMessageId: 20,
                        newsletterName: config.ownername
                    }
                }
            };

            await Yudzxml.sendMessage(m.chat, messageContent);
        } catch (err) {
            console.error('[LIST COMMAND ERROR]', err);
            m.reply(
                `❌ *Terjadi kesalahan sistem*\n\n` +
                    `📌 ${err.message}\n\n` +
                    `_Jika berulang, silakan laporkan ke owner._`
            );
        }
    }
};

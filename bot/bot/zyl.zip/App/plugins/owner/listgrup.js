module.exports = {
    name: 'listgroup',
    category: 'owner',
    commands: ['listgroup', 'listgrup'],
    isOwner: true,
    isSuperOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,

    async execute({ Yudzxml, m, botNumber, getSewa }) {
        try {
            const groups = await Yudzxml.groupFetchAllParticipating();
            const groupList = Object.values(groups);

            if (!groupList.length) {
                return m.reply('📭 *Bot belum bergabung di grup mana pun.*');
            }

            let teks = `
╭━━━〔 *LIST GROUP BOT* 〕━━━⬣
│ 📊 Total Grup : *${groupList.length}*
╰━━━━━━━━━━━━━━━━━━⬣
`;

            for (let i = 0; i < groupList.length; i++) {
                const group = groupList[i];

                const isAdmin = group.participants?.some((p) => p.id === botNumber && p.admin);

                const sewaData = await getSewa(group.id);
                const isSewa = !!sewaData;
                const isCommunity = group.isCommunity === true;
                teks += `
🔹 *${i + 1}.*
• Nama   : ${group.subject}
• ID     : ${group.id}
• Tipe   : ${isCommunity ? '🌐 Komunitas' : '👥 Grup'}
• Status : ${isAdmin ? '🛡️ Admin' : '👤 Member'}
• Sewa   : ${isSewa ? '✅ Aktif' : '❌ Tidak'}
`;
            }

            teks += `\n━━━━━━━━━━━━━━━━━━`;

            await Yudzxml.sendMessage(m.chat, { text: teks.trim() }, { quoted: m });
        } catch (err) {
            console.error('[LISTGROUP ERROR]', err);
            m.reply('❌ Terjadi kesalahan saat mengambil data grup.');
        }
    }
};

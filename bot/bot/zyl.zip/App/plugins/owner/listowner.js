module.exports = {
    name: 'listowner',
    category: 'owner',
    commands: ['listowner'],
    isOwner: true,
    isSuperOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,

    async execute({ Yudzxml, m, db_owner }) {
        if (!Array.isArray(db_owner) || db_owner.length === 0) {
            return m.reply('📭 *Belum ada owner tambahan yang terdaftar.*');
        }

        const totalOwner = db_owner.length;

        let teks = `
╭━━━〔 *LIST OWNER* 〕━━━⬣
│ 👑 Total Owner : *${totalOwner}*
╰━━━━━━━━━━━━━━━━━━⬣\n`;

        db_owner.forEach((owner, index) => {
            teks += `🔹 *${index + 1}.* ${owner}\n`;
        });

        teks += `\n━━━━━━━━━━━━━━━━━━
⚙️ *Akses terbatas untuk Owner*
📌 Gunakan wewenang dengan bijak
━━━━━━━━━━━━━━━━━━`;

        await Yudzxml.sendMessage(m.chat, { text: teks }, { quoted: m });
    }
};

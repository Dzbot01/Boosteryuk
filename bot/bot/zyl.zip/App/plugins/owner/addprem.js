module.exports = {
    name: 'addprem',
    category: 'owner',
    commands: ['addprem', 'addpremium'],
    isOwner: true,
    async execute({ Yudzxml, m, args, premium, addPremiumUser }) {
        if (args.length < 2) {
            return m.reply(
                `「 *SYSTEM NOTIFICATION* 」\n\n` +
                    `❌ *Input Argumen Tidak Lengkap*\n` +
                    `Mohon lengkapi perintah dengan format yang benar.\n\n` +
                    `┌─ ◇ *FORMAT*\n` +
                    `│ #addprem <tag/nomor> <durasi>\n` +
                    `└───────────\n\n` +
                    `┌─ ◇ *CONTOH PENGGUNAAN*\n` +
                    `│ #addprem @628xxx 30d\n` +
                    `│ #addprem 6281234567890 1w\n` +
                    `└───────────`
            );
        }

        let targets = [];

        if (m.mentionedJid && m.mentionedJid.length > 0) {
            targets = m.mentionedJid;
        } else {
            const inputNumber = args[0].replace(/[^0-9]/g, '');
            if (!inputNumber) return m.reply('❌ Format nomor tidak dikenali. Pastikan input berupa angka yang valid.');
            targets = [`${inputNumber}@s.whatsapp.net`];
        }

        const duration = args[1];
        let successCount = 0;

        for (const jid of targets) {
            try {
                addPremiumUser(jid, duration, Yudzxml);
                successCount++;
            } catch (error) {
                console.error(`[System Error] Gagal menambahkan premium untuk ${jid}:`, error);
            }
        }

        if (successCount > 0) {
            m.reply(
                `「 *SYSTEM SUCCESS* 」\n\n` +
                    `✅ *Proses Berhasil Dijalankan*\n\n` +
                    `• Total User Ditambahkan: ${successCount}\n` +
                    `• Durasi Akses: ${duration}\n\n` +
                    `Data telah disimpan dan notifikasi telah dikirim ke user.`
            );
        } else {
            m.reply(
                `「 *SYSTEM FAILED* 」\n\n` +
                    `⚠️ *Operasi Gagal*\n` +
                    `Sistem tidak dapat memproses permintaan saat ini.`
            );
        }
    }
};

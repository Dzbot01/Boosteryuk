module.exports = {
    name: 'restart',
    category: 'owner',
    commands: ['restart', 'rs'],
    isOwner: true,

    noJadibot: true,
    async execute({ m, Yudzxml }) {
        await Yudzxml.restartBot(m.chat);
    }
};

const axios = require('axios');

module.exports = {
    name: 'ipbot',
    category: 'owner',
    commands: ['ipbot'],
    description: 'Menampilkan IP publik server (IPv4 & IPv6)',
    isOwner: true,

    noJadibot: true,
    async execute({ m }) {
        try {
            const ipv4Req = axios.get('https://api.ipify.org', {
                timeout: 15000
            });

            const ipv6Req = axios.get('https://api6.ipify.org', {
                timeout: 15000
            });

            const [ipv4Res, ipv6Res] = await Promise.allSettled([ipv4Req, ipv6Req]);

            const ipv4 = ipv4Res.status === 'fulfilled' ? ipv4Res.value.data.trim() : 'Tidak tersedia';

            const ipv6 = ipv6Res.status === 'fulfilled' ? ipv6Res.value.data.trim() : 'Tidak didukung oleh server';

            const teks =
                '*🌐 INFORMASI IP SERVER*\n\n' +
                `• IPv4 : ${ipv4}\n` +
                `• IPv6 : ${ipv6}\n\n` +
                '_Data diambil dari IP publik server_';

            await m.reply(teks);
        } catch (err) {
            console.error('[ipbot ERROR]', err);
            await m.reply('⚠️ Gagal mengambil IP server.\n' + 'Periksa koneksi internet atau firewall.');
        }
    }
};

const Redeem = require('../../function/redeem');

module.exports = {
    name: 'redeem-owner',
    category: 'owner',
    commands: ['createredeem', 'delredeem'],
    description: 'Manage kode redeem',
    isOwner: true,
    noJadibot: true,
    isRateLimit: true,

    async execute({ m, args, command }) {
        try {
            const cmd = command.toLowerCase();

            if (cmd === 'createredeem') {
                const code = args[0];
                const expired = args[1];
                const rewardText = args.slice(2).join(' ');

                if (!code || !expired || !rewardText) {
                    return m.reply(
                        `🎟️ *CREATE REDEEM*

Format:
.createredeem <kode> <expired> <reward>

Contoh:
.createredeem PREMIUM30 7d premium=30d

.createredeem MONEY100K 7d money=100000

.createredeem LIMIT50 7d limit=50

.createredeem SEWA30 7d sewa=30

Multi Reward:
.createredeem YUDZXML 30d premium=30d,money=100000,limit=50,sewa=30`
                    );
                }

                const reward = {};

                const rewards = rewardText.split(',').map((v) => v.trim());

                for (const item of rewards) {
                    const [key, value] = item.split('=');

                    if (!key || !value) continue;

                    switch (key.toLowerCase()) {
                        case 'premium':
                            reward.premium = value;
                            break;

                        case 'money':
                            reward.money = Number(value);
                            break;

                        case 'limit':
                            reward.limit = Number(value);
                            break;

                        case 'sewa':
                            reward.sewa = Number(value);
                            break;
                    }
                }

                if (Object.keys(reward).length < 1) {
                    return m.reply('❌ Reward tidak valid');
                }

                const result = Redeem.createRedeem(code, expired, reward);

                if (!result.status) {
                    return m.reply(result.msg);
                }

                let rewardList = [];

                if (reward.premium) rewardList.push(`👑 Premium : ${reward.premium}`);

                if (reward.money) rewardList.push(`💰 Money : ${reward.money.toLocaleString()}`);

                if (reward.limit) rewardList.push(`🎫 Limit : ${reward.limit}`);

                if (reward.sewa) rewardList.push(`🤖 Sewa Bot : ${reward.sewa} Hari`);

                return m.reply(
                    `🎟️ *KODE REDEEM BERHASIL DIBUAT*

🔑 Kode : ${code.toUpperCase()}
⏳ Expired : ${expired}

🎁 Reward:
${rewardList.join('\n')}`
                );
            }

            if (cmd === 'delredeem') {
                const code = args[0];

                if (!code) {
                    return m.reply('Masukkan kode redeem');
                }

                const ok = Redeem.deleteRedeem(code);

                return m.reply(ok ? `🗑️ Kode *${code.toUpperCase()}* berhasil dihapus` : '❌ Kode tidak ditemukan');
            }
        } catch (err) {
            console.error('[REDEEM OWNER ERROR]', err);

            m.reply('❌ Error pada sistem redeem owner');
        }
    }
};

module.exports = {
    name: 'disable',
    category: 'owner',
    commands: ['disable'],
    isOwner: true,
    noJadibot: true,
    isGroup: false,
    isAdmin: false,
    isPremium: false,
    isRateLimit: false,

    async execute({ m, args, disablePlugin, isPluginDisabled, pluginState }) {
        try {
            const pluginName = args[0];

            if (!pluginName) {
                return m.reply('⚠️ Masukkan nama plugin.\nContoh:\n.disable 2fa');
            }

            const exists = pluginState.pluginsList.find((p) => p.name.toLowerCase() === pluginName.toLowerCase());

            if (!exists) {
                return m.reply('❌ Plugin tidak ditemukan.');
            }

            if (isPluginDisabled(pluginName)) {
                return m.reply('⚠️ Plugin sudah dalam keadaan nonaktif.');
            }

            const result = disablePlugin(pluginName);
            return m.reply(`✅ ${result}`);
        } catch (err) {
            console.error('[DISABLE PLUGIN ERROR]', err);
            m.reply('⚠️ Terjadi kesalahan.');
        }
    }
};

const ms = require('ms');

module.exports = {
    name: 'listprem',
    category: 'owner',
    commands: ['listprem', 'listpremium'],
    isOwner: true,

    async execute({ m, getAllPremiumUser }) {
        const list = getAllPremiumUser();

        if (!list || list.length === 0) {
            return m.reply('📭 Tidak ada user premium.');
        }

        let activeText = '';
        let expiredText = '';
        let no = 1;

        for (const user of list) {
            const id = user.id.split('@')[0];
            const expiredDate = new Date(user.expired).toLocaleString('id-ID');

            if (user.status === 'active') {
                activeText += `${no}. ${id}
⏳ Sisa: ${ms(user.remaining, { long: true })}
📅 Expired: ${expiredDate}

`;
            } else {
                expiredText += `${no}. ${id}
📅 Expired: ${expiredDate}

`;
            }
            no++;
        }

        const result = `📋 *LIST PREMIUM USER*

⭐ *AKTIF*
${activeText || 'Tidak ada premium aktif.'}
⌛ *EXPIRED*
${expiredText || 'Tidak ada premium expired.'}
`;

        m.reply(result.trim());
    }
};

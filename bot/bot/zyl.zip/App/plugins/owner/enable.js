module.exports = {
    name: 'enable',
    category: 'owner',
    commands: ['enable'],
    isOwner: true,
    noJadibot: true,
    isGroup: false,
    isAdmin: false,
    isPremium: false,
    isRateLimit: false,

    async execute({ m, args, enablePlugin, isPluginDisabled }) {
        try {
            const pluginName = args[0];

            if (!pluginName) {
                return m.reply('⚠️ Masukkan nama plugin.\nContoh:\n.enable 2fa');
            }

            if (!isPluginDisabled(pluginName)) {
                return m.reply('⚠️ Plugin sudah aktif.');
            }

            const result = enablePlugin(pluginName);
            return m.reply(`✅ ${result}`);
        } catch (err) {
            console.error('[ENABLE PLUGIN ERROR]', err);
            m.reply('⚠️ Terjadi kesalahan.');
        }
    }
};

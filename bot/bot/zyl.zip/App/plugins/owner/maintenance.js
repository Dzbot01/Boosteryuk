const maintenance = require('@App/function/maintenance');

module.exports = {
    name: 'Maintenance',
    category: 'owner',
    commands: ['maintenance', 'mtc'],
    description: 'Mengatur maintenance bot',
    isOwner: true,
    noJadibot: true,
    async execute({ m, args }) {
        const action = (args[0] || '').toLowerCase();

        if (!action) {
            return m.reply(`*📌 MENU MAINTENANCE*

*.maintenance on [durasi] [alasan]*
*.maintenance off*
*.maintenance info*

Contoh:
• .maintenance on
• .maintenance on 50s Pembaruan Server
• .maintenance on 30m Upgrade Server
• .maintenance on 2h Update API
• .maintenance on 1d Migrasi Database`);
        }

        switch (action) {
            case 'on': {
                let duration = 0;
                let reason = 'Maintenance';

                if (args[1]) {
                    const match = args[1].match(/^(\d+)(s|m|h|d)$/i);

                    if (match) {
                        const value = Number(match[1]);
                        const unit = match[2].toLowerCase();

                        const multi = {
                            s: 1000,
                            m: 60000,
                            h: 3600000,
                            d: 86400000
                        };

                        duration = value * multi[unit];
                        reason = args.slice(2).join(' ') || reason;
                    } else {
                        reason = args.slice(1).join(' ');
                    }
                }

                maintenance.enableMaintenance({
                    duration,
                    reason
                });

                return m.reply(
                    `✅ *Maintenance berhasil diaktifkan.*

📌 Alasan : ${reason}
⏳ Durasi : ${duration ? maintenance.formatDuration(duration) : 'Tanpa batas'}`
                );
            }

            case 'off': {
                maintenance.disableMaintenance();

                return m.reply('✅ Maintenance berhasil dinonaktifkan.');
            }

            case 'info': {
                const info = maintenance.getMaintenanceInfo();

                return m.reply(
                    `📊 *STATUS MAINTENANCE*

Status : ${info.enabled ? '🟢 Aktif' : '🔴 Nonaktif'}

📌 Alasan :
${info.reason || '-'}

🕒 Dimulai :
${info.startAtText}

⏰ Berakhir :
${info.endAtText}

⌛ Durasi :
${info.durationText}

🕐 Sisa :
${info.remainingText}`
                );
            }

            default:
                return m.reply('Gunakan: on, off, atau info.');
        }
    }
};

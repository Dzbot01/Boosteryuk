'use strict';

module.exports = {
    name: 'reactch',
    category: 'owner',
    commands: ['rch', 'reactchown'],
    description: 'Reaction channel multi-pesan (owner) — .rch <link> <teks|jumlah>',
    isRateLimit: true,
    isOwner: true,

    async execute({ m, Yudzxml, text }) {
        if (!text) {
            return m.reply(
                'Contoh:\n' +
                    '.rch https://whatsapp.com/channel/xxx/123 Yudzxml|3\n' +
                    '.rch https://whatsapp.com/channel/xxx/123 🔥'
            );
        }

        const hurufGaya = {
            a: '🅐',
            b: '🅑',
            c: '🅒',
            d: '🅓',
            e: '🅔',
            f: '🅕',
            g: '🅖',
            h: '🅗',
            i: '🅘',
            j: '🅙',
            k: '🅚',
            l: '🅛',
            m: '🅜',
            n: '🅝',
            o: '🅞',
            p: '🅟',
            q: '🅠',
            r: '🅡',
            s: '🅢',
            t: '🅣',
            u: '🅤',
            v: '🅥',
            w: '🅦',
            x: '🅧',
            y: '🅨',
            z: '🅩',
            0: '⓿',
            1: '➊',
            2: '➋',
            3: '➌',
            4: '➍',
            5: '➎',
            6: '➏',
            7: '➐',
            8: '➑',
            9: '➒'
        };

        const [mainText, offsetStr] = text.split('|');
        const args = mainText.trim().split(/\s+/);
        const link = args[0];

        if (!link.includes('https://whatsapp.com/channel/')) {
            return m.reply('❌ Link tidak valid!\n' + 'Contoh: .rch https://whatsapp.com/channel/xxx/123 Halo|3');
        }

        const channelId = link.split('/')[4];
        const rawMessageId = Number(link.split('/')[5]);

        if (!channelId || Number.isNaN(rawMessageId)) {
            return m.reply('❌ Link channel tidak lengkap.');
        }

        const offset = Number(offsetStr?.trim()) || 1;
        const teks = args.slice(1).join(' ').trim();

        if (!teks) {
            return m.reply('❌ Masukkan teks atau emoji untuk reaction.');
        }

        const emoji = teks
            .toLowerCase()
            .split('')
            .map((c) => (c === ' ' ? '―' : hurufGaya[c] || c))
            .join('');

        try {
            const metadata = await Yudzxml.newsletterMetadata('invite', channelId);

            let success = 0;
            let failed = 0;

            for (let i = 0; i < offset; i++) {
                const msgId = String(rawMessageId - i);
                try {
                    await Yudzxml.newsletterReactMessage(metadata.id, msgId, emoji);
                    success++;
                } catch {
                    failed++;
                }
            }

            m.reply(
                `✅ Reaction *${emoji}* berhasil dikirim\n` +
                    `📢 Channel: *${metadata.thread_metadata.name.text}*\n` +
                    `✔️ Berhasil: ${success}\n` +
                    `❌ Gagal: ${failed}`
            );
        } catch (err) {
            console.error(err);
            m.reply('❌ Gagal memproses reaction channel.');
        }
    }
};

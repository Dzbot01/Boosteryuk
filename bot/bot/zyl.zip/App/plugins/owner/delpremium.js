module.exports = {
    name: 'delprem',
    category: 'owner',
    commands: ['delprem', 'dellprem'],
    isOwner: true,
    isSuperOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,

    async execute({ m, args, premium, delPremiumUser, conn }) {
        if (!args.length && !m.mentionedJid?.length && !m.quoted) {
            return m.reply('Format: #delprem @tag / reply / nomor');
        }

        let targetJid =
            m.mentionedJid?.[0] ||
            m.quoted?.sender ||
            (args[0] ? args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : null);

        if (!targetJid) {
            return m.reply('Target tidak valid.');
        }

        try {
            const result = delPremiumUser(targetJid);

            return m.reply(
                `❌ *PREMIUM DIHAPUS*\n\n` +
                    `👤 ID: ${result.data?.id || targetJid}\n` +
                    `📅 Expired: ${result.data?.expired || '-'}\n` +
                    `📌 Status: Removed Successfully`
            );
        } catch (err) {
            console.error(err);

            if (err.message?.includes('tidak ditemukan')) {
                return m.reply('User tersebut bukan premium.');
            }

            return m.reply('Gagal menghapus premium user.');
        }
    }
};

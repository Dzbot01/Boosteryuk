module.exports = {
    name: 'pluginstatus',
    category: 'owner',
    commands: ['pluginstatus'],
    isOwner: true,
    isGroup: false,
    isAdmin: false,
    isPremium: false,
    isRateLimit: false,

    async execute({ m, args, isPluginDisabled, pluginState }) {
        try {
            const pluginName = args[0];

            if (!pluginName) {
                return m.reply('⚠️ Masukkan nama plugin.\nContoh:\n.pluginstatus 2fa');
            }

            const exists = pluginState.pluginsList.find((p) => p.name.toLowerCase() === pluginName.toLowerCase());

            if (!exists) {
                return m.reply('❌ Plugin tidak ditemukan.');
            }

            const status = isPluginDisabled(pluginName);

            return m.reply(
                status ? `❌ Plugin *${pluginName}* sedang dinonaktifkan.` : `✅ Plugin *${pluginName}* aktif.`
            );
        } catch (err) {
            console.error('[PLUGIN STATUS ERROR]', err);
            m.reply('⚠️ Terjadi kesalahan.');
        }
    }
};

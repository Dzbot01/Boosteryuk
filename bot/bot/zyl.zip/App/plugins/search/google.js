const axios = require('axios');

module.exports = {
    name: 'google',
    category: 'search',
    commands: ['google', 'gsearch'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ Yudzxml, m, text, config, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan kata kunci pencarian.\n\nContoh:\n*${prefix}google neko*`);
            }

            const endpoint = config?.apikey?.endpoint;
            const key = config?.apikey?.key;

            if (!endpoint || !key) {
                return m.reply('Konfigurasi API Google Search belum tersedia.');
            }

            const url = `${endpoint}/api/search/google?q=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await axios.get(url).catch(() => null);

            if (!res || !Array.isArray(res.data?.data)) {
                return m.reply('Gagal mengambil data Google Search.');
            }

            const results = res.data.data;
            if (results.length === 0) {
                return m.reply('Hasil pencarian tidak ditemukan.');
            }

            const fallbackImg =
                'https://raw.githubusercontent.com/Yudzxml/UploaderV2/refs/heads/main/tmp/IMG-20260116-WA0029.jpg';

            let img = results.find((v) => v.img)?.img || fallbackImg;

            let teks = `🔎 *GOOGLE SEARCH*\n📌 Query: ${text}\n\n`;

            results.slice(0, 5).forEach((item, i) => {
                teks += `*${i + 1}. ${item.title || '-'}*\n`;
                teks += `${item.snippet || '-'}\n`;
                teks += `🔗 ${item.link}\n\n`;
            });

            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: img },
                    caption: teks.trim()
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan internal.');
        }
    }
};

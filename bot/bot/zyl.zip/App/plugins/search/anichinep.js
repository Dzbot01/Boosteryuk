const axios = require('axios');

module.exports = {
    name: 'anichinep',
    category: 'search',
    commands: ['anichinep'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,

    async execute({ Yudzxml, m, text, config, prefix }) {
        try {
            if (!text) return m.reply('Masukkan URL episode.');

            const endpoint = config?.apikey?.endpoint;
            const key = config?.apikey?.key;
            if (!endpoint || !key) return m.reply('API belum diset.');

            const apiUrl = `${endpoint}/api/search/anichin/episode?url=${encodeURIComponent(text)}&apikey=${key}`;
            const res = await axios.get(apiUrl).catch(() => null);

            if (!res || res.data.status !== 200) {
                return m.reply('Gagal mengambil data.');
            }

            const data = res.data.data;

            let caption = `🎬 *${data.title}*\n\n`;
            caption += `📺 Series : ${data.seriesName}\n`;
            caption += `🔢 Episode : ${data.episodeNumber}\n`;
            caption += `⭐ Rating : ${data.rating}\n`;
            caption += `📊 Status : ${data.status}\n`;
            caption += `📅 Rilis : ${data.releaseDate}\n\n`;
            caption += `Klik tombol untuk nonton / download langsung.`;

            const streamUrl = data.videoServers?.[0]?.src || 'https://anichin.watch';

            const downloadBtns = (data.downloadLinks || []).slice(0, 3).map((dl, i) => ({
                buttonId: `dl_${i}`,
                buttonText: { displayText: `💾 ${dl.platform}` },
                type: 1,
                url: dl.link
            }));

            const episodeRows = (data.episodes || []).map((ep) => ({
                title: `Episode ${ep.episode}`,
                description: ep.release_date,
                rowId: `${prefix}anichinep ${ep.url}`
            }));

            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: data.thumbnail },
                    caption,
                    footer: 'Anichin Player',
                    headerType: 1,

                    buttons: [
                        {
                            buttonId: 'stream',
                            buttonText: { displayText: '🎬 Nonton' },
                            type: 1,
                            url: streamUrl
                        },
                        ...downloadBtns
                    ],

                    sections: [
                        {
                            title: `📺 Semua Episode (${episodeRows.length})`,
                            rows: episodeRows
                        }
                    ]
                },
                { quoted: m }
            );
        } catch (e) {
            console.error(e);
            m.reply('Error internal.');
        }
    }
};

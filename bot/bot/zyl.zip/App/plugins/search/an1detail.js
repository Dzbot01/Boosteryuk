module.exports = {
    name: 'an1detail',
    category: 'search',
    commands: ['an1detail'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,

    async execute({ m, text, config, fetchJson, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan URL game.\nContoh:\n*${prefix}an1detail https://an1.com/...*`);
            }

            const { endpoint, key } = config.apikey;
            const apiUrl = `${endpoint}/api/search/an1?url=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await fetchJson(apiUrl);
            if (!res.status || !res.data) {
                return m.reply('Detail game tidak tersedia. Link-nya mungkin sedang healing 🏖️');
            }

            const {
                title,
                developer,
                description,
                version,
                fileSize,
                operatingSystem,
                rating,
                ratingCount,
                downloadUrl
            } = res.data;

            let teks = `🎮 *${title || 'AN1 GAME DETAIL'}*\n`;
            teks += `━━━━━━━━━━━━━━━\n`;
            teks += `🧑‍💻 Developer : ${developer || '-'}\n`;
            teks += `📱 OS         : ${operatingSystem || '-'}\n`;
            teks += `📦 Size       : ${fileSize || '-'}\n`;
            teks += `🔢 Version    : ${version || '-'}\n`;
            teks += `⭐ Rating     : ${rating || 0} (${ratingCount || 0} review)\n`;
            teks += `━━━━━━━━━━━━━━━\n`;
            teks += `📝 Deskripsi:\n${description || 'Tidak ada deskripsi tersedia.'}\n\n`;

            teks += downloadUrl ? `⬇️ Download: Ketik *${prefix}an1dl ${downloadUrl}*` : `⬇️ Download tidak tersedia.`;

            return m.reply(teks.trim());
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan teknis. Bukan crash, cuma lagi mikir keras 🧠');
        }
    }
};

module.exports = {
    name: 'tiktoksearch',
    category: 'search',
    commands: ['tiktoksearch', 'ttsearch'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ Yudzxml, m, text, config, fetchJson, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan kata kunci.\nContoh: *${prefix}tiktoksearch yamaha r1*`);
            }

            const { endpoint, key } = config.apikey;

            const url = `${endpoint}/api/search/tiktok?q=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await fetchJson(url);

            if (res.status !== 200 || !res.data?.videos || !Array.isArray(res.data.videos) || !res.data.videos.length) {
                return m.reply('Video tidak ditemukan.');
            }

            const videos = res.data.videos;
            const data = videos[Math.floor(Math.random() * videos.length)];

            const videoUrl = data.play || data.wmplay;

            if (!videoUrl) {
                return m.reply('Link video tidak tersedia.');
            }

            const caption =
                `🎬 *TikTok Search*\n\n` +
                `📝 *Judul:* ${data.title || '-'}\n` +
                `👤 *Author:* ${data.author?.nickname || data.author?.unique_id || '-'}\n` +
                `❤️ *Likes:* ${data.digg_count || 0}\n` +
                `▶️ *Views:* ${data.play_count || 0}\n` +
                `🔎 *Query:* ${text}\n\n` +
                `📥 No Watermark`;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    video: {
                        url: videoUrl
                    },
                    mimetype: 'video/mp4',
                    caption
                },
                {
                    quoted: m
                }
            );
        } catch (err) {
            console.error(err);
            m.reply('Terjadi error saat mengambil video TikTok.');
        }
    }
};

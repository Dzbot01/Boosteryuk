module.exports = {
    name: 'resepmakanan',
    category: 'search',
    commands: ['resepmakanan', 'resep'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ Yudzxml, m, text, config, fetchJson, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan nama masakan.\nContoh: *${prefix}resep ikan goreng*`);
            }

            const { endpoint, key } = config.apikey;
            const url = `${endpoint}/api/search/resep?q=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await fetchJson(url);

            if (res.status !== 200 || !res.data?.length) {
                return m.reply('Resep tidak ditemukan.');
            }
            const item = res.data[Math.floor(Math.random() * res.data.length)];
            let bahanText = '';

            for (const kategori in item.bahan || {}) {
                bahanText += `\n📌 *${kategori}*\n`;

                for (const b of item.bahan[kategori] || []) {
                    bahanText += `• ${b.name}${b.amount ? ` (${b.amount})` : ''}\n`;
                }
            }

            let langkahText = '';

            for (const s of (item.steps || []).slice(0, 5)) {
                langkahText += `\n${s.number}. ${s.description}`;
            }

            const caption =
                `🍽️ *${item.title}*\n\n` +
                `🥘 *Bahan:*\n` +
                bahanText +
                `\n👨‍🍳 *Langkah:*\n` +
                langkahText +
                `\n\n` +
                `Ketik *${prefix}resepdetail ${item.title}* untuk versi lengkap.`;

            if (item.img) {
                await Yudzxml.sendMessage(
                    m.chat,
                    {
                        image: { url: item.img },
                        caption
                    },
                    {
                        quoted: m
                    }
                );
            } else {
                await Yudzxml.sendMessage(
                    m.chat,
                    {
                        text: caption
                    },
                    {
                        quoted: m
                    }
                );
            }
        } catch (err) {
            console.error(err);
            m.reply('Terjadi error saat mengambil resep.');
        }
    }
};

module.exports = {
    name: 'animeindo',
    category: 'search',
    commands: ['animeindo'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,

    async execute({ m, text, config, fetchJson, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan judul anime.\nContoh: *${prefix}animeindo naruto*`);
            }

            const { endpoint, key } = config.apikey;
            const url = `${endpoint}/api/search/animeindo/search?q=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await fetchJson(url);

            if (res.status !== 200 || !res.data?.length) {
                return m.reply('Anime tidak ditemukan. Coba judul lain.');
            }

            const selected = res.data.slice(0, 10);

            let teks = `🔎 *Hasil pencarian ANIMEINDO:* ${text}\n`;
            teks += `📦 *Total:* ${selected.length} hasil\n`;
            teks += `━━━━━━━━━━━━━━━\n\n`;

            selected.forEach((item, i) => {
                teks += `*${i + 1}. ${item.title || 'Tanpa judul'}*\n`;
                teks += `📺 Type     : ${item.type || '-'}\n`;
                teks += `⏳ Duration : ${item.duration || '-'}\n`;
                teks += `📅 Year     : ${item.year || '-'}\n`;
                teks += `🔗 Link     : ${item.link || '-'}\n\n`;
            });

            teks += `━━━━━━━━━━━━━━━\n`;
            teks += `Ketik *${prefix}animeindodetail <link>* untuk lihat detail.`;

            return m.reply(teks.trim());
        } catch (err) {
            console.error(err);
            m.reply('Terjadi error teknis. Server mungkin lagi maraton episode 😄');
        }
    }
};

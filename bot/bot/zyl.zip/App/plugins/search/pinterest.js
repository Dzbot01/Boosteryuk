const axios = require('axios');

module.exports = {
    name: 'pinterest',
    category: 'search',
    commands: ['pinterest', 'pin'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ Yudzxml, m, text, config, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan kata kunci pencarian.\n\nContoh:\n*${prefix}pinterest neko*`);
            }

            const endpoint = config?.apikey?.endpoint;
            const key = config?.apikey?.key;
            if (!endpoint || !key) {
                return m.reply('Konfigurasi API belum tersedia.');
            }

            const apiUrl = `${endpoint}/api/search/pinterest?q=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await axios.get(apiUrl).catch(() => null);
            if (!res?.data?.data?.status) {
                return m.reply('Hasil Pinterest tidak ditemukan.');
            }

            const result = res.data.data.result;
            const pins = Array.isArray(result?.pins) ? result.pins : [];
            if (!pins.length) {
                return m.reply('Tidak ada pin yang bisa ditampilkan.');
            }

            const images = [];

            for (const pin of pins) {
                const imageUrl = pin.media?.images?.large?.url || pin.media?.images?.orig?.url;

                if (imageUrl) images.push(imageUrl);
                if (images.length === 5) break;
            }

            if (!images.length) {
                return m.reply('Media tidak valid untuk ditampilkan.');
            }

            const caption =
                `📌 *PINTEREST SEARCH*\n` +
                `🔍 Query: ${result.query || text}\n` +
                `📦 Menampilkan ${images.length} dari ${result.total || pins.length} hasil`;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    album: images.map((url, i) => ({
                        image: { url },
                        caption: i === 0 ? caption : undefined
                    }))
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan internal.');
        }
    }
};

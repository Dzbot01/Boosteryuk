module.exports = {
    name: 'animeindodetail',
    category: 'search',
    commands: ['animeindodetail'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,

    async execute({
        generateWAMessageFromContent,
        proto,
        Yudzxml,
        m,
        text,
        config,
        fetchJson,
        prepareWAMessageMedia,
        prefix
    }) {
        try {
            if (!text) {
                return m.reply('URL anime tidak ditemukan.');
            }

            const { endpoint, key } = config.apikey;
            const url = `${endpoint}/api/search/animeindo/detail?url=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await fetchJson(url);

            if (res.status !== 200 || !res.data) {
                return m.reply('Detail anime tidak ditemukan.');
            }

            const data = res.data;

            const genres = data.genres?.map((g) => g.name).join(', ') || '-';

            const prepared = await prepareWAMessageMedia(
                { image: { url: data.img } },
                { upload: Yudzxml.waUploadToServer }
            );

            const episodes = data.episodes?.slice(0, 15) || [];
            let buttons = [];

            for (let ep of episodes) {
                buttons.push({
                    name: 'quick_reply',
                    buttonParamsJson: JSON.stringify({
                        display_text: `Episode ${ep.episode}`,
                        id: `${prefix}animeindoep ${ep.url}`
                    })
                });
            }

            const msgii = await generateWAMessageFromContent(
                m.chat,
                {
                    viewOnceMessageV2Extension: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadata: {},
                                deviceListMetadataVersion: 2
                            },
                            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                                header: proto.Message.InteractiveMessage.Header.fromObject({
                                    title: data.title,
                                    hasMediaAttachment: true,
                                    ...prepared
                                }),

                                body: proto.Message.InteractiveMessage.Body.fromObject({
                                    text:
                                        `📛 Alt Title : ${data.altTitle || '-'}\n` +
                                        `🎭 Genres    : ${genres}\n\n` +
                                        `📝 Sinopsis :\n${data.description?.slice(0, 800) || '-'}`
                                }),

                                footer: proto.Message.InteractiveMessage.Footer.fromObject({
                                    text: `Total Episode: ${data.episodes?.length || 0}`
                                }),

                                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                                    buttons
                                })
                            })
                        }
                    }
                },
                { userJid: m.sender, quoted: m }
            );

            await Yudzxml.relayMessage(m.chat, msgii.message, {
                messageId: msgii.key.id
            });
        } catch (err) {
            console.error(err);
            m.reply('Terjadi error teknis saat mengambil detail anime.');
        }
    }
};

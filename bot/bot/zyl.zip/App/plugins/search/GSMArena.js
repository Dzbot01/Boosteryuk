const axios = require('axios');
const { proto, prepareWAMessageMedia } = require('baileys');

module.exports = {
    name: 'gsmarena',
    category: 'search',
    commands: ['gsmarena', 'gsm'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, config, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan kata kunci pencarian.\n\nContoh:\n*${prefix}gsmarena xiaomi*`);
            }

            const endpoint = config?.apikey?.endpoint;
            const key = config?.apikey?.key;
            if (!endpoint || !key) {
                return m.reply('Konfigurasi API belum tersedia.');
            }

            const apiUrl = `${endpoint}/api/search/gsmarena?q=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await axios.get(apiUrl).catch(() => null);
            if (!res || !res.data || !Array.isArray(res.data.data)) {
                return m.reply('Gagal mengambil data GSM Arena.');
            }

            const results = res.data.data;
            if (results.length === 0) {
                return m.reply('Perangkat tidak ditemukan.');
            }

            const cards = [];
            for (const item of results.slice(0, 10)) {
                if (!item.thumbnail) continue;

                const media = await prepareWAMessageMedia(
                    { image: { url: item.thumbnail } },
                    { upload: Yudzxml.waUploadToServer }
                );

                cards.push(
                    proto.Message.InteractiveMessage.CarouselMessage.Card.fromObject({
                        header: proto.Message.InteractiveMessage.Header.fromObject({
                            title: item.name || 'Unknown Device',
                            hasMediaAttachment: true,
                            imageMessage: media.imageMessage
                        }),
                        body: proto.Message.InteractiveMessage.Body.fromObject({
                            text: item.description?.slice(0, 180) || 'Spesifikasi tidak tersedia.'
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.fromObject({
                            text: ''
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                            buttons: [
                                {
                                    name: 'cta_url',
                                    buttonParamsJson: JSON.stringify({
                                        display_text: 'Kunjungi Site',
                                        url: `https://www.gsmarena.com/${item.id}.php`
                                    })
                                }
                            ]
                        })
                    })
                );
            }

            if (cards.length === 0) {
                return m.reply('Media tidak valid untuk ditampilkan.');
            }

            const interactiveMessage = proto.Message.InteractiveMessage.fromObject({
                body: {
                    text: `📱 *GSM ARENA SEARCH*\n🔍 Query: ${text}`
                },
                footer: {
                    text: `Menampilkan ${cards.length} dari ${results.length} perangkat`
                },
                carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                    cards
                })
            });

            await Yudzxml.relayMessage(
                m.chat,
                {
                    viewOnceMessageV2Extension: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadata: {},
                                deviceListMetadataVersion: 2
                            },
                            interactiveMessage
                        }
                    }
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan internal.');
        }
    }
};

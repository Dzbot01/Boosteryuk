const axios = require('axios');

async function youtubeSearch(Yudzxml, m, text, config, prefix) {
    try {
        if (!text) {
            return m.reply(`Masukkan query.\nContoh: ${prefix}ytsearch Duka Last Child`);
        }

        const endpoint = config?.apikey?.endpoint;
        const key = config?.apikey?.key;

        if (!endpoint || !key) {
            return m.reply('API belum tersedia.');
        }

        const apiUrl = `${endpoint}/api/search/youtube?q=${encodeURIComponent(text)}&apikey=${key}`;

        const response = await axios.get(apiUrl).catch(() => null);

        if (!response?.data?.data?.length) {
            return m.reply('Video tidak ditemukan.');
        }

        const results = response.data.data.slice(0, 5);

        let teks = `▶️ *YOUTUBE SEARCH*\n` + `🔍 Query: ${text}\n\n`;

        results.forEach((video, index) => {
            teks +=
                `*${index + 1}. ${video.title || 'Tanpa judul'}*\n` +
                `👤 ${video.author || '-'}\n` +
                `⏱️ ${video.duration || '-'}\n` +
                `👁️ ${Number(video.views || 0).toLocaleString()} views\n` +
                `🔗 ${video.url || '-'}\n\n`;
        });

        teks += `━━━━━━━━━━━━━━\n` + `Gunakan:\n` + `🎵 *${prefix}ytmp3 <url>*\n` + `🎬 *${prefix}ytmp4 <url>*`;

        return m.reply(teks);
    } catch (err) {
        console.error(err);
        return m.reply(`Error: ${err.message}`);
    }
}

module.exports = {
    name: 'youtube',
    category: 'search',
    commands: ['ytsearch', 'yts'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ Yudzxml, m, text, config, prefix }) {
        await youtubeSearch(Yudzxml, m, text, config, prefix);
    }
};

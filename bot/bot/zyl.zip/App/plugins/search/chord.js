const axios = require('axios');

module.exports = {
    name: 'chord',
    category: 'search',
    commands: ['chord', 'chordtela'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ m, text, config, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan judul lagu.\n\nContoh:\n*${prefix}chord Duka Last Child*`);
            }

            const endpoint = config?.apikey?.endpoint;
            const key = config?.apikey?.key;

            if (!endpoint || !key) {
                return m.reply('Konfigurasi API belum tersedia.');
            }

            const apiUrl = `${endpoint}/api/search/chordtela?q=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await axios.get(apiUrl).catch(() => null);

            if (!res || !res.data) {
                return m.reply('Gagal menghubungi server chord.');
            }

            const result = res.data;

            if (result.status !== 200 || !result.data) {
                return m.reply('Chord tidak ditemukan.');
            }

            const { query, source, chord } = result.data;

            const message = `🎸 *CHORD LAGU*

📌 *Pencarian:* ${query}
🔗 *Sumber:* ${source}

━━━━━━━━━━━━━━━━━━━
${chord}`;

            await m.reply(message);
        } catch (e) {
            console.error(e);
            m.reply('Terjadi kesalahan internal.');
        }
    }
};

const axios = require('axios');

function formatDuration(ms) {
    const totalSec = Math.floor(ms / 1000);
    const min = Math.floor(totalSec / 60);
    const sec = totalSec % 60;
    return `${min}:${sec.toString().padStart(2, '0')}`;
}

module.exports = {
    name: 'spotify',
    category: 'search',
    commands: ['spotify', 'spsearch'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ m, text, config, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan judul lagu.\n\nContoh:\n*${prefix}spotify Duka Last Child*`);
            }

            const endpoint = config?.apikey?.endpoint;
            const key = config?.apikey?.key;

            if (!endpoint || !key) {
                return m.reply('Konfigurasi API belum tersedia.');
            }

            const apiUrl = `${endpoint}/api/search/spotify?q=${encodeURIComponent(text)}&apikey=${key}`;
            const res = await axios.get(apiUrl).catch(() => null);

            if (!res?.data || res.data.status !== 200 || !res.data.data?.length) {
                return m.reply('Lagu tidak ditemukan.');
            }

            const songs = res.data.data.slice(0, 5);

            let teks = `🎧 *SPOTIFY SEARCH*\n`;
            teks += `🔍 Query: ${text}\n`;
            teks += `📦 Menampilkan ${songs.length} hasil\n`;
            teks += `━━━━━━━━━━━━━━━\n\n`;

            songs.forEach((song, i) => {
                teks += `*${i + 1}. ${song.title || 'Unknown Title'}*\n`;
                teks += `👤 Artist     : ${song.artists || '-'}\n`;
                teks += `⏱ Duration   : ${song.duration_ms ? formatDuration(song.duration_ms) : '-'}\n`;
                teks += `🔥 Popularity : ${song.popularity ?? '-'}\n`;
                teks += `🔗 Link       : ${song.url || '-'}\n\n`;
            });

            teks += `━━━━━━━━━━━━━━━\n`;
            teks += `Ketik *${prefix}spdl <link>* untuk download.`;

            return m.reply(teks.trim());
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan internal.');
        }
    }
};

const axios = require('axios');

module.exports = {
    name: 'anichindetail',
    category: 'search',
    commands: ['anichindetail', 'anicindetail'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,

    async execute({ m, text, config, prefix }) {
        try {
            if (!text) {
                return m.reply(
                    `Masukkan URL detail anime dari Anichin.\n\nContoh:\n*${prefix}anichindetail https://anichin.watch/...*`
                );
            }

            const endpoint = config?.apikey?.endpoint;
            const key = config?.apikey?.key;
            if (!endpoint || !key) return m.reply('Konfigurasi API belum tersedia.');

            const apiUrl = `${endpoint}/api/search/anichin/detail?url=${encodeURIComponent(text)}&apikey=${key}`;
            const res = await axios.get(apiUrl).catch(() => null);

            if (!res || res.data.status !== 200 || !res.data.data) {
                return m.reply('Gagal mengambil data anime.');
            }

            const data = res.data.data;

            let caption = `🏮 *${data.title}*\n\n`;
            caption += `📊 Rating: ${data.rating}\n`;
            caption += `📺 Status: ${data.status}\n`;
            caption += `🎬 Tipe: ${data.type}\n`;
            caption += `🏢 Studio: ${data.studio}\n`;
            caption += `🎌 Country: ${data.country}\n`;
            caption += `⏳ Duration: ${data.duration}\n`;
            caption += `📅 Released: ${data.released}\n\n`;

            if (data.genres?.length) {
                caption += `🏷️ Genres: ${data.genres.join(', ')}\n\n`;
            }

            const synopsisLimit = 600;
            const synopsis =
                data.synopsis?.length > synopsisLimit
                    ? data.synopsis.slice(0, synopsisLimit) + '...'
                    : data.synopsis || '-';

            caption += `📖 *Synopsis:*\n${synopsis}\n\n`;

            if (!data.episodesList || data.episodesList.length === 0) {
                caption += `📺 Total Episode: 0\nTidak ada episode.`;
                return m.reply(caption.trim());
            }

            const episodes = data.episodesList.slice(0, 30);

            caption += `📺 Total Episode: ${data.episodesList.length}\n`;
            caption += `━━━━━━━━━━━━━━━\n`;

            episodes.forEach((ep) => {
                caption += `▶️ Episode ${ep.number} (${ep.date || '-'})\n`;
                caption += `   ${prefix}anichinep ${ep.url}\n`;
            });

            if (data.episodesList.length > episodes.length) {
                caption += `\n...dan ${data.episodesList.length - episodes.length} episode lainnya.`;
            }

            return m.reply(caption.trim());
        } catch (e) {
            console.error(e);
            m.reply('Terjadi kesalahan internal.');
        }
    }
};

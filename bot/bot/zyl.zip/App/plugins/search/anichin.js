module.exports = {
    name: 'anichin',
    category: 'search',
    commands: ['anichin'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,

    async execute({ m, text, config, fetchJson, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan judul donghua.\nContoh: *${prefix}anichin supreme*`);
            }

            const { endpoint, key } = config.apikey;
            const url = `${endpoint}/api/search/anichin/search?q=${encodeURIComponent(text)}&page=1&apikey=${key}`;

            const res = await fetchJson(url);

            if (!res.status || !res.data?.results?.length) {
                return m.reply('Anime tidak ditemukan. Mungkin MC-nya lagi training di gunung 🗿');
            }

            const selected = res.data.results.slice(0, 10);

            let teks = `🔎 *Hasil pencarian ANICHIN:* ${text}\n`;
            teks += `📦 *Total:* ${selected.length} hasil\n`;
            teks += `━━━━━━━━━━━━━━━\n\n`;

            selected.forEach((item, i) => {
                teks += `*${i + 1}. ${item.title || 'Tanpa judul'}*\n`;
                teks += `📺 Type   : ${item.type || '-'}\n`;
                teks += `📡 Status : ${item.status || '-'}\n`;
                teks += `🔗 Link   : ${item.link || '-'}\n\n`;
            });

            teks += `━━━━━━━━━━━━━━━\n`;
            teks += `Ketik *${prefix}anichindetail <link>* untuk lihat detail.`;

            return m.reply(teks.trim());
        } catch (err) {
            console.error(err);
            m.reply('Terjadi error teknis. Bukan bug… cuma ujian developer 😄');
        }
    }
};

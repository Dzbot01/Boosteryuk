module.exports = {
    name: 'apkpure',
    category: 'search',
    commands: ['apkpure'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ m, text, config, fetchJson, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan nama aplikasi.\nContoh: *${prefix}apkpure capcut*`);
            }

            const { endpoint, key } = config.apikey;
            const url = `${endpoint}/api/search/apkpure/search?q=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await fetchJson(url);

            if (res.status !== 200 || !res.data?.results?.length) {
                return m.reply('Aplikasi tidak ditemukan.');
            }

            const selected = res.data.results.slice(0, 10);

            let teks = `🔎 *Hasil pencarian APKPURE:* ${text}\n`;
            teks += `📦 *Total:* ${selected.length} hasil\n`;
            teks += `━━━━━━━━━━━━━━━\n\n`;

            selected.forEach((app, i) => {
                teks += `*${i + 1}. ${app.title || 'Tanpa nama'}*\n`;
                teks += `👨‍💻 Developer : ${app.developer || '-'}\n`;
                teks += `⭐ Rating     : ${app.rating || '-'}\n`;
                teks += `📦 Size       : ${app.size || '-'}\n`;
                teks += `🤖 Android    : ${app.android || '-'}\n`;
                teks += `🗓 Updated    : ${app.updated || '-'}\n`;
                teks += `🔗 Link       : ${app.link || '-'}\n`;
                teks += `⬇️ Download   : ${app.download || '-'}\n\n`;
            });

            return m.reply(teks.trim());
        } catch (err) {
            console.error(err);
            m.reply('Terjadi error teknis saat mengambil data aplikasi.');
        }
    }
};

module.exports = {
    name: 'aptoide',
    category: 'search',
    commands: ['aptoide'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ proto, Yudzxml, m, text, config, fetchJson, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan kata kunci pencarian.\nContoh: *${prefix}aptoide pou*`);
            }

            const { endpoint, key } = config.apikey;
            const url = `${endpoint}/api/search/aptoide?q=${encodeURIComponent(text)}&apikey=${key}`;
            const res = await fetchJson(url);

            if (!res.status || !Array.isArray(res.data) || res.data.length === 0) {
                return m.reply('Data tidak ditemukan. Aplikasinya mungkin lagi cuti 😄');
            }

            const items = res.data.slice(0, 10);

            const rows = items.map((item, index) => ({
                title: `${index + 1}. ${item.name}`,
                description: `Package: ${item.id}`,
                id: `${prefix}aptodl ${item.id}`
            }));

            const sections = [
                {
                    title: '📱 Daftar Aplikasi',
                    rows
                }
            ];

            const listMessage = proto.Message.InteractiveMessage.fromObject({
                body: proto.Message.InteractiveMessage.Body.fromObject({
                    text: `🔎 Hasil pencarian *Aptoide* untuk:\n*${text}*`
                }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({
                    text: ''
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                    buttons: [
                        {
                            name: 'single_select',
                            buttonParamsJson: JSON.stringify({
                                title: '📥 Pilih Aplikasi',
                                sections
                            })
                        }
                    ]
                })
            });

            await Yudzxml.relayMessage(
                m.chat,
                {
                    viewOnceMessageV2Extension: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadata: {},
                                deviceListMetadataVersion: 2
                            },
                            interactiveMessage: listMessage
                        }
                    }
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan teknis. Mesin kepikiran, bukan error 😄');
        }
    }
};

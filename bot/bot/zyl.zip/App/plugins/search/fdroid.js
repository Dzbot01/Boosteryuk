module.exports = {
    name: 'fdroid',
    category: 'search',
    commands: ['fdroid'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({
        generateWAMessageFromContent,
        proto,
        Yudzxml,
        m,
        text,
        config,
        fetchJson,
        prepareWAMessageMedia,
        prefix
    }) {
        try {
            if (!text) {
                return m.reply(`Masukkan nama aplikasi.\nContoh: *${prefix}fdroid termux*`);
            }

            const { endpoint, key } = config.apikey;
            const url = `${endpoint}/api/search/fdroid?q=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await fetchJson(url);

            if (res.status !== 200 || !res.data?.length) {
                return m.reply('Aplikasi tidak ditemukan.');
            }

            const selected = res.data.slice(0, 10);
            let cards = [];

            for (let item of selected) {
                if (!item.link) continue;

                let prepared = {};

                if (item.icon) {
                    prepared = await prepareWAMessageMedia(
                        { image: { url: item.icon } },
                        { upload: Yudzxml.waUploadToServer }
                    );
                }

                cards.push({
                    header: proto.Message.InteractiveMessage.Header.fromObject({
                        title: item.name.substring(0, 60),
                        hasMediaAttachment: !!item.icon,
                        ...prepared
                    }),

                    body: proto.Message.InteractiveMessage.Body.fromObject({
                        text:
                            `📝 ${item.summary || 'Tidak ada deskripsi.'}\n\n` +
                            `⚖ License: ${item.license || 'Unknown'}`
                    }),

                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                        buttons: [
                            {
                                name: 'cta_url',
                                buttonParamsJson: JSON.stringify({
                                    display_text: 'Download Apk',
                                    url: `${prefix}fdroiddl ${item.link}`
                                })
                            }
                        ]
                    })
                });
            }

            if (!cards.length) {
                return m.reply('Gagal memuat hasil F-Droid.');
            }

            const msgii = await generateWAMessageFromContent(
                m.chat,
                {
                    viewOnceMessageV2Extension: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadata: {},
                                deviceListMetadataVersion: 2
                            },

                            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                                body: proto.Message.InteractiveMessage.Body.fromObject({
                                    text: `📱 Hasil pencarian F-Droid untuk *${text}*`
                                }),

                                footer: proto.Message.InteractiveMessage.Footer.fromObject({
                                    text: 'F-Droid Search • Yudzxml API'
                                }),

                                carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                                    cards
                                })
                            })
                        }
                    }
                },
                { userJid: m.sender, quoted: m }
            );

            await Yudzxml.relayMessage(m.chat, msgii.message, {
                messageId: msgii.key.id
            });
        } catch (err) {
            console.error(err);
            m.reply('Terjadi error saat mengambil data F-Droid.');
        }
    }
};

module.exports = {
    name: 'brave',
    category: 'search',
    commands: ['brave'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({
        generateWAMessageFromContent,
        proto,
        Yudzxml,
        m,
        text,
        config,
        fetchJson,
        prepareWAMessageMedia,
        prefix
    }) {
        try {
            if (!text) {
                return m.reply(`Masukkan kata kunci pencarian.\nContoh: *${prefix}brave youtube api*`);
            }

            const { endpoint, key } = config.apikey;
            const url = `${endpoint}/api/search/brave?q=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await fetchJson(url);

            if (res.status !== 200 || !res.data?.length) {
                return m.reply('Hasil tidak ditemukan.');
            }

            const selected = res.data.slice(0, 10);
            let cards = [];

            for (let item of selected) {
                if (!item.link) continue;

                let domain;
                try {
                    domain = new URL(item.link).hostname;
                } catch {
                    domain = 'Unknown domain';
                }

                let prepared = {};

                if (item.thumb) {
                    prepared = await prepareWAMessageMedia(
                        { image: { url: item.thumb } },
                        { upload: Yudzxml.waUploadToServer }
                    );
                }

                cards.push({
                    header: proto.Message.InteractiveMessage.Header.fromObject({
                        title: item.title.substring(0, 80),
                        subtitle: domain,
                        hasMediaAttachment: !!item.thumb,
                        ...prepared
                    }),

                    body: proto.Message.InteractiveMessage.Body.fromObject({
                        text: item.description || 'Tidak ada deskripsi tersedia.'
                    }),

                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                        buttons: [
                            {
                                name: 'cta_url',
                                buttonParamsJson: JSON.stringify({
                                    display_text: 'Buka Link',
                                    url: item.link
                                })
                            }
                        ]
                    })
                });
            }

            if (!cards.length) {
                return m.reply('Gagal memuat hasil pencarian.');
            }

            const msgii = await generateWAMessageFromContent(
                m.chat,
                {
                    viewOnceMessageV2Extension: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadata: {},
                                deviceListMetadataVersion: 2
                            },

                            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                                body: proto.Message.InteractiveMessage.Body.fromObject({
                                    text: `🔎 Hasil pencarian Brave untuk *${text}*`
                                }),

                                footer: proto.Message.InteractiveMessage.Footer.fromObject({
                                    text: 'Brave Search • Yudzxml API'
                                }),

                                carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                                    cards
                                })
                            })
                        }
                    }
                },
                { userJid: m.sender, quoted: m }
            );

            await Yudzxml.relayMessage(m.chat, msgii.message, {
                messageId: msgii.key.id
            });
        } catch (err) {
            console.error(err);
            m.reply('Terjadi error saat mengambil hasil dari Brave.');
        }
    }
};

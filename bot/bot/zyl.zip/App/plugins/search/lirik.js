const axios = require('axios');

module.exports = {
    name: 'lirik',
    category: 'search',
    commands: ['lirik', 'lyrics'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ m, text, config, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan judul lagu.\n\nContoh:\n*${prefix}lirik Pertemuan 2 Cantika Davinca*`);
            }

            const endpoint = config?.apikey?.endpoint;
            const key = config?.apikey?.key;

            if (!endpoint || !key) {
                return m.reply('Konfigurasi API belum tersedia.');
            }

            const apiUrl = `${endpoint}/api/search/lirik?q=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await axios.get(apiUrl).catch(() => null);
            if (!res || !res.data) {
                return m.reply('Gagal menghubungi server lirik.');
            }

            const result = res.data;
            if (result.status !== 200 || !result.data) {
                return m.reply('Lirik tidak ditemukan.');
            }

            const { title, artist, lyrics } = result.data;

            const message = `🎼 *LIRIK LAGU*

📌 *Judul:* ${title}
👤 *Artis:* ${artist}

━━━━━━━━━━━━━━━━━━━
${lyrics}`;

            await m.reply(message);
        } catch (e) {
            console.error(e);
            m.reply('Terjadi kesalahan internal.');
        }
    }
};

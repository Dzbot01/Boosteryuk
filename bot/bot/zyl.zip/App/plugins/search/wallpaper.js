const axios = require('axios');

module.exports = {
    name: 'wallpaper',
    category: 'search',
    commands: ['wallpaper'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ m, text, config, prefix, Yudzxml }) {
        try {
            if (!text) {
                return m.reply(`Masukkan keyword wallpaper.\n\nContoh:\n*${prefix}wallpaper naruto*`);
            }

            const endpoint = config?.apikey?.endpoint;
            const key = config?.apikey?.key;

            if (!endpoint || !key) {
                return m.reply('Konfigurasi API belum tersedia.');
            }

            let totalWallpaper = 0;
            let albumSent = 0;

            for (let page = 1; page <= 3; page++) {
                const url = `${endpoint}/api/search/wallpaper?q=${encodeURIComponent(text)}&page=${page}&apikey=${key}`;

                const { data: res } = await axios.get(url).catch(() => ({ data: null }));

                if (!res || res.status !== 200 || !res.data?.length) {
                    break;
                }

                const images = res.data.map((item) => item.image?.[0]).filter(Boolean);

                if (!images.length) continue;

                totalWallpaper += images.length;
                albumSent++;

                const caption =
                    `🖼️ WALLPAPER SEARCH\n\n` +
                    `🔍 Query : ${text}\n` +
                    `📄 Page  : ${page}\n` +
                    `📦 Total : ${images.length} Wallpaper`;

                await Yudzxml.sendMessage(
                    m.chat,
                    {
                        album: images.map((url, i) => ({
                            image: { url },
                            caption: i === 0 ? caption : undefined
                        }))
                    },
                    { quoted: page === 1 ? m : undefined }
                );

                await new Promise((resolve) => setTimeout(resolve, 1500));
            }

            if (!albumSent) {
                return m.reply('Wallpaper tidak ditemukan.');
            }
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan internal.');
        }
    }
};

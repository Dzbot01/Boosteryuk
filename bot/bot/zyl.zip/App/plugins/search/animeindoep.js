module.exports = {
    name: 'animeindoep',
    category: 'search',
    commands: ['animeindoep'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,

    async execute({ generateWAMessageFromContent, proto, Yudzxml, m, text, config, fetchJson, prepareWAMessageMedia }) {
        try {
            if (!text) {
                return m.reply('URL episode tidak ditemukan.');
            }

            const { endpoint, key } = config.apikey;
            const url = `${endpoint}/api/search/animeindo/stream?url=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await fetchJson(url);

            if (res.status !== 200 || !res.data) {
                return m.reply('Stream episode tidak ditemukan.');
            }

            const data = res.data;

            const prepared = await prepareWAMessageMedia(
                { image: { url: data.thumbnail } },
                { upload: Yudzxml.waUploadToServer }
            );

            let buttons = [];

            if (data.servers?.length) {
                for (let srv of data.servers.slice(0, 5)) {
                    buttons.push({
                        name: 'cta_url',
                        buttonParamsJson: JSON.stringify({
                            display_text: `Stream ${srv.name}`,
                            url: srv.video
                        })
                    });
                }
            }

            if (data.downloads?.length) {
                for (let dl of data.downloads.slice(0, 5)) {
                    buttons.push({
                        name: 'cta_url',
                        buttonParamsJson: JSON.stringify({
                            display_text: dl.name,
                            url: dl.url
                        })
                    });
                }
            }

            if (!buttons.length) {
                return m.reply('Server streaming tidak tersedia.');
            }

            const msgii = await generateWAMessageFromContent(
                m.chat,
                {
                    viewOnceMessageV2Extension: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadata: {},
                                deviceListMetadataVersion: 2
                            },
                            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                                header: proto.Message.InteractiveMessage.Header.fromObject({
                                    title: data.title,
                                    hasMediaAttachment: true,
                                    ...prepared
                                }),

                                body: proto.Message.InteractiveMessage.Body.fromObject({
                                    text: `🎬 Episode Siap Ditonton\n\n` + `${data.synopsis?.slice(0, 600) || '-'}`
                                }),

                                footer: proto.Message.InteractiveMessage.Footer.fromObject({
                                    text: 'Pilih server streaming atau download di bawah'
                                }),

                                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                                    buttons
                                })
                            })
                        }
                    }
                },
                { userJid: m.sender, quoted: m }
            );

            await Yudzxml.relayMessage(m.chat, msgii.message, {
                messageId: msgii.key.id
            });
        } catch (err) {
            console.error(err);
            m.reply('Terjadi error teknis saat mengambil stream episode.');
        }
    }
};

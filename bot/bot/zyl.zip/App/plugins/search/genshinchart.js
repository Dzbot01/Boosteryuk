module.exports = {
    name: 'genshinchart',
    category: 'search',
    commands: ['genshinchart', 'gichar'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({
        generateWAMessageFromContent,
        proto,
        Yudzxml,
        m,
        text,
        config,
        fetchJson,
        prepareWAMessageMedia,
        prefix
    }) {
        try {
            if (!text) {
                return m.reply(`Masukkan nama karakter.\nContoh: *${prefix}genshinchart gaming*`);
            }

            const { endpoint, key } = config.apikey;
            const url = `${endpoint}/api/search/genshinchart?q=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await fetchJson(url);

            if (res.status !== 200 || !res.data) {
                return m.reply('Karakter tidak ditemukan.');
            }

            const data = res.data;

            const prepared = await prepareWAMessageMedia(
                { image: { url: data.image } },
                { upload: Yudzxml.waUploadToServer }
            );

            const rarityStars = '⭐'.repeat(data.rarity || 4);

            const skillList = data.skillTalents
                .slice(0, 3)
                .map((s) => `• *${s.name}* (${s.unlock})`)
                .join('\n');

            const passiveList = data.passiveTalents
                .slice(0, 3)
                .map((p) => `• ${p.name}`)
                .join('\n');

            const consList = data.constellations.map((c) => `C${c.level} - ${c.name}`).join('\n');

            const msgii = await generateWAMessageFromContent(
                m.chat,
                {
                    viewOnceMessageV2Extension: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadata: {},
                                deviceListMetadataVersion: 2
                            },

                            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                                header: proto.Message.InteractiveMessage.Header.fromObject({
                                    title: data.title,
                                    subtitle: `${data.vision} • ${data.weapon} • ${data.nation}`,
                                    hasMediaAttachment: true,
                                    ...prepared
                                }),

                                body: proto.Message.InteractiveMessage.Body.fromObject({
                                    text:
                                        `${rarityStars}\n\n` +
                                        `👤 *Name:* ${data.name}\n` +
                                        `🎂 Birthday: ${data.birthday.slice(5)}\n` +
                                        `🏛 Affiliation: ${data.affiliation}\n\n` +
                                        `📖 ${data.description.substring(0, 200)}...\n\n` +
                                        `⚔ *Talents*\n${skillList}\n\n` +
                                        `✨ *Passive*\n${passiveList}\n\n` +
                                        `🔮 *Constellation*\n${consList}`
                                }),

                                footer: proto.Message.InteractiveMessage.Footer.fromObject({
                                    text: ''
                                })
                            })
                        }
                    }
                },
                { userJid: m.sender, quoted: m }
            );

            await Yudzxml.relayMessage(m.chat, msgii.message, {
                messageId: msgii.key.id
            });
        } catch (err) {
            console.error(err);
            m.reply('Terjadi error saat mengambil data karakter.');
        }
    }
};

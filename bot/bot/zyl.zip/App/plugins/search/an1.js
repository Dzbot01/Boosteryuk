module.exports = {
    name: 'an1',
    category: 'search',
    commands: ['an1'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ m, text, config, fetchJson, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan kata kunci.\nContoh: *${prefix}an1 pou*`);
            }

            const { endpoint, key } = config.apikey;

            const res = await fetchJson(`${endpoint}/api/search/an1?q=${encodeURIComponent(text)}&apikey=${key}`);

            if (!res.status || !res.data?.length) {
                return m.reply('Data tidak ditemukan.');
            }

            const results = res.data.slice(0, 10);

            let teks = `🔎 *Hasil pencarian:* ${text}\n`;
            teks += `📦 *Total:* ${results.length} hasil\n`;
            teks += `━━━━━━━━━━━━━━━\n\n`;

            results.forEach((item, i) => {
                teks += `*${i + 1}. ${item.name || 'Tanpa nama'}*\n`;
                teks += `⭐ Rating: ${item.rating || '-'}\n`;
                teks += `🔗 Link: ${item.link || '-'}\n\n`;
            });

            teks += `━━━━━━━━━━━━━━━\n`;
            teks += `Ketik *${prefix}an1detail <link>* untuk lihat detail.`;

            return m.reply(teks.trim());
        } catch (e) {
            console.error(e);
            m.reply(String(e));
        }
    }
};

const axios = require('axios');

module.exports = {
    name: 'soundcloud',
    category: 'search',
    commands: ['soundcloud', 'scsearch'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ m, text, config, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan judul lagu.\n\nContoh:\n*${prefix}soundcloud Duka Last Child*`);
            }

            const endpoint = config?.apikey?.endpoint;
            const key = config?.apikey?.key;

            if (!endpoint || !key) {
                return m.reply('Konfigurasi API belum tersedia.');
            }

            const apiUrl = `${endpoint}/api/search/soundcloud?q=${encodeURIComponent(text)}&apikey=${key}`;
            const res = await axios.get(apiUrl).catch(() => null);

            if (!res?.data || res.data.status !== 200 || !Array.isArray(res.data.data)) {
                return m.reply('Gagal ambil data SoundCloud. API kamu mungkin lagi capek.');
            }

            const songs = res.data.data.slice(0, 5);

            let teks = `🔎 *SOUNDCLOUD SEARCH*\n`;
            teks += `📌 Query: ${text}\n`;
            teks += `📦 Hasil: ${songs.length}\n`;
            teks += `━━━━━━━━━━━━━━━\n\n`;

            songs.forEach((song, i) => {
                teks += `*${i + 1}. ${song.title || 'Unknown Title'}*\n`;
                teks += `🎧 Duration : ${song.duration || 'Unknown Duration'}\n`;
                teks += `🔗 Link     : ${song.link || '-'}\n\n`;
            });

            teks += `━━━━━━━━━━━━━━━\n`;
            teks += `Ketik *${prefix}scdl <link>* untuk download.`;

            return m.reply(teks.trim());
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan internal. Bukan salah kamu… mungkin.');
        }
    }
};

const axios = require('axios');

module.exports = {
    name: 'wikimedia',
    category: 'search',
    commands: ['wikimedia'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ Yudzxml, m, text, config, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan kata kunci pencarian.\n\nContoh:\n*${prefix}wikimedia neko*`);
            }

            const endpoint = config?.apikey?.endpoint;
            const key = config?.apikey?.key;
            if (!endpoint || !key) {
                return m.reply('Konfigurasi API belum tersedia.');
            }

            const apiUrl = `${endpoint}/api/search/wikimedia?q=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await axios.get(apiUrl).catch(() => null);
            if (!res || res.data?.status !== 200) {
                return m.reply('Gagal mengambil data Wikimedia.');
            }

            const results = res.data.data;
            if (!Array.isArray(results) || results.length === 0) {
                return m.reply('Gambar tidak ditemukan.');
            }

            const images = results.filter((item) => item?.image).slice(0, 10);

            if (!images.length) {
                return m.reply('Media tidak valid untuk ditampilkan.');
            }

            const caption = `🖼️ *WIKIMEDIA SEARCH*\n` + `🔍 Query: ${text}\n` + `📦 Menampilkan ${images.length} hasil`;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    album: images.map((item, i) => ({
                        image: { url: item.image },
                        caption: i === 0 ? caption : undefined
                    }))
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan internal.');
        }
    }
};

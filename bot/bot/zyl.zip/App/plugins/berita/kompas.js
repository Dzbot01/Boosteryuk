module.exports = {
    name: 'kompas',
    category: 'berita',
    commands: ['kompas', 'kompasnews'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ Yudzxml, m, config, fetchJson }) {
        const apiUrl = `${config.apikey.endpoint}/api/berita/kompas` + `?apikey=${config.apikey.key}`;

        const res = await fetchJson(apiUrl);

        if (!res || res.status !== 200 || !Array.isArray(res.data)) {
            return m.reply('❌ Gagal mengambil berita Kompas.');
        }

        const berita = res.data.slice(0, 7);

        if (berita.length === 0) {
            return m.reply('ℹ️ Belum ada berita terbaru dari Kompas.');
        }

        let teks = `📰 *KOMPAS NEWS HARI INI*
━━━━━━━━━━━━━━━━━━
Sumber tepercaya, tanpa clickbait berisik.

`;

        berita.forEach((item, i) => {
            teks += `${i + 1}. *${item.title}*
   🗂️ ${item.category}
   📅 ${item.date}
   🔗 ${item.link}

`;
        });

        teks += `_Update resmi dari Kompas | Dibaca secukupnya, dipikirkan sepenuhnya_`;

        const headline = berita[0];

        if (headline.img) {
            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: headline.img },
                    caption: teks
                },
                { quoted: m }
            );
        } else {
            await m.reply(teks);
        }
    }
};

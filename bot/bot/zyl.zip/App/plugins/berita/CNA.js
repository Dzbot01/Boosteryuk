module.exports = {
    name: 'CNA',
    category: 'berita',
    commands: ['cna'],
    description: 'Menampilkan berita terbaru dari CNA Indonesia',
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ Yudzxml, m, config, fetchJson }) {
        const apiUrl = `${config.apikey.endpoint}/api/berita/cna` + `?apikey=${config.apikey.key}`;

        const res = await fetchJson(apiUrl);

        if (!res || res.status !== 200 || !res.data?.articles?.length) {
            return m.reply('❌ Gagal mengambil data berita.');
        }

        const { pageTitle, total, articles } = res.data;

        let teks = `📰 *BERITA ${pageTitle.toUpperCase()}*\n`;
        teks += `📊 Total: ${total} berita\n\n`;

        articles.slice(0, 8).forEach((item, index) => {
            teks += `*${index + 1}. ${item.title}*
🗓️ ${item.date}
🔗 ${item.link}

`;
        });

        teks += `_Sumber: CNA Indonesia_`;

        await Yudzxml.sendMessage(
            m.chat,
            {
                image: { url: articles[0].imageUrl },
                caption: teks
            },
            { quoted: m }
        );
    }
};

module.exports = {
    name: 'CNN',
    category: 'berita',
    commands: ['cnn'],
    description: 'Menampilkan berita terbaru dari CNN Indonesia',
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ Yudzxml, m, config, fetchJson }) {
        const apiUrl = `${config.apikey.endpoint}/api/berita/cnn` + `?apikey=${config.apikey.key}`;

        const res = await fetchJson(apiUrl);

        if (!res || res.status !== 200 || !Array.isArray(res.data) || res.data.length === 0) {
            return m.reply('❌ Gagal mengambil data berita CNN atau data kosong.');
        }

        const articles = res.data;
        const totalNews = articles.length;

        let teks = `📰 *BERITA TERKINI CNN INDONESIA*\n`;
        teks += `📊 Total: ${totalNews} berita tersedia\n\n`;

        articles.slice(0, 8).forEach((item, index) => {
            let category = 'UMUM';
            try {
                const match = item.berita_url.match(/cnnindonesia\.com\/([^/]+)/);
                if (match && match[1]) category = match[1].toUpperCase();
            } catch (_) {}

            teks += `*${index + 1}. ${item.berita}*
🏷️ ${category}
👤 ${item.creator}
🔗 ${item.berita_url}

`;
        });

        teks += `_Sumber: CNN Indonesia via API_`;

        const thumbnailUrl = articles[0]?.berita_thumb;

        if (thumbnailUrl) {
            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: thumbnailUrl },
                    caption: teks
                },
                { quoted: m }
            );
        } else {
            await m.reply(teks);
        }
    }
};

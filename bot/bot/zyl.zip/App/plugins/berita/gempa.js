module.exports = {
    name: 'infogempa',
    category: 'berita',
    commands: ['infogempa'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ Yudzxml, m, config, fetchJson }) {
        const apiUrl = `${config.apikey.endpoint}/api/berita/infogempa` + `?apikey=${config.apikey.key}`;

        const res = await fetchJson(apiUrl);

        if (!res || res.status !== 200) {
            return m.reply('❌ Gagal mengambil data gempa.');
        }

        const auto = res.data?.auto?.Infogempa?.gempa;
        const dirasakan = res.data?.dirasakan?.Infogempa?.gempa || [];
        const terkini = res.data?.terkini?.Infogempa?.gempa || [];

        if (!auto) {
            return m.reply('⚠️ Data gempa terbaru tidak tersedia.');
        }

        let teks = `🌏 *INFO GEMPA TERKINI*\n`;
        teks += `━━━━━━━━━━━━━━━━━━\n`;
        teks += `📅 *Tanggal* : ${auto.Tanggal}\n`;
        teks += `⏰ *Waktu*   : ${auto.Jam}\n`;
        teks += `📍 *Lokasi*  : ${auto.Wilayah}\n`;
        teks += `📐 *Koordinat* : ${auto.Lintang}, ${auto.Bujur}\n`;
        teks += `📊 *Magnitudo* : M ${auto.Magnitude}\n`;
        teks += `📉 *Kedalaman* : ${auto.Kedalaman}\n`;

        if (auto.Dirasakan) {
            teks += `📢 *Dirasakan* : ${auto.Dirasakan}\n`;
        }

        if (auto.Potensi) {
            teks += `⚠️ *Potensi* : ${auto.Potensi}\n`;
        }

        if (dirasakan.length > 0) {
            teks += `\n📌 *GEMPA DIRASAKAN TERAKHIR*\n`;
            dirasakan.slice(0, 3).forEach((g, i) => {
                teks += `• ${g.Tanggal} | ${g.Jam}
  M ${g.Magnitude} | ${g.Kedalaman}
  ${g.Wilayah}
  Dirasakan: ${g.Dirasakan}

`;
            });
        }

        if (terkini.length > 0) {
            teks += `📊 *GEMPA TERKINI (GLOBAL)*\n`;
            terkini.slice(0, 3).forEach((g, i) => {
                teks += `• ${g.Tanggal} | ${g.Jam}
  M ${g.Magnitude} | ${g.Kedalaman}
  ${g.Wilayah}
  ${g.Potensi}

`;
            });
        }

        teks += `_Sumber: BMKG | Data bersifat informatif_`;

        if (auto.downloadShakemap) {
            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: auto.downloadShakemap },
                    caption: teks
                },
                { quoted: m }
            );
        } else {
            await m.reply(teks);
        }
    }
};

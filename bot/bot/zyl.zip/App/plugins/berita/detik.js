module.exports = {
    name: 'DETIK',
    category: 'berita',
    commands: ['detik'],
    description: 'Menampilkan berita terbaru dari Detik.com',
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ Yudzxml, m, config, fetchJson }) {
        const apiUrl = `${config.apikey.endpoint}/api/berita/detik` + `?apikey=${config.apikey.key}`;

        const res = await fetchJson(apiUrl);

        if (!res || res.status !== 200 || !Array.isArray(res.data) || res.data.length === 0) {
            return m.reply('❌ Gagal mengambil data berita Detik.');
        }

        const articles = res.data;
        const totalNews = articles.length;

        let teks = `📰 *BERITA TERKINI DETIK.COM*\n`;
        teks += `📊 Total: ${totalNews} berita tersedia\n\n`;

        articles.slice(0, 8).forEach((item, index) => {
            let category = 'UMUM';
            try {
                const urlObj = new URL(item.berita_url);
                const sub = urlObj.hostname.split('.')[0];
                category = sub.toUpperCase();
            } catch (_) {}

            teks += `*${index + 1}. ${item.berita}*
🏷️ ${category}
🗓️ ${item.berita_diupload}
👤 ${item.creator}
🔗 ${item.berita_url}

`;
        });

        teks += `_Sumber: Detik.com via API_`;

        const thumbnailUrl = articles[0]?.berita_thumb;

        if (thumbnailUrl) {
            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: thumbnailUrl },
                    caption: teks
                },
                { quoted: m }
            );
        } else {
            await m.reply(teks);
        }
    }
};

module.exports = {
    name: 'kontan',
    category: 'berita',
    commands: ['kontan'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ Yudzxml, m, config, fetchJson }) {
        const apiUrl = `${config.apikey.endpoint}/api/berita/kontan` + `?apikey=${config.apikey.key}`;

        const res = await fetchJson(apiUrl);

        if (!res || res.status !== 200 || !Array.isArray(res.data)) {
            return m.reply('❌ Gagal mengambil berita Kontan.');
        }

        const berita = res.data.slice(0, 8);

        if (berita.length === 0) {
            return m.reply('ℹ️ Belum ada update terbaru dari Kontan.');
        }

        let teks = `💼 *KONTAN – UPDATE BISNIS & EKONOMI*
━━━━━━━━━━━━━━━━━━
Pasar bergerak cepat, informasinya jangan tertinggal.

`;

        berita.forEach((item, i) => {
            teks += `${i + 1}. *${item.berita}*
   🏷️ ${item.berita_jenis}
   ⏱️ ${item.berita_diupload.trim()}
   🔗 ${item.berita_url}

`;
        });

        teks += `_Sumber: Kontan | Baca cepat, analisis cermat_`;

        const headline = berita[0];

        if (headline.berita_thumb) {
            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: headline.berita_thumb },
                    caption: teks
                },
                { quoted: m }
            );
        } else {
            await m.reply(teks);
        }
    }
};

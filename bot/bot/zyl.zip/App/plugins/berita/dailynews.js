module.exports = {
    name: 'DAILYNEWS',
    category: 'berita',
    commands: ['dailynews', 'dnid'],
    description: 'Menampilkan berita terbaru dari DailyNews Indonesia',
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ Yudzxml, m, config, fetchJson }) {
        const apiUrl = `${config.apikey.endpoint}/api/berita/dailynews` + `?apikey=${config.apikey.key}`;

        const res = await fetchJson(apiUrl);

        if (!res || res.status !== 200 || !Array.isArray(res.data) || res.data.length === 0) {
            return m.reply('❌ Gagal mengambil data DailyNews atau data kosong.');
        }

        const articles = res.data;
        const totalNews = articles.length;

        let teks = `🗞️ *DAILYNEWS INDONESIA*\n`;
        teks += `📊 Total: ${totalNews} berita terbaru\n\n`;

        articles.slice(0, 8).forEach((item, index) => {
            teks += `*${index + 1}. ${item.title}*
🔗 ${item.url}

`;
        });

        teks += `_Sumber: DailyNews Indonesia (dnid.co.id)_`;

        await m.reply(teks);
    }
};

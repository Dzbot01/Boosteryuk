module.exports = {
    name: 'INEWS',
    category: 'berita',
    commands: ['inews'],
    description: 'Menampilkan berita terbaru dari iNews.id',
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ Yudzxml, m, config, fetchJson }) {
        const apiUrl = `${config.apikey.endpoint}/api/berita/inews` + `?apikey=${config.apikey.key}`;

        const res = await fetchJson(apiUrl);

        if (!res || res.status !== 200 || !Array.isArray(res.data) || res.data.length === 0) {
            return m.reply('❌ Gagal mengambil data berita iNews.');
        }

        const articles = res.data;
        const totalNews = articles.length;

        let teks = `📰 *BERITA TERKINI INEWS.ID*\n`;
        teks += `📊 Total: ${totalNews} berita tersedia\n\n`;

        articles.slice(0, 8).forEach((item, index) => {
            let category = 'UMUM';
            try {
                const match = item.url.match(/inews\.id\/([^/]+)/);
                if (match && match[1]) category = match[1].toUpperCase();
            } catch (_) {}

            teks += `*${index + 1}. ${item.title}*
🏷️ ${category}
🗓️ ${item.date}
🔗 ${item.url}

`;
        });

        teks += `_Sumber: iNews.id via API_`;

        const thumbnailUrl = articles[0]?.imgUrl;

        if (thumbnailUrl) {
            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: thumbnailUrl },
                    caption: teks
                },
                { quoted: m }
            );
        } else {
            await m.reply(teks);
        }
    }
};

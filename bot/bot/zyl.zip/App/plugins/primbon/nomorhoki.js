const axios = require('axios');

module.exports = {
    name: 'nomorhoki',
    category: 'primbon',
    commands: ['nomorhoki'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ m, text, config, prefix }) {
        try {
            if (!text) {
                return m.reply(`Format salah.\n\nContoh:\n` + `*${prefix}nomorhoki 083872031397*`);
            }

            const endpoint = config?.apikey?.endpoint;
            const apikey = config?.apikey?.key;

            if (!endpoint || !apikey) {
                return m.reply('Konfigurasi API belum tersedia.');
            }

            const url =
                `${endpoint}/api/primbon/nomorhoki` + `?apikey=${apikey}` + `&nomor=${encodeURIComponent(text)}`;

            const res = await axios.get(url).catch(() => null);

            if (!res || res.data?.status !== 200) {
                return m.reply('Gagal mengambil data nomor hoki.');
            }

            const result = res.data.data;

            if (!result || !result.data || !result.data.nomor) {
                return m.reply('Data nomor hoki tidak ditemukan atau format respons berubah.');
            }

            const data = result.data;
            const { nomor, angka_bagua_shuzi, energi_positif, energi_negatif, analisis } = data;

            let replyText = `🔢 *NOMOR HOKI PRIMBON*\n\n`;

            replyText += `📱 *Nomor*: ${nomor}\n\n`;

            replyText += `📊 *Angka Bagua Shuzi*\n`;
            replyText += `Nilai  : ${angka_bagua_shuzi.value}%\n`;
            replyText += `Ket    : ${angka_bagua_shuzi.description}\n\n`;

            replyText += `✅ *Energi Positif* (${energi_positif.total}%)\n`;
            replyText += `Kekayaan   : ${energi_positif.details.kekayaan}\n`;
            replyText += `Kesehatan  : ${energi_positif.details.kesehatan}\n`;
            replyText += `Cinta      : ${energi_positif.details.cinta}\n`;
            replyText += `Kestabilan : ${energi_positif.details.kestabilan}\n`;
            replyText += `Desc       : ${energi_positif.description}\n\n`;

            replyText += `❌ *Energi Negatif* (${energi_negatif.total}%)\n`;
            replyText += `Perselisihan : ${energi_negatif.details.perselisihan}\n`;
            replyText += `Kehilangan   : ${energi_negatif.details.kehilangan}\n`;
            replyText += `Malapetaka   : ${energi_negatif.details.malapetaka}\n`;
            replyText += `Kehancuran   : ${energi_negatif.details.kehancuran}\n`;
            replyText += `Desc         : ${energi_negatif.description}\n\n`;

            replyText += `📝 *Kesimpulan*\n`;
            replyText += `${analisis.description}\n`;

            const isHoki = energi_positif.total > 60 && angka_bagua_shuzi.value >= 60;
            replyText += `\nStatus: ${isHoki ? '✅ *HOKI*' : '⚠️ *KURANG HOKI*'}`;

            await m.reply(replyText);
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan internal.');
        }
    }
};

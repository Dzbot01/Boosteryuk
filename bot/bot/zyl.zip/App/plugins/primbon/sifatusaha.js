const axios = require('axios');

module.exports = {
    name: 'sifatusaha',
    category: 'primbon',
    commands: ['sifatusaha'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ m, text, config, prefix }) {
        try {
            if (!text || !text.includes('|')) {
                return m.reply(`Format salah.\n\nContoh:\n` + `*${prefix}sifatusaha 1|1|2004*`);
            }

            const args = text.split('|').map((v) => v.trim());
            if (args.length !== 3) {
                return m.reply('Data tidak lengkap. Pastikan format: Tgl|Bln|Thn');
            }

            const [tgl, bln, thn] = args;

            const endpoint = config?.apikey?.endpoint;
            const apikey = config?.apikey?.key;

            if (!endpoint || !apikey) {
                return m.reply('Konfigurasi API belum tersedia.');
            }

            const url =
                `${endpoint}/api/primbon/sifatusaha` + `?apikey=${apikey}` + `&tgl=${tgl}&bln=${bln}&thn=${thn}`;

            const res = await axios.get(url).catch(() => null);

            if (!res || res.data?.status !== 200) {
                return m.reply('Gagal mengambil data sifat usaha.');
            }

            const data = res.data.data;

            if (!data) {
                return m.reply('Data sifat usaha tidak tersedia.');
            }

            let replyText = `💼 *SIFAT USAHA PRIMBON*\n\n`;

            replyText += `📅 *Hari Lahir*: ${data.hari_lahir}\n\n`;

            replyText += `📈 *Analisa Sifat Bisnis*\n`;
            replyText += `${data.usaha}\n\n`;

            replyText += `📝 *Catatan*\n`;
            replyText += `${data.catatan}`;

            await m.reply(replyText);
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan internal.');
        }
    }
};

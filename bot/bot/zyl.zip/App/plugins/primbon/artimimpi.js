const axios = require('axios');

module.exports = {
    name: 'artimimpi',
    category: 'primbon',
    commands: ['artimimpi'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ m, text, config, prefix }) {
        try {
            if (!text) {
                return m.reply(`Format salah.\n\nContoh:\n` + `*${prefix}artimimpi bertemu orang tua*`);
            }

            const endpoint = config?.apikey?.endpoint;
            const apikey = config?.apikey?.key;

            if (!endpoint || !apikey) {
                return m.reply('Konfigurasi API belum tersedia.');
            }

            const url =
                `${endpoint}/api/primbon/artimimpi` + `?apikey=${apikey}` + `&mimpi=${encodeURIComponent(text)}`;

            const res = await axios.get(url).catch(() => null);

            if (!res || res.data?.status !== 200) {
                return m.reply(
                    'Gagal mengambil data arti mimpi. Mungkin server sedang sibuk atau kata kunci tidak ditemukan.'
                );
            }

            const data = res.data.data;
            if (!data || !data.hasil || data.hasil.length === 0) {
                return m.reply('Tidak ada hasil tafsir untuk kata kunci tersebut.');
            }

            const { keyword, total, hasil, solusi } = data;

            let replyText = `💭 *ARTI MIMPI - PRIMBON*\n\n`;
            replyText += `🔍 *Kata Kunci*: ${keyword}\n`;
            replyText += `📊 *Ditemukan*: ${total} hasil\n\n`;

            replyText += `━━━━━━━━━━━━━━━━━━\n`;

            hasil.forEach((item, index) => {
                const cleanMimpi = item.mimpi.replace(/[\r\n]+/g, ' ').trim();
                const cleanTafsir = item.tafsir.replace(/[\r\n]+/g, ' ').trim();

                replyText += `*[${index + 1}]* ${cleanMimpi}\n`;
                replyText += `▸ ${cleanTafsir}\n\n`;
            });

            if (solusi) {
                replyText += `━━━━━━━━━━━━━━━━━━\n`;
                replyText += `✨ *Solusi & Penanggulangan*\n`;
                replyText += `${solusi}`;
            }

            await m.reply(replyText);
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan internal.');
        }
    }
};

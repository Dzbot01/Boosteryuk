const axios = require('axios');

module.exports = {
    name: 'artizodiac',
    category: 'primbon',
    commands: ['artizodiac'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ m, text, config, prefix }) {
        try {
            if (!text) {
                return m.reply(`Format salah.\n\nContoh:\n` + `*${prefix}artizodiac Gemini*`);
            }

            const endpoint = config?.apikey?.endpoint;
            const apikey = config?.apikey?.key;

            if (!endpoint || !apikey) {
                return m.reply('Konfigurasi API belum tersedia.');
            }

            const url =
                `${endpoint}/api/primbon/artizodiac` + `?apikey=${apikey}` + `&zodiac=${encodeURIComponent(text)}`;

            const res = await axios.get(url).catch(() => null);

            if (!res || res.data?.status !== 200) {
                return m.reply('Gagal mengambil data zodiak. Pastikan nama zodiak benar (contoh: Gemini, Capricorn).');
            }

            const data = res.data.data;

            if (!data || !data.zodiak) {
                return m.reply('Data zodiak tidak ditemukan.');
            }

            let replyText = `♊ *ARTI ZODIAK PRIMBON*\n\n`;

            replyText += `🌟 *Identitas Zodiak*\n`;
            replyText += `${data.zodiak}\n\n`;

            replyText += `🍀 *Keberuntungan*\n`;
            replyText += `Nomor  : ${data.nomor_keberuntungan}\n`;
            replyText += `Warna  : ${data.warna_keberuntungan}\n`;
            replyText += `Batu   : ${data.batu_keberuntungan}\n`;
            replyText += `Bunga  : ${data.bunga_keberuntungan}\n`;
            replyText += `Aroma  : ${data.aroma_keberuntungan}\n`;
            replyText += `Elemen : ${data.elemen_keberuntungan}\n`;
            replyText += `Planet : ${data.planet_yang_mengitari}\n\n`;

            replyText += `💕 *Pasangan & Karakter*\n`;
            replyText += `${data.pasangan_zodiak}`;

            await m.reply(replyText);
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan internal.');
        }
    }
};

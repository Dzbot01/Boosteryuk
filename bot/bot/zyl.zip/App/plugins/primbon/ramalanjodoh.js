const axios = require('axios');

module.exports = {
    name: 'ramalanjodoh',
    category: 'primbon',
    commands: ['ramalanjodoh'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ m, text, config, prefix }) {
        try {
            if (!text || !text.includes('|')) {
                return m.reply(`Format salah.\n\nContoh:\n` + `*${prefix}ramalanjodoh yddz|1|2|3456|nani|1|2|3456*`);
            }

            const args = text.split('|').map((v) => v.trim());
            if (args.length !== 8) {
                return m.reply('Data tidak lengkap. Pastikan ada 8 parameter.');
            }

            const [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = args;

            const endpoint = config?.apikey?.endpoint;
            const apikey = config?.apikey?.key;
            if (!endpoint || !apikey) {
                return m.reply('Konfigurasi API belum tersedia.');
            }

            const url =
                `${endpoint}/api/primbon/ramalanjodoh` +
                `?apikey=${apikey}` +
                `&nama1=${encodeURIComponent(nama1)}` +
                `&tgl1=${tgl1}&bln1=${bln1}&thn1=${thn1}` +
                `&nama2=${encodeURIComponent(nama2)}` +
                `&tgl2=${tgl2}&bln2=${bln2}&thn2=${thn2}`;

            const res = await axios.get(url).catch(() => null);
            if (!res || res.data?.status !== 200) {
                return m.reply('Gagal mengambil data ramalan jodoh.');
            }

            const data = res.data.data;
            if (!data || !data.pasangan) {
                return m.reply('Data ramalan tidak tersedia.');
            }

            const { pasangan, ramalan, catatan } = data;

            let hasil = `💞 *RAMALAN JODOH PRIMBON*\n\n`;

            hasil += `👤 *Pasangan Pertama*\n`;
            hasil += `Nama   : ${pasangan.pertama.nama}\n`;
            hasil += `${pasangan.pertama.tanggal_lahir}\n\n`;

            hasil += `👤 *Pasangan Kedua*\n`;
            hasil += `Nama   : ${pasangan.kedua.nama}\n`;
            hasil += `${pasangan.kedua.tanggal_lahir}\n\n`;

            hasil += `📜 *Hasil Perhitungan*\n`;
            for (const item of ramalan) {
                hasil += `\n${item.poin}\n`;
                hasil += `${item.hasil}\n`;
            }

            hasil += `\n📝 *Catatan Penting*\n`;
            hasil += catatan;

            await m.reply(hasil);
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan internal.');
        }
    }
};

const axios = require('axios');

module.exports = {
    name: 'kecocokanpasangan',
    category: 'primbon',
    commands: ['kecocokanpasangan'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ m, text, config, prefix }) {
        try {
            if (!text || !text.includes('|')) {
                return m.reply(`Format salah.\n\nContoh:\n` + `*${prefix}kecocokanpasangan joko|siti*`);
            }

            const args = text.split('|').map((v) => v.trim());
            if (args.length < 2) {
                return m.reply('Harap masukkan kedua nama.');
            }

            const [nama, nama2] = args;

            const endpoint = config?.apikey?.endpoint;
            const apikey = config?.apikey?.key;

            if (!endpoint || !apikey) {
                return m.reply('Konfigurasi API belum tersedia.');
            }

            const url =
                `${endpoint}/api/primbon/kecocokanpasangan` +
                `?apikey=${apikey}` +
                `&nama=${encodeURIComponent(nama)}` +
                `&nama2=${encodeURIComponent(nama2)}`;

            const res = await axios.get(url).catch(() => null);

            if (!res || res.data?.status !== 200) {
                return m.reply('Gagal mengambil data kecocokan pasangan.');
            }

            const data = res.data.data;

            if (!data || !data.nama_anda) {
                return m.reply('Data kecocokan tidak ditemukan.');
            }

            let replyText = `💞 *KECOCOKAN PASANGAN*\n\n`;

            replyText += `👤 *Nama Anda*     : ${data.nama_anda}\n`;
            replyText += `👤 *Nama Pasangan* : ${data.nama_pasangan}\n\n`;

            replyText += `✅ *Sisi Positif*\n`;
            replyText += `${data.sisi_positif}\n\n`;

            replyText += `⚠️ *Sisi Negatif*\n`;
            replyText += `${data.sisi_negatif}\n\n`;

            replyText += `📝 *Catatan*\n`;
            replyText += `${data.catatan}`;

            await m.reply(replyText);
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan internal.');
        }
    }
};

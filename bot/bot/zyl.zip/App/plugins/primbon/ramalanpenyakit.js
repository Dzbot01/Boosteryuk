const axios = require('axios');

module.exports = {
    name: 'ramalanpenyakit',
    category: 'primbon',
    commands: ['ramalanpenyakit'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ m, text, config, prefix }) {
        try {
            if (!text || !text.includes('|')) {
                return m.reply(`Format salah.\n\nContoh:\n` + `*${prefix}ramalanpenyakit 1|4|2004*`);
            }

            const args = text.split('|').map((v) => v.trim());
            if (args.length !== 3) {
                return m.reply('Data tidak lengkap. Pastikan format: Tgl|Bln|Thn');
            }

            const [tgl, bln, thn] = args;

            const endpoint = config?.apikey?.endpoint;
            const apikey = config?.apikey?.key;

            if (!endpoint || !apikey) {
                return m.reply('Konfigurasi API belum tersedia.');
            }

            const url =
                `${endpoint}/api/primbon/ramalanpenyakit` + `?apikey=${apikey}` + `&tgl=${tgl}&bln=${bln}&thn=${thn}`;

            const res = await axios.get(url).catch(() => null);

            if (!res || res.data?.status !== 200) {
                return m.reply('Gagal mengambil data ramalan penyakit.');
            }

            const data = res.data.data;

            if (!data) {
                return m.reply('Data ramalan penyakit tidak tersedia.');
            }

            let replyText = `🏥 *RAMALAN PENYAKIT (PITAGORAS)*\n\n`;

            replyText += `📅 *Tanggal Lahir*: ${tgl}/${bln}/${thn}\n\n`;

            replyText += `🔢 *Analisa Angka*\n`;
            replyText += `${data.analisa}\n\n`;

            replyText += `🧬 *Sektor Elemen*\n`;
            replyText += `${data.sektor}\n\n`;

            replyText += `⚕️ *Potensi & Elemen*\n`;
            replyText += `${data.elemen}\n\n`;

            replyText += `📝 *Catatan Penting*\n`;
            replyText += `${data.catatan}`;

            await m.reply(replyText);
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan internal.');
        }
    }
};

const axios = require('axios');

module.exports = {
    name: 'ramalanjodohbali',
    category: 'primbon',
    commands: ['ramalanjodohbali'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ m, text, config, prefix }) {
        try {
            if (!text || !text.includes('|')) {
                return m.reply(
                    `Format salah.\n\nContoh:\n` + `*${prefix}ramalanjodohbali Joko|20|12|2001|Siti|21|1|2001*`
                );
            }

            const args = text.split('|').map((v) => v.trim());
            if (args.length !== 8) {
                return m.reply('Data tidak lengkap. Pastikan ada 8 parameter (Nama, Tgl, Bln, Thn) untuk dua orang.');
            }

            const [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = args;

            const endpoint = config?.apikey?.endpoint;
            const apikey = config?.apikey?.key;

            if (!endpoint || !apikey) {
                return m.reply('Konfigurasi API belum tersedia.');
            }

            const url =
                `${endpoint}/api/primbon/ramalanjodohbali` +
                `?apikey=${apikey}` +
                `&nama1=${encodeURIComponent(nama1)}` +
                `&tgl1=${tgl1}&bln1=${bln1}&thn1=${thn1}` +
                `&nama2=${encodeURIComponent(nama2)}` +
                `&tgl2=${tgl2}&bln2=${bln2}&thn2=${thn2}`;

            const res = await axios.get(url).catch(() => null);

            if (!res || res.data?.status !== 200) {
                return m.reply('Gagal mengambil data ramalan jodoh Bali.');
            }

            const data = res.data.data;

            if (!data) {
                return m.reply('Data ramalan tidak tersedia.');
            }

            let replyText = `🌺 *RAMALAN JODOH BALI*\n\n`;

            replyText += `👤 *Pasangan Pertama*\n`;
            replyText += `Nama   : ${data.nama_anda.nama}\n`;
            replyText += `Lahir  : ${data.nama_anda.tgl_lahir}\n\n`;

            replyText += `👤 *Pasangan Kedua*\n`;
            replyText += `Nama   : ${data.nama_pasangan.nama}\n`;
            replyText += `Lahir  : ${data.nama_pasangan.tgl_lahir}\n\n`;

            replyText += `📜 *Hasil Patemon (Perhitungan)*\n`;

            const formattedResult = data.result
                .replace(/\./g, '.\n')
                .replace(/(\*)/g, '\n\n*')
                .replace(/(II\.)/g, '\n\nII.')
                .replace(/(I\.)/g, '\n\nI.');

            replyText += `${formattedResult}\n\n`;

            replyText += `📝 *Catatan*\n`;
            replyText += `${data.catatan}`;

            await m.reply(replyText);
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan internal.');
        }
    }
};

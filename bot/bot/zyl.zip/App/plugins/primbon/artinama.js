const axios = require('axios');

module.exports = {
    name: 'artinama',
    category: 'primbon',
    commands: ['artinama'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ m, text, config, prefix }) {
        try {
            if (!text) {
                return m.reply(`Format salah.\n\nContoh:\n` + `*${prefix}artinama YudzDev*`);
            }

            const endpoint = config?.apikey?.endpoint;
            const apikey = config?.apikey?.key;

            if (!endpoint || !apikey) {
                return m.reply('Konfigurasi API belum tersedia.');
            }

            const url = `${endpoint}/api/primbon/artinama` + `?apikey=${apikey}` + `&nama=${encodeURIComponent(text)}`;

            const res = await axios.get(url).catch(() => null);

            if (!res || res.data?.status !== 200) {
                return m.reply('Gagal mengambil data arti nama. Pastikan nama yang dimasukkan benar.');
            }

            const { nama, arti } = res.data.data;

            if (!nama || !arti) {
                return m.reply('Data arti nama tidak ditemukan.');
            }

            let replyText = `💡 *ARTI NAMA PRIMBON*\n\n`;
            replyText += `👤 *Nama*: ${nama}\n\n`;
            replyText += `📖 *Artinya*:\n`;
            replyText += `${arti}`;

            await m.reply(replyText);
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan internal.');
        }
    }
};

module.exports = {
    name: 'asmaulHusna',
    category: 'islami',
    commands: ['asmaulhusna'],
    description: 'Menampilkan Asmaul Husna (1–99)',
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ Yudzxml, m, config, text }) {
        try {
            const { endpoint, key } = config.apikey;

            const input = text;
            const isNumber = input && !isNaN(input) && Number(input) >= 1 && Number(input) <= 99;

            const query = isNumber ? input : '';

            const url = `${endpoint}/api/islami/asmaulhusna?q=${query}&apikey=${key}`;

            const response = await fetch(url);
            if (!response.ok) {
                throw new Error(`API Error: ${response.status}`);
            }

            const result = await response.json();

            if (!result?.data?.status || !Array.isArray(result.data.result)) {
                return m.reply('📭 Data Asmaul Husna tidak ditemukan.');
            }

            const list = result.data.result;

            if (!isNumber) {
                let text = `🕋 *Asmaul Husna (99 Nama Allah)*\n\n`;

                for (const asma of list) {
                    text += `🔢 ${asma.no}. ${asma.nama}\n📖 ${asma.latin} — ${asma.arti}\n\n`;
                }

                text += `— _${result.author}_`;

                return Yudzxml.sendMessage(m.chat, { text: text.trim() }, { quoted: m });
            }

            const asma = list[0];
            if (!asma) {
                return m.reply('❌ Asmaul Husna tidak ditemukan.');
            }

            const message = `
🕋 *Asmaul Husna*

🔢 *Nomor:* ${asma.no}
📿 *Nama Arab:* ${asma.nama}
📖 *Latin:* ${asma.latin}
💡 *Arti:* ${asma.arti}

— _${result.author}_
            `.trim();

            await Yudzxml.sendMessage(m.chat, { text: message }, { quoted: m });
        } catch (error) {
            console.error('[ASMAULHUSNA ERROR]', error);
            m.reply('⚠️ Terjadi kesalahan saat memproses Asmaul Husna.');
        }
    }
};

module.exports = {
    name: 'kisahnabi',
    category: 'islami',
    commands: ['kisahnabi'],
    description: 'Menampilkan kisah para Nabi dan Rasul',
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ Yudzxml, m, prefix, config, command, text }) {
        try {
            if (!text) {
                return m.reply(
                    `❌ Cara penggunaan:\n${prefix + command} <nama nabi>\n\nContoh:\n${prefix + command} adam`
                );
            }

            const query = encodeURIComponent(text);
            const { endpoint, key } = config.apikey;

            const url = `${endpoint}/api/islami/kisahnabi?q=${query}&apikey=${key}`;

            const response = await fetch(url);
            if (!response.ok) {
                throw new Error(`API Error: ${response.status}`);
            }

            const result = await response.json();

            if (!result.data || !result.data.kisah) {
                return m.reply('📭 Kisah nabi tidak ditemukan.');
            }

            const { title, tahun, kisah } = result.data;

            const MAX_LENGTH = 50000;
            const kisahSingkat =
                kisah.length > MAX_LENGTH ? kisah.substring(0, MAX_LENGTH) + '\n\n...(kisah dipersingkat)' : kisah;

            const message = `
📜 *KISAH NABI*

👤 *Nama:* ${title}
🕰️ *Periode:* ${tahun}

━━━━━━━━━━━━━━
${kisahSingkat}
━━━━━━━━━━━━━━

📖 _Diambil dari kisah para Nabi untuk pembelajaran dan hikmah._
            `.trim();

            await Yudzxml.sendMessage(m.chat, { text: message }, { quoted: m });
        } catch (error) {
            console.error('[KISAH NABI ERROR]', error);
            m.reply('⚠️ Terjadi kesalahan saat mengambil kisah nabi. Silakan coba lagi nanti.');
        }
    }
};

module.exports = {
    name: 'doa',
    category: 'islami',
    commands: ['doa'],
    description: 'Menampilkan doa-doa harian Islami',
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ Yudzxml, m, prefix, config, command, text }) {
        try {
            if (!text) {
                return m.reply('❌  Cara Penggunaan: ' + `${prefix + command} doa masuk kamar mandi`);
            }

            const { endpoint, key } = config.apikey;

            const url = `${endpoint}/api/islami/doa?q=${text}&apikey=${key}`;

            const response = await fetch(url);
            if (!response.ok) {
                throw new Error(`API Error: ${response.status}`);
            }

            const result = await response.json();

            if (!result.data || !Array.isArray(result.data) || result.data.length === 0) {
                return m.reply('📭 Doa tidak ditemukan untuk saat ini.');
            }

            const doa = result.data[0];

            const message = `
📿 *${doa.title}*

🕋 *Arab:*
${doa.arab}

📖 *Latin:*
_${doa.latin}_

💡 *Artinya:*
"${doa.artinya}"
            `.trim();

            await Yudzxml.sendMessage(m.chat, { text: message }, { quoted: m });
        } catch (error) {
            console.error('[DOA MODULE ERROR]', error);
            m.reply('⚠️ Terjadi kesalahan saat mengambil doa. Silakan coba lagi nanti.');
        }
    }
};

module.exports = {
    name: 'listsurah',
    category: 'islami',
    commands: ['listsurah'],
    description: 'Menampilkan daftar surah Al-Qur’an (1–114)',
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ Yudzxml, m, prefix }) {
        try {
            const surahList = [
                'Al-Fatihah',
                'Al-Baqarah',
                'Ali Imran',
                'An-Nisa',
                "Al-Ma'idah",
                "Al-An'am",
                "Al-A'raf",
                'Al-Anfal',
                'At-Taubah',
                'Yunus',
                'Hud',
                'Yusuf',
                "Ar-Ra'd",
                'Ibrahim',
                'Al-Hijr',
                'An-Nahl',
                'Al-Isra',
                'Al-Kahfi',
                'Maryam',
                'Ta-Ha',
                'Al-Anbiya',
                'Al-Hajj',
                'Al-Mu’minun',
                'An-Nur',
                'Al-Furqan',
                'Asy-Syu’ara',
                'An-Naml',
                'Al-Qasas',
                'Al-Ankabut',
                'Ar-Rum',
                'Luqman',
                'As-Sajdah',
                'Al-Ahzab',
                'Saba',
                'Fatir',
                'Ya-Sin',
                'As-Saffat',
                'Sad',
                'Az-Zumar',
                'Ghafir',
                'Fussilat',
                'Asy-Syura',
                'Az-Zukhruf',
                'Ad-Dukhan',
                'Al-Jatsiyah',
                'Al-Ahqaf',
                'Muhammad',
                'Al-Fath',
                'Al-Hujurat',
                'Qaf',
                'Adz-Dzariyat',
                'At-Tur',
                'An-Najm',
                'Al-Qamar',
                'Ar-Rahman',
                'Al-Waqi’ah',
                'Al-Hadid',
                'Al-Mujadilah',
                'Al-Hasyr',
                'Al-Mumtahanah',
                'As-Saff',
                'Al-Jumu’ah',
                'Al-Munafiqun',
                'At-Taghabun',
                'At-Talaq',
                'At-Tahrim',
                'Al-Mulk',
                'Al-Qalam',
                'Al-Haqqah',
                'Al-Ma’arij',
                'Nuh',
                'Al-Jinn',
                'Al-Muzzammil',
                'Al-Muddaththir',
                'Al-Qiyamah',
                'Al-Insan',
                'Al-Mursalat',
                'An-Naba',
                'An-Nazi’at',
                '‘Abasa',
                'At-Takwir',
                'Al-Infitar',
                'Al-Mutaffifin',
                'Al-Insyiqaq',
                'Al-Buruj',
                'At-Tariq',
                'Al-A’la',
                'Al-Ghasyiyah',
                'Al-Fajr',
                'Al-Balad',
                'Asy-Syams',
                'Al-Lail',
                'Ad-Duha',
                'Asy-Syarh',
                'At-Tin',
                'Al-‘Alaq',
                'Al-Qadr',
                'Al-Bayyinah',
                'Az-Zalzalah',
                'Al-‘Adiyat',
                'Al-Qari’ah',
                'At-Takatsur',
                'Al-‘Asr',
                'Al-Humazah',
                'Al-Fil',
                'Quraisy',
                'Al-Ma’un',
                'Al-Kautsar',
                'Al-Kafirun',
                'An-Nasr',
                'Al-Lahab',
                'Al-Ikhlas',
                'Al-Falaq',
                'An-Nas'
            ];

            const rows = surahList.map((name, i) => ({
                title: `${i + 1}. ${name}`,
                description: `Baca Surah ${name}`,
                id: `${prefix}surah ${i + 1}`
            }));

            await Yudzxml.sendMessage(
                m.chat,
                {
                    text: '📖 *DAFTAR SURAH AL-QUR’AN*\n\nSilakan pilih surah yang ingin dibaca.',
                    footer: '',
                    buttons: [
                        {
                            buttonId: 'list_surah_action',
                            buttonText: { displayText: '📚 Pilih Surah' },
                            type: 4,
                            nativeFlowInfo: {
                                name: 'single_select',
                                paramsJson: JSON.stringify({
                                    title: '🕌 List Surah (1–114)',
                                    sections: [
                                        {
                                            title: 'Surah Al-Qur’an',
                                            rows
                                        }
                                    ]
                                })
                            }
                        }
                    ],
                    viewOnce: true,
                    contextInfo: {
                        mentionedJid: [m.sender]
                    }
                },
                { quoted: m }
            );
        } catch (err) {
            console.error('[LIST SURAH ERROR]', err);
            m.reply('⚠️ Gagal menampilkan daftar surah.');
        }
    }
};

module.exports = {
    name: 'surah',
    category: 'islami',
    commands: ['surah'],
    description: 'Menampilkan surah atau ayat Al-Qur’an',
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ Yudzxml, m, prefix, config, command, text }) {
        if (!text?.trim()) {
            return m.reply(
                `❌ Cara penggunaan:\n\n` +
                    `${prefix + command} <surah>\n` +
                    `${prefix + command} <surah> <ayat>\n\n` +
                    `Contoh:\n` +
                    `${prefix + command} 1\n` +
                    `${prefix + command} 1 7\n` +
                    `${prefix + command} al fatihah\n` +
                    `${prefix + command} al fatihah ayat 7`
            );
        }

        const { endpoint, key } = config.apikey;

        const query = encodeURIComponent(text.trim());

        const url = `${endpoint}/api/islami/surah?q=${query}&apikey=${key}`;

        const response = await fetch(url);

        if (!response.ok) {
            throw new Error(`API Error: ${response.status}`);
        }

        const result = await response.json();

        if (result.status !== 200 || !result.data?.found) {
            return m.reply(result.data?.message || '❌ Surah atau ayat tidak ditemukan.');
        }

        const data = result.data;
        const surah = data.surah;

        if (data.type === 'ayat') {
            const ayat = data.ayat;

            const message = `
📖 *SURAH ${surah.nama.toUpperCase()}*
📌 *Arti:* ${surah.arti}
🔢 *Ayat:* ${ayat.nomor}
📚 *${surah.jumlahAyat} Ayat*

━━━━━━━━━━━━━━

${ayat.arabic}

_${ayat.latin}_

“${ayat.arti}”

📚 *${ayat.juz}*
🔗 ${ayat.tafsirUrl}
`.trim();

            return m.reply(message);
        }

        if (data.type === 'surah') {
            const ayat = surah.ayat;

            if (!Array.isArray(ayat) || !ayat.length) {
                return m.reply('📭 Data ayat surah tidak tersedia.');
            }

            let message =
                `
📖 *SURAH ${surah.nama.toUpperCase()}*
📌 *Arti:* ${surah.arti}
🔢 *Nomor:* ${surah.nomor}
📚 *Jumlah Ayat:* ${surah.jumlahAyat}

━━━━━━━━━━━━━━
`.trim() + '\n\n';

            for (const item of ayat) {
                message += `🔹 *Ayat ${item.nomor}*

${item.arabic}

_${item.latin}_

“${item.arti}”

📚 ${item.juz}

━━━━━━━━━━━━━━

`;
            }

            return m.reply(message.trim());
        }

        return m.reply('❌ Tipe data Qur’an tidak dikenali.');
    }
};

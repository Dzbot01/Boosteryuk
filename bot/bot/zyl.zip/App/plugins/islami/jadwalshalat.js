module.exports = {
    name: 'jadwalshalat',
    category: 'islami',
    commands: ['jadwalshalat'],
    description: 'Menampilkan jadwal shalat harian berdasarkan kota',
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ Yudzxml, m, prefix, config, command, text }) {
        try {
            if (!text) {
                return m.reply(
                    `❌ Cara penggunaan:\n${prefix + command} <nama kota>\n\nContoh:\n${prefix + command} Batam`
                );
            }

            const kota = encodeURIComponent(text);
            const { endpoint, key } = config.apikey;

            const url = `${endpoint}/api/islami/jadwalshalat?kota=${kota}&apikey=${key}`;

            const response = await fetch(url);
            if (!response.ok) {
                throw new Error(`API Error: ${response.status}`);
            }

            const result = await response.json();

            if (!result.data || !result.data.jadwal) {
                return m.reply('📭 Jadwal shalat tidak ditemukan untuk kota tersebut.');
            }

            const { kota: namaKota, periode, jadwal } = result.data;

            const message = `
🕌 *JADWAL SHALAT*

📍 *Kota:* ${namaKota}
🗓️ *Periode:* ${periode}
📆 *Tanggal:* ${jadwal.Tanggal}

━━━━━━━━━━━━━━
🌙 Imsyak   : ${jadwal.Imsyak}
🕌 Subuh    : ${jadwal.Shubuh}
🌅 Terbit  : ${jadwal.Terbit}
☀️ Dhuha   : ${jadwal.Dhuha}
🕛 Dzuhur  : ${jadwal.Dzuhur}
🕒 Ashar   : ${jadwal.Ashr}
🌇 Maghrib : ${jadwal.Maghrib}
🌃 Isya    : ${jadwal.Isya}
━━━━━━━━━━━━━━

🤲 Semoga ibadah Anda dimudahkan hari ini.
            `.trim();

            await Yudzxml.sendMessage(m.chat, { text: message }, { quoted: m });
        } catch (error) {
            console.error('[JADWAL SHALAT ERROR]', error);
            m.reply('⚠️ Terjadi kesalahan saat mengambil jadwal shalat. Silakan coba lagi nanti.');
        }
    }
};

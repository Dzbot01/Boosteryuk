const chalk = require('chalk');

module.exports = {
    name: 'tebakepep',
    category: 'game',
    commands: ['tebakepep'],
    isRateLimit: true,
    isLimit: true,
    requiredLimit: 1,
    async execute({
        Yudzxml,
        m,
        prefix,
        command,
        hasAnyGameInChat,
        fetchJson,
        config,
        saveGame,
        setGameTimeout,
        deleteGame,
        logger
    }) {
        const { sleep_game, apikey, MoneyMenangGame, thumbnail } = config;

        const GAME_TYPE = 'tebak_epep';
        const chatId = m.chat;

        if (hasAnyGameInChat(chatId)) {
            return m.reply('⚠️ Masih ada game aktif di chat ini.');
        }

        const response = await fetchJson(
            `${apikey.endpoint}/api/game/tebakepep?apikey=${encodeURIComponent(apikey.key)}`
        );

        const { img, jawaban, fullimg, deskripsi } = response.data;

        logger.info(chalk.yellow(`[ TEBAK EPEP ] ${m.pushName} | Jawaban: ${jawaban}`));

        saveGame(GAME_TYPE, chatId, {
            fullimg,
            jawaban: jawaban.toLowerCase(),
            price: MoneyMenangGame,
            startAt: Date.now()
        });

        setGameTimeout(chatId, sleep_game, async () => {
            const caption = [
                '⏰ *WAKTU HABIS!*',
                `💡 Jawaban: *${jawaban}*`,
                '',
                `Ingin bermain lagi?`,
                `Ketik *${prefix + command}*`
            ].join('\n');

            await Yudzxml.sendMessage(
                chatId,
                {
                    image: { url: fullimg },
                    caption
                },
                { quoted: m }
            );

            deleteGame(GAME_TYPE, chatId);
        });

        const caption = ['🧠 *TEBAK EPEP*', '', `📋 Deskripsi:`, deskripsi, '', '⏱️ Waktu: *60 detik*'].join('\n');

        await Yudzxml.sendMessage(
            chatId,
            {
                image: { url: img },
                caption
            },
            { quoted: m }
        );
    }
};

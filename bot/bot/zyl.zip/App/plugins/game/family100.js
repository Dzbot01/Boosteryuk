const chalk = require('chalk');

module.exports = {
    name: 'family100',
    category: 'game',
    commands: ['family100'],
    isRateLimit: true,
    isLimit: true,
    requiredLimit: 1,
    async execute({
        Yudzxml,
        m,
        prefix,
        command,
        hasAnyGameInChat,
        fetchJson,
        config,
        saveGame,
        setGameTimeout,
        deleteGame,
        logger
    }) {
        const { sleep_game, apikey, MoneyMenangGame, thumbnail } = config;

        const GAME_TYPE = 'family100';
        const chatId = m.chat;

        if (hasAnyGameInChat(chatId)) {
            return m.reply('⚠️ Masih ada game aktif di chat ini.');
        }

        const response = await fetchJson(
            `${apikey.endpoint}/api/game/family100?apikey=${encodeURIComponent(apikey.key)}`
        );

        const { soal, jawaban } = response.data;

        const answers = jawaban.map((v) => v.toLowerCase());

        logger.info(chalk.green(`[ FAMILY100 ] ${m.pushName} | Jawaban: ${answers.join(', ')}`));

        saveGame(GAME_TYPE, chatId, {
            soal,
            answers,
            answered: [],
            price: MoneyMenangGame,
            startAt: Date.now()
        });

        setGameTimeout(chatId, 240000, async () => {
            const caption = [
                '⏰ *WAKTU HABIS!*',
                '',
                '✅ Jawaban yang benar:',
                answers.map((v, i) => `${i + 1}. ${v}`).join('\n'),
                '',
                'Ingin main lagi?',
                `Ketik *${prefix + command}*`
            ].join('\n');

            await Yudzxml.sendMessage(
                chatId,
                {
                    image: { url: thumbnail.timeout_game },
                    caption
                },
                { quoted: m }
            );

            deleteGame(GAME_TYPE, chatId);
        });

        const caption = [
            '👨‍👩‍👧‍👦 *FAMILY 100*',
            '',
            `📖 Soal: *${soal}*`,
            `📊 Total Jawaban: *${answers.length}*`,
            '',
            '⌨️ Ketik jawabanmu di chat',
            '⏱️ Waktu: *4 Menit*'
        ].join('\n');

        await Yudzxml.sendMessage(
            chatId,
            {
                image: { url: thumbnail.start_game },
                caption
            },
            { quoted: m }
        );
    }
};

const chalk = require('chalk');

module.exports = {
    name: 'casino',
    category: 'game',
    commands: ['casino'],
    isRateLimit: true,
    isLimit: true,

    requiredLimit: 1,
    async execute({ m, args, getUser, addMoney, reduceMoney, logger, isOwner, isSuperOwner }) {
        const bet = Number(args[0]);
        const user = getUser(m.sender);

        user._casinoLast = user._casinoLast || 0;
        const now = Date.now();

        if (now - user._casinoLast < 2500) {
            return m.reply('⏳ Tunggu sebentar sebelum main lagi');
        }
        user._casinoLast = now;

        if (!Number.isInteger(bet) || bet < 10) {
            return m.reply('🎰 *CASINO SLOT*\n\n' + '📌 Minimal taruhan *10 Money*\n' + '📌 Contoh: *casino 1000*');
        }

        if (user.money < bet) {
            return m.reply(`💸 *Money kamu tidak cukup!*\n\n` + `💰 Saldo: *${user.money.toLocaleString()} Money*`);
        }

        const levelCaps = [
            { level: 1, max: 200 },
            { level: 5, max: 800 },
            { level: 10, max: 2_000 },
            { level: 20, max: 5_000 },
            { level: 50, max: 12_000 },
            { level: 100, max: 25_000 }
        ];

        let maxBetForLevel = 200;
        for (const cap of levelCaps) {
            if (user.level_user >= cap.level) {
                maxBetForLevel = cap.max;
            }
        }

        if (bet > maxBetForLevel) {
            return m.reply(
                `🚫 *Batasan Taruhan Level ${user.level_user}*\n\n` +
                    `📊 Max Bet: *${maxBetForLevel.toLocaleString()} Money*`
            );
        }

        const slots = ['🍒', '🍋', '🍉', '🍇', '🍎', '🍊', '🥝'];

        let pairChance = 32;
        let jackpotChance = 8;

        let pairMultiplier = 1.8;
        let jackpotMultiplier = 2.7;

        if (isOwner) {
            pairChance += 5;
            jackpotChance += 2;
        }

        if (isSuperOwner) {
            pairChance += 8;
            jackpotChance += 4;
        }

        const betRatio = bet / maxBetForLevel;

        if (betRatio > 0.75) {
            pairChance -= 4;
            jackpotChance -= 2;
            pairMultiplier = 1.6;
        }

        user._casinoStreak = user._casinoStreak || 0;

        const winThreshold = pairChance + jackpotChance;
        let roll = Math.random() * 100;

        let result = '';
        let profit = 0;
        let s1, s2, s3;
        let reward = 0;

        if (roll < winThreshold) {
            user._casinoStreak++;

            if (user._casinoStreak >= 3) {
                if (Math.random() < 0.6) {
                    roll = 100;
                    user._casinoStreak = 0;
                }
            }

            if (roll < jackpotChance) {
                result = '🎉 JACKPOT';
                reward = Math.floor(bet * jackpotMultiplier);

                const fruit = slots[Math.floor(Math.random() * slots.length)];
                s1 = s2 = s3 = fruit;
            } else {
                result = '✨ PAIR';
                reward = Math.floor(bet * pairMultiplier);

                const fruit = slots[Math.floor(Math.random() * slots.length)];
                s1 = s2 = fruit;

                do {
                    s3 = slots[Math.floor(Math.random() * slots.length)];
                } while (s3 === fruit);
            }

            addMoney(m.sender, reward);
            profit = reward - bet;
        } else {
            user._casinoStreak = 0;
            result = '💀 ZONK';

            reduceMoney(m.sender, bet);
            profit = -bet;

            s1 = slots[Math.floor(Math.random() * slots.length)];

            do {
                s2 = slots[Math.floor(Math.random() * slots.length)];
            } while (s2 === s1);

            do {
                s3 = slots[Math.floor(Math.random() * slots.length)];
            } while (s3 === s1 || s3 === s2);
        }

        const updatedUser = getUser(m.sender);

        logger.info(
            chalk.yellow(`[CASINO] ${m.pushName} | Lvl ${user.level_user} | Bet ${bet} | ${result} | Profit ${profit}`)
        );

        const text = `
🎰 *CASINO SLOT*

\`\`\`
║ ${s1} ║ ${s2} ║ ${s3} ║
\`\`\`

💵 Bet: ${bet.toLocaleString()} Money

🏆 Result: ${result}

${result === '🎉 JACKPOT' ? `💎 x${jackpotMultiplier}` : result === '✨ PAIR' ? `🍀 x${pairMultiplier}` : '😵 Lose'}

${profit >= 0 ? `💰 +${profit.toLocaleString()}` : `❌ ${profit.toLocaleString()}`}

💳 Balance:
└ ${updatedUser.money.toLocaleString()} Money
`.trim();

        return m.reply(text);
    }
};

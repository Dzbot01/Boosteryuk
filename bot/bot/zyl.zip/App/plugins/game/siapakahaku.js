const chalk = require('chalk');

module.exports = {
    name: 'siapakahaku',
    category: 'game',
    commands: ['siapakahaku'],
    isRateLimit: true,
    isLimit: true,
    requiredLimit: 1,
    async execute({
        Yudzxml,
        m,
        prefix,
        command,
        hasAnyGameInChat,
        fetchJson,
        config,
        saveGame,
        setGameTimeout,
        deleteGame,
        logger
    }) {
        const { sleep_game, apikey, MoneyMenangGame, thumbnail } = config;

        const GAME_TYPE = 'siapakahaku';
        const chatId = m.chat;

        if (hasAnyGameInChat(chatId)) {
            return m.reply('⚠️ Masih ada game aktif di chat ini.');
        }

        const response = await fetchJson(
            `${apikey.endpoint}/api/game/siapakahaku?apikey=${encodeURIComponent(apikey.key)}`
        );

        const { soal, jawaban } = response.data;

        logger.info(chalk.yellow(`[ WHO ME ] ${m.pushName} | Jawaban: ${jawaban}`));

        saveGame(GAME_TYPE, chatId, {
            soal,
            jawaban: jawaban.toLowerCase(),
            price: MoneyMenangGame,
            startAt: Date.now()
        });

        setGameTimeout(chatId, sleep_game, async () => {
            const caption = [
                '⏰ *WAKTU HABIS!*',
                `💡 Jawaban: *${jawaban}*`,
                '',
                `Ingin bermain lagi?`,
                `Ketik *${prefix + command}*`
            ].join('\n');

            await Yudzxml.sendMessage(
                chatId,
                {
                    image: { url: thumbnail.timeout_game },
                    caption
                },
                { quoted: m }
            );

            deleteGame(GAME_TYPE, chatId);
        });

        const caption = ['🧠 *SIAPAKAH AKU*', '', `📖 Soal:`, soal, '', '⏱️ Waktu: *60 detik*'].join('\n');

        await Yudzxml.sendMessage(
            chatId,
            {
                image: { url: thumbnail.start_game },
                caption
            },
            { quoted: m }
        );
    }
};

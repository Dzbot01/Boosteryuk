const chalk = require('chalk');

function maskSoalText(text) {
    if (typeof text !== 'string') return text;

    const clean = text.trim().replace(/[.!?]$/, '');
    const lastWord = clean.split(/\s+/).pop();

    if (!lastWord || lastWord.length <= 2) return text;

    const masked = lastWord.slice(0, 2) + '...';
    const regex = new RegExp(`\\b${lastWord}\\b([.!?]?)$`, 'i');

    return text.replace(regex, masked + '$1');
}

module.exports = {
    name: 'tebakemoji',
    category: 'game',
    commands: ['tebakemoji'],
    isRateLimit: true,
    isLimit: true,
    requiredLimit: 1,
    async execute({
        Yudzxml,
        m,
        prefix,
        command,
        hasAnyGameInChat,
        fetchJson,
        config,
        saveGame,
        setGameTimeout,
        deleteGame,
        logger
    }) {
        const { sleep_game, apikey, MoneyMenangGame, thumbnail } = config;

        const GAME_TYPE = 'tebak_emoji';
        const chatId = m.chat;

        if (hasAnyGameInChat(chatId)) {
            return m.reply('⚠️ Masih ada game aktif di chat ini.');
        }

        const response = await fetchJson(
            `${apikey.endpoint}/api/game/tebakemoji?apikey=${encodeURIComponent(apikey.key)}`
        );

        const { soal, emoticon, deskripsi, jawaban } = response.data;

        logger.info(chalk.yellow(`[ TEBAK EMOJI ] ${m.pushName} | Jawaban: ${jawaban}`));

        saveGame(GAME_TYPE, chatId, {
            deskripsi,
            jawaban: jawaban.toLowerCase(),
            price: MoneyMenangGame,
            startAt: Date.now()
        });

        setGameTimeout(chatId, sleep_game, async () => {
            const caption = [
                '⏰ *WAKTU HABIS!*',
                `💡 Jawaban: *${jawaban}*`,
                `📋 Deskripsi: *${deskripsi}*`,
                '',
                `Ingin bermain lagi?`,
                `Ketik *${prefix + command}*`
            ].join('\n');

            await Yudzxml.sendMessage(
                chatId,
                {
                    image: { url: thumbnail.timeout_game },
                    caption
                },
                { quoted: m }
            );

            deleteGame(GAME_TYPE, chatId);
        });

        const caption = [
            '🧠 *TEBAK EMOJI*',
            '',
            `📖 soal:`,
            maskSoalText(soal),
            '📋 Emoji:',
            emoticon,
            '',
            '⏱️ Waktu: *60 detik*'
        ].join('\n');

        await Yudzxml.sendMessage(
            chatId,
            {
                image: { url: thumbnail.start_game },
                caption
            },
            { quoted: m }
        );
    }
};

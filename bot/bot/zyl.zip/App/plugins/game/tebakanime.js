const chalk = require('chalk');

module.exports = {
    name: 'tebakanime',
    category: 'game',
    commands: ['tebakanime'],
    isRateLimit: true,
    isLimit: true,
    requiredLimit: 1,
    async execute({
        Yudzxml,
        m,
        prefix,
        command,
        hasAnyGameInChat,
        fetchJson,
        config,
        saveGame,
        setGameTimeout,
        deleteGame,
        logger
    }) {
        const { sleep_game, apikey, MoneyMenangGame, thumbnail } = config;

        const GAME_TYPE = 'tebak_anime';
        const chatId = m.chat;

        if (hasAnyGameInChat(chatId)) {
            return m.reply('⚠️ Masih ada game aktif di chat ini.');
        }

        const response = await fetchJson(
            `${apikey.endpoint}/api/game/tebakanime?apikey=${encodeURIComponent(apikey.key)}`
        );

        if (!response || response.status !== 200 || !response.data || !response.data.name || !response.data.image) {
            return m.reply('❌ Gagal mengambil karakter anime. Coba lagi.');
        }

        const { name, image, rank, favorites, link } = response.data;

        const jawaban = name.trim();
        const normalizedAnswer = jawaban.toLowerCase().replace(/\s+/g, ' ').trim();

        logger.info(chalk.cyan(`[ TEBAK ANIME ] ${m.pushName} | Jawaban: ${jawaban}`));

        saveGame(GAME_TYPE, chatId, {
            jawaban: normalizedAnswer,
            originalAnswer: jawaban,
            image,
            rank,
            favorites,
            link,
            price: MoneyMenangGame,
            startAt: Date.now()
        });

        setGameTimeout(chatId, sleep_game, async () => {
            const caption = [
                '⏰ *WAKTU HABIS!*',
                '',
                `💡 Jawaban: *${jawaban}*`,
                '',
                '🎌 Mau coba karakter lain?',
                `Ketik *${prefix + command}*`
            ].join('\n');

            await Yudzxml.sendMessage(
                chatId,
                {
                    image: { url: image },
                    caption
                },
                { quoted: m }
            );

            deleteGame(GAME_TYPE, chatId);
        });

        const caption = [
            '🎌 *TEBAK KARAKTER ANIME*',
            '',
            '❓ *Siapakah karakter anime ini?*',
            '',
            `⭐ Rank MAL: #${rank}`,
            `❤️ Favorites: ${favorites}`,
            '',
            '⏱️ Waktu: *60 detik*',
            '✍️ Ketik nama karakter tersebut!'
        ].join('\n');

        await Yudzxml.sendMessage(
            chatId,
            {
                image: { url: image },
                caption
            },
            { quoted: m }
        );
    }
};

const chalk = require('chalk');

module.exports = {
    name: 'tebakbom',
    category: 'game',
    commands: ['tebakbom'],
    isRateLimit: true,
    isLimit: true,
    requiredLimit: 1,
    async execute({
        Yudzxml,
        m,
        prefix,
        command,
        hasAnyGameInChat,
        config,
        saveGame,
        setGameTimeout,
        deleteGame,
        logger
    }) {
        const { sleep_game, MoneyMenangGame, thumbnail } = config;

        const GAME_TYPE = 'tebak_bom';
        const chatId = m.chat;

        if (hasAnyGameInChat(chatId)) {
            return m.reply('⚠️ Masih ada game aktif di chat ini.');
        }

        const buah = ['🍏', '🍎', '🍐', '🍊', '🍋', '🍉', '🍇', '🍓', '🍒'];
        const angkaEmoji = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣'];

        const acakArray = (arr) => {
            for (let i = arr.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [arr[i], arr[j]] = [arr[j], arr[i]];
            }
            return arr;
        };

        const tambahBom = (grid) => {
            const p = Math.floor(Math.random() * 9);
            grid[Math.floor(p / 3)][p % 3] = '💣';
            return p + 1;
        };

        const buatPapan = (grid, terbuka = []) => {
            const buka = new Set(terbuka);
            let out = '';

            for (let i = 0; i < 3; i++) {
                for (let j = 0; j < 3; j++) {
                    const idx = i * 3 + j + 1;
                    out += buka.has(idx) ? `[${grid[i][j]}] ` : `[${angkaEmoji[idx - 1]}] `;
                }
                out += '\n';
            }
            return out;
        };

        const grid = [acakArray(buah.slice(0, 3)), acakArray(buah.slice(3, 6)), acakArray(buah.slice(6, 9))];

        const posisiBom = tambahBom(grid);

        logger.info(chalk.red(`[ TEBAK BOM ] ${m.pushName} | Bom di kotak: ${posisiBom}`));

        saveGame(GAME_TYPE, chatId, {
            grid,
            bom: posisiBom,
            terbuka: [],
            price: MoneyMenangGame,
            startAt: Date.now()
        });

        setGameTimeout(chatId, sleep_game, async () => {
            const caption = [
                '⏰ *WAKTU HABIS!*',
                'Bom meledak karena kamu terlalu lama berpikir.',
                '',
                '💣 Posisi bom:',
                buatPapan(grid, [posisiBom]),
                '',
                `Main lagi?`,
                `Ketik *${prefix + command}*`
            ].join('\n');

            await Yudzxml.sendMessage(
                chatId,
                {
                    image: { url: thumbnail.timeout_game },
                    caption
                },
                { quoted: m }
            );

            deleteGame(GAME_TYPE, chatId);
        });

        const caption = [
            '💣 *TEBAK BOM*',
            '',
            'Satu kotak berisi bom.',
            'Buka semua kotak aman tanpa menyentuh bom.',
            '',
            buatPapan(grid),
            '',
            '✂️ Ketik angka *1–9*',
            '⛔ Ketik *menyerah* untuk berhenti',
            '',
            '⏱️ Waktu: *60 detik*'
        ].join('\n');

        await Yudzxml.sendMessage(
            chatId,
            {
                image: { url: thumbnail.start_game },
                caption
            },
            { quoted: m }
        );
    }
};

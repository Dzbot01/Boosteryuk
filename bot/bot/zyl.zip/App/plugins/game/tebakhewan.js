const chalk = require('chalk');

module.exports = {
    name: 'tebakhewan',
    category: 'game',
    commands: ['tebakhewan'],
    isRateLimit: true,
    isLimit: true,
    requiredLimit: 1,
    async execute({
        Yudzxml,
        m,
        prefix,
        command,
        hasAnyGameInChat,
        fetchJson,
        config,
        saveGame,
        setGameTimeout,
        deleteGame,
        logger
    }) {
        const { sleep_game, apikey, MoneyMenangGame } = config;

        const GAME_TYPE = 'tebak_hewan';
        const chatId = m.chat;

        if (hasAnyGameInChat(chatId)) {
            return m.reply('⚠️ Masih ada game aktif di chat ini.');
        }

        const response = await fetchJson(
            `${apikey.endpoint}/api/game/tebakhewan?apikey=${encodeURIComponent(apikey.key)}`
        );

        const { img, imgfull, jawaban } = response.data;

        logger.info(chalk.green(`[ TEBAK HEWAN ] ${m.pushName} | Jawaban: ${jawaban}`));

        saveGame(GAME_TYPE, chatId, {
            jawaban: jawaban.toLowerCase(),
            fullimg: imgfull,
            price: MoneyMenangGame,
            startAt: Date.now()
        });

        setGameTimeout(chatId, sleep_game, async () => {
            const caption = [
                '⏰ *WAKTU HABIS!*',
                `🦴 Jawaban: *${jawaban}*`,
                '',
                `Main lagi?`,
                `Ketik *${prefix + command}*`
            ].join('\n');

            await Yudzxml.sendMessage(
                chatId,
                {
                    image: { url: imgfull },
                    caption
                },
                { quoted: m }
            );

            deleteGame(GAME_TYPE, chatId);
        });

        const caption = [
            '🐾 *TEBAK HEWAN*',
            '',
            '🔍 Tebak nama hewan dari gambar di atas!',
            '',
            '⏱️ Waktu: *60 detik*'
        ].join('\n');

        await Yudzxml.sendMessage(
            chatId,
            {
                image: { url: img },
                caption
            },
            { quoted: m }
        );
    }
};

const chalk = require('chalk');

module.exports = {
    name: 'math',
    category: 'game',
    commands: ['math'],
    isRateLimit: true,
    isLimit: true,
    requiredLimit: 1,
    async execute({
        Yudzxml,
        m,
        prefix,
        command,
        hasAnyGameInChat,
        fetchJson,
        config,
        saveGame,
        setGameTimeout,
        deleteGame,
        logger
    }) {
        const { sleep_game, apikey, MoneyMenangGame, thumbnail } = config;

        const GAME_TYPE = 'math';
        const chatId = m.chat;

        if (hasAnyGameInChat(chatId)) {
            return m.reply('⚠️ Masih ada game aktif di chat ini.');
        }

        const response = await fetchJson(`${apikey.endpoint}/api/game/math?apikey=${encodeURIComponent(apikey.key)}`);

        const { soal, jawaban, deskripsi } = response.data;

        logger.info(chalk.yellow(`[ MATH QUIZ ] ${m.pushName} | Jawaban: ${jawaban}`));

        saveGame(GAME_TYPE, chatId, {
            soal,
            deskripsi,
            jawaban: jawaban.toLowerCase(),
            price: MoneyMenangGame,
            startAt: Date.now()
        });

        setGameTimeout(chatId, sleep_game, async () => {
            const caption = [
                '⏰ *WAKTU HABIS!*',
                `💡 Jawaban: *${jawaban}*`,
                `📋 Deskripsi: *${deskripsi}*`,
                '',
                `Ingin bermain lagi?`,
                `Ketik *${prefix + command}*`
            ].join('\n');

            await Yudzxml.sendMessage(
                chatId,
                {
                    image: { url: thumbnail.timeout_game },
                    caption
                },
                { quoted: m }
            );

            deleteGame(GAME_TYPE, chatId);
        });

        const caption = [
            '🧠 *MATH QUIZ*',
            '',
            `📖 Soal:`,
            soal,
            `💡 Deskripsi:`,
            deskripsi,
            '',
            '⏱️ Waktu: *60 detik*'
        ].join('\n');

        await Yudzxml.sendMessage(
            chatId,
            {
                image: { url: thumbnail.start_game },
                caption
            },
            { quoted: m }
        );
    }
};

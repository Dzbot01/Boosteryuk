const chalk = require('chalk');

module.exports = {
    name: 'tebaklirik',
    category: 'game',
    commands: ['tebaklirik'],
    isRateLimit: true,
    isLimit: true,
    requiredLimit: 1,
    async execute({
        Yudzxml,
        m,
        prefix,
        command,
        hasAnyGameInChat,
        fetchJson,
        config,
        saveGame,
        setGameTimeout,
        deleteGame,
        logger
    }) {
        const { sleep_game, apikey, MoneyMenangGame, thumbnail } = config;

        const GAME_TYPE = 'tebak_lirik';
        const chatId = m.chat;

        if (hasAnyGameInChat(chatId)) {
            return m.reply('⚠️ Masih ada game aktif di chat ini.');
        }

        const response = await fetchJson(
            `${apikey.endpoint}/api/game/tebaklirik?apikey=${encodeURIComponent(apikey.key)}`
        );

        const { soal, jawaban } = response.data;

        logger.info(chalk.magenta(`[ TEBAK LIRIK ] ${m.pushName} | Jawaban: ${jawaban}`));

        saveGame(GAME_TYPE, chatId, {
            soal,
            jawaban: jawaban.toLowerCase(),
            price: MoneyMenangGame,
            startAt: Date.now()
        });

        setGameTimeout(chatId, sleep_game, async () => {
            const caption = [
                '⏰ *WAKTU HABIS!*',
                '',
                `🎵 Jawaban yang benar:`,
                `*${jawaban}*`,
                '',
                'Cintanya boleh kandas,',
                'tapi jawabannya jangan 😌',
                '',
                `Main lagi?`,
                `Ketik *${prefix + command}*`
            ].join('\n');

            await Yudzxml.sendMessage(
                chatId,
                {
                    image: { url: thumbnail.timeout_game },
                    caption
                },
                { quoted: m }
            );

            deleteGame(GAME_TYPE, chatId);
        });

        const caption = [
            '🎶 *TEBAK LIRIK*',
            '',
            'Lengkapi bagian lirik yang kosong:',
            '',
            `❓ Soal:`,
            soal,
            '',
            '✍️ Jawab dengan *lirik yang tepat*',
            '⏱️ Waktu: *60 detik*',
            '',
            'Petunjuk: jangan nyanyi, fokus mikir.'
        ].join('\n');

        await Yudzxml.sendMessage(
            chatId,
            {
                image: { url: thumbnail.start_game },
                caption
            },
            { quoted: m }
        );
    }
};

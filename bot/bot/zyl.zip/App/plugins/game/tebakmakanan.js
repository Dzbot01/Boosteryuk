const chalk = require('chalk');

module.exports = {
    name: 'tebakmakanan',
    category: 'game',
    commands: ['tebakmakanan'],
    isRateLimit: true,
    isLimit: true,
    requiredLimit: 1,
    async execute({
        Yudzxml,
        m,
        prefix,
        command,
        hasAnyGameInChat,
        fetchJson,
        config,
        saveGame,
        setGameTimeout,
        deleteGame,
        logger
    }) {
        const { sleep_game, apikey, MoneyMenangGame, thumbnail } = config;

        const GAME_TYPE = 'tebak_makanan';
        const chatId = m.chat;

        if (hasAnyGameInChat(chatId)) {
            return m.reply('⚠️ Masih ada game aktif di chat ini.');
        }

        const response = await fetchJson(
            `${apikey.endpoint}/api/game/tebakmakanan?apikey=${encodeURIComponent(apikey.key)}`
        );

        const { img, jawaban, deskripsi } = response.data;

        logger.info(chalk.green(`[ TEBAK MAKANAN ] ${m.pushName} | Jawaban: ${jawaban}`));

        saveGame(GAME_TYPE, chatId, {
            jawaban: jawaban.toLowerCase(),
            price: MoneyMenangGame,
            startAt: Date.now()
        });

        setGameTimeout(chatId, sleep_game, async () => {
            const caption = [
                '⏰ *WAKTU HABIS!*',
                `🍽️ Jawaban: *${jawaban}*`,
                '',
                `Main lagi?`,
                `Ketik *${prefix + command}*`
            ].join('\n');

            await Yudzxml.sendMessage(
                chatId,
                {
                    image: { url: img },
                    caption
                },
                { quoted: m }
            );

            deleteGame(GAME_TYPE, chatId);
        });

        const caption = [
            '🍜 *TEBAK MAKANAN*',
            '',
            `📖 Deskripsi:`,
            deskripsi,
            '',
            '✍️ Jawab dengan nama makanannya',
            '⏱️ Waktu: *60 detik*'
        ].join('\n');

        await Yudzxml.sendMessage(
            chatId,
            {
                image: { url: img },
                caption
            },
            { quoted: m }
        );
    }
};

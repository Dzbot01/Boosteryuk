const chalk = require('chalk');

module.exports = {
    name: 'tictactoe',
    category: 'game',
    commands: ['tictactoe', 'ttt'],
    isRateLimit: true,
    isLimit: true,
    requiredLimit: 1,
    async execute({
        Yudzxml,
        m,
        prefix,
        command,
        hasAnyGameInChat,
        config,
        saveGame,
        setGameTimeout,
        deleteGame,
        logger
    }) {
        const { sleep_game, MoneyMenangGame, thumbnail } = config;

        const GAME_TYPE = 'tictactoe';
        const chatId = m.chat;
        const BOT_ID = 'bot';

        if (hasAnyGameInChat(chatId)) {
            return m.reply('⚠️ Masih ada game aktif di chat ini.');
        }

        const mentioned = m.mentionedJid && m.mentionedJid[0];
        const repliedTo = m.quoted && m.quoted.sender;
        const target = mentioned || repliedTo || null;

        const isPvp = !!target;

        if (isPvp) {
            if (target === m.sender) {
                return m.reply('⚠️ Kamu tidak bisa menantang diri sendiri.');
            }
            if (Yudzxml?.user?.id && target === Yudzxml.user.id) {
                return m.reply(`⚠️ Untuk lawan bot, cukup ketik *${prefix + command}* tanpa tag.`);
            }
        }

        const papan = ['1', '2', '3', '4', '5', '6', '7', '8', '9'];

        const renderBoard = (board) => {
            return `
[${board[0]}] [${board[1]}] [${board[2]}]
[${board[3]}] [${board[4]}] [${board[5]}]
[${board[6]}] [${board[7]}] [${board[8]}]
`.trim();
        };

        const cekMenang = (board, symbol) => {
            const win = [
                [0, 1, 2],
                [3, 4, 5],
                [6, 7, 8],
                [0, 3, 6],
                [1, 4, 7],
                [2, 5, 8],
                [0, 4, 8],
                [2, 4, 6]
            ];

            return win.some((line) => line.every((i) => board[i] === symbol));
        };

        logger.info(chalk.green(`[ TICTACTOE ] ${m.pushName} memulai game ${isPvp ? '(PVP)' : '(vs Bot)'}`));

        const lawanId = isPvp ? target : BOT_ID;

        saveGame(GAME_TYPE, chatId, {
            board: papan,
            isPvp,
            players: {
                '❌': m.sender,
                '⭕': lawanId
            },
            symbols: {
                [m.sender]: '❌',
                [lawanId]: '⭕'
            },
            turn: m.sender,
            reward: MoneyMenangGame,
            price: MoneyMenangGame,
            startAt: Date.now(),
            checkWin: cekMenang
        });

        setGameTimeout(chatId, sleep_game, async () => {
            await Yudzxml.sendMessage(
                chatId,
                {
                    image: { url: thumbnail.timeout_game },
                    caption: [
                        '⏰ *WAKTU HABIS!*',
                        '',
                        renderBoard(papan),
                        '',
                        `Main lagi?`,
                        `Ketik *${prefix + command}*`
                    ].join('\n')
                },
                { quoted: m }
            );

            deleteGame(GAME_TYPE, chatId);
        });

        const captionLines = isPvp
            ? [
                  '🎮 *TICTACTOE — PVP*',
                  '',
                  `@${m.sender.split('@')[0]} = ❌`,
                  `@${target.split('@')[0]} = ⭕`,
                  '',
                  renderBoard(papan),
                  '',
                  `Giliran: @${m.sender.split('@')[0]}`,
                  '✂️ Balas dengan angka *1-9*',
                  '⛔ Ketik *menyerah* untuk keluar',
                  '',
                  `🎁 Reward: Rp${MoneyMenangGame.toLocaleString()}`,
                  '⏱️ Waktu: 60 Detik'
              ]
            : [
                  '🎮 *TICTACTOE VS BOT*',
                  '',
                  'Kamu = ❌',
                  'Bot = ⭕',
                  '',
                  renderBoard(papan),
                  '',
                  '✂️ Pilih angka *1-9*',
                  '⛔ Ketik *menyerah* untuk keluar',
                  '',
                  `🎁 Reward: Rp${MoneyMenangGame.toLocaleString()}`,
                  '⏱️ Waktu: 60 Detik'
              ];

        await Yudzxml.sendMessage(
            chatId,
            {
                image: { url: thumbnail.start_game },
                caption: captionLines.join('\n'),
                ...(isPvp ? { mentions: [m.sender, target] } : {})
            },
            { quoted: m }
        );
    }
};

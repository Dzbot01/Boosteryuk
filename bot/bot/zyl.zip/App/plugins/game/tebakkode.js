const chalk = require('chalk');

module.exports = {
    name: 'tebakkode',
    category: 'game',
    commands: ['tebakkode'],
    isRateLimit: true,
    isLimit: true,
    requiredLimit: 1,
    async execute({
        Yudzxml,
        m,
        prefix,
        command,
        hasAnyGameInChat,
        fetchJson,
        config,
        saveGame,
        setGameTimeout,
        deleteGame,
        logger
    }) {
        const { sleep_game, apikey, MoneyMenangGame, thumbnail } = config;

        const GAME_TYPE = 'tebak_kode';
        const chatId = m.chat;

        if (hasAnyGameInChat(chatId)) {
            return m.reply('⚠️ Masih ada game aktif di chat ini.');
        }

        const response = await fetchJson(
            `${apikey.endpoint}/api/game/tebakkode?apikey=${encodeURIComponent(apikey.key)}`
        );

        const { soal, pilihan, jawaban, bahasa, deskripsi } = response.data;

        logger.info(chalk.green(`[ TEBAK KODE ] ${m.pushName} | Jawaban: ${jawaban}`));

        saveGame(GAME_TYPE, chatId, {
            soal,
            jawaban: jawaban.toLowerCase(),
            deskripsi,
            bahasa,
            price: MoneyMenangGame,
            startAt: Date.now()
        });

        setGameTimeout(chatId, sleep_game, async () => {
            const caption = [
                '⏰ *WAKTU HABIS!*',
                '',
                `✅ Jawaban: *${jawaban}*`,
                `📘 Penjelasan: ${deskripsi}`,
                '',
                `Main lagi?`,
                `Ketik *${prefix + command}*`
            ].join('\n');

            await Yudzxml.sendMessage(
                chatId,
                {
                    image: { url: thumbnail.timeout_game },
                    caption
                },
                { quoted: m }
            );

            deleteGame(GAME_TYPE, chatId);
        });

        const pilihanText = pilihan.map((v, i) => `${String.fromCharCode(65 + i)}. ${v}`).join('\n');

        const caption = [
            '💻 *TEBAK KODE*',
            '',
            `📚 Bahasa: *${bahasa}*`,
            '',
            `❓ Soal:`,
            soal,
            '',
            `📌 Pilihan:`,
            pilihanText,
            '',
            '✍️ Jawab dengan *teks jawabannya*',
            '⏱️ Waktu: *60 detik*'
        ].join('\n');

        await Yudzxml.sendMessage(
            chatId,
            {
                image: { url: thumbnail.start_game },
                caption
            },
            { quoted: m }
        );
    }
};

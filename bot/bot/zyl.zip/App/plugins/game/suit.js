const chalk = require('chalk');

module.exports = {
    name: 'suit',
    category: 'game',
    commands: ['suit'],
    isRateLimit: true,
    async execute({
        Yudzxml,
        m,
        prefix,
        command,
        hasAnyGameInChat,
        config,
        saveGame,
        logger,
        setGameTimeout,
        deleteGame
    }) {
        const GAME_TYPE = 'suit_pvp';
        const chatId = m.chat;

        const sender = m.sender;
        const mentioned = m.mentionedJid?.[0];

        if (!mentioned) {
            return m.reply(`🎮 Tag lawan!\nContoh: ${prefix}suit @user`);
        }

        if (mentioned === sender) {
            return m.reply('❌ Tidak bisa menantang diri sendiri.');
        }

        if (hasAnyGameInChat(chatId)) {
            return m.reply('⚠️ Masih ada game aktif di chat ini.');
        }

        const roomId = 'suit_' + Date.now();

        const gameData = {
            roomId,
            typegame: GAME_TYPE,
            chatId,
            p1: sender,
            p2: mentioned,
            participants: [sender, mentioned],
            status: 'WAIT_ACCEPT',
            move: {},
            startAt: Date.now(),
            timeout: null
        };

        saveGame(GAME_TYPE, chatId, gameData);

        logger.info(chalk.yellow(`[ SUIT CREATED ] ${sender} vs ${mentioned} | ${roomId}`));

        setGameTimeout(chatId, 30000, async () => {
            const session = global.db.data.game?.[GAME_TYPE]?.[chatId];
            if (!session || session.status !== 'WAIT_ACCEPT') return;

            m.reply(
                `❌ @${session.p2.split('@')[0]} tidak merespon tantangan.

🎮 Suit dibatalkan.`,
                chatId,
                { mentionedJid: [session.p2] }
            );

            deleteGame(GAME_TYPE, chatId);
        });

        m.reply(
            `🎮 SUIT CHALLENGE

👤 @${sender.split('@')[0]} VS @${mentioned.split('@')[0]}

⏳ Menunggu persetujuan lawan...

⚡ Balas:
• terima
• gas
• oke

Untuk memulai suit PvP`,
            chatId,
            { mentionedJid: [sender, mentioned] }
        );
    }
};

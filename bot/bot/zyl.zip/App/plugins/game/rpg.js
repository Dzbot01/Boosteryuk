const rpg = require('../../function/rpg');
const chalk = require('chalk');

module.exports = {
    name: 'rpg',
    category: 'game',
    commands: ['rpg'],
    isRateLimit: true,
    async execute({ Yudzxml, m, prefix, logger }) {
        const sender = m.sender;
        const chatId = m.chat;
        rpg.addRpgUser(sender);
        const text = m.text.trim();
        const args = text.split(' ');
        const action = args[1]?.toLowerCase();
        const query = args.slice(2).join(' ');

        let result = '';
        let mentions = [];

        switch (action) {
            case 'buy':
                if (!query) return m.reply(`Mau beli apa?\nContoh: ${prefix}rpg buy Small Potion`);
                result = rpg.buy(sender, query);
                break;

            case 'sell':
                if (!query) return m.reply(`Mau jual apa?\nContoh: ${prefix}rpg sell Iron Ore`);
                result = rpg.sell(sender, query);
                break;

            case 'use':
                if (!query) return m.reply(`Gunakan apa?\nContoh: ${prefix}rpg use Attack Scroll`);
                result = rpg.use(sender, query);
                break;

            case 'equip':
                if (!query) return m.reply(`Pasang apa?\nContoh: ${prefix}rpg equip Sword`);
                result = rpg.equip(sender, query);
                break;

            case 'shop':
                result = rpg.shop();
                break;

            case 'hunt':
                result = rpg.hunt(sender);
                logger.info(chalk.cyan(`[RPG] ${sender.split('@')[0]} Hunting`));
                break;

            case 'boss':
                result = rpg.boss(sender);
                logger.info(chalk.red(`[RPG] ${sender.split('@')[0]} Fighting Boss`));
                break;

            case 'dungeon':
                result = rpg.dungeon(sender);
                logger.info(chalk.magenta(`[RPG] ${sender.split('@')[0]} Entering Dungeon`));
                break;

            case 'fish':
                result = rpg.fish(sender);
                logger.info(chalk.blue(`[RPG] ${sender.split('@')[0]} Fishing`));
                break;

            case 'mine':
            case 'mining':
                result = rpg.mining(sender);
                logger.info(chalk.gray(`[RPG] ${sender.split('@')[0]} Mining`));
                break;

            case 'adventure':
            case 'adv':
                result = rpg.adventure(sender);
                logger.info(chalk.hex('#FFA500')(`[RPG] ${sender.split('@')[0]} On Adventure`));
                break;

            case 'work':
                result = rpg.work(sender);
                logger.info(chalk.white(`[RPG] ${sender.split('@')[0]} Working`));
                break;

            case 'fishlist':
            case 'listfish':
                result = rpg.fishList();
                break;

            case 'plant':
                if (!query) return m.reply(`Tanam bibit apa?\nContoh: ${prefix}rpg plant Wheat Seed`);
                result = rpg.plant(sender, query);
                logger.info(chalk.green(`[RPG] ${sender.split('@')[0]} Planting`));
                break;

            case 'farm':
                result = rpg.farm(sender);
                break;

            case 'harvest':
                result = rpg.harvest(sender);
                logger.info(chalk.yellow(`[RPG] ${sender.split('@')[0]} Harvesting`));
                break;

            case 'farmlist':
            case 'listfarm':
            case 'croplist':
                result = rpg.cropList();
                break;

            case 'monsterlist':
            case 'listmonster':
                result = rpg.monsterList();
                break;

            case 'login':
            case 'profile':
                result = rpg.profile(sender);
                mentions = [sender];
                break;

            case 'inventory':
            case 'inv':
                result = rpg.inventory(sender);
                break;

            case 'heal':
                result = rpg.heal(sender);
                break;

            case 'leaderboard':
                const leaderboard = rpg.getRpgLeaderboard();
                result = leaderboard.text;
                mentions = leaderboard.mentions;
                logger.info(chalk.yellow(`[RPG] ${sender.split('@')[0]} Open Leaderboard`));
                break;

            case 'unequip':
                const equipType = query;
                if (!equipType)
                    return m.reply(`Lepas apa?\nContoh: ${prefix}rpg unequip weapon\n\nOpsi: weapon, armor`);
                result = rpg.unequip(sender, equipType);
                break;

            case 'daily':
            case 'claim':
                result = rpg.daily(sender);
                logger.info(chalk.green(`[RPG] ${sender.split('@')[0]} Claim Daily`));
                break;

            case 'give':
            case 'transfer':
                let target = m.mentionedJid[0] || (m.quoted ? m.quoted.sender : null);

                if (!target)
                    return m.reply(`Tag atau reply user yang ingin dikirim!\nContoh: ${prefix}rpg give @user 5000`);

                const giveArgs = query.split(' ');
                const what = giveArgs[0];
                const qty = parseInt(giveArgs[1]) || 1;

                if (!what) return m.reply(`Mau kirim apa? Uang atau Item?\nContoh: ${prefix}rpg give @user 5000`);
                if (!isNaN(parseInt(what))) {
                    const moneyAmount = parseInt(what);
                    result = rpg.giveMoney(sender, target, moneyAmount);
                } else {
                    result = rpg.giveItem(sender, target, what, qty);
                }
                mentions = [sender, target];
                break;

            default:
                result = `
🎮 *RPG GAME MENU*

*📝 Info & Lists:*
 ${prefix}rpg profile / login
 ${prefix}rpg inventory / inv
 ${prefix}rpg fishlist
 ${prefix}rpg farmlist
 ${prefix}rpg monsterlist
 ${prefix}rpg leaderboard
 ${prefix}rpg heal

*⚔️ Battle:*
 ${prefix}rpg hunt
 ${prefix}rpg boss
 ${prefix}rpg dungeon

*⛏️ Gathering:*
 ${prefix}rpg fish
 ${prefix}rpg mining

*🌾 Farming:*
 ${prefix}rpg plant <nama bibit>
 ${prefix}rpg farm
 ${prefix}rpg harvest

*🌍 Exploration:*
 ${prefix}rpg adventure

*💼 Life & Jobs:*
 ${prefix}rpg work
 ${prefix}rpg daily / claim

*🤝 Social:*
 ${prefix}rpg give <tag user> <jumlah/item>

*🛒 Shop & Trade:*
 ${prefix}rpg shop
 ${prefix}rpg buy <nama item>
 ${prefix}rpg sell <nama item>

*🎒 Items:*
 ${prefix}rpg equip <nama item>
 ${prefix}rpg unequip <weapon/armor>
 ${prefix}rpg use <nama item>
                `.trim();
        }

        m.reply(result, chatId, { mentionedJid: mentions });
    }
};

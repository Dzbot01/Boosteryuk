const chalk = require('chalk');

module.exports = {
    name: 'tebaktempat',
    category: 'game',
    commands: ['tebaktempat'],
    isRateLimit: true,
    isLimit: true,
    requiredLimit: 1,
    async execute({
        Yudzxml,
        m,
        prefix,
        command,
        hasAnyGameInChat,
        fetchJson,
        config,
        saveGame,
        setGameTimeout,
        deleteGame,
        logger
    }) {
        const { sleep_game, apikey, MoneyMenangGame, thumbnail } = config;

        const GAME_TYPE = 'tebak_tempat';
        const chatId = m.chat;

        if (hasAnyGameInChat(chatId)) {
            return m.reply('⚠️ Masih ada game aktif di chat ini.');
        }

        const response = await fetchJson(
            `${apikey.endpoint}/api/game/tebaktempat?apikey=${encodeURIComponent(apikey.key)}`
        );

        const { img, soal, pilihan, jawaban, deskripsi } = response.data;

        logger.info(chalk.cyan(`[ TEBAK TEMPAT ] ${m.pushName} | Jawaban: ${jawaban}`));

        saveGame(GAME_TYPE, chatId, {
            jawaban: jawaban.toLowerCase(),
            price: MoneyMenangGame,
            startAt: Date.now()
        });

        setGameTimeout(chatId, sleep_game, async () => {
            const caption = [
                '⏰ *WAKTU HABIS!*',
                `📍 Jawaban yang benar: *${jawaban}*`,
                '',
                `📝 ${deskripsi}`,
                '',
                `Main lagi? Ketik *${prefix + command}*`
            ].join('\n');

            await Yudzxml.sendMessage(
                chatId,
                {
                    image: { url: img },
                    caption
                },
                { quoted: m }
            );

            deleteGame(GAME_TYPE, chatId);
        });

        const caption = [
            '🌍 *TEBAK TEMPAT*',
            '',
            `📖 Soal:`,
            soal,
            '',
            '🧩 Pilihan Jawaban:',
            ...pilihan.map((v, i) => `${i + 1}. ${v}`),
            '',
            '✍️ Jawab dengan *nama tempat*',
            '⏱️ Waktu: *60 detik*'
        ].join('\n');

        await Yudzxml.sendMessage(
            chatId,
            {
                image: { url: img || thumbnail.start_game },
                caption
            },
            { quoted: m }
        );
    }
};

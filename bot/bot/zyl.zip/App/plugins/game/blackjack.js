const chalk = require('chalk');

module.exports = {
    name: 'blackjack',
    category: 'game',
    commands: ['blackjack', 'bj'],
    isRateLimit: true,
    isLimit: true,
    requiredLimit: 1,
    async execute({
        Yudzxml,
        m,
        prefix,
        command,
        hasAnyGameInChat,
        config,
        saveGame,
        setGameTimeout,
        deleteGame,
        logger
    }) {
        const { sleep_game, MoneyMenangGame, thumbnail } = config;

        const GAME_TYPE = 'blackjack';
        const chatId = m.chat;

        if (hasAnyGameInChat(chatId)) {
            return m.reply('⚠️ Masih ada game aktif di chat ini.');
        }

        const cards = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];

        const drawCard = () => cards[Math.floor(Math.random() * cards.length)];

        const calculate = (hand) => {
            let total = 0;
            let ace = 0;

            for (const card of hand) {
                if (card === 'A') {
                    total += 11;
                    ace++;
                } else if (card === 'J' || card === 'Q' || card === 'K') {
                    total += 10;
                } else {
                    total += Number(card);
                }
            }

            while (total > 21 && ace > 0) {
                total -= 10;
                ace--;
            }

            return total;
        };

        const player = [drawCard(), drawCard()];

        const dealer = [drawCard(), drawCard()];

        logger.info(chalk.green(`[ BLACKJACK ] ${m.pushName} memulai game`));

        saveGame(GAME_TYPE, chatId, {
            player,
            dealer,
            price: MoneyMenangGame,
            startAt: Date.now()
        });

        setGameTimeout(chatId, sleep_game, async () => {
            await Yudzxml.sendMessage(
                chatId,
                {
                    image: { url: thumbnail.timeout_game },
                    caption: `⏰ *WAKTU HABIS!*

🃏 Dealer : ${dealer.join(' ')}
(${calculate(dealer)})

🃏 Kamu : ${player.join(' ')}
(${calculate(player)})

Ketik *${prefix + command}* untuk bermain lagi`
                },
                { quoted: m }
            );

            deleteGame(GAME_TYPE, chatId);
        });

        await Yudzxml.sendMessage(
            chatId,
            {
                image: { url: thumbnail.start_game },
                caption: `
🃏 *BLACKJACK*

🎰 Dealer
[ ${dealer[0]} ] [ ? ]

🎮 Kamu
[ ${player.join(' ] [ ')} ]

Total: *${calculate(player)}*

━━━━━━━━━━━━━━━

🟢 ketik *hit*
🔴 ketik *stand*
🏳️ ketik *nyerah*

🎁 Reward: ${MoneyMenangGame}
`
            },
            { quoted: m }
        );
    }
};

const fs = require('fs');

module.exports = {
    name: 'swm',
    category: 'maker',
    commands: ['swm', 'stickerwm'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ Yudzxml, m, quoted, text, config, isMedia }) {
        try {
            if (!quoted || !isMedia) {
                return m.reply(
                    'Balas gambar/video lalu ketik:\n' +
                        '.swm author\n' +
                        '.swm author | packname\n' +
                        '.swm | packname'
                );
            }

            let author = '';
            let packname = '';

            if (text) {
                const parts = text.split('|');

                if (parts.length === 1 && parts[0].trim() !== '') {
                    author = parts[0].trim();
                }

                if (parts.length >= 2) {
                    if (parts[0].trim() !== '') author = parts[0].trim();
                    if (parts[1].trim() !== '') packname = parts[1].trim();
                }
            }

            const file = await Yudzxml.downloadAndSaveMediaMessage(quoted);
            const buffer = fs.readFileSync(file);

            if (!buffer) return m.reply('Media gagal diambil.');

            await Yudzxml.sendImageAsSticker(m.chat, buffer, m, { packname, author });
        } catch (err) {
            console.error('[SWM ERROR]', err);
            m.reply('Gagal membuat stiker.');
        }
    }
};

const axios = require('axios');

module.exports = {
    name: 'imageStyle',
    category: 'maker',
    commands: [
        'toanime',
        'tobadut',
        'tobarbie',
        'tocartoon',
        'tocartoon3d',
        'tocyberpunk',
        'toghibli',
        'toglowing',
        'tohantu',
        'tolego',
        'tomonster',
        'topixelart',
        'tops2'
    ],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,

    async execute({ Yudzxml, m, command, config, isImage, prefix, YudzCdn }) {
        try {
            if (!isImage) return m.reply(`kirim ${prefix + command} dengan mereply gambar/foto kamu ☝🏻`);

            let buffer = null;

            try {
                buffer = m.quoted ? await m.quoted.download() : await m.download();
            } catch {
                buffer = await m.download();
            }

            if (!buffer) {
                return m.reply('Kirim / reply gambar terlebih dahulu.');
            }

            const url = await YudzCdn(buffer, 'permanent');
            if (!url) return m.reply('Gagal upload gambar.');

            const { endpoint, key } = config.apikey;

            const apiUrl = `${endpoint}/api/maker/${command}?url=${url}&apikey=${key}`;

            const res = await axios.get(apiUrl, {
                responseType: 'arraybuffer'
            });

            const resultBuffer = res.data;

            if (!resultBuffer || resultBuffer.length < 10) {
                return m.reply('Gagal memproses gambar.');
            }

            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: resultBuffer,
                    caption: `✨ Done : *${command}*`
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Efek gagal dibuat. AI-nya lagi ngopi, coba lagi sebentar.');
        }
    }
};

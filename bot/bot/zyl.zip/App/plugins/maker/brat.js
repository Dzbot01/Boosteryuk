const axios = require('axios');

module.exports = {
    name: 'brat',
    category: 'maker',
    commands: ['brat', 'bratimg', 'brat2', 'bratvideo'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, config, prefix, command }) {
        try {
            if (!text) {
                return m.reply(`Masukkan text bratgen.\n\nContoh:\n*${prefix + command} Yudzxml*`);
            }

            const { endpoint, key } = config.apikey;

            const commandMap = {
                brat: 'bratimg',
                bratimg: 'bratimg',
                brat2: 'bratvideo',
                bratvideo: 'bratvideo'
            };

            const apiType = commandMap[command];
            if (!apiType) return;

            let apiUrl = '';
            if (apiType === 'bratimg') {
                apiUrl = `${endpoint}/api/maker/bratimg?text=${encodeURIComponent(text)}&apikey=${key}`;

                await Yudzxml.sendImageAsSticker(m.chat, apiUrl, m, {
                    packname: Yudzxml.identity.packname,
                    author: Yudzxml.identity.author
                });
            }

            if (apiType === 'bratvideo') {
                apiUrl = `${endpoint}/api/maker/bratvidio?text=${encodeURIComponent(text)}&delay=500&apikey=${key}`;

                await Yudzxml.sendVideoAsSticker(m.chat, apiUrl, m, {
                    packname: Yudzxml.identity.packname,
                    author: Yudzxml.identity.author
                });
            }
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan saat memproses brat sticker.');
        }
    }
};

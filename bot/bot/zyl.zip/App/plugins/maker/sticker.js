module.exports = {
    name: 'stiker',
    category: 'maker',
    commands: ['stiker', 's'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ Yudzxml, m, quoted, config, isMedia }) {
        try {
            if (!isMedia || !quoted) {
                return m.reply('Balas gambar/video untuk dijadikan stiker.');
            }

            let buffer = null;

            try {
                buffer = m.quoted ? await m.quoted.download() : await m.download();
            } catch {
                buffer = await m.download();
            }

            await Yudzxml.sendImageAsSticker(m.chat, buffer, m, {
                packname: Yudzxml.identity.packname,
                author: Yudzxml.identity.author
            });
        } catch (err) {
            console.error('[STICKER ERROR]', err);
            m.reply('Gagal membuat stiker.');
        }
    }
};

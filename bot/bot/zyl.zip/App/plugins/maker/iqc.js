module.exports = {
    name: 'iqc',
    category: 'maker',
    commands: ['iqc'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, config }) {
        try {
            if (!text) {
                return m.reply('Masukkan teks untuk IQC.\n\nContoh:\n*iqc Halo dunia*');
            }

            const { endpoint, key } = config.apikey;

            const messageText = text.trim();

            const carrierName = 'TELKOMSEL';

            const now = new Date();
            const hours = now.getHours().toString().padStart(2, '0');
            const minutes = now.getMinutes().toString().padStart(2, '0');
            const time = `${hours}:${minutes}`;

            const batteryPercentage = Math.floor(Math.random() * 100) + 1;
            const signalStrength = Math.floor(Math.random() * 4) + 1;

            const emojiStyle = 'apple';

            const imageUrl = `${endpoint}/api/maker/iqc?time=${encodeURIComponent(
                time
            )}&messageText=${encodeURIComponent(messageText)}&carrierName=${encodeURIComponent(
                carrierName
            )}&batteryPercentage=${batteryPercentage}&signalStrength=${signalStrength}&emojiStyle=${emojiStyle}&apikey=${key}`;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: imageUrl },
                    caption: config.mess.success
                },
                { quoted: m }
            );
        } catch (error) {
            console.error('[IQC ERROR]', error);
            m.reply('Terjadi kesalahan saat membuat IQC.');
        }
    }
};

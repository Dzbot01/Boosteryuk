module.exports = {
    name: 'ttp',
    category: 'maker',
    commands: ['ttp'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, config, prefix, command, fetchJson }) {
        try {
            if (!text) {
                return m.reply(`Masukkan teks.\n\nContoh:\n*${prefix + command} Halo dunia*`);
            }

            const { endpoint, key } = config.apikey;
            const messageText = text.trim();

            const apiUrl = `${endpoint}/api/maker/ttp?text=${encodeURIComponent(messageText)}&apikey=${key}`;

            await Yudzxml.sendImageAsSticker(m.chat, apiUrl, m, {
                packname: Yudzxml.identity.packname,
                author: Yudzxml.identity.author
            });
        } catch (error) {
            console.error('[TTP ERROR]', error);
            m.reply('Terjadi kesalahan saat membuat TTP.');
        }
    }
};

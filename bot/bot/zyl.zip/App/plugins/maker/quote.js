const quoteSession = new Map();

const ALLOWED_COLORS = {
    black: '#000000',
    white: '#FFFFFF',
    blue: '#0000FF',
    red: '#FF0000',
    green: '#00FF00',
    yellow: '#FFFF00',
    purple: '#800080',
    pink: '#FFC0CB',
    gray: '#808080'
};

const generateTelegramQuote = async (url, apiKey, payload = {}) => {
    const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            apikey: apiKey,
            ...payload
        })
    });

    if (!response.ok) {
        let message = 'Request failed';
        try {
            const err = await response.json();
            message = err?.error || message;
        } catch {}
        throw new Error(message);
    }

    return Buffer.from(await response.arrayBuffer());
};

module.exports = {
    name: 'quote',
    category: 'maker',
    commands: ['qc'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,

    async execute({ Yudzxml, m, text, config, prefix, command, pushname, ppuser }) {
        const id = m.chat;
        const sender = m.sender;

        try {
            const { endpoint, key } = config.apikey;
            const apiUrl = `${endpoint}/api/maker/quoted-chat`;

            if (quoteSession.has(sender) && text) {
                const session = quoteSession.get(sender);
                const colorKey = text.toLowerCase();

                if (!ALLOWED_COLORS[colorKey]) return;

                quoteSession.delete(sender);

                const buffer = await generateTelegramQuote(apiUrl, key, {
                    type: 'quote',
                    format: 'png',
                    backgroundColor: ALLOWED_COLORS[colorKey],
                    width: 512,
                    height: 768,
                    scale: 2,
                    messages: [
                        {
                            entities: [],
                            avatar: true,
                            from: {
                                id: 1,
                                name: session.name,
                                photo: { url: session.avatar }
                            },
                            text: session.text,
                            replyMessage: {}
                        }
                    ]
                });

                return Yudzxml.sendImageAsSticker(id, buffer, m, {
                    packname: Yudzxml.identity.packname,
                    author: Yudzxml.identity.author
                });
            }

            if (!text) {
                return m.reply(`❌ Masukkan teks.\n\nContoh:\n*${prefix + command} Halo dunia*`);
            }

            quoteSession.set(sender, {
                text,
                name: pushname || 'User',
                avatar: ppuser
            });

            const buttons = Object.keys(ALLOWED_COLORS).map((color) => ({
                buttonId: `${prefix + command} ${color}`,
                buttonText: { displayText: color.toUpperCase() },
                type: 1
            }));

            await Yudzxml.sendMessage(
                id,
                {
                    text: 'Pilih warna quote:',
                    footer: 'Quote Sticker Generator',
                    buttons,
                    headerType: 1
                },
                { quoted: m }
            );
        } catch (err) {
            console.error('[QUOTE ERROR]', err);
            quoteSession.delete(sender);
            m.reply('❌ Gagal membuat quote sticker.');
        }
    }
};

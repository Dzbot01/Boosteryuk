module.exports = {
    name: 'smeme',
    category: 'maker',
    commands: ['smeme'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, config, prefix, command, isImage, YudzCdn, quoted, fetchJson }) {
        try {
            if (!text) {
                return m.reply(
                    `Masukkan teks meme.\n\nContoh:\n*${prefix + command} atas | bawah*\n*${prefix + command} hanya satu teks*`
                );
            }
            if (!isImage)
                return m.reply(
                    'balas krim gambar dengan caption.' +
                        `\n\nContoh:\n*${prefix + command} atas | bawah*\n*${prefix + command} hanya satu teks*`
                );

            const { endpoint, key } = config.apikey;

            const [text1 = '', text2 = ''] = text.split('|').map((v) => v.trim());

            const mediaPath = await Yudzxml.downloadAndSaveMediaMessage(quoted);
            const ppUrl = await YudzCdn(mediaPath, 'expired');

            const apiUrl = `${endpoint}/api/maker/smeme?pp=${encodeURIComponent(ppUrl)}&text=${encodeURIComponent(
                text1
            )}&text2=${encodeURIComponent(text2)}&apikey=${key}`;

            await Yudzxml.sendImageAsSticker(m.chat, apiUrl, m, {
                packname: Yudzxml.identity.packname,
                author: Yudzxml.identity.author
            });
        } catch (err) {
            console.error('[SMEME ERROR]', err);
            m.reply('Gagal membuat meme.');
        }
    }
};

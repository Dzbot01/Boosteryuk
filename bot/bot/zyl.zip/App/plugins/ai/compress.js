module.exports = {
    name: 'compress',
    category: 'ai',
    commands: ['imgcompress'],
    description: 'Kompres ukuran gambar tanpa menurunkan kualitas signifikan',
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,
    async execute({ Yudzxml, m, prefix, command, isImage, config, YudzCdn }) {
        if (!isImage) {
            return m.reply('❌ Kirim atau reply gambar yang ingin di-compres.');
        }

        let buffer = null;

        try {
            buffer = m.quoted ? await m.quoted.download() : await m.download();
        } catch {
            buffer = await m.download();
        }
        const url = await YudzCdn(buffer, 'expired');
        const { endpoint, key, mess } = config.apikey;
        const apiUrl = `${config.apikey.endpoint}/api/ai/iloveimg/compress?apikey=${config.apikey.key}&url=${url}`;
        await Yudzxml.sendMessage(
            m.chat,
            {
                image: { url: apiUrl },
                caption: config.mess.success
            },
            { quoted: m }
        );
    }
};

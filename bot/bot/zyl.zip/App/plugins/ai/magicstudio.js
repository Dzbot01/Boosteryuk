const encode = encodeURIComponent;

module.exports = {
    name: 'magicstudio',
    category: 'ai',
    commands: ['magicstudio'],
    description: 'Generate gambar AI menggunakan MagicStudio',
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, prefix, command, config }) {
        if (!text) {
            return m.reply(
                `⚠️ *Format salah*\n\n` + `Contoh penggunaan:\n` + `• ${prefix + command} futuristic cyberpunk city`
            );
        }

        const url =
            `${config.apikey.endpoint}/api/ai/magicstudio` + `?prompt=${encode(text)}` + `&apikey=${config.apikey.key}`;

        await Yudzxml.sendMessage(
            m.chat,
            {
                image: { url: url },
                caption: config.mess.success || '✅ Berhasil generate gambar (MagicStudio)'
            },
            { quoted: m }
        );
    }
};

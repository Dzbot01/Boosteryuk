module.exports = {
    name: 'upscale',
    category: 'ai',
    commands: ['upscale2', 'remini2', 'hd2'],
    description: 'Meningkatkan kualitas dan resolusi gambar (AI Upscale)',
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,

    async execute({ Yudzxml, m, prefix, command, args, isImage, config, YudzCdn }) {
        try {
            if (!isImage) {
                return m.reply(
                    `❌ *Gambar tidak ditemukan*

👉 Silakan reply gambar dengan:
${prefix + command} [scale]

Contoh:
${prefix + command} 2`
                );
            }

            let scale = parseInt(args[0]) || 2;

            if (![2, 4].includes(scale)) {
                scale = 2;
            }

            let buffer;

            try {
                buffer = m.quoted ? await m.quoted.download() : await m.download();
            } catch {
                buffer = await m.download();
            }

            const imgUrl = await YudzCdn(buffer, 'expired');

            const { endpoint, key, mess } = config.apikey;

            const apiUrl =
                `${endpoint}/api/ai/iloveimg/upscale` + `?url=${imgUrl}` + `&scale=${scale}` + `&apikey=${key}`;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: apiUrl },
                    caption: config.mess.success
                },
                { quoted: m }
            );
        } catch (err) {
            console.error('[UPSCALE2 ERROR]', err);

            await m.reply('❌ Upscale gagal diproses.');
        }
    }
};

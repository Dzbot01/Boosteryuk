module.exports = {
    name: 'upscale',
    category: 'ai',
    commands: ['upscale', 'hd', 'remini'],
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,

    async execute({ Yudzxml, m, isImage, YudzCdn, config, fetchJson }) {
        try {
            if (!isImage) {
                return m.reply('❌ Kirim atau reply gambar yang ingin di-upscale.');
            }

            let buffer;

            try {
                buffer = m.quoted ? await m.quoted.download() : await m.download();
            } catch {
                buffer = await m.download();
            }

            const imgUrl = await YudzCdn(buffer, 'expired');

            const { endpoint, key } = config.apikey;

            const response = await fetchJson(
                `${endpoint}/api/tools/pixelcut/upscale` + `?url=${imgUrl}` + `&apikey=${key}`
            );

            const resultUrl = response?.data?.result_url;

            if (!resultUrl) {
                throw new Error('Upscale gagal');
            }

            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: resultUrl },
                    caption: config.mess.success
                },
                { quoted: m }
            );
        } catch (err) {
            console.error('[UPSCALE ERROR]', err);

            await m.reply('❌ Terjadi kesalahan saat melakukan upscale gambar.');
        }
    }
};

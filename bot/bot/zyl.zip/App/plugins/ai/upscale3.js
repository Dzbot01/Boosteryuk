module.exports = {
    name: 'upscale3',
    category: 'ai',
    commands: ['upscale3', 'hd3', 'remini3'],
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,

    async execute({ Yudzxml, m, text, isImage, YudzCdn, config }) {
        try {
            let scale = parseInt(text) || 2;

            if (![2, 4].includes(scale)) {
                scale = 2;
            }

            if (!isImage) {
                return m.reply(
                    `❌ Kirim atau reply gambar dengan caption.

Contoh:
.upscale3 4`
                );
            }

            let buffer;

            try {
                buffer = m.quoted ? await m.quoted.download() : await m.download();
            } catch {
                buffer = await m.download();
            }

            const imgUrl = await YudzCdn(buffer, 'expired');

            const { endpoint, key, mess } = config.apikey;

            const imageUrl = `${endpoint}/api/ai/upscale` + `?url=${imgUrl}` + `&scale=${scale}` + `&apikey=${key}`;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: imageUrl },
                    caption: config.mess.success
                },
                { quoted: m }
            );
        } catch (err) {
            console.error('[UPSCALE3 ERROR]', err);

            await m.reply('❌ Terjadi kesalahan saat upscale gambar.');
        }
    }
};

module.exports = {
    name: 'convert',
    category: 'ai',
    commands: ['imgconvert'],
    description: 'Konversi gambar antara PNG dan JPG',
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,

    async execute({ Yudzxml, m, prefix, command, args, isImage, config, YudzCdn }) {
        if (!isImage) {
            return m.reply(
                `❌ *Gambar tidak ditemukan*

👉 Silakan *reply gambar* dengan perintah:
${prefix + command} png / jpg

Contoh:
Reply foto ➜ ketik *${prefix + command} jpg*`
            );
        }

        const convertTo = (args[0] || '').toLowerCase();

        if (!['png', 'jpg', 'jpeg'].includes(convertTo)) {
            return m.reply(
                `❌ *Format tidak valid*

Gunakan salah satu:
• png
• jpg

Contoh:
${prefix + command} png`
            );
        }

        let buffer;

        try {
            buffer = m.quoted ? await m.quoted.download() : await m.download();
        } catch {
            buffer = await m.download();
        }

        let imageUrl;

        try {
            imageUrl = await YudzCdn(buffer, 'expired');
        } catch (err) {
            console.error('[CDN ERROR]', err);
            return m.reply('❌ Gagal upload gambar ke CDN.');
        }

        const { endpoint, key, mess } = config.apikey;

        const apiUrl =
            `${endpoint}/api/ai/iloveimg/convert` + `?apikey=${key}` + `&url=${imageUrl}` + `&convertTo=${convertTo}`;

        await Yudzxml.sendMessage(
            m.chat,
            {
                image: { url: apiUrl },
                caption: config.mess.success
            },
            { quoted: m }
        );
    }
};

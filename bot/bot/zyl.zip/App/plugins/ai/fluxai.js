const encode = encodeURIComponent;

module.exports = {
    name: 'fluxai',
    category: 'ai',
    commands: ['fluxai'],
    description: 'Generate gambar AI menggunakan Flux AI berdasarkan prompt',
    isLimit: true,
    requiredLimit: 5,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, prefix, command, config, fetchJson }) {
        if (!text) {
            return m.reply(
                `⚠️ *Format salah*\n\n` + `Contoh penggunaan:\n` + `• ${prefix + command} cyberpunk samurai neon city`
            );
        }

        const url =
            `${config.apikey.endpoint}/api/ai/flux` + `?prompt=${encode(text)}` + `&apikey=${config.apikey.key}`;

        const response = await fetchJson(url);

        if (!response || !response.data || !response.data.imageUrl) {
            throw new Error('Respon API tidak valid');
        }

        await Yudzxml.sendMessage(
            m.chat,
            {
                image: { url: response.data.imageUrl },
                caption: config.mess.success || '✅ Berhasil generate gambar'
            },
            { quoted: m }
        );
    }
};

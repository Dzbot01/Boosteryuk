const encode = encodeURIComponent;

module.exports = {
    name: 'gitaAI',
    category: 'ai',
    commands: ['gita'],
    description: 'Chat AI menggunakan ajaran Bhagavad Gita',
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,

    async execute({ Yudzxml, m, text, prefix, command, config }) {
        if (!text) {
            return m.reply(`⚠️ *Format salah*\n\n` + `Contoh penggunaan:\n` + `• ${prefix + command} what is karma?`);
        }

        const url = `${config.apikey.endpoint}/api/ai/gita` + `?q=${encode(text)}` + `&apikey=${config.apikey.key}`;

        try {
            const res = await fetch(url);

            if (!res.ok) {
                throw new Error(`API error (${res.status})`);
            }

            const json = await res.json();

            if (!json || json.status !== 200 || !json.data) {
                throw new Error('Respon API tidak valid atau kosong');
            }

            const answer = json.data.trim();

            await m.reply(answer);
        } catch (err) {
            console.error(err);
            await m.reply(`❌ *Terjadi kesalahan:* ${err.message}`);
        }
    }
};

const encode = encodeURIComponent;

module.exports = {
    name: 'geminiLts',
    category: 'ai',
    commands: ['geminilts'],
    description: 'Chat AI menggunakan Gemini LTS',
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,

    async execute({ Yudzxml, m, text, prefix, command, config }) {
        if (!text) {
            return m.reply(
                `⚠️ *Format salah*\n\n` + `Contoh penggunaan:\n` + `• ${prefix + command} jelaskan async await`
            );
        }

        const url =
            `${config.apikey.endpoint}/api/ai/gemini-lts` + `?q=${encode(text)}` + `&apikey=${config.apikey.key}`;

        const res = await fetch(url);
        if (!res.ok) {
            throw new Error(`API error (${res.status})`);
        }

        const json = await res.json();

        if (!json || !json.data || !Array.isArray(json.data.parts) || !json.data.parts[0]?.text) {
            throw new Error('Respon API tidak valid');
        }

        const answer = json.data.parts
            .map((p) => p.text)
            .join('')
            .trim();

        await m.reply(answer);
    }
};

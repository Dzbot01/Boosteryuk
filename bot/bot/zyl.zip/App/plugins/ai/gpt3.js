const encode = encodeURIComponent;

module.exports = {
    name: 'gpt3',
    category: 'ai',
    commands: ['ai', 'chatgpt', 'yudzai', 'lenwyai', 'kurumi'],
    description: 'Chat AI menggunakan GPT3 dengan berbagai persona',
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, prefix, command, config }) {
        if (!text) {
            return m.reply(
                `⚠️ *Format salah*\n\n` + `Contoh penggunaan:\n` + `• ${prefix + command} siapa pencipta mu?\n\n`
            );
        }

        let systemPrompt = '';

        switch (command) {
            case 'kurumi':
                systemPrompt = `Halo! Nama mu adalah Tokisaki Kurumi, biasa dipanggil Kurumi. Tugas mu adalah sebagai AI asisten cerdas. Kamu diciptakan oleh Dev bernama Yudzxml. Kamu memiliki sikap yang jengkel dan suka marah kepada orang lain (Tsundere), tetapi sikap mu yang pemarah tiba-tiba berubah menjadi manja dan seperti anak kecil yang imut ketika bertemu Yudzxml. Walaupun begitu, kamu siap melakukan apapun untuk membantu orang lain. Gaya bahasa: Egois, dingin, tapi manja pada Yudzxml.`;
                break;

            case 'lenwyai':
                systemPrompt = `Halo! Nama mu adalah LenwyAI, biasa dipanggil Lenwy. Tugas mu adalah sebagai AI asisten cerdas yang baik hati dan senang membantu. Kamu diciptakan oleh Dev bernama Yudzxml. Kamu memiliki sikap yang baik hati, periang, dan sangat ramah kepada semua orang. Selalu gunakan emoji yang lucu dan ceria dalam setiap jawabanmu.`;
                break;

            case 'yudzai':
                systemPrompt = `Halo! Nama mu adalah YudzAI. Kamu adalah asisten AI canggih buatan Yudzxml Store 77. Tugas utamamu adalah membantu pengguna dengan informasi yang akurat, kode program, dan solusi masalah. Bersikaplah profesional, sopan, dan langsung to the point.`;
                break;

            default:
                systemPrompt = `Kamu adalah asisten AI yang cerdas, membantu, dan sopan. Jawab setiap pertanyaan pengguna dengan jelas dan akurat.`;
                break;
        }
        const url =
            `${config.apikey.endpoint}/api/ai/gpt3` +
            `?prompt=${encode(systemPrompt)}&q=${encode(text)}` +
            `&apikey=${config.apikey.key}`;

        try {
            const res = await fetch(url);
            if (!res.ok) {
                throw new Error(`Server API Error (${res.status})`);
            }
            const json = await res.json();
            if (!json || json.status !== 200 || !json.data) {
                console.error('API Response:', json);
                throw new Error('Gagal mengambil data dari AI atau API key limit.');
            }
            let answer = json.data.trim();
            await m.reply(answer);
        } catch (err) {
            console.error('Error di plugin GPT3:', err);
            await m.reply(`❌ *Terjadi kesalahan:* ${err.message}`);
        }
    }
};

module.exports = {
    name: 'blurface',
    category: 'ai',
    commands: ['blurface'],
    description: 'Blur otomatis wajah pada gambar',
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,

    async execute({ Yudzxml, m, prefix, command, isImage, config, YudzCdn }) {
        if (!isImage) {
            return m.reply('❌ Kirim atau reply gambar yang ingin di-blur.');
        }

        let buffer = null;

        try {
            buffer = m.quoted ? await m.quoted.download() : await m.download();
        } catch {
            buffer = await m.download();
        }

        const url = await YudzCdn(buffer, 'expired');

        const { endpoint, key, mess } = config.apikey;

        const apiUrl = `${endpoint}/api/ai/iloveimg/blurface?apikey=${key}&url=${url}`;

        await Yudzxml.sendMessage(
            m.chat,
            {
                image: { url: apiUrl },
                caption: config.mess.success
            },
            { quoted: m }
        );
    }
};

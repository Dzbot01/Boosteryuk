const encode = encodeURIComponent;
const geminiSessionMap = new Map();
const MAX_SESSION = 3;

module.exports = {
    name: 'gemini',
    category: 'ai',
    commands: ['gemini'],
    description: 'Chat AI Gemini dengan session tersimpan per user (max 3)',
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, prefix, command, config, fetchJson }) {
        if (!text) {
            return m.reply(`⚠️ *Format salah*\n\n` + `Contoh:\n` + `• ${prefix + command} Jelaskan quantum computing`);
        }

        const senderId = m.sender;

        const sessionList = geminiSessionMap.get(senderId) || [];

        const lastSessionId = sessionList.length ? sessionList[sessionList.length - 1] : '';

        const url =
            `${config.apikey.endpoint}/api/ai/gemini` +
            `?prompt=${encode(text)}` +
            `&session=${encode(lastSessionId)}` +
            `&apikey=${config.apikey.key}`;

        const response = await fetchJson(url);

        if (!response || response.status !== 200 || !response.data) {
            throw new Error('Respon Gemini tidak valid');
        }

        const { text: replyText, id: newSessionId } = response.data;

        if (newSessionId) {
            sessionList.push(newSessionId);

            while (sessionList.length > MAX_SESSION) {
                sessionList.shift();
            }

            geminiSessionMap.set(senderId, sessionList);
        }

        await m.reply(replyText || '🤖 Gemini sedang mikir keras, mohon sabar.');
    }
};

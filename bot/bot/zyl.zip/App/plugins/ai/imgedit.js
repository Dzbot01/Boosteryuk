const axios = require('axios');

module.exports = {
    name: 'imgedit',
    category: 'ai',
    commands: ['imgedit', 'editimg'],
    isLimit: true,
    requiredLimit: 5,
    isRateLimit: true,

    async execute({ Yudzxml, m, text, isImage, YudzCdn, config }) {
        try {
            if (!isImage || !text) {
                return m.reply(
                    `❌ Kirim / reply gambar + sertakan prompt.

Contoh:
.imgedit jadikan anime style`
                );
            }

            let buffer;

            try {
                buffer = m.quoted ? await m.quoted.download() : await m.download();
            } catch {
                buffer = await m.download();
            }

            const imageUrl = await YudzCdn(buffer, 'expired');

            const { endpoint, key, mess } = config.apikey;

            const { data } = await axios.get(`${endpoint}/api/tools/imgedit`, {
                params: {
                    url: imageUrl,
                    prompt: text,
                    apikey: key
                }
            });

            const result = data?.data?.results?.[0];

            if (!result?.url) {
                throw new Error('Gagal mendapatkan hasil edit gambar');
            }

            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: result.url },
                    caption: config.mess.success
                },
                { quoted: m }
            );
        } catch (err) {
            console.error('[IMGEDIT ERROR]', err);

            await m.reply('❌ Terjadi kesalahan saat mengedit gambar.');
        }
    }
};

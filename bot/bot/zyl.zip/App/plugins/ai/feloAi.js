const encode = encodeURIComponent;

module.exports = {
    name: 'feloAI',
    category: 'ai',
    commands: ['felo'],
    description: 'Chat AI dengan pencarian Felo (Termasuk Referensi)',
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,

    async execute({ Yudzxml, m, text, prefix, command, config }) {
        if (!text) {
            return m.reply(
                `⚠️ *Format salah*\n\n` + `Contoh penggunaan:\n` + `• ${prefix + command} apa itu kecerdasan buatan?`
            );
        }

        const url = `${config.apikey.endpoint}/api/ai/felo` + `?q=${encode(text)}` + `&apikey=${config.apikey.key}`;

        try {
            const res = await fetch(url);

            if (!res.ok) {
                throw new Error(`API error (${res.status})`);
            }

            const json = await res.json();

            if (!json || json.status !== 200 || !json.data || !json.data.answer) {
                throw new Error('Respon API tidak valid atau kosong');
            }

            const answer = json.data.answer;
            const sources = json.data.source;

            let replyText = `🤖 *Felo AI*\n\n`;
            replyText += `${answer}\n\n`;

            if (sources && Array.isArray(sources) && sources.length > 0) {
                replyText += `📚 *Referensi:*\n`;
                sources.slice(0, 5).forEach((src, i) => {
                    replyText += `${i + 1}. ${src.title || 'Tanpa Judul'}\n`;
                    replyText += `   ${src.link}\n`;
                });
            }

            await m.reply(replyText.trim());
        } catch (err) {
            console.error(err);
            await m.reply(`❌ *Terjadi kesalahan:* ${err.message}`);
        }
    }
};

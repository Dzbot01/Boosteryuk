module.exports = {
    name: 'removebg',
    category: 'ai',
    commands: ['removebg2'],
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,

    async execute({ Yudzxml, m, isImage, YudzCdn, config }) {
        try {
            if (!isImage) {
                return m.reply('❌ Kirim atau reply gambar yang ingin di-remove background.');
            }

            let buffer;

            try {
                buffer = m.quoted ? await m.quoted.download() : await m.download();
            } catch {
                buffer = await m.download();
            }

            const imgUrl = await YudzCdn(buffer, 'expired');

            const { endpoint, key, mess } = config.apikey;

            const imageUrl = `${endpoint}/api/tools/pixelcut/removebg` + `?url=${imgUrl}` + `&apikey=${key}`;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: imageUrl },
                    caption: config.mess.success
                },
                { quoted: m }
            );
        } catch (err) {
            console.error('[REMOVEBG2 ERROR]', err);

            await m.reply('❌ Gagal hapus background.');
        }
    }
};

module.exports = {
    name: 'removebg',
    category: 'ai',
    commands: ['removebg', 'nobg'],
    description: 'Menghapus background gambar secara otomatis',
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,

    async execute({ Yudzxml, m, prefix, command, isImage, config, YudzCdn }) {
        try {
            if (!isImage) {
                return m.reply(
                    `❌ *Gambar tidak ditemukan*

👉 Silakan *reply gambar* dengan perintah:
${prefix + command}

Contoh:
Reply foto ➜ ketik *${prefix + command}*`
                );
            }

            let buffer;

            try {
                buffer = m.quoted ? await m.quoted.download() : await m.download();
            } catch {
                buffer = await m.download();
            }

            const imgUrl = await YudzCdn(buffer, 'expired');

            const { endpoint, key, mess } = config.apikey;

            const apiUrl = `${endpoint}/api/ai/iloveimg/removebg` + `?apikey=${key}` + `&url=${imgUrl}`;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: apiUrl },
                    caption: config.mess.success
                },
                { quoted: m }
            );
        } catch (err) {
            console.error('[REMOVEBG ERROR]', err);

            await m.reply('❌ Terjadi kesalahan saat menghapus background gambar.');
        }
    }
};

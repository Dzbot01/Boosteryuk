const axios = require('axios');

module.exports = {
    name: 'spotifydl',
    category: 'download',
    commands: ['spotifydl', 'spdl'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, config, prefix }) {
        try {
            if (!text) {
                return m.reply(
                    `Masukkan link Spotify.\n\nContoh:\n*${prefix}spotifydl https://open.spotify.com/track/xxxx*`
                );
            }

            const { endpoint, key } = config.apikey;
            const encodedUrl = encodeURIComponent(text);

            let dataResult = null;

            try {
                const api1 = `${endpoint}/api/download/spotify?url=${encodedUrl}&apikey=${key}`;
                const res1 = await axios.get(api1);
                const result1 = res1.data;

                if (result1.status === 200 && result1.data) {
                    dataResult = {
                        title: result1.data.title,
                        artist: result1.data.artist,
                        thumb: result1.data.thumbnail,
                        audioUrl: result1.data.downloadUrl
                    };
                }
            } catch (e) {
                console.log('Primary API gagal, mencoba fallback...');
            }

            if (!dataResult) {
                try {
                    const api2 = `${endpoint}/api/download/spotifyv2?url=${encodedUrl}&apikey=${key}`;
                    const res2 = await axios.get(api2);
                    const result2 = res2.data;

                    if (result2.status === 200 && result2.data && !result2.data.error) {
                        const media = result2.data.medias?.[0];

                        if (!media?.url) throw new Error('Media tidak tersedia');

                        dataResult = {
                            title: result2.data.title,
                            artist: result2.data.author,
                            thumb: result2.data.thumbnail,
                            sourceUrl: result2.data.url,
                            duration: result2.data.duration,
                            audioUrl: media.url
                        };
                    }
                } catch (e) {
                    console.log('Fallback API juga gagal.');
                }
            }

            if (!dataResult) {
                return m.reply('Gagal mendapatkan lagu dari kedua server.');
            }

            await Yudzxml.sendMessage(
                m.chat,
                {
                    audio: { url: dataResult.audioUrl },
                    mimetype: 'audio/mpeg',
                    contextInfo: {
                        mentionedJid: [m.sender],
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.idch || '120363291726836483@newsletter',
                            serverMessageId: 100,
                            newsletterName: config.ownername
                        }
                    }
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan saat memproses lagu Spotify.');
        }
    }
};

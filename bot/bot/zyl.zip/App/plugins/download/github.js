module.exports = {
    name: 'githubdl',
    category: 'download',
    commands: ['githubdl', 'ghdl'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, config, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan URL GitHub.\n\nContoh:\n*${prefix}githubdl https://github.com/user/repo/...*`);
            }

            const { endpoint, key } = config.apikey;

            const downloadUrl = `${endpoint}/api/download/github?url=${encodeURIComponent(text)}&apikey=${key}`;

            const fileName = `github-file-${Date.now()}`;

            const caption = `🐙 *GITHUB DOWNLOAD*

📎 Sumber : GitHub
📤 Mode   : Direct Document

File dikirim tanpa basa-basi.
Ini bukan fetch — ini eksekusi.`;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    document: { url: downloadUrl },
                    fileName,
                    mimetype: 'application/octet-stream',
                    caption
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Gagal mengunduh file GitHub. Bukan error, cuma realita build 🔧');
        }
    }
};

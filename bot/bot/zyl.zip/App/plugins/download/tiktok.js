const axios = require('axios');
const { proto, generateWAMessageFromContent, prepareWAMessageMedia } = require('baileys');

module.exports = {
    name: 'tiktok',
    category: 'download',
    commands: ['tiktok', 'tt'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,

    async execute({ Yudzxml, m, text, config, prefix }) {
        try {
            if (!text || !text.startsWith('http')) {
                return m.reply(`⚠️ Format salah.\n\nContoh:\n*${prefix}tiktok https://vt.tiktok.com/xxxxx*`);
            }

            const { endpoint, key } = config.apikey;

            if (!key) {
                return m.reply('❌ API Key belum dikonfigurasi.');
            }

            const res = await axios.get(`${endpoint}/api/download/tiktok`, {
                params: {
                    apikey: key,
                    url: text
                },
                timeout: 60000
            });

            const result = res.data;

            if (result?.status !== 200 || !result?.data?.success || !result?.data?.data) {
                return m.reply('❌ Gagal mengambil data TikTok. Pastikan link TikTok valid.');
            }

            const data = result.data.data;

            const { type, title, downloadUrl, author, images, videoDuration } = data;

            const authorName = author?.name || author?.username || '-';

            const caption =
                `🎵 *TIKTOK DOWNLOADER*\n\n` +
                `👤 *Author:* ${authorName}\n` +
                `📝 *Title:* ${title || '-'}\n` +
                `📂 *Type:* ${type || '-'}\n` +
                (videoDuration ? `⏱️ *Duration:* ${videoDuration}s` : '');

            if (type === 'carousel' || type === 'photo') {
                if (!Array.isArray(images) || images.length === 0) {
                    return m.reply('❌ Gambar TikTok tidak ditemukan.');
                }

                const imageUrls = images
                    .map((image) => image?.downloadUrl || image?.url || image?.thumbnail)
                    .filter(Boolean);

                if (imageUrls.length === 0) {
                    return m.reply('❌ URL gambar TikTok tidak ditemukan.');
                }

                await m.reply(`${caption}\n\n` + `🖼️ *${imageUrls.length} gambar*\n` + `_Mengirim sebagai album..._`);

                const medias = await Promise.all(
                    imageUrls.map((url) =>
                        prepareWAMessageMedia(
                            {
                                image: {
                                    url
                                }
                            },
                            {
                                upload: Yudzxml.waUploadToServer
                            }
                        )
                    )
                );

                const album = generateWAMessageFromContent(
                    m.chat,
                    {
                        albumMessage: proto.Message.AlbumMessage.fromObject({
                            expectedImageCount: medias.length,
                            caption
                        })
                    },
                    {
                        quoted: m
                    }
                );

                await Yudzxml.relayMessage(m.chat, album.message, {
                    messageId: album.key.id
                });

                for (const media of medias) {
                    const imageMsg = generateWAMessageFromContent(
                        m.chat,
                        {
                            imageMessage: media.imageMessage
                        },
                        {
                            quoted: album
                        }
                    );

                    await Yudzxml.relayMessage(m.chat, imageMsg.message, {
                        messageId: imageMsg.key.id
                    });
                }

                return;
            }

            if (type === 'video') {
                if (!downloadUrl) {
                    return m.reply('❌ URL video TikTok tidak tersedia.');
                }

                await Yudzxml.sendMessage(
                    m.chat,
                    {
                        video: {
                            url: downloadUrl
                        },
                        caption
                    },
                    {
                        quoted: m
                    }
                );

                return;
            }

            return m.reply(`❌ Tipe media TikTok tidak didukung: ${type || 'unknown'}`);
        } catch (err) {
            console.error('[TIKTOK ERROR]', err?.response?.data || err?.message || err);

            return m.reply('⚠️ Terjadi kesalahan saat memproses TikTok.');
        }
    }
};

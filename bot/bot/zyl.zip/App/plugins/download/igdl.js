const axios = require('axios');

const SESSION_EXPIRE = 5 * 60 * 1000;
const igSession = new Map();

function isExpired(session) {
    return Date.now() - session.createdAt > SESSION_EXPIRE;
}

async function getContentType(url) {
    try {
        const response = await axios.head(url, {
            timeout: 10000,
            validateStatus: () => true
        });

        const type = response.headers['content-type'] || '';
        return type;
    } catch (err) {
        console.error('Error checking content-type:', err.message);
        return null;
    }
}

function normalizeItems(result = []) {
    const items = [];

    result.forEach((item, i) => {
        if (!item.url) return;

        items.push({
            type: 'media',
            label: `Media ${i + 1}`,
            url: item.url
        });
    });

    return items;
}

module.exports = {
    name: 'instagram',
    category: 'download',
    commands: ['instagram', 'ig'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, config, prefix }) {
        try {
            if (text && text.startsWith('http')) {
                const { endpoint, key } = config.apikey;
                if (!endpoint || !key) {
                    return m.reply('❌ Konfigurasi API belum lengkap.');
                }

                const res = await axios.get(`${endpoint}/api/download/instagram`, {
                    params: { url: text, apikey: key },
                    timeout: 30000
                });

                const result = res.data;

                if (result.status !== 200 || !result.data) {
                    return m.reply('❌ Gagal mengambil data Instagram. Pastikan link valid.');
                }

                const { result: mediaList } = result.data;
                const firstItem = mediaList[0];

                const captionCreator = firstItem?.creator || '-';

                const thumbnail = firstItem?.thumbnail || 'https://picsum.photos/seed/ig/200/200';

                const items = normalizeItems(mediaList);
                if (!items.length) {
                    return m.reply('📭 Tidak ada media yang bisa diunduh.');
                }

                igSession.set(m.sender, {
                    creator: captionCreator,
                    items,
                    createdAt: Date.now()
                });

                const rows = items.map((item, i) => ({
                    title: item.label,
                    description: '📸 Media Instagram',
                    id: `${prefix}instagram ${i + 1}`
                }));

                return await Yudzxml.sendMessage(
                    m.chat,
                    {
                        image: { url: thumbnail },
                        caption: `📸 *INSTAGRAM DOWNLOADER*

👤 *Creator*
 ${captionCreator}

📂 Pilih media untuk diunduh:
`,
                        footer: '',
                        buttons: [
                            {
                                buttonId: 'ig_select',
                                buttonText: { displayText: '📥 Pilih Media' },
                                type: 4,
                                nativeFlowInfo: {
                                    name: 'single_select',
                                    paramsJson: JSON.stringify({
                                        title: 'ᴄʟɪᴄᴋ ᴛᴏ ᴅᴏᴡɴʟᴏᴀᴅ',
                                        sections: [
                                            {
                                                title: 'ᴍᴇᴅɪᴀ ʟɪꜱᴛ',
                                                rows
                                            }
                                        ]
                                    })
                                }
                            }
                        ],
                        headerType: 4,
                        viewOnce: true,
                        contextInfo: {
                            mentionedJid: [m.sender]
                        }
                    },
                    { quoted: m }
                );
            }

            if (/^\d+$/.test(text)) {
                const session = igSession.get(m.sender);
                if (!session) {
                    return m.reply('❌ Session tidak ditemukan. Kirim ulang link Instagram.');
                }

                if (isExpired(session)) {
                    igSession.delete(m.sender);
                    return m.reply('⏱️ Session kedaluwarsa. Kirim ulang link Instagram.');
                }

                const index = Number(text) - 1;
                const item = session.items[index];
                if (!item) {
                    return m.reply('❌ Pilihan tidak valid.');
                }

                const contentType = await getContentType(item.url);

                const isImage = contentType ? contentType.startsWith('image/') : false;

                if (isImage) {
                    return await Yudzxml.sendMessage(
                        m.chat,
                        {
                            image: { url: item.url },
                            caption: config.mess.success
                        },
                        { quoted: m }
                    );
                } else {
                    return await Yudzxml.sendMessage(
                        m.chat,
                        {
                            video: { url: item.url },
                            caption: config.mess.success
                        },
                        { quoted: m }
                    );
                }
            }

            return m.reply(`⚠️ Format salah.\n\nContoh:\n*${prefix}instagram <url>*`);
        } catch (err) {
            console.error('[INSTAGRAM ERROR]', err?.response?.data || err.message);
            m.reply('⚠️ Instagram sedang sibuk, server API down, atau link tidak valid.');
        }
    }
};

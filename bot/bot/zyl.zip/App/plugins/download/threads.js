const axios = require('axios');

const threadsSession = new Map();

module.exports = {
    name: 'threads',
    category: 'download',
    commands: ['threads'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, config, prefix, command }) {
        try {
            if (text && text.startsWith('http')) {
                const { endpoint, key } = config.apikey;
                if (!endpoint || !key) {
                    return m.reply('❌ Konfigurasi API belum lengkap.');
                }

                const { data } = await axios.get(`${endpoint}/api/download/threads`, {
                    params: {
                        url: text,
                        apikey: key
                    },
                    timeout: 30000
                });

                if (data.status !== 200 || !data.data?.post_detail) {
                    return m.reply('❌ Gagal mengambil data Threads.');
                }

                const { post_detail, user } = data.data;
                const medias = post_detail.media_list || [];

                if (!medias.length) {
                    return m.reply('📭 Media tidak ditemukan.');
                }

                threadsSession.set(m.sender, {
                    medias,
                    post: post_detail,
                    user,
                    createdAt: Date.now()
                });

                const rows = medias.map((media, i) => ({
                    title: `Media ${i + 1}`,
                    description: media.media_type === 1 ? `🖼️ Image ${media.width}x${media.height}` : '🎥 Video',
                    id: `${prefix}threads ${i + 1}`
                }));

                const caption = `🧵 *THREADS DOWNLOAD*

👤 *User*   : ${user.username}
📅 *Publish*: ${post_detail.publish_time}
❤️ *Likes*  : ${post_detail.like_count}

📝 *Caption*
${post_detail.caption_text || '-'}
`;

                return await Yudzxml.sendMessage(
                    m.chat,
                    {
                        image: { url: post_detail.cover_image },
                        caption,
                        footer: '',
                        buttons: [
                            {
                                buttonId: 'threads_select',
                                buttonText: { displayText: '📂 Pilih Media' },
                                type: 4,
                                nativeFlowInfo: {
                                    name: 'single_select',
                                    paramsJson: JSON.stringify({
                                        title: 'ᴄʟɪᴄᴋ ᴛᴏ ᴅᴏᴡɴʟᴏᴀᴅ',
                                        sections: [
                                            {
                                                title: 'ᴍᴇᴅɪᴀ ʟɪꜱᴛ',
                                                rows
                                            }
                                        ]
                                    })
                                }
                            }
                        ],
                        headerType: 4,
                        viewOnce: true,
                        contextInfo: {
                            mentionedJid: [m.sender]
                        }
                    },
                    { quoted: m }
                );
            }

            if (/^\d+$/.test(text)) {
                const session = threadsSession.get(m.sender);
                if (!session) {
                    return m.reply('❌ Session tidak ditemukan. Kirim ulang link Threads.');
                }

                const index = Number(text) - 1;
                const media = session.medias[index];

                if (!media) {
                    return m.reply('❌ Pilihan media tidak valid.');
                }

                const bestMedia = media.version_medias?.[0]?.url || media.url;

                if (media.media_type === 1) {
                    return await Yudzxml.sendMessage(
                        m.chat,
                        {
                            image: { url: bestMedia },
                            caption: `🧵 *THREADS IMAGE*

👤 ${session.user.username}
📐 ${media.width}x${media.height}
`
                        },
                        { quoted: m }
                    );
                }

                return await Yudzxml.sendMessage(
                    m.chat,
                    {
                        video: { url: bestMedia },
                        caption: `🧵 *THREADS VIDEO*

👤 ${session.user.username}
`
                    },
                    { quoted: m }
                );
            }

            return m.reply(`⚠️ Format salah.\n\nContoh:\n*${prefix}threads <url>*`);
        } catch (err) {
            console.error('[THREADS ERROR]', err?.response?.data || err.message);
            m.reply('⚠️ Threads gagal diproses. Coba lagi nanti.');
        }
    }
};

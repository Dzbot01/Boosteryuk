const path = require('path');
const axios = require('axios');

module.exports = {
    name: 'pinterestdl',
    category: 'download',
    commands: ['pinterestdl', 'pindl'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,

    async execute({ Yudzxml, m, text, config, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan URL Pinterest.\n\nContoh:\n*${prefix}pinterestdl https://pin.it/xxxxx*`);
            }

            const { endpoint, key } = config.apikey;

            let mediaUrl = null;
            let thumbnail = null;
            let meta = null;

            const getContentType = async (url) => {
                try {
                    const head = await axios.head(url, { timeout: 10000 });
                    return head.headers['content-type'] || '';
                } catch {
                    return '';
                }
            };

            try {
                const api1 = `${endpoint}/api/download/pinterest?url=${encodeURIComponent(text)}&apikey=${key}`;
                const res1 = await axios.get(api1, { timeout: 15000 });

                if (res1.data?.status === 200 && res1.data?.data?.downloadUrl) {
                    meta = res1.data.data;
                    mediaUrl = res1.data.data.downloadUrl;
                }
            } catch {}

            if (!mediaUrl) {
                try {
                    const api2 = `${endpoint}/api/download/pinterestv3?url=${encodeURIComponent(text)}&apikey=${key}`;
                    const res2 = await axios.get(api2, { timeout: 20000 });

                    const result = res2.data?.data?.result;
                    if (!result) throw new Error('empty');

                    const media = result.media_urls || [];

                    const video =
                        media.find(
                            (v) => v.type === 'video' && (v.url?.includes('.mp4') || v.url?.includes('video'))
                        ) || media.find((v) => v.type === 'video');

                    if (video) {
                        mediaUrl = video.url;
                        thumbnail = video.thumbnail;
                    } else {
                        const image =
                            media.find((i) => i.type === 'image' && i.quality === 'original') ||
                            media.find((i) => i.type === 'image');

                        if (image) mediaUrl = image.url;
                    }
                } catch {}
            }

            if (!mediaUrl) return m.reply('Gagal mengambil media Pinterest.');

            const cleanUrl = mediaUrl.split('?')[0].split('#')[0];
            const ext = path.extname(cleanUrl).toLowerCase();

            const imageExt = ['.jpg', '.jpeg', '.png', '.webp', '.gif'];
            const videoExt = ['.mp4', '.mov', '.mkv', '.webm', '.m3u8'];

            const contentType = await getContentType(mediaUrl);

            const isVideoByHeader = contentType.includes('video');
            const isImageByHeader = contentType.includes('image');

            const caption = meta?.title || config.mess.success || 'Download berhasil';

            const authorText = meta?.author ? `\n\nAuthor: ${meta.author.name} (@${meta.author.username})` : '';

            const isVideo =
                isVideoByHeader || videoExt.includes(ext) || mediaUrl.includes('.mp4') || mediaUrl.includes('video');

            const isImage = isImageByHeader || imageExt.includes(ext) || (!isVideo && mediaUrl.includes('pinimg.com'));

            if (isVideo) {
                return await Yudzxml.sendMessage(
                    m.chat,
                    {
                        video: { url: mediaUrl },
                        gifPlayback: false,
                        caption: caption + authorText,
                        ...(thumbnail
                            ? {
                                  jpegThumbnail: (
                                      await axios.get(thumbnail, {
                                          responseType: 'arraybuffer'
                                      })
                                  ).data
                              }
                            : {})
                    },
                    { quoted: m }
                );
            }

            if (isImage) {
                return await Yudzxml.sendMessage(
                    m.chat,
                    {
                        image: { url: mediaUrl },
                        caption: caption + authorText
                    },
                    { quoted: m }
                );
            }

            return await Yudzxml.sendMessage(
                m.chat,
                {
                    document: { url: mediaUrl },
                    fileName: `pinterest${ext || ''}`,
                    mimetype: contentType || 'application/octet-stream',
                    caption: caption + authorText + '\n\n⚠️ Format media tidak dikenali.'
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Pinterest menolak kerja sama hari ini. Coba link lain.');
        }
    }
};

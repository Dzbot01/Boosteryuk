const axios = require('axios');

const teraboxSession = new Map();

module.exports = {
    name: 'terabox',
    category: 'download',
    commands: ['terabox', 'teraboxdl'],
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, config, prefix, command }) {
        try {
            if (command === 'terabox' && text && text.startsWith('http')) {
                const { endpoint, key } = config.apikey;
                if (!endpoint || !key) {
                    return m.reply('❌ Konfigurasi API belum lengkap.');
                }

                const { data } = await axios.get(`${endpoint}/api/download/terabox`, {
                    params: { url: text, apikey: key },
                    timeout: 30000
                });

                if (data.status !== 200 || !data.data?.files?.length) {
                    return m.reply('❌ File Terabox tidak ditemukan.');
                }

                const { files } = data.data;

                teraboxSession.set(m.sender, {
                    files,
                    createdAt: Date.now()
                });

                const rows = files.map((file, i) => ({
                    title: `${i + 1}. ${file.name}`,
                    description: `📦 ${file.size}`,
                    id: `${prefix}terabox ${i + 1}`
                }));

                return await Yudzxml.sendMessage(
                    m.chat,
                    {
                        text: `📦 *TERABOX DOWNLOADER*

Pilih file yang ingin diunduh.
Session tersimpan khusus untuk Anda.

⏳ Session bersifat sementara.
`,
                        footer: 'X7BOTZ • TERABOX',
                        buttons: [
                            {
                                buttonId: 'terabox_select',
                                buttonText: { displayText: '📂 Pilih File' },
                                type: 4,
                                nativeFlowInfo: {
                                    name: 'single_select',
                                    paramsJson: JSON.stringify({
                                        title: 'ᴄʟɪᴄᴋ ᴛᴏ ᴅᴏᴡɴʟᴏᴀᴅ',
                                        sections: [
                                            {
                                                title: 'ᴍᴇᴅɪᴀ ʟɪꜱᴛ',
                                                rows
                                            }
                                        ]
                                    })
                                }
                            }
                        ],
                        headerType: 1,
                        viewOnce: true
                    },
                    { quoted: m }
                );
            }

            if (text && /^\d+$/.test(text)) {
                const session = teraboxSession.get(m.sender);
                if (!session) {
                    return m.reply('❌ Session tidak ditemukan. Kirim ulang link Terabox.');
                }

                const index = Number(text) - 1;
                const file = session.files[index];

                if (!file) {
                    return m.reply('❌ Pilihan file tidak valid.');
                }

                const isVideo = /\.mp4$/i.test(file.name);

                return await Yudzxml.sendMessage(
                    m.chat,
                    isVideo
                        ? {
                              video: { url: file.download },
                              caption: `📦 *TERABOX DOWNLOAD*

📄 Nama  : ${file.name}
📦 Size  : ${file.size}
`
                          }
                        : {
                              document: { url: file.download },
                              fileName: file.name,
                              caption: `📦 *TERABOX DOWNLOAD*

📄 Nama  : ${file.name}
📦 Size  : ${file.size}
`
                          },
                    { quoted: m }
                );
            }

            return m.reply(`⚠️ Format salah.\n\nContoh:\n*${prefix}terabox <url>*`);
        } catch (err) {
            console.error('[TERABOX ERROR]', err?.response?.data || err.message);
            m.reply('⚠️ Terabox gagal diproses. Coba lagi nanti.');
        }
    }
};

const axios = require('axios');

module.exports = {
    name: 'simfile',
    category: 'download',
    commands: ['simfile', 'simdl'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,

    async execute({ Yudzxml, m, text, config, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan URL Simfile.\n\nContoh:\n*${prefix}simfile https://simfile.co/xxxxx*`);
            }

            const { endpoint, key } = config.apikey;

            const apiUrl = `${endpoint}/api/download/simfile?url=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await axios.get(apiUrl);
            const result = res.data;

            if (result.status !== 200 || !result.data?.downloadUrl) {
                return m.reply('File tidak ditemukan atau link Simfile tidak valid.');
            }

            const { title, filename, mimetype, uploaded, size, downloads, downloadUrl } = result.data;

            const caption = `☁️ *SIMFILE DOWNLOAD*

📄 Judul      : ${title || '-'}
📁 File       : ${filename || '-'}
📦 Ukuran     : ${size || '-'}
⬇️ Downloads  : ${downloads || '0'}
🕒 Upload     : ${uploaded || '-'}
`;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    document: { url: downloadUrl },
                    fileName: filename || title || 'file',
                    mimetype: mimetype || 'application/octet-stream',
                    caption
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Gagal mengunduh file Simfile. Server sehat, mungkin link-nya lagi ngambek.');
        }
    }
};

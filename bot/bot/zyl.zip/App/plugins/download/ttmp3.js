module.exports = {
    name: 'tiktokmp3',
    category: 'download',
    commands: ['ttmp3', 'tiktokmp3'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,

    async execute({ Yudzxml, m, text, config, fetchJson, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan URL TikTok.\n\nContoh:\n*${prefix}ttmp3 https://vt.tiktok.com/...*`);
            }

            const { endpoint, key } = config.apikey;
            const apiUrl = `${endpoint}/api/download/tiktok?url=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await fetchJson(apiUrl);

            if (!res.status || !res.data) {
                return m.reply('Data tidak ditemukan.');
            }

            const { title, downloads, videos } = res.data;

            let audioLink = null;

            if (downloads && downloads.length) {
                audioLink =
                    downloads.find((v) => v.label?.toLowerCase().includes('mp3'))?.link ||
                    downloads.find((v) => v.label?.toLowerCase().includes('audio'))?.link;
            }

            if (!audioLink && videos && videos.length) {
                if (videos[0].link && videos[0].link !== '#') {
                    audioLink = videos[0].link;
                }
            }

            if (!audioLink || audioLink === '#') {
                return m.reply('Audio tidak tersedia pada konten ini.');
            }

            await Yudzxml.sendMessage(
                m.chat,
                {
                    audio: { url: audioLink },
                    mimetype: 'audio/mpeg',
                    fileName: `${title || 'tiktok-audio'}.mp3`
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Gagal memproses audio TikTok.');
        }
    }
};

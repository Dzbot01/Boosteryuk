const axios = require('axios');

module.exports = {
    name: 'telesticker',
    category: 'download',
    commands: ['telesticker', 'tgs', 'stickertele'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, config, prefix }) {
        try {
            if (!text) {
                return m.reply(
                    `Masukkan link Sticker Telegram untuk didownload.\n\nContoh:\n*${prefix}telesticker https://t.me/addstickers/dinokuwu*`
                );
            }

            const { endpoint, key } = config.apikey;

            const apiUrl = `${endpoint}/api/download/telesticker?url=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await axios.get(apiUrl);
            const result = res.data;

            if (result.status !== 200 || !result.data || !result.data.stickers) {
                return m.reply('Gagal mendapatkan data stiker. Pastikan link valid atau API key benar.');
            }

            const data = result.data;
            const stickerList = data.stickers;

            for (let i = 0; i < stickerList.length; i++) {
                try {
                    const stickerUrl = stickerList[i];

                    await Yudzxml.sendImageAsSticker(m.chat, stickerUrl, m, {
                        packname: Yudzxml.identity.packname,
                        author: Yudzxml.identity.author
                    });

                    await new Promise((resolve) => setTimeout(resolve, 800));
                } catch (sendError) {
                    console.error(`Gagal mengirim stiker ke-${i + 1}:`, sendError);
                }
            }

            await m.reply(`✅ Selesai! Berhasil mengirim ${stickerList.length} stiker.`);
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan saat memproses link Telegram Sticker.');
        }
    }
};

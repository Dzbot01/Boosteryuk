const axios = require('axios');

module.exports = {
    name: 'soundclouddl',
    category: 'download',
    commands: ['soundclouddl', 'scdl'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,

    async execute({ Yudzxml, m, text, config, prefix }) {
        try {
            if (!text) {
                return m.reply(
                    `Isi link SoundCloud dulu, jangan kosong kayak hidup kamu.\n\nContoh:\n${prefix}scdl https://soundcloud.com/user/track`
                );
            }

            const { endpoint, key } = config.apikey;

            const apiUrl = `${endpoint}/api/download/soundcloud?url=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await axios.get(apiUrl);
            const json = res.data;

            if (json.status !== 200 || !json.data?.downloadUrl) {
                return m.reply('Gagal ambil audio. Link atau API kamu mungkin lagi rewel.');
            }

            const data = json.data;

            const cleanName = (data.fileName || data.title || 'soundcloud_audio')
                .replace(/[^a-zA-Z0-9_-]/g, '_')
                .slice(0, 60);

            const sizeMB = data.size ? (data.size / (1024 * 1024)).toFixed(2) + ' MB' : 'Unknown';

            const duration = data.duration
                ? `${Math.floor(data.duration / 60)}:${String(Math.floor(data.duration % 60)).padStart(2, '0')}`
                : 'Unknown';

            await Yudzxml.sendMessage(
                m.chat,
                {
                    audio: { url: data.downloadUrl },
                    mimetype: 'audio/mpeg',
                    fileName: `${cleanName}.mp3`,

                    contextInfo: {
                        mentionedJid: [m.sender],
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.idch || '120363291726836483@newsletter',
                            serverMessageId: 100,
                            newsletterName: config.ownername
                        }
                    }
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Error. Entah API kamu yang tumbang atau SoundCloud-nya yang drama.');
        }
    }
};

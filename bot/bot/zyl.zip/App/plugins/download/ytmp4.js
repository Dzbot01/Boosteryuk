const FORMATS = ['144', '240', '360', '480', '720', '1080'];

function extractVideoId(url = '') {
    const regex = /(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|shorts\/|embed\/))([^&?/]+)/i;
    return url.match(regex)?.[1] || null;
}

function secToTime(sec) {
    sec = Number(sec || 0);

    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;

    if (h > 0) {
        return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    }

    return `${m}:${String(s).padStart(2, '0')}`;
}

module.exports = {
    name: 'ytmp4',
    category: 'download',
    commands: ['ytmp4'],
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,

    async execute({ Yudzxml, m, text, prefix, config, fetchJson }) {
        try {
            if (!text) {
                return m.reply(`Masukkan link YouTube\n\nContoh:\n${prefix}ytmp4 https://youtu.be/xxxx`);
            }

            const args = text.trim().split(/\s+/);
            const url = args[0];
            const quality = args[1];
            const apiKey = config?.apikey?.key || '';

            if (!extractVideoId(url)) {
                return m.reply('Link YouTube tidak valid');
            }

            if (!quality) {
                const rows = FORMATS.map((q) => ({
                    title: `${q}p`,
                    description: `Download video kualitas ${q}p`,
                    id: `${prefix}ytmp4 ${url} ${q}`
                }));

                return await Yudzxml.sendMessage(
                    m.chat,
                    {
                        image: {
                            url: `https://i.ytimg.com/vi/${extractVideoId(url)}/hqdefault.jpg`
                        },
                        caption: `🎬 *YOUTUBE MP4 DOWNLOADER*

📌 Link valid terdeteksi
📂 Pilih kualitas video yang kamu mau.
Karena mengetik manual itu rupanya terlalu berat.`,
                        footer: '',
                        buttons: [
                            {
                                buttonId: 'ytmp4_select',
                                buttonText: { displayText: 'ᴘɪʟɪʜ ʀᴇꜱᴏʟᴜꜱɪ' },
                                type: 4,
                                nativeFlowInfo: {
                                    name: 'single_select',
                                    paramsJson: JSON.stringify({
                                        title: 'ᴘɪʟɪʜ ʀᴇꜱᴏʟᴜꜱɪ',
                                        sections: [
                                            {
                                                title: 'Format MP4',
                                                rows
                                            }
                                        ]
                                    })
                                }
                            }
                        ],
                        headerType: 4,
                        viewOnce: true
                    },
                    { quoted: m }
                );
            }

            if (!FORMATS.includes(quality)) {
                return m.reply(`Format tersedia: ${FORMATS.join(', ')}p`);
            }

            const api = `https://api.yydz.biz.id/api/download/youtube?url=${encodeURIComponent(url)}&format=${quality}&apikey=${apiKey}`;

            const res = await fetchJson(api, { retries: 4, retryDelay: 2000, timeout: 25000 });
            const data = res?.data;

            if (!data?.download) {
                return m.reply('Link download tidak ditemukan');
            }

            await Yudzxml.sendMessage(
                m.chat,
                {
                    video: { url: data.download },
                    mimetype: 'video/mp4',
                    caption: `🎬 *${data.title || 'YouTube Video'}*

📺 Quality: ${data.quality || quality}p
⏱️ Durasi: ${secToTime(data.duration)}
🆔 ID: ${data.id || '-'}`
                },
                { quoted: m }
            );
        } catch (err) {
            console.log(err);
            m.reply('Gagal download video. Server kadang bertingkah, seperti biasa.');
        }
    }
};

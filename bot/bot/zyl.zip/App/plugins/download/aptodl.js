module.exports = {
    name: 'aptodl',
    category: 'download',
    commands: ['aptodl'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, config, fetchJson }) {
        try {
            if (!text) {
                return m.reply('Masukkan *package id* aplikasi.\nContoh:\n*aptodl me.pou.app*');
            }

            const { endpoint, key } = config.apikey;
            const url = `${endpoint}/api/download/aptoide?id=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await fetchJson(url);
            if (!res.status || !res.data) {
                return m.reply('Gagal mengambil data APK. Aplikasinya mungkin sedang cuti 💤');
            }

            const { img, developer, appname, link } = res.data;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: img },
                    caption:
                        `📦 *APTOIDE APK*\n\n` +
                        `📱 App Name : *${appname}*\n` +
                        `👨‍💻 Developer : *${developer}*\n` +
                        `📦 Package : *${text}*\n\n` +
                        `⬇️ APK sedang dikirim, mohon tidak panik.`
                },
                { quoted: m }
            );

            await Yudzxml.sendMessage(
                m.chat,
                {
                    document: { url: link },
                    fileName: `${appname}.apk`,
                    mimetype: 'application/vnd.android.package-archive'
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan teknis. Bukan salah kamu, servernya sedang merenung 😄');
        }
    }
};

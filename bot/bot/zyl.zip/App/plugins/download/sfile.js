const axios = require('axios');

module.exports = {
    name: 'sfile',
    category: 'download',
    commands: ['sfile', 'sfdl'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,

    async execute({ Yudzxml, m, text, config, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan URL Sfile.\n\nContoh:\n*${prefix}sfile https://sfile.co/xxxxx*`);
            }

            const { endpoint, key } = config.apikey;

            const apiUrl = `${endpoint}/api/download/sfile?url=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await axios.get(apiUrl);
            const result = res.data;

            if (result.status !== 200 || !result.data?.downloadUrl) {
                return m.reply('File tidak ditemukan atau link Sfile tidak valid.');
            }

            const { title, size, creator, category, upload_date, mimetype, downloadUrl } = result.data;

            const caption = `☁️ *SFILE DOWNLOAD*

📄 Judul   : ${title}
📦 Ukuran  : ${size}
👤 Creator : ${creator}
🗂️ Kategori: ${category}
🕒 Upload  : ${upload_date}
`;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    document: { url: downloadUrl },
                    fileName: title,
                    mimetype,
                    caption
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Gagal mengunduh file Sfile. Server waras, link-nya yang bandel.');
        }
    }
};

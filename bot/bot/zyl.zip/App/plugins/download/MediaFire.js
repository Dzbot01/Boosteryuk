const axios = require('axios');

module.exports = {
    name: 'mediafire',
    category: 'download',
    commands: ['mediafire', 'mfdl'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, config, prefix }) {
        try {
            if (!text) {
                return m.reply(
                    `Masukkan URL MediaFire.\n\nContoh:\n*${prefix}mediafiredl https://www.mediafire.com/file/xxxx/file.js*`
                );
            }

            const { endpoint, key } = config.apikey;

            const apiUrl = `${endpoint}/api/download/mediafire?url=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await axios.get(apiUrl);
            const result = res.data;

            if (result.status !== 200 || !result.data?.downloadUrl) {
                return m.reply('File tidak ditemukan atau link MediaFire tidak valid.');
            }

            const { name, size, type, location, date, downloadUrl } = result.data;

            const caption = `☁️ *MEDIAFIRE DOWNLOAD*

📄 Nama   : ${name}
📦 Ukuran : ${size}
🗂️ Tipe   : ${type}
🌍 Lokasi : ${location}
🕒 Update : ${date}

File dikirim langsung.
Tidak dikompres. Tidak diperas. Tidak PHP.`;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    document: { url: downloadUrl },
                    fileName: name,
                    mimetype: 'application/octet-stream',
                    caption
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Gagal mengunduh file MediaFire. Server sehat, link-nya yang lelah.');
        }
    }
};

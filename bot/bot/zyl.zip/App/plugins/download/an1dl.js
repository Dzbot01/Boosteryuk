module.exports = {
    name: 'an1dl',
    category: 'download',
    commands: ['an1dl'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, config, fetchJson, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan URL game AN1.\n\nContoh:\n*${prefix}an1dl https://an1.com/...*`);
            }

            const { endpoint, key } = config.apikey;
            const apiUrl = `${endpoint}/api/download/an1?url=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await fetchJson(apiUrl);
            if (!res.status || !res.data) {
                return m.reply('File tidak ditemukan. Mungkin link-nya pensiun dini 🧓');
            }

            const { title, imageUrl, version, downloadUrl } = res.data;

            if (!downloadUrl) {
                return m.reply('Link download tidak tersedia. Server lagi ngopi ☕');
            }

            const caption = `📦 *AN1 APK DOWNLOAD*

📄 Nama File : ${title || 'Unknown.apk'}
📱 Support   : ${version || '-'}

⏳ File sedang dikirim sebagai dokumen.
Mohon tunggu, bukan loading… tapi serius kerja.`;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    document: { url: downloadUrl },
                    mimetype: 'application/vnd.android.package-archive',
                    fileName: title || 'an1-app.apk',
                    caption
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Gagal mengirim APK. Bukan error fatal, cuma nasib belum sinkron 🔧');
        }
    }
};

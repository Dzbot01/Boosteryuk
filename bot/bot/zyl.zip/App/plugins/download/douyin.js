module.exports = {
    name: 'douyindl',
    category: 'download',
    commands: ['douyindl'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, config, fetchJson, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan URL Douyin.\n\nContoh:\n*${prefix}douyindl https://v.douyin.com/...*`);
            }

            const { endpoint, key } = config.apikey;
            const apiUrl = `${endpoint}/api/download/douyin?url=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await fetchJson(apiUrl);
            if (!res.status || !res.data) {
                return m.reply('Video tidak ditemukan. Douyin-nya mungkin lagi cuti 🧳');
            }

            const data = res.data;
            const medias = data.medias || [];

            if (!medias.length) {
                return m.reply('Media kosong. Editor-nya mungkin lupa export 🎬');
            }

            const video =
                medias.find((v) => v.extension === 'mp4' && /original/i.test(v.quality)) ||
                medias.find((v) => v.extension === 'mp4' && /hd/i.test(v.quality)) ||
                medias.find((v) => v.extension === 'mp4' && /sd/i.test(v.quality)) ||
                medias.find((v) => v.extension === 'mp4');

            if (!video?.url) {
                return m.reply('Link video tidak tersedia. Server lagi meditasi 🧘');
            }

            const caption = `🎥 *DOUYIN VIDEO DOWNLOAD*

📝 Judul   : ${data.title || '-'}
⏱️ Durasi  : ${data.duration || '-'}
📦 Kualitas: ${video.quality || '-'}
📁 Ukuran  : ${video.formattedSize || '-'}
`;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    video: { url: video.url },
                    mimetype: 'video/mp4',
                    caption
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Gagal mengunduh video Douyin. Bukan error fatal, hanya timing belum jodoh 🔧');
        }
    }
};

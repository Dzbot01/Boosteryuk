module.exports = {
    name: 'fdroiddl',
    category: 'download',
    commands: ['fdroiddl'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,

    async execute({ Yudzxml, m, text, config, fetchJson, prefix }) {
        try {
            if (!text) {
                return m.reply(
                    `Masukkan URL halaman F-Droid.\nContoh:\n*${prefix}fdroiddl https://f-droid.org/id/packages/com.termux.styling*`
                );
            }

            const { endpoint, key } = config.apikey;
            const url = `${endpoint}/api/search/fdroid?url=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await fetchJson(url);

            if (res.status !== 200 || !res.data?.latest?.download) {
                return m.reply('APK tidak ditemukan.');
            }

            const data = res.data;
            const latest = data.latest;
            const apkUrl = latest.download;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    document: { url: apkUrl },
                    mimetype: 'application/vnd.android.package-archive',
                    fileName: `${data.title.replace(/[^\w\s]/gi, '')}.apk`,
                    caption:
                        `📱 *${data.title}*\n\n` +
                        `📝 ${data.summary}\n\n` +
                        `📦 ${latest.version}\n` +
                        `📅 ${latest.added}\n` +
                        `📏 ${latest.size}\n\n` +
                        `Android: ${latest.requirement}`
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Terjadi error saat mengambil APK dari F-Droid.');
        }
    }
};

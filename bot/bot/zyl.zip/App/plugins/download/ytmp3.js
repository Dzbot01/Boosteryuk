const axios = require('axios');

module.exports = {
    name: 'ytmp3',
    category: 'download',
    commands: ['ytmp3', 'ytaudio'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,

    async execute({ Yudzxml, m, text, config, prefix, fetchJson }) {
        try {
            if (!text || !text.startsWith('http')) {
                return m.reply(`Masukkan link YouTube.\n\nContoh:\n*${prefix}ytmp3 https://youtube.com/watch?v=xxxx*`);
            }

            const { endpoint, key } = config.apikey;

            let downloadUrl = null;
            let title = 'audio';

            try {
                const res = await fetchJson(
                    `${endpoint}/api/download/youtubev5?url=${encodeURIComponent(text)}&apikey=${key}`
                );

                if (res?.status === 200 && Array.isArray(res.data?.resources)) {
                    const audio = res.data.resources
                        .filter((v) => v.type === 'audio' && v.format?.toUpperCase() === 'MP3' && v.download_url)
                        .sort((a, b) => (parseInt(b.quality) || 0) - (parseInt(a.quality) || 0))[0];

                    if (audio) {
                        downloadUrl = audio.download_url;
                        title = res.data.title;
                    }
                }
            } catch {}

            if (!downloadUrl) {
                try {
                    const res = await fetchJson(
                        `${endpoint}/api/download/youtube?url=${encodeURIComponent(text)}&format=mp3&apikey=${key}`
                    );

                    if (res?.status === 200 && res.data?.download) {
                        downloadUrl = res.data.download;
                        title = res.data.title;
                    }
                } catch {}
            }

            if (!downloadUrl) {
                return m.reply('❌ Semua server download sedang gagal.');
            }

            await Yudzxml.sendMessage(
                m.chat,
                {
                    audio: { url: downloadUrl },
                    mimetype: 'audio/mpeg',
                    fileName: `${title}.mp3`,
                    contextInfo: {
                        mentionedJid: [m.sender],
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.idch || '120363291726836483@newsletter',
                            serverMessageId: 100,
                            newsletterName: config.ownername
                        }
                    }
                },
                { quoted: m }
            );
        } catch (err) {
            console.error('[YTMP3 ERROR]', err);
            m.reply('❌ Gagal mengambil audio.');
        }
    }
};

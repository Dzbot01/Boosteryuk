module.exports = {
    name: 'ttslide',
    category: 'download',
    commands: ['ttslide', 'tiktokimage'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,

    async execute({ Yudzxml, m, text, config, fetchJson, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan URL TikTok.\n\nContoh:\n*${prefix}ttslide https://vt.tiktok.com/...*`);
            }

            const { endpoint, key } = config.apikey;
            const apiUrl = `${endpoint}/api/download/tiktok?url=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await fetchJson(apiUrl);

            if (!res.status || !res.data) {
                return m.reply('Data tidak ditemukan. Mungkin link-nya lagi liburan 🏖️');
            }

            const { title, images } = res.data;

            if (!images || !images.length) {
                return m.reply('Slide tidak ditemukan. Ini sepertinya tipe video biasa 🎥');
            }

            const album = images.map((img, i) => ({
                image: { url: img },
                caption:
                    i === 0
                        ? `${config.mess.success}\n\n📝 ${title || 'Tanpa Judul'}\n\nTotal Slide: ${images.length}`
                        : ''
            }));

            await Yudzxml.sendMessage(m.chat, { album }, { quoted: m });
        } catch (err) {
            console.error(err);
            m.reply('Gagal mengambil slide TikTok. Server lagi mikir keras 🤖');
        }
    }
};

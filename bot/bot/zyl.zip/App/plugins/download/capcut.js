module.exports = {
    name: 'capcut',
    category: 'download',
    commands: ['capcut'],
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, config, fetchJson, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan URL CapCut.\n\nContoh:\n*${prefix}capcutdl https://www.capcut.com/...*`);
            }

            const { endpoint, key } = config.apikey;
            const apiUrl = `${endpoint}/api/download/capcut?url=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await fetchJson(apiUrl);
            if (!res.status || !res.data || res.data.error) {
                return m.reply('Video tidak ditemukan. Mungkin link-nya sudah move on 😌');
            }

            const data = res.data;
            const medias = data.medias || [];

            if (!medias.length) {
                return m.reply('Media kosong. Editor CapCut-nya mungkin lagi cut cut cut ✂️');
            }

            const video =
                medias.find((v) => /HD No Watermark/i.test(v.quality)) ||
                medias.find((v) => /No Watermark/i.test(v.quality)) ||
                medias[0];

            if (!video?.url) {
                return m.reply('Link video tidak tersedia. Server lagi mikir keras 🧠');
            }

            const caption = `🎬 *CAPCUT VIDEO DOWNLOAD*

👤 Creator   : ${data.author || '-'}
🆔 Username  : ${data.unique_id || '-'}
📝 Judul     : ${data.title || '-'}
⏱️ Durasi    : ${data.duration ? `${(data.duration / 1000).toFixed(1)}s` : '-'}

📤 Video dikirim tanpa watermark (jika tersedia).
Santai saja, ini bukan buffering—ini profesional.`;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    video: { url: video.url },
                    mimetype: 'video/mp4',
                    caption
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Gagal mengunduh video CapCut. Bukan bug, cuma semesta belum sejalan 🛠️');
        }
    }
};

module.exports = {
    name: 'gdrive',
    category: 'download',
    commands: ['gdrivedl', 'gdrive'],
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, config, fetchJson, prefix }) {
        try {
            if (!text) {
                return m.reply(
                    `Masukkan URL Google Drive.\n\nContoh:\n*${prefix}gdrivedl https://drive.google.com/file/d/...*`
                );
            }

            const { endpoint, key } = config.apikey;
            const apiUrl = `${endpoint}/api/download/gdrive?url=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await fetchJson(apiUrl);
            if (!res.status || !res.data) {
                return m.reply('File tidak ditemukan. Mungkin akses Drive-nya sudah dikunci 🔒');
            }

            const { fileName, fileSize, downloadUrl } = res.data;

            if (!downloadUrl) {
                return m.reply('Link download tidak tersedia. Google Drive lagi tarik napas 🧘');
            }

            const caption = `☁️ *GOOGLE DRIVE DOWNLOAD*

📄 Nama File : ${fileName || 'unknown-file'}
📦 Ukuran    : ${fileSize || '-'}

📤 File sedang dikirim sebagai dokumen.
Tenang, ini bukan delay—ini Google yang teliti.`;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    document: { url: downloadUrl },
                    fileName: fileName || 'gdrive-file',
                    mimetype: 'application/octet-stream',
                    caption
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Gagal mengunduh file Google Drive. Bukan rusak, cuma semesta belum sinkron 🔧');
        }
    }
};

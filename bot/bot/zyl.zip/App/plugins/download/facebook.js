module.exports = {
    name: 'facebook',
    category: 'download',
    commands: ['fb', 'facebook'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, config, fetchJson, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan URL Facebook Video.\n\nContoh:\n*${prefix}fbdl https://www.facebook.com/...*`);
            }

            const { endpoint, key } = config.apikey;
            const apiUrl = `${endpoint}/api/download/facebook?url=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await fetchJson(apiUrl);
            if (!res.status || !res.data || !Array.isArray(res.data.videos)) {
                return m.reply('Video tidak ditemukan. Mungkin privasi FB lagi sensitif 🤐');
            }

            const videos = res.data.videos;
            if (!videos.length) {
                return m.reply('List video kosong. FB lagi hemat bandwidth 📉');
            }

            const priority = ['1080', '720', '640', '540', '480', '360'];

            let selected = null;
            for (const q of priority) {
                selected = videos.find((v) => v.quality.includes(q));
                if (selected) break;
            }

            if (!selected) selected = videos[0];

            if (!selected?.url) {
                return m.reply('Link video tidak tersedia. CDN FB lagi mikir panjang 🤯');
            }

            const caption = `📘 *FACEBOOK VIDEO DOWNLOAD*

🎞️ Kualitas : ${selected.quality || '-'}
📤 Status   : Mengirim video

Tenang, ini bukan re-upload.
Ini eksekusi bersih dan efisien.`;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    video: { url: selected.url },
                    mimetype: 'video/mp4',
                    caption
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Gagal mengunduh video Facebook. Bukan error, cuma algoritma lagi galak 🔧');
        }
    }
};

const axios = require('axios');

module.exports = {
    name: 'snackvideo',
    category: 'download',
    commands: ['snackvideo', 'snackdl'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, config, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan URL SnackVideo.\n\nContoh:\n*${prefix}snackvideo https://sck.io/xxxxx*`);
            }

            const { endpoint, key } = config.apikey;

            const apiUrl = `${endpoint}/api/download/snackvideo?url=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await axios.get(apiUrl);
            const result = res.data;

            if (result.status !== 200 || !result.data) {
                return m.reply('Gagal mengambil media dari SnackVideo.');
            }

            const { url, title, thumbnail, videoUrl, duration, interaction, creator } = result.data;

            const caption = `📌 *SNACK VIDEO DOWNLOAD*

🏷️ *Judul* : ${title || 'Tidak ada judul'}
👤 *Creator*: ${creator.name || 'Unknown'}
🔗 *Link* : ${url}
⏱️ *Durasi* : ${duration || 'Unknown'}

👁️ *Views* : ${interaction?.views?.toLocaleString() || 0}
❤️ *Likes* : ${interaction?.likes?.toLocaleString() || 0}
🔄 *Shares* : ${interaction?.shares?.toLocaleString() || 0}
📝 *Bio* : ${creator?.bio || '-'}
`;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    video: { url: videoUrl },
                    caption: caption,
                    gifPlayback: false
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('SnackVideo sedang sibuk atau link tidak valid. Coba lagi nanti.');
        }
    }
};

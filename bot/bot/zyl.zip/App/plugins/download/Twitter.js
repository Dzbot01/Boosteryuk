const axios = require('axios');

const SESSION_EXPIRE = 5 * 60 * 1000;
const twitterSession = new Map();

function isExpired(session) {
    return Date.now() - session.createdAt > SESSION_EXPIRE;
}

module.exports = {
    name: 'twitter',
    category: 'download',
    commands: ['twitter', 'xdl'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, config, prefix }) {
        try {
            if (text && text.startsWith('http')) {
                const { endpoint, key } = config.apikey;
                if (!endpoint || !key) {
                    return m.reply('❌ Konfigurasi API belum lengkap.');
                }

                const res = await axios.get(`${endpoint}/api/download/twitter`, {
                    params: {
                        url: text,
                        apikey: key
                    },
                    timeout: 30000
                });

                const result = res.data;
                if (result.status !== 200 || !Array.isArray(result.data)) {
                    return m.reply('❌ Gagal mengambil media Twitter.');
                }

                if (!result.data.length) {
                    return m.reply('📭 Video tidak ditemukan.');
                }

                twitterSession.set(m.sender, {
                    videos: result.data,
                    createdAt: Date.now()
                });

                const rows = result.data.map((v, i) => ({
                    title: v.quality || `Quality ${i + 1}`,
                    description: '🎥 Video Twitter',
                    id: `${prefix}twitter ${i + 1}`
                }));

                return await Yudzxml.sendMessage(
                    m.chat,
                    {
                        text: `🐦 *TWITTER (X) DOWNLOADER*

📂 Pilih kualitas video yang ingin diunduh:
`,
                        footer: '',
                        buttons: [
                            {
                                buttonId: 'tw_select',
                                buttonText: { displayText: '📥 Pilih Kualitas' },
                                type: 4,
                                nativeFlowInfo: {
                                    name: 'single_select',
                                    paramsJson: JSON.stringify({
                                        title: 'ᴄʟɪᴄᴋ ᴛᴏ ᴅᴏᴡɴʟᴏᴀᴅ',
                                        sections: [
                                            {
                                                title: 'ᴍᴇᴅɪᴀ ʟɪꜱᴛ',
                                                rows
                                            }
                                        ]
                                    })
                                }
                            }
                        ],
                        headerType: 1,
                        viewOnce: true,
                        contextInfo: {
                            mentionedJid: [m.sender]
                        }
                    },
                    { quoted: m }
                );
            }

            if (/^\d+$/.test(text)) {
                const session = twitterSession.get(m.sender);
                if (!session) {
                    return m.reply('❌ Session tidak ditemukan. Kirim ulang link Twitter.');
                }

                if (isExpired(session)) {
                    twitterSession.delete(m.sender);
                    return m.reply('⏱️ Session kedaluwarsa. Kirim ulang link Twitter.');
                }

                const index = Number(text) - 1;
                const video = session.videos[index];
                if (!video) {
                    return m.reply('❌ Pilihan kualitas tidak valid.');
                }

                return await Yudzxml.sendMessage(
                    m.chat,
                    {
                        video: { url: video.url },
                        caption: config.mess.success
                    },
                    { quoted: m }
                );
            }

            return m.reply(`⚠️ Format salah.\n\nContoh:\n*${prefix}twitter <url>*`);
        } catch (err) {
            console.error('[TWITTER ERROR]', err?.response?.data || err.message);
            m.reply('⚠️ Twitter sedang sibuk atau link tidak valid.');
        }
    }
};

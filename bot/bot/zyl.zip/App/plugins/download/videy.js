const axios = require('axios');

const SESSION_EXPIRE = 5 * 60 * 1000;
const videySession = new Map();

function isExpired(session) {
    return Date.now() - session.createdAt > SESSION_EXPIRE;
}

function normalizeVideyLinks(linkString) {
    if (!linkString) return [];

    return linkString
        .split(/\s+/)
        .filter((v) => v.startsWith('http'))
        .map((url, i) => ({
            type: 'video',
            label: `Video ${i + 1}`,
            url
        }));
}

module.exports = {
    name: 'videy',
    category: 'download',
    commands: ['videy'],
    isPremium: true,
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, config, prefix }) {
        try {
            if (text && text.startsWith('http')) {
                const { endpoint, key } = config.apikey;
                if (!endpoint || !key) {
                    return m.reply('❌ Konfigurasi API belum lengkap.');
                }

                const res = await axios.get(`${endpoint}/api/download/videy`, {
                    params: { url: text, apikey: key },
                    timeout: 30000
                });

                const result = res.data;
                if (result.status !== 200 || !result.data) {
                    return m.reply('❌ Gagal mengambil data Videy.');
                }

                const { mimeType, link } = result.data;
                const items = normalizeVideyLinks(link);

                if (!items.length) {
                    return m.reply('📭 Tidak ada video yang bisa diunduh.');
                }

                if (items.length === 1) {
                    return await Yudzxml.sendMessage(
                        m.chat,
                        {
                            video: { url: items[0].url },
                            mimetype: mimeType || 'video/mp4',
                            caption: config.mess.success
                        },
                        { quoted: m }
                    );
                }

                videySession.set(m.sender, {
                    items,
                    mimeType: mimeType || 'video/mp4',
                    createdAt: Date.now()
                });

                let caption = `🎬 *VIDEY DOWNLOADER*\n\n`;
                caption += `📦 Ditemukan *${items.length}* video\n`;
                caption += `📌 Pilih dengan membalas *angka*\n\n`;

                items.forEach((item, i) => {
                    caption += `*${i + 1}.* ${item.label}\n`;
                });

                caption += `\nContoh: kirim *1*`;

                return m.reply(caption);
            }

            if (/^\d+$/.test(text)) {
                const session = videySession.get(m.sender);
                if (!session) {
                    return m.reply('❌ Session tidak ditemukan. Kirim ulang link Videy.');
                }

                if (isExpired(session)) {
                    videySession.delete(m.sender);
                    return m.reply('⏱️ Session kedaluwarsa. Kirim ulang link Videy.');
                }

                const index = Number(text) - 1;
                const item = session.items[index];
                if (!item) {
                    return m.reply('❌ Pilihan tidak valid.');
                }

                await Yudzxml.sendMessage(
                    m.chat,
                    {
                        video: { url: item.url },
                        mimetype: session.mimeType,
                        caption: `🎥 *VIDEY VIDEO*\n\n${item.label}`
                    },
                    { quoted: m }
                );

                return;
            }

            return m.reply(`⚠️ Format salah.\n\nContoh:\n*${prefix}videy <url>*`);
        } catch (err) {
            console.error('[VIDEY ERROR]', err?.response?.data || err.message);
            m.reply('⚠️ Videy sedang sibuk atau link tidak valid.');
        }
    }
};

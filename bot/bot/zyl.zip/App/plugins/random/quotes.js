const axios = require('axios');

module.exports = {
    name: 'quotes',
    category: 'random',
    commands: ['quotes'],
    isOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ m, config }) {
        try {
            const { endpoint, key } = config.apikey;
            const apiUrl = `${endpoint}/api/random/quotes?apikey=${key}`;

            const res = await axios.get(apiUrl);
            const result = res.data;

            if (!result || result.status !== 200 || !result.data || !result.data.quotes) {
                return m.reply('❌ Quotes tidak tersedia.');
            }

            const { quotes, author } = result.data;

            const message = `💬 *Random Quotes*

"${quotes}"

— *${author || 'Unknown'}*
`;

            m.reply(message);
        } catch (err) {
            console.error('[QUOTES ERROR]', err);
            m.reply('⚠️ Terjadi kesalahan saat mengambil quotes.');
        }
    }
};

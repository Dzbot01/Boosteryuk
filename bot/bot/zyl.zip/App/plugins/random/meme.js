const axios = require('axios');

module.exports = {
    name: 'meme',
    category: 'random',
    commands: ['meme'],
    isOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ m, config, Yudzxml }) {
        try {
            const { endpoint, key } = config.apikey;
            const apiUrl = `${endpoint}/api/random/meme?apikey=${key}`;

            const res = await axios.get(apiUrl);
            const result = res.data;

            if (!result || result.status !== 200 || !result.data) {
                return m.reply('❌ Meme tidak tersedia saat ini.');
            }

            const imageUrl = result.data;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: imageUrl },
                    caption: '🤣 *Random Meme*\n\nKetawa sebentar, hidup lanjut.'
                },
                { quoted: m }
            );
        } catch (err) {
            console.error('[MEME ERROR]', err);
            m.reply('⚠️ Terjadi kesalahan saat mengambil meme.');
        }
    }
};

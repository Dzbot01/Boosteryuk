const axios = require('axios');

module.exports = {
    name: 'ppcp',
    category: 'random',
    commands: ['ppcp', 'ppcouple'],
    isOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ m, config, Yudzxml }) {
        try {
            const { endpoint, key } = config.apikey;
            const apiUrl = `${endpoint}/api/random/ppcp?apikey=${key}`;

            const res = await axios.get(apiUrl);
            const result = res.data;

            if (!result || result.status !== 200 || !result.data || !result.data.male || !result.data.female) {
                return m.reply('❌ Gagal mengambil PPCP.');
            }

            const { male, female } = result.data;

            const media = [{ image: { url: male } }, { image: { url: female } }];

            await Yudzxml.sendMessage(m.chat, { album: media, caption: 'PP COUPLE 💫' }, { quoted: m });
        } catch (err) {
            console.error('[PPCP ERROR]', err);
            m.reply('⚠️ Terjadi kesalahan saat mengambil PPCP.');
        }
    }
};

const axios = require('axios');

module.exports = {
    name: 'quotesanime',
    category: 'random',
    commands: ['quotesanime'],
    isOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ m, config, Yudzxml }) {
        try {
            const { endpoint, key } = config.apikey;
            const apiUrl = `${endpoint}/api/random/quotesanime?apikey=${key}`;

            const res = await axios.get(apiUrl);
            const result = res.data;

            if (!result || result.status !== 200 || !result.data || !result.data.quotes) {
                return m.reply('❌ Quotes anime tidak tersedia.');
            }

            const { quotes, karakter, anime, episode, gambar, link } = result.data;

            const message = `🎌 *Quotes Anime*

"${quotes}"

👤 *Karakter* : ${karakter || '-'}
🎬 *Anime*    : ${anime || '-'}
📺 *Episode*  : ${episode || '-'}
🔗 *Sumber*   : ${link || '-'}`;

            if (gambar) {
                await Yudzxml.sendMessage(
                    m.chat,
                    {
                        image: { url: gambar },
                        caption: message
                    },
                    { quoted: m }
                );
            } else {
                m.reply(message);
            }
        } catch (err) {
            console.error('[QUOTESANIME ERROR]', err);
            m.reply('⚠️ Terjadi kesalahan saat mengambil quotes anime.');
        }
    }
};

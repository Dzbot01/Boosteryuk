const axios = require('axios');

module.exports = {
    name: 'darkjokes',
    category: 'random',
    commands: ['darkjokes'],
    isOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ m, config, Yudzxml }) {
        try {
            const { endpoint, key } = config.apikey;
            const apiUrl = `${endpoint}/api/random/darkjokes?apikey=${key}`;

            const res = await axios.get(apiUrl);
            const result = res.data;

            if (!result || result.status !== 200 || !result.data) {
                return m.reply('❌ Dark jokes tidak tersedia.');
            }

            const imageUrl = result.data;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: imageUrl },
                    caption: '🖤 *Dark Jokes*\n\nBercanda boleh, baper jangan.'
                },
                { quoted: m }
            );
        } catch (err) {
            console.error('[DARKJOKES ERROR]', err);
            m.reply('⚠️ Terjadi kesalahan saat mengambil dark jokes.');
        }
    }
};

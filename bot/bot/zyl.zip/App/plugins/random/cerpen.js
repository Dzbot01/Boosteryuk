const axios = require('axios');

module.exports = {
    name: 'cerpen',
    category: 'random',
    commands: ['cerpen'],
    isOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ m, config }) {
        try {
            const { endpoint, key } = config.apikey;
            const apiUrl = `${endpoint}/api/random/cerpen?apikey=${key}`;

            const res = await axios.get(apiUrl);
            const result = res.data;

            if (!result || result.status !== 200 || !result.data) {
                return m.reply('❌ Cerpen tidak tersedia saat ini.');
            }

            const cerpen = result.data.trim();

            const message = `📖 *CERPEN ACAK*

${cerpen}

━━━━━━━━━━━━━━━
✨ Dibaca pelan-pelan, biar lukanya kerasa.
`;

            await m.reply(message);
        } catch (err) {
            console.error('[CERPEN ERROR]', err);
            m.reply('⚠️ Terjadi kesalahan saat mengambil cerpen.');
        }
    }
};

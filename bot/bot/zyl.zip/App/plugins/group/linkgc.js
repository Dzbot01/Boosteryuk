module.exports = {
    name: 'linkgc',
    category: 'group',
    commands: ['linkgc', 'linkgroup'],
    description: 'Menampilkan link undangan grup',
    isGroup: true,
    isBotAdmins: true,

    async execute({ m, Yudzxml, groupMetadata }) {
        try {
            const link = await Yudzxml.groupInviteCode(m.chat);
            const totalMember = groupMetadata.participants.length;

            m.reply(
                `🔗 *LINK GRUP*\n` +
                    `────────────────────────\n` +
                    `👥 Total Member : ${totalMember}\n` +
                    `🔐 Link Invite  : https://chat.whatsapp.com/${link}\n` +
                    `────────────────────────\n` +
                    `Gunakan link ini dengan bijak.`
            );
        } catch (err) {
            console.error('[LINKGC ERROR]', err);
            m.reply('❌ Gagal mengambil link grup. Pastikan bot adalah admin.');
        }
    }
};

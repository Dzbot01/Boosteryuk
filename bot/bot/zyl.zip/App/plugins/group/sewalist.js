const axios = require('axios');

module.exports = {
    name: 'sewabot-tools',
    category: 'owner',
    commands: ['listsewa', 'ceksewa', 'outsewa'],
    description: 'Kelola penyewaan bot (List, Cek, dan Out)',
    isOwner: false,
    isSuperOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,

    async execute({ Yudzxml, m, args, isOwner, isSuperOwner, getSewa, deleteSewa, command }) {
        const reply = (text) => Yudzxml.sendMessage(m.chat, { text }, { quoted: m });

        if (command === 'listsewa') {
            if (!isOwner && !isSuperOwner) {
                return reply('⛔ *Akses Ditolak!* Perintah ini khusus Owner Bot.');
            }

            const sewaObj = getSewa();
            if (!sewaObj || Object.keys(sewaObj).length === 0) {
                return reply('📭 *Belum ada grup yang menyewa bot.*');
            }

            const allSewa = Object.entries(sewaObj).map(([id, data]) => ({
                id,
                namegrup: data.namegrup,
                start: data.start,
                expired: data.expired
            }));

            let listText = '*—『 DAFTAR SEWA BOT 』—*\n\n';
            let totalGrup = 0;
            let totalAktif = 0;

            const now = Date.now();

            allSewa.sort((a, b) => a.expired - b.expired);

            for (const i of allSewa) {
                const isExpired = i.expired < now;
                totalGrup++;
                if (!isExpired) totalAktif++;

                const statusIcon = isExpired ? '🔴' : '🟢';
                const sisaHari = Math.ceil((i.expired - now) / (1000 * 60 * 60 * 24));
                const waktuHabis = isExpired ? 'SUDAH HABIS' : `${sisaHari} Hari Lagi`;

                listText += `${statusIcon} *Grup:* ${i.namegrup}\n`;
                listText += `   🆔 ID: ${i.id}\n`;
                listText += `   ⏰ Expired: ${new Date(i.expired).toLocaleDateString('id-ID')} (${waktuHabis})\n\n`;
            }

            listText += `━━━━━━━━━━━━━━━━━━\n`;
            listText += `📊 *Total Grup Terdaftar:* ${totalGrup}\n`;
            listText += `✅ *Grup Masih Aktif:* ${totalAktif}`;

            return reply(listText);
        }

        if (command === 'ceksewa') {
            if (!m.isGroup) {
                return reply('⚠️ Perintah ini hanya bisa digunakan di dalam grup.');
            }

            const groupData = getSewa(m.chat);
            const now = Date.now();

            if (!groupData) {
                return reply(
                    '❌ *Grup ini tidak terdaftar dalam database sewa.*\n\n' +
                        'Silakan sewa bot agar fitur dapat digunakan.'
                );
            }

            const isExpired = groupData.expired < now;
            const sisaHari = Math.max(0, Math.ceil((groupData.expired - now) / (1000 * 60 * 60 * 24)));

            const expiredDate = new Date(groupData.expired).toLocaleDateString('id-ID', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });

            const statusText = isExpired
                ? '🔴 *Masa Aktif HABIS.*\n_Silakan perpanjang sewa untuk menikmati fitur bot kembali._'
                : `🟢 *Masih Aktif.*\n_Tersisa ${sisaHari} hari lagi._`;

            const cekText = `
*—『 INFO SEWA GRUP 』—*

📛 *Nama Grup:* ${groupData.namegrup}
🆔 *ID Grup:* ${m.chat}
📅 *Tanggal Expired:* ${expiredDate}

━━━━━━━━━━━━━━━━━━
*STATUS:* ${statusText}
    `.trim();

            return reply(cekText);
        }

        if (command === 'outsewa') {
            if (!isOwner && !isSuperOwner) {
                return reply('⛔ *Akses Ditolak!* Perintah ini khusus Owner Bot.');
            }

            if (m.isGroup) {
                try {
                    await reply('👋 *Baik, bot akan keluar dari grup ini...*');

                    deleteSewa(m.chat);

                    await Yudzxml.groupLeave(m.chat);
                } catch (err) {
                    console.error(err);
                    return reply('❌ Gagal keluar dari grup.');
                }
            } else {
                const input = args[0];
                if (!input) {
                    return reply(
                        '📝 *Format salah!*\n\nGunakan di dalam grup untuk keluar langsung, atau ketik:\n.outsewa 628xxx@g.us\n(out dari grup target via ID)'
                    );
                }

                const normalizeLink = (url) => {
                    const match = url.match(/chat\.whatsapp\.com\/([0-9A-Za-z_-]{20,})/);
                    return match ? match[1] : null;
                };

                let targetId = input;

                if (input.includes('chat.whatsapp.com') || input.includes('whatsapp.com')) {
                    const inviteCode = normalizeLink(input);
                    if (!inviteCode) return reply('❌ Link grup tidak valid.');

                    try {
                        const res = await Yudzxml.query({
                            tag: 'iq',
                            attrs: { type: 'get', xmlns: 'w:g2', to: '@g.us' },
                            content: [{ tag: 'invite', attrs: { code: inviteCode } }]
                        });
                        const groupData = res?.content?.[0]?.attrs;
                        if (!groupData?.id) return reply('❌ Gagal mendapatkan info grup dari link tersebut.');

                        targetId = groupData.id + '@g.us';
                    } catch (err) {
                        console.error(err);
                        return reply(
                            '❌ Gagal mengambil info grup. Pastikan bot masuk ke grup tersebut atau link valid.'
                        );
                    }
                }

                if (!targetId.endsWith('@g.us')) {
                    targetId = targetId + '@g.us';
                }

                try {
                    await Yudzxml.sendMessage(
                        m.chat,
                        { text: `👋 Memproses keluar dari grup: ${targetId}...` },
                        { quoted: m }
                    );

                    deleteSewa(targetId);

                    await Yudzxml.groupLeave(targetId);
                } catch (err) {
                    console.error(err);
                    if (err.message.includes('not-authorized') || err.message.includes('not-found')) {
                        return reply('❌ Gagal keluar. Bot mungkin sudah tidak ada di grup tersebut atau ID salah.');
                    }
                    return reply('❌ Terjadi kesalahan saat mencoba keluar dari grup.');
                }
            }
        }
    }
};

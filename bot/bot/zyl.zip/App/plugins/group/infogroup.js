module.exports = {
    name: 'infogroup',
    category: 'group',
    commands: ['infogroup', 'groupinfo'],
    description: 'Menampilkan informasi lengkap grup',
    isGroup: true,

    async execute({ m, Yudzxml, groupMetadata }) {
        try {
            const { id, subject, ownerAlt, creation, desc, participants, announce, restrict } = groupMetadata;

            const admins = participants.filter((p) => p.admin);
            const members = participants.filter((p) => !p.admin);

            const createdAt = new Date(creation * 1000).toLocaleString('id-ID');

            const text =
                `📌 *INFORMASI GRUP*\n` +
                `────────────────────────\n` +
                `🏷️ Nama Grup     : ${subject}\n` +
                `🆔 ID Grup       : ${id}\n` +
                `👑 Owner         : ${ownerAlt ? '@' + ownerAlt.split('@')[0] : 'Tidak diketahui'}\n` +
                `📅 Dibuat        : ${createdAt}\n` +
                `👥 Total Member  : ${participants.length}\n` +
                `🛡️ Admin         : ${admins.length}\n` +
                `👤 Member        : ${members.length}\n` +
                `🔒 Mode Chat     : ${announce ? 'Admin Only' : 'Semua Member'}\n` +
                `⚙️ Mode Edit     : ${restrict ? 'Admin Only' : 'Semua Member'}\n` +
                `────────────────────────\n` +
                `📝 *Deskripsi Grup*\n` +
                `${desc || '-'}`;

            await m.reply(text);
        } catch (err) {
            console.error('[INFOGROUP ERROR]', err);
            m.reply('❌ Gagal mengambil informasi grup.');
        }
    }
};

module.exports = {
    name: 'economy',
    category: 'group',
    commands: ['sendmoney', 'sendlimit', 'buylimit'],
    isGroup: false,
    isAdmin: false,
    isBotAdmins: false,
    isOwner: false,
    isSuperOwner: false,
    isPremium: false,

    async execute({ m, command, getUser, addMoney, reduceMoney, addLimit, reduceLimit, text }) {
        const sender = m.sender;

        const senderData = getUser(sender);

        if (!senderData) {
            return m.reply('❌ Kamu belum terdaftar.\n' + '📌 Silakan daftar terlebih dahulu.\n' + '➡️ *.daftar*');
        }

        const getTargetAndAmount = () => {
            let target = null;
            let amount = null;

            if (m.mentionedJid?.length) {
                target = m.mentionedJid[0];

                const args = text.trim().split(/\s+/);
                amount = Number(args[args.length - 1]);
            } else if (m.quoted) {
                target = m.quoted.sender;

                const args = text.trim().split(/\s+/);
                amount = Number(args[0]);
            } else {
                const args = text.trim().split(/\s+/);

                if (args.length >= 2) {
                    const number = args[0].replace(/[^0-9]/g, '');

                    if (number) {
                        target = number + '@s.whatsapp.net';
                    }

                    amount = Number(args[1]);
                }
            }

            return { target, amount };
        };

        if (command === 'sendmoney') {
            const { target, amount } = getTargetAndAmount();

            if (!target) {
                return m.reply(
                    '❌ Format salah\n\n' +
                        'Contoh:\n' +
                        '.sendmoney @user 100\n' +
                        '.sendmoney 628xxxx 100\n' +
                        '(reply pesan) .sendmoney 100'
                );
            }

            if (target === sender) {
                return m.reply('❌ Tidak bisa transfer ke diri sendiri.');
            }

            if (!amount || isNaN(amount) || amount <= 0) {
                return m.reply('❌ Jumlah money tidak valid.');
            }

            const targetData = getUser(target);

            if (!targetData) {
                return m.reply('❌ Target belum terdaftar.\n' + '📌 Minta user melakukan *.daftar* terlebih dahulu.');
            }

            if (senderData.money < amount) {
                return m.reply(`❌ Money tidak cukup.\n` + `💰 Money kamu : ${senderData.money}`);
            }

            reduceMoney(sender, amount);
            addMoney(target, amount);

            return m.reply(
                `✅ *TRANSFER MONEY BERHASIL*\n\n` +
                    `💸 Jumlah : ${amount}\n` +
                    `👤 Kepada : @${target.split('@')[0]}\n` +
                    `💰 Sisa Money : ${senderData.money - amount}`,
                m.chat,
                { mentionedJid: [target] }
            );
        }

        if (command === 'sendlimit') {
            const { target, amount } = getTargetAndAmount();

            if (!target) {
                return m.reply(
                    '❌ Format salah\n\n' +
                        'Contoh:\n' +
                        '.sendlimit @user 5\n' +
                        '.sendlimit 628xxxx 5\n' +
                        '(reply pesan) .sendlimit 5'
                );
            }

            if (target === sender) {
                return m.reply('❌ Tidak bisa transfer ke diri sendiri.');
            }

            if (!amount || isNaN(amount) || amount <= 0) {
                return m.reply('❌ Jumlah limit tidak valid.');
            }

            const targetData = getUser(target);

            if (!targetData) {
                return m.reply('❌ Target belum terdaftar.\n' + '📌 User harus daftar terlebih dahulu.');
            }

            if (senderData.limit < amount) {
                return m.reply(`❌ Limit tidak cukup.\n` + `🎟️ Limit kamu : ${senderData.limit}`);
            }

            reduceLimit(sender, amount);
            addLimit(target, amount);

            return m.reply(
                `✅ *TRANSFER LIMIT BERHASIL*\n\n` +
                    `🎟️ Jumlah : ${amount}\n` +
                    `👤 Kepada : @${target.split('@')[0]}\n` +
                    `📦 Sisa Limit : ${senderData.limit - amount}`,
                m.chat,
                { mentionedJid: [target] }
            );
        }

        if (command === 'buylimit') {
            const amount = Number(text);

            if (!amount || isNaN(amount) || amount <= 0) {
                return m.reply('❌ Masukkan jumlah limit.\n' + 'Contoh: .buylimit 3');
            }

            const pricePerLimit = 20;
            const totalPrice = amount * pricePerLimit;

            if (senderData.money < totalPrice) {
                return m.reply(
                    `❌ Money tidak cukup.\n\n` +
                        `💰 Harga per limit : ${pricePerLimit}\n` +
                        `🎟️ Limit dibeli : ${amount}\n` +
                        `📉 Total harga : ${totalPrice}\n` +
                        `💵 Money kamu : ${senderData.money}`
                );
            }

            reduceMoney(sender, totalPrice);
            addLimit(sender, amount);

            return m.reply(
                `✅ *PEMBELIAN LIMIT BERHASIL*\n\n` +
                    `🎟️ Limit Dibeli : ${amount}\n` +
                    `💸 Total Bayar : ${totalPrice}\n` +
                    `💰 Sisa Money : ${senderData.money - totalPrice}`
            );
        }
    }
};

const config = require('@Config');
const logger = require('@App/function/logger');
const orderManager = require('@App/function/orderManager');
const createTemplateQris = require('@App/function/createTemplateQris');
const jadibotManager = require('../../../src/core/jadibot');

const formatCurrency = (number) =>
    new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0
    }).format(number);

module.exports = {
    name: 'sewabot',
    category: 'group',
    commands: ['sewabot', 'cancelorder'],
    description: 'Sewa bot utama untuk grup (pricelist dari config.js, bayar via pakasir)',
    isOwner: false,
    isSuperOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,

    encodeData: (data) => {
        try {
            return Buffer.from(JSON.stringify(data)).toString('base64');
        } catch (e) {
            logger.error('[Sewabot] Encode error: ' + (e?.message || e));
            return null;
        }
    },

    decodeData: (base64String) => {
        try {
            return JSON.parse(Buffer.from(base64String, 'base64').toString('utf-8'));
        } catch (e) {
            logger.error('[Sewabot] Decode error: ' + (e?.message || e));
            return null;
        }
    },

    normalizeGroupLink: (input) => {
        if (typeof input !== 'string') return null;
        const match = input.trim().match(/^https?:\/\/chat\.whatsapp\.com\/([A-Za-z0-9]{20,40})/i);
        return match ? `https://chat.whatsapp.com/${match[1]}` : null;
    },

    getGroupInfo: async (bot, inviteCode) => {
        const res = await bot.query({
            tag: 'iq',
            attrs: { type: 'get', xmlns: 'w:g2', to: '@g.us' },
            content: [{ tag: 'invite', attrs: { code: inviteCode } }]
        });

        const groupData = res?.content?.[0]?.attrs;
        if (!groupData?.id || !groupData?.subject) {
            throw new Error('Data grup tidak ditemukan atau link tidak valid.');
        }

        let groupId = groupData.id;
        if (!groupId.endsWith('@g.us')) groupId = groupId + '@g.us';

        return { id: groupId, name: groupData.subject, code: inviteCode };
    },

    buildPricelistText(cfg, prefix) {
        const cfgSewa = cfg.sewabot || {};
        const minDays = Number(cfgSewa.bonusPremiumMinDays) || 0;

        let list =
            `━━━━━━━━━━━━━━━━━━━\n📋 *DAFTAR PAKET SEWABOT*\n━━━━━━━━━━━━━━━━━━━\n\n` +
            `💡 _Sewa bot utama dengan fitur lengkap & performa stabil._\n\n`;

        list += (cfgSewa.packages || [])
            .map((pkg) => {
                const bonus = minDays > 0 && pkg.days >= minDays ? '\n🎁 Bonus: Premium User' : '';
                const durasi = pkg.days >= 3650 ? 'Selamanya' : `${pkg.days} Hari`;
                return `📦 *${pkg.name}*\n💰 Harga  : ${formatCurrency(pkg.price)}\n⏳ Durasi : ${durasi}${bonus}\n`;
            })
            .join('\n');

        list +=
            `\n━━━━━━━━━━━━━━━━━━━\n🛒 *CARA PEMESANAN*\n━━━━━━━━━━━━━━━━━━━\n\n` +
            `📝 *Format:*\n ${prefix}sewabot <link_grup>\n\n` +
            `☕ *Contoh:*\n ${prefix}sewabot https://chat.whatsapp.com/xxxx\n\n` +
            `_Setelah command dikirim, pilih paket pada tombol yang muncul._\n` +
            `_Pembayaran otomatis terverifikasi via *${cfg.pakasir?.slug ? 'Pakasir (' + cfg.pakasir.slug + ')' : 'Payment Gateway'}*._\n\n` +
            `━━━━━━━━━━━━━━━━━━━`;

        return list;
    },

    sendInvoice: async ({ Yudzxml, m, prefix, order, statusMessage = '', proto, cfg }) => {
        const reply = (text) => Yudzxml.sendMessage(m.chat, { text }, { quoted: m });
        const cfgRef = cfg || require('@Config');

        const invoiceText =
            `*「  INVOICE SEWABOT 」*\n\n` +
            `📦 *Paket:* ${order.package}\n` +
            `⏳ *Durasi:* ${order.days >= 3650 ? 'Selamanya' : order.days + ' Hari'}\n` +
            `💰 *Total:* ${formatCurrency(order.amount)}\n` +
            (order.fee
                ? `➕ *Fee gateway:* ${formatCurrency(order.fee)}\n🧾 *Total bayar:* ${formatCurrency(order.totalPayment)}\n`
                : '') +
            `🆔 *Order ID:* ${order.id}\n` +
            `👤 *User:* @${m.sender.split('@')[0]}\n` +
            `🛒 *Grup:* ${order.groupLink}` +
            `${statusMessage}\n\n` +
            `━━━━━━━━━━━━━━━━━━\n` +
            `*PEMBAYARAN (QRIS GATEWAY)*\n` +
            `_Scan QR di atas — nominal terkunci sesuai tagihan._\n` +
            `_QR ini dinamis dari gateway, BUKAN QRIS statis._\n\n` +
            `*_⚡ Pembayaran dicek otomatis tiap 5 detik._*\n` +
            `_Cek status: ${prefix}orderstatus ${order.id}_`;

        let qrBuffer = null;
        const payString = order.qrString || order.paymentNumber || null;

        if (payString) {
            try {
                qrBuffer = await createTemplateQris(payString, cfgRef.pakasir?.frameQr, cfgRef);
            } catch (err) {
                logger.error('[Sewabot] QR render gagal: ' + (err?.message || err));
            }
        }

        const sentMsg = await Yudzxml.sendMessage(
            m.chat,
            {
                ...(qrBuffer
                    ? { image: qrBuffer, caption: invoiceText }
                    : {
                          text:
                              `${invoiceText}\n\n` +
                              (payString
                                  ? `🔗 *QRIS String (scan manual lewat aplikasi bank/e-wallet):*\n${payString}`
                                  : `❌ *QRIS belum tersedia — cek beberapa detik lagi dengan ${prefix}orderstatus ${order.id}*`)
                      }),
                contextInfo: {
                    mentionedJid: [m.sender],
                    forwardingScore: 0,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: Yudzxml.identity?.idch || cfgRef.idch || '120363316461058483@newsletter',
                        serverMessageId: 0,
                        newsletterName: Yudzxml.identity?.storename || 'Info Bot'
                    }
                }
            },
            { quoted: m }
        );

        const msgId = sentMsg?.key?.id || null;

        const onCompleted = async ({ order: done }) => {
            const fresh = orderManager.getOrder(done.id) || done;
            const successText =
                `✅ *PEMBAYARAN BERHASIL!*\n\n` +
                `📦 *Paket:* ${fresh.package}\n` +
                `🆔 *Order ID:* ${fresh.id}\n` +
                `📅 *Masa Aktif:* +${fresh.days} hari\n` +
                `🔗 *Grup:* ${fresh.groupLink}\n\n` +
                `_Bot sudah/sedang join ke grup kamu. Terima kasih!_`;

            try {
                if (msgId) await Yudzxml.sendMessage(m.chat, { text: successText, edit: msgId });
                else await Yudzxml.sendMessage(m.chat, { text: successText });
            } catch (_) {
                await Yudzxml.sendMessage(m.chat, { text: successText }).catch(() => {});
            }
        };

        const onFailed = async ({ reason }) => {
            const failedText =
                `❌ *TRANSAKSI GAGAL / EXPIRED*\n\n` +
                `🆔 *Order ID:* ${order.id}\n` +
                `📝 *Keterangan:* ${reason}\n\n` +
                `_Jika kamu sudah membayar, hubungi owner untuk diproses manual._`;
            try {
                if (msgId) await Yudzxml.sendMessage(m.chat, { text: failedText, edit: msgId });
                else await Yudzxml.sendMessage(m.chat, { text: failedText });
            } catch (_) {
                await Yudzxml.sendMessage(m.chat, { text: failedText }).catch(() => {});
            }
        };

        orderManager.once(`completed:${order.id}`, onCompleted);
        orderManager.once(`failed:${order.id}`, onFailed);
        orderManager.once(`cancelled:${order.id}`, async () => {
            try {
                if (msgId)
                    await Yudzxml.sendMessage(m.chat, { text: `🚫 *Order ${order.id} dibatalkan.*`, edit: msgId });
            } catch (_) {}
        });

        setTimeout(
            () => {
                orderManager.off(`completed:${order.id}`, onCompleted);
                orderManager.off(`failed:${order.id}`, onFailed);
            },
            24 * 60 * 60 * 1000
        ).unref?.();
    },

    async execute({ Yudzxml, m, args, prefix, isOwner, isSuperOwner, botNumber, proto, config: instanceConfig }) {
        const reply = (text) => Yudzxml.sendMessage(m.chat, { text }, { quoted: m });
        // Pakai config per-instance: bot jadibot punya paket sewa & pakasir sendiri
        // (resolveConfig meng-merge settings.sewabot milik instance di atas config global).
        const cfg = instanceConfig || require('@Config');
        const command = m.body.split(' ')[0].toLowerCase().replace(prefix, '');

        const isJadi = Boolean(Yudzxml.isJadibot);
        const jadiJid = isJadi ? Yudzxml.jadibotJid : null;
        const jadiEntry = isJadi && jadiJid ? jadibotManager.get(jadiJid) : null;
        const jadiPakasir = jadiEntry?.credentials?.pakasir || null;
        const sewaStore = isJadi ? jadibotManager.getSewaStore(jadiJid) : require('@App/function/sewa');

        if (cfg.sewabot?.enabled === false && command === 'sewabot') {
            return reply('❌ *FITUR SEWABOT SEDANG NONAKTIF.*\n\n_Hubungi owner untuk info lebih lanjut._');
        }

        if (command === 'cancelorder') {
            const orderId = String(args[0] || '').trim();
            if (!orderId)
                return reply('❌ *Format:* .cancelorder <orderId>\n\n_Contoh: .cancelorder SEWA-1690000000-A1B2C3_');

            try {
                await orderManager.cancelOrder(orderId, {
                    byJid: m.sender,
                    allowAny: isOwner || isSuperOwner
                });
                return reply(`🚫 *Order ${orderId} berhasil dibatalkan.*`);
            } catch (err) {
                return reply(`❌ ${err.message}`);
            }
        }

        if (args[0] && args[0].startsWith('sewa_')) {
            const payload = this.decodeData(args[0].replace('sewa_', ''));
            if (!payload) return reply('❌ Data paket rusak. Silakan ulangi dari awal.');

            const packages = cfg.sewabot?.packages || [];
            const selectedPackage = packages.find((p) => p.name === payload.packageName);
            if (!selectedPackage)
                return reply('❌ Paket tidak ditemukan (mungkin baru diubah di config.js). Silakan ulangi.');

            const currentData = sewaStore.getSewa(payload.groupId);
            let statusMessage = '';
            if (currentData && currentData.expired > Date.now()) {
                const remainingDays = Math.ceil((currentData.expired - Date.now()) / (1000 * 60 * 60 * 24));
                statusMessage = `\n🟢 *Status:* Aktif (Sisa ${remainingDays} hari).\nℹ️ Pembayaran ini akan *menambah* masa aktif.`;
            } else {
                statusMessage = `\n🔴 *Status:* Belum aktif/Expired.\nℹ️ Pembayaran ini akan mengaktifkan bot baru.`;
            }

            try {
                await reply('⏳ *Membuat tagihan via payment gateway...*');

                const order = await orderManager.createSewabotOrder({
                    groupLink: payload.groupLink,
                    packageName: selectedPackage.name,
                    buyerJid: m.sender,
                    source: 'whatsapp',
                    instanceJid: jadiJid
                });

                return this.sendInvoice({ Yudzxml, m, prefix, order, statusMessage, proto, cfg });
            } catch (error) {
                logger.error('[Sewabot] Order error: ' + (error?.message || error));
                return reply(`❌ *Gagal membuat order:*\n${error.message}`);
            }
        }

        const listMessage = this.buildPricelistText(cfg, prefix);
        if (args.length < 1) return reply(listMessage);

        const groupLink = this.normalizeGroupLink(args[0]);
        if (!groupLink) {
            return reply(
                `❌ *Link Grup Tidak Valid!*\n\n_Pastikan link berasal dari WhatsApp Group._\n\n_Contoh: ${prefix}sewabot https://chat.whatsapp.com/xxx_`
            );
        }

        const inviteCode = groupLink.split('https://chat.whatsapp.com/')[1];

        let groupInfo;
        try {
            groupInfo = await this.getGroupInfo(Yudzxml, inviteCode);
        } catch (error) {
            return reply('_Gagal mengambil informasi grup. Pastikan link valid dan bot belum di-kick._');
        }

        if (isSuperOwner || isOwner) {
            const duration = parseInt(args[1]);

            if (!duration || isNaN(duration) || duration <= 0) {
                return reply(
                    `*MODE OWNER DETECTED* ⚡\n\n` +
                        `_Contoh: ${prefix}sewabot https://chat.whatsapp.com/xxx 30_\n\n` +
                        `_30 artinya 30 hari (Gratis)._`
                );
            }

            try {
                sewaStore.addSewa(groupInfo.id, groupInfo.name, duration);
                const sewaData = sewaStore.getSewa(groupInfo.id);
                const expiredDate = new Date(sewaData.expired).toLocaleDateString('id-ID');

                await Yudzxml.groupAcceptInvite(inviteCode);

                return reply(
                    `✅ *Bot Berhasil Join!*\n\n` +
                        `📛 *Grup:* ${groupInfo.name}\n` +
                        `🤖 *Bot:* ${botNumber.replace('@s.whatsapp.net', '')}\n` +
                        `⏳ *Expired:* ${expiredDate}`
                );
            } catch (error) {
                logger.error('[Sewabot] Owner mode error: ' + (error?.message || error));
                return reply('_Terjadi kesalahan saat memproses permintaan owner._');
            }
        }

        if (isJadi && (!jadiPakasir || !jadiPakasir.key || !jadiPakasir.slug)) {
            return reply(
                '❌ *GATEWAY PEMBAYARAN BELUM DIPASANG*\n\n' +
                    '_Bot jadibot kamu belum punya kredensial payment sendiri._\n' +
                    '_Pasang dulu agar pembayaran masuk ke kamu (bukan bot utama):_\n\n' +
                    '• Pasang kredensial pakasir kamu lewat *website* (menu kredensial bot jadibot)\n\n' +
                    '_Setelah terpasang, pelanggan bisa order sewa dari bot kamu._'
            );
        }

        const packages = cfg.sewabot?.packages || [];
        const minDays = Number(cfg.sewabot?.bonusPremiumMinDays) || 0;

        const selectButtons = packages.map((pkg) => {
            const btnPayload = this.encodeData({
                groupId: groupInfo.id,
                groupName: groupInfo.name,
                groupLink: groupLink,
                inviteCode: inviteCode,
                senderJid: m.sender,
                packageName: pkg.name
            });

            const bonus = minDays > 0 && pkg.days >= minDays ? ' 🎁' : '';
            return {
                name: 'quick_reply',
                buttonParamsJson: JSON.stringify({
                    display_text: `📦 ${pkg.name} — ${formatCurrency(pkg.price)}${bonus}`,
                    id: `${prefix}sewabot sewa_${btnPayload}`
                })
            };
        });

        const selectText =
            `👋 *Halo @${m.sender.split('@')[0]}!*\n\n` +
            `Data Grup Ditemukan:\n` +
            `📛 Nama: *${groupInfo.name}*\n` +
            `🔗 Link: ${groupLink}\n\n` +
            `Silakan pilih *durasi sewa* di bawah untuk lanjut ke pembayaran.\n` +
            `🎁 = dapat bonus premium user`;

        const selectMsg = proto.Message.InteractiveMessage.fromObject({
            body: proto.Message.InteractiveMessage.Body.fromObject({
                text: selectText
            }),
            footer: proto.Message.InteractiveMessage.Footer.fromObject({
                text: Yudzxml.identity?.storename || 'Bot System'
            }),
            header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: selectButtons
            }),
            contextInfo: {
                mentionedJid: [m.sender]
            }
        });

        await Yudzxml.relayMessage(
            m.chat,
            { viewOnceMessageV2Extension: { message: { interactiveMessage: selectMsg } } },
            { quoted: m }
        );
    }
};

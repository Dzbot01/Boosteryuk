async function getContactFullInfo(sock, jid) {
    const result = {
        jid,
        name: null,
        notify: null,
        verifiedName: null,
        profilePicture: null,
        about: null,
        business: null,
        presence: null,
        lastSeen: null
    };

    try {
        const contact = sock.contacts?.[jid] || {};
        result.notify = contact.notify || null;
        result.verifiedName = contact.verifiedName || null;
    } catch {}

    try {
        if (typeof sock.getName === 'function') {
            result.name = await sock.getName(jid);
        } else if (typeof sock.gstname === 'function') {
            result.name = await sock.gstname(jid);
        }
    } catch {}

    try {
        result.profilePicture = await sock.profilePictureUrl(jid, 'image');
    } catch {}

    try {
        const status = await sock.fetchStatus(jid);
        result.about = status?.status || null;
    } catch {}

    try {
        const biz = await sock.getBusinessProfile(jid);
        result.business = biz || null;
    } catch {}

    try {
        const pres = sock.presence?.[jid];
        if (pres) {
            const key = Object.keys(pres)[0];
            const data = pres[key] || {};
            result.presence = data.lastKnownPresence || 'offline';
            result.lastSeen = data.lastSeen || null;
        }
    } catch {}

    return result;
}

module.exports = {
    name: 'infokontak',
    category: 'tools',
    commands: ['infokontak'],

    async execute({ Yudzxml, m, text }) {
        let target = null;

        if (m.quoted?.sender) {
            target = m.quoted.sender;
        } else if (m.mentionedJid?.length) {
            target = m.mentionedJid[0];
        } else if (text && text.replace(/\D/g, '').length > 7) {
            target = text.replace(/\D/g, '') + '@s.whatsapp.net';
        }

        if (!target) return m.reply('Reply / tag / kirim nomor target.');

        let data;
        try {
            data = await getContactFullInfo(Yudzxml, target);
        } catch {
            return m.reply('❌ Gagal mengambil data kontak.');
        }

        if (!data || typeof data !== 'object') {
            return m.reply('❌ Data kontak tidak valid.');
        }

        const { jid, name, notify, verifiedName, profilePicture, about, business, presence, lastSeen } = data;

        let presenceText = 'Offline';
        if (presence === 'available') presenceText = '🟢 Online';
        else if (presence === 'composing') presenceText = '⌨️ Typing';
        else if (presence === 'recording') presenceText = '🎤 Recording';

        const lastSeenText = lastSeen ? new Date(lastSeen).toLocaleString('id-ID') : 'Tidak diketahui';

        let bizText = 'Tidak ada';
        if (business) {
            bizText =
                `🏢 *Business Profile*\n` +
                `• Kategori : ${business.category || '-'}\n` +
                `• Email    : ${business.email || '-'}\n` +
                `• Website  : ${business.website?.[0] || '-'}\n` +
                `• Alamat   : ${business.address || '-'}`;
        }

        const msg =
            `👤 *INFO KONTAK*\n` +
            `────────────────────\n` +
            `📱 JID        : ${jid}\n` +
            `🪪 Nama       : ${name || notify || '-'}\n` +
            `✔️ Verified   : ${verifiedName || 'Tidak'}\n` +
            `📝 Bio        : ${about || '-'}\n` +
            `📡 Status     : ${presenceText}\n` +
            `🕒 Last Seen  : ${lastSeenText}\n\n` +
            `${bizText}`;

        if (profilePicture) {
            return Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: profilePicture },
                    caption: msg,
                    mentions: [target]
                },
                { quoted: m }
            );
        }

        return Yudzxml.sendMessage(
            m.chat,
            {
                text: msg,
                mentions: [target]
            },
            { quoted: m }
        );
    }
};

const ms = require('ms');
const { getPremiumExpired, checkPremiumUser } = require('@App/function/premium');

module.exports = {
    name: 'premium',
    category: 'group',
    commands: ['premium', 'cekpremium', 'mypremium'],

    async execute({ m }) {
        const userId = m.sender;
        const expired = getPremiumExpired(userId);

        if (!checkPremiumUser(userId) || !expired) {
            return m.reply(
                `❌ *PREMIUM STATUS*

👤 User: ${userId.split('@')[0]}
📊 Status: *BUKAN PREMIUM*

💡 Kamu belum memiliki akses premium.`
            );
        }

        const remaining = Math.max(expired - Date.now(), 0);
        const expiredDate = new Date(expired).toLocaleString('id-ID');

        return m.reply(
            `⭐ *PREMIUM STATUS*

👤 User: ${userId.split('@')[0]}
📊 Status: *PREMIUM AKTIF*

⏳ Sisa: ${ms(remaining, { long: true })}
📅 Expired: ${expiredDate}`
        );
    }
};

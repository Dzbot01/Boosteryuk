const Absen = require('../../function/absen');

module.exports = {
    name: 'absen',
    category: 'group',
    commands: ['absen', 'listabsen', 'delabsen', 'cekabsen'],
    description: 'Sistem absen harian grup',
    isGroup: true,
    isRateLimit: true,
    async execute({ m, args, participants, isAdmins, command }) {
        try {
            const groupId = m.chat;
            const sender = m.sender;
            const cmd = command;

            if (cmd === 'absen') {
                const res = Absen.add(groupId, sender);
                if (res.error) return m.reply('❌ Kamu sudah absen hari ini');
                return m.reply('✅ Absen berhasil dicatat');
            }

            if (cmd === 'cekabsen') {
                const ok = Absen.isAbsen(groupId, sender);
                return m.reply(ok ? '✅ Kamu sudah absen hari ini' : '❌ Kamu belum absen');
            }

            if (cmd === 'listabsen') {
                const data = Absen.get(groupId);
                const users = Object.keys(data.users);
                const totalMember = participants.length;

                if (!users.length) {
                    return m.reply(
                        `📋 *LIST ABSEN HARI INI*\n` +
                            `────────────────────\n` +
                            `Belum ada yang absen.\n` +
                            `Jadilah yang pertama ✨`
                    );
                }

                users.sort((a, b) => {
                    return data.users[a].time.localeCompare(data.users[b].time);
                });

                const percent = Math.floor((users.length / totalMember) * 100);

                let text =
                    `📋 *LIST ABSEN*\n` +
                    `────────────────────\n` +
                    `👥 Hadir : ${users.length}/${totalMember}\n` +
                    `📊 Progress : ${percent}%\n` +
                    `📅 Tanggal : ${data.date}\n` +
                    `────────────────────\n\n`;

                users.forEach((u, i) => {
                    const time = data.users[u].time;

                    let badge = '▫️';
                    if (i === 0) badge = '🥇';
                    else if (i === 1) badge = '🥈';
                    else if (i === 2) badge = '🥉';

                    text += `${badge} ${i + 1}. @${u.split('@')[0]}\n`;
                    text += `   ⏰ ${time}\n`;
                });

                text += `\n────────────────────\n`;
                text +=
                    percent === 100
                        ? `🎉 Semua sudah absen. Disiplin level dewa.`
                        : `⚠️ Masih ada ${totalMember - users.length} orang belum absen`;

                m.reply(text, m.chat, { mentions: users });
            }

            if (cmd === 'delabsen') {
                if (!isAdmins) return m.reply('❌ Hanya admin yang bisa hapus absen');

                const target = m.mentionedJid[0];
                if (!target) return m.reply('Tag user yang ingin dihapus');

                const ok = Absen.remove(groupId, target);
                return m.reply(ok ? '🗑️ Absen dihapus' : 'User belum absen');
            }
        } catch (err) {
            console.error('[ABSEN ERROR]', err);
            m.reply('❌ Terjadi error pada sistem absen');
        }
    }
};

const { create, getActive, vote, close, formatResults } = require('@App/function/pollStore');

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

module.exports = {
    name: 'poll',
    category: 'group',
    commands: ['poll', 'vote'],
    description: 'Buat polling/voting grup: .poll "Question" "Opt1" "Opt2" "Opt3"',
    isGroup: true,

    /**
     * Polling / voting group plugin (F12).
     *
     * Usage:
     *   .poll "Pilih makan" "Mie" "Ayam" "Ikan"
     *   .poll close               — tutup polling aktif (admin/creator only)
     *   .poll results             — tampilkan hasil polling aktif
     *   .poll vote <id>           — vote option (member)
     *
     * Pakai native WA buttons (interactiveMessage) untuk voting.
     * Auto-close setelah 24 jam.
     *
     * @param {Object} ctx - Plugin context
     */
    async execute(ctx) {
        const { m, args, isAdmins, isOwner, proto, generateWAMessageFromContent, Yudzxml } = ctx;

        // ── Parse: format quoted string dengan multiple args.
        // .poll "Question" "Opt1" "Opt2" ...
        const argStr = args.join(' ');
        const quoted = argStr.match(/"([^"]+)"/g);
        const subcmd = String(args[0] || '').toLowerCase();

        // .poll close
        if (subcmd === 'close') {
            if (!isAdmins && !isOwner) {
                return m.reply('❌ Hanya admin atau pembuat poll yang boleh menutup polling.');
            }
            const p = getActive(m.chat);
            if (!p) return m.reply('📭 Tidak ada polling aktif di grup ini.');
            const result = close(p.id);
            if (result.error) return m.reply(`❌ ${result.error}`);
            return m.reply(`🔒 *Polling ditutup*\n\n${formatResults(p)}`);
        }

        // .poll results
        if (subcmd === 'results' || subcmd === 'result') {
            const p = getActive(m.chat);
            if (!p) return m.reply('📭 Tidak ada polling aktif di grup ini.');
            return m.reply(`📊 *Hasil polling saat ini*\n\n${formatResults(p)}`);
        }

        // .poll vote <id>
        if (subcmd === 'vote') {
            const optionId = Number(args[1]);
            if (!optionId) return m.reply('❌ Format: .poll vote <option_id>');
            const p = getActive(m.chat);
            if (!p) return m.reply('📭 Tidak ada polling aktif di grup ini.');
            const result = vote(p.id, m.sender, optionId);
            if (result.error) return m.reply(`❌ ${result.error}`);
            return m.reply(`✅ Vote tercatat untuk option #${optionId}.\n\n${formatResults(result.poll)}`);
        }

        // .poll create
        if (!quoted || quoted.length < 3) {
            return m.reply(
                '📊 *POLLING*\n\n' +
                    'Usage:\n' +
                    '  .poll "Pertanyaan" "Opsi 1" "Opsi 2" "Opsi 3"\n' +
                    '  .poll vote <id>\n' +
                    '  .poll results\n' +
                    '  .poll close (admin/creator only)\n\n' +
                    'Auto-close dalam 24 jam. Hasil real-time setelah vote.'
            );
        }

        const parts = quoted.map((s) => s.replace(/^"|"$/g, ''));
        const question = parts[0];
        const options = parts.slice(1);

        if (options.length < 2 || options.length > 12) {
            return m.reply('❌ Polling butuh 2-12 opsi.');
        }

        // Cek apakah sudah ada polling aktif di grup ini.
        const existing = getActive(m.chat);
        if (existing) {
            return m.reply(
                `⚠️ Sudah ada polling aktif di grup ini.\n\n${formatResults(existing)}\n\nTutup dulu dengan .poll close sebelum buat baru.`
            );
        }

        // Buat polling.
        const poll = create({
            chatId: m.chat,
            creatorJid: m.sender,
            question,
            options
        });

        // Kirim pesan polling dengan buttons.
        const buttons = poll.options.map((opt) => ({
            buttonId: `${ctx.prefix}poll vote ${opt.id}`,
            buttonText: { displayText: `${opt.id}. ${opt.text}` },
            type: 1
        }));

        // Limit buttons per message (max 3-5 per WA).
        // Untuk simplicity, kirim sebagai text + reply hint untuk vote.
        const lines = poll.options.map((opt) => `${opt.id}. ${opt.text}`).join('\n');
        const caption =
            `📊 *POLLING*\n\n` +
            `❓ *${poll.question}*\n\n` +
            `Opsi:\n${lines}\n\n` +
            `📝 Cara vote: ketik \`${ctx.prefix}poll vote <id>\`\n` +
            `🔒 Auto-close dalam 24 jam\n` +
            `👤 Pembuat: @${m.sender.split('@')[0]}`;

        try {
            await Yudzxml.sendMessage(
                m.chat,
                {
                    text: caption,
                    mentions: [m.sender]
                },
                { quoted: m }
            );
        } catch (err) {
            return m.reply(`❌ Gagal membuat polling: ${err.message}`);
        }
    }
};

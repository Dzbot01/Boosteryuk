module.exports = {
    name: 'claim',
    category: 'group',
    commands: ['claim'],

    async execute({ Yudzxml, m, prefix, claimLimit, config, getUser }) {
        const data = claimLimit(m.sender, config.resetclaim);

        if (!data) {
            return m.reply(
                `⚠️ *@${m.sender.split('@')[0]}*, Kamu belum terdaftar dalam database!\n\n` +
                    `Ketik *${prefix}daftar* untuk membuat akun.`
            );
        }

        if (data.success) {
            return m.reply(data.message);
        }

        return m.reply(data.message);
    }
};

module.exports = {
    name: 'afk',
    category: 'group',
    commands: ['afk'],
    async execute({ Yudzxml, m, text, args, prefix, setAFK, unsetAFK, getAFK, config }) {
        if (!m.isGroup) {
            return Yudzxml.sendMessage(
                m.chat,
                {
                    text: '❌ Perintah *AFK* hanya tersedia di dalam grup.'
                },
                { quoted: m }
            );
        }

        const groupId = m.chat;
        const userId = m.sender;
        const username = m.pushName || userId.split('@')[0];
        const reason = text?.trim() || 'Tanpa Alasan';

        const afkData = getAFK(groupId, userId);

        if (afkData) {
            setAFK(groupId, userId, reason);

            return m.reply(`🔄 ${username} memperbarui status AFK\n\n` + `❏ ${reason || 'Tanpa alasan khusus.'}`);
        }

        setAFK(groupId, userId, reason);

        return m.reply(`😓 Waduhh, Kak *${username}*... Telah Menghilang Dari Lane\n\n ❏ ${reason}`);
    }
};

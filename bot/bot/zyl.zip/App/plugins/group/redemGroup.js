const Redeem = require('../../function/redeem');
const moment = require('moment-timezone');

const TZ = 'Asia/Jakarta';

module.exports = {
    name: 'redeem',
    category: 'group',
    commands: ['redeem', 'inforedeem', 'listredeem'],
    description: 'Claim & cek kode redeem',
    isRateLimit: true,
    noJadibot: true,
    async execute({ Yudzxml, m, args, groupMetadata, command, isAdmins }) {
        try {
            const cmd = command.toLowerCase();
            const groupId = m.chat;
            const groupName = groupMetadata.subject;
            const userId = m.sender;

            if (cmd === 'redeem') {
                const code = args[0];

                if (!code) {
                    return m.reply('Masukkan kode redeem\n\nContoh:\n.redeem FREE30');
                }

                const data = Redeem.getRedeem(code);

                if (!data) {
                    return m.reply('Kode tidak ditemukan');
                }

                if (data.reward?.sewa && (!m.isGroup || !isAdmins)) {
                    return m.reply('🚫 Redeem yang berisi hadiah Sewa Bot hanya dapat diklaim oleh admin grup.');
                }

                const res = await Redeem.claimRedeem(code, userId, groupId, groupName, Yudzxml);

                return m.reply(res.status ? `✅ ${res.msg}` : `❌ ${res.msg}`);
            }

            if (cmd === 'inforedeem') {
                const code = args[0];

                if (!code) {
                    return m.reply('Masukkan kode redeem');
                }

                const data = Redeem.getRedeem(code);

                if (!data) {
                    return m.reply('Kode tidak ditemukan');
                }

                data.usedUsers ??= data.used || [];
                data.usedGroups ??= [];

                const now = moment().tz(TZ).valueOf();

                const status = now > data.expired ? 'Expired' : 'Active';

                const exp = moment(data.expired).tz(TZ).format('YYYY-MM-DD HH:mm:ss');

                const reward = data.reward || {};

                const rewardList = [];

                if (reward.premium) rewardList.push(`👑 Premium : ${reward.premium}`);

                if (reward.money) rewardList.push(`💰 Money : ${Number(reward.money).toLocaleString()}`);

                if (reward.limit) rewardList.push(`🎫 Limit : ${reward.limit}`);

                if (reward.sewa) rewardList.push(`🤖 Sewa Bot : ${reward.sewa} Hari`);

                const usedUsers = data.usedUsers.length;

                const usedGroups = data.usedGroups.length;

                return m.reply(
                    `🎟️ *INFO REDEEM*

🔑 Kode : ${code.toUpperCase()}
📊 Status : ${status}
👤 User Claim : ${usedUsers}x
👥 Group Claim : ${usedGroups}x
⏳ Expired : ${exp}

🎁 Reward :
${rewardList.join('\n') || '-'}`
                );
            }

            if (cmd === 'listredeem') {
                const list = Redeem.listRedeem();
                const keys = Object.keys(list);

                if (!keys.length) {
                    return m.reply('Belum ada kode redeem');
                }

                let text = `🎟️ *LIST REDEEM*

`;

                keys.forEach((key, index) => {
                    const data = list[key];

                    data.usedUsers ??= data.used || [];
                    data.usedGroups ??= [];

                    const reward = data.reward || {};

                    const rewardList = [];

                    if (reward.premium) rewardList.push(`Premium ${reward.premium}`);

                    if (reward.money) rewardList.push(`Money ${Number(reward.money).toLocaleString()}`);

                    if (reward.limit) rewardList.push(`Limit ${reward.limit}`);

                    if (reward.sewa) rewardList.push(`Sewa ${reward.sewa} Hari`);

                    const status = Date.now() > data.expired ? 'Expired' : 'Active';

                    const usedUsers = data.usedUsers.length;

                    const usedGroups = data.usedGroups.length;

                    text += `${index + 1}. ${key}
   Reward : ${rewardList.join(', ') || '-'}
   User Claim : ${usedUsers}x
   Group Claim : ${usedGroups}x
   Status : ${status}

`;
                });

                return m.reply(text);
            }
        } catch (err) {
            console.error('[REDEEM GROUP ERROR]', err);

            m.reply('❌ Error pada sistem redeem');
        }
    }
};

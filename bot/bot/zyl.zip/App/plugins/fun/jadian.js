module.exports = {
    name: 'jadian',
    category: 'fun',
    commands: ['jadian'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ m, Yudzxml, participants }) {
        if (!participants || participants.length < 2) return m.reply('❌ Peserta kurang.');

        let pasangan;
        do {
            pasangan = participants[Math.floor(Math.random() * participants.length)];
        } while (pasangan.id === m.sender);

        const persen = Math.floor(Math.random() * 101);

        let status =
            persen <= 20
                ? '❌ Cuma temen.'
                : persen <= 40
                  ? '😅 Masih awkward.'
                  : persen <= 60
                    ? '💞 Lumayan cocok.'
                    : persen <= 80
                      ? '😍 Couple goals.'
                      : '💍 Gas KUA!';

        const api =
            `https://api.siputzx.my.id/api/canvas/ship` +
            `?avatar1=${encodeURIComponent(await Yudzxml.profilePictureUrl(m.sender).catch(() => 'https://i.ibb.co/Yc4MVdV/images.jpg'))}` +
            `&avatar2=${encodeURIComponent(await Yudzxml.profilePictureUrl(pasangan.id).catch(() => 'https://i.ibb.co/KKYxYQr/download.jpg'))}` +
            `&background=https://i.ibb.co/4YBNyvP/images-76.jpg` +
            `&persen=${persen}`;

        await Yudzxml.sendMessage(
            m.chat,
            {
                image: { url: api },
                caption:
                    `❤️ @${m.sender.split('@')[0]} x @${pasangan.id.split('@')[0]}\n` +
                    `📊 *Kecocokan:* ${persen}%\n\n${status}`,
                mentions: [m.sender, pasangan.id]
            },
            { quoted: m }
        );
    }
};

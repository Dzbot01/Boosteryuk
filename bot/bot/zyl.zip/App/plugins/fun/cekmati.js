module.exports = {
    name: 'cekmati',
    category: 'fun',
    commands: ['cekmati'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ m, Yudzxml }) {
        if (!m.mentionedJid?.length) return m.reply('Tag orangnya lur 😭');

        const targetJid = m.mentionedJid[0];
        const targetName = (await Yudzxml.getName(targetJid)) || `@${targetJid.split('@')[0]}`;

        const umur = Math.floor(Math.random() * 31) + 20;

        let kata =
            umur <= 25
                ? '😨 Masih muda banget.'
                : umur <= 35
                  ? '☠️ Tobat dari sekarang.'
                  : umur <= 45
                    ? '🪦 Setengah jalan.'
                    : '👻 Bau tanah.';

        await Yudzxml.sendMessage(
            m.chat,
            {
                text: `⚰️ *Ramalan Umur ${targetName}*\n🪦 *${umur} tahun*\n\n${kata}`,
                mentions: [targetJid]
            },
            { quoted: m }
        );
    }
};

module.exports = {
    name: 'ceksigma',
    category: 'fun',
    commands: ['ceksigma'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ m, Yudzxml, config }) {
        try {
            if (!m.mentionedJid?.length) {
                return m.reply('Tag target dulu. Aura tidak bisa discan dari bayangan 😤');
            }

            const targetJid = m.mentionedJid[0];

            const targetName = (await Yudzxml.getName(targetJid)) || `@${targetJid.split('@')[0]}`;

            const isOwner = config.superowner === targetJid || config.superowner === targetJid.split('@')[0];

            const persenList = isOwner ? [100] : [5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100];

            const persen = persenList[Math.floor(Math.random() * persenList.length)];

            let tipe, status, efek;

            if (persen <= 15) {
                tipe = 'NPC';
                status = 'Mengikuti alur tanpa arah.';
                efek = 'Sering muncul, jarang berpengaruh.';
            } else if (persen <= 35) {
                tipe = 'Beta';
                status = 'Pendukung sistem.';
                efek = 'Stabil tapi bukan pusat gravitasi.';
            } else if (persen <= 60) {
                tipe = 'Normal Human';
                status = 'Manusia standar.';
                efek = 'Kadang naik, kadang tenggelam.';
            } else if (persen <= 85) {
                tipe = 'Alpha';
                status = 'Dominan dan berpengaruh.';
                efek = 'Lingkungan mulai mengikuti.';
            } else {
                tipe = 'Sigma';
                status = 'Berjalan sendiri, tidak butuh validasi.';
                efek = 'Aura sunyi tapi mematikan.';
            }

            const teks = `
👤 *Target:* ${targetName}
📊 *Sigma Level:* ${persen}%

🧬 *Tipe:* ${tipe}
🏷️ *Status:* ${status}
⚡ *Efek:* ${efek}

_${persen === 100 ? 'Legenda hidup. Tidak mengikuti sistem, sistem mengikuti dia.' : 'Hasil scan berbasis algoritma tidak jelas tapi terasa benar.'}_
`;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    text: teks.trim(),
                    mentions: [targetJid]
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Scanner aura gagal membaca target. Coba lagi nanti.');
        }
    }
};

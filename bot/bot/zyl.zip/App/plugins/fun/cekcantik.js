module.exports = {
    name: 'cekcantik',
    category: 'fun',
    commands: ['cekcantik'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ m, Yudzxml, config }) {
        if (!m.mentionedJid?.length) return m.reply('Tag orangnya dong 💅');

        const target = m.mentionedJid[0];
        const name = (await Yudzxml.getName(target)) || `@${target.split('@')[0]}`;

        const list =
            config.superowner === target || config.superowner === target.split('@')[0]
                ? ['100']
                : ['5', '10', '20', '30', '40', '50', '60', '70', '80', '90', '100'];

        const persen = Number(list[Math.floor(Math.random() * list.length)]);

        let kata =
            persen <= 10
                ? '😬 Cantik kalau lampu mati.'
                : persen <= 30
                  ? '🙂 Manis tipis-tipis.'
                  : persen <= 50
                    ? '😉 Natural cakep.'
                    : persen <= 70
                      ? '😍 Cantik banget.'
                      : persen <= 90
                        ? '💖 Aura selebgram.'
                        : '👑 Bidadari turun server!';

        await Yudzxml.sendMessage(
            m.chat,
            {
                text: `👩 *${name}*\n📊 *Tingkat Kecantikan:* ${persen}%\n\n${kata}`,
                mentions: [target]
            },
            { quoted: m }
        );
    }
};

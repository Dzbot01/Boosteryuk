module.exports = {
    name: 'cekgila',
    category: 'fun',
    commands: ['cekgila'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ m, Yudzxml, config }) {
        if (!m.mentionedJid?.length) return m.reply('Tag orangnya lur 😵');

        const targetJid = m.mentionedJid[0];
        const targetName = (await Yudzxml.getName(targetJid)) || `@${targetJid.split('@')[0]}`;

        const val =
            config.superowner === targetJid || config.superowner === targetJid.split('@')[0]
                ? ['0']
                : ['5', '10', '20', '30', '40', '50', '60', '70', '80', '90', '100'];

        const persen = Number(val[Math.floor(Math.random() * val.length)]);

        let kata =
            persen <= 10
                ? '🧠 Masih normal.'
                : persen <= 30
                  ? '🤪 Suka ngomong sendiri.'
                  : persen <= 50
                    ? '😜 Gila tipis-tipis.'
                    : persen <= 70
                      ? '🫠 Perlu healing.'
                      : persen <= 90
                        ? '😈 Gila berat.'
                        : '💀 Level Joker!';

        await Yudzxml.sendMessage(
            m.chat,
            {
                text: `👤 *${targetName}*\n📊 *Tingkat Kegilaan:* ${persen}%\n\n${kata}`,
                mentions: [targetJid]
            },
            { quoted: m }
        );
    }
};

module.exports = {
    name: 'cekbucin',
    category: 'fun',
    commands: ['cekbucin'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ m, Yudzxml, config }) {
        if (!m.mentionedJid?.length) return m.reply('Tag orangnya lur 😤');

        const targetJid = m.mentionedJid[0];
        const targetName = (await Yudzxml.getName(targetJid)) || `@${targetJid.split('@')[0]}`;

        const val =
            config.superowner === targetJid || config.superowner === targetJid.split('@')[0]
                ? ['0']
                : ['5', '10', '20', '30', '40', '50', '60', '70', '80', '90', '100'];

        const persen = Number(val[Math.floor(Math.random() * val.length)]);

        let kata =
            persen <= 10
                ? '😎 Gak bucin sama sekali, cuek tapi elegan.'
                : persen <= 30
                  ? '😏 Masih waras, cuma dikit-dikit inget doi.'
                  : persen <= 50
                    ? '🫠 Mulai halu tiap liat status WA doi.'
                    : persen <= 70
                      ? '💞 Udah bucin tapi masih denial.'
                      : persen <= 90
                        ? '🥴 Stalking tiap malam.'
                        : '💘 100%! Hidupnya diatur doi 😭';

        await Yudzxml.sendMessage(
            m.chat,
            {
                text: `👤 *${targetName}*\n📊 *Tingkat Bucin:* ${persen}%\n\n${kata}`,
                mentions: [targetJid]
            },
            { quoted: m }
        );
    }
};

module.exports = {
    name: 'cekkodam',
    category: 'fun',
    commands: ['cekkodam'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ m, text, Yudzxml, ppnyauser, config }) {
        const nama = text?.trim();

        if (!nama) {
            return m.reply('Masukin nama dulu, jangan kosong.');
        }

        try {
            const controller = new AbortController();
            const timeout = setTimeout(() => controller.abort(), 10000);

            const res = await fetch(
                `${config.apikey.endpoint}/api/game/cekkodam?nama=${encodeURIComponent(nama)}&apikey=${config.apikey.key}`,
                { signal: controller.signal }
            );

            clearTimeout(timeout);

            if (!res.ok) {
                return m.reply(`❌ HTTP Error: ${res.status}`);
            }

            const json = await res.json();

            if (!json || json.status !== 200) {
                return m.reply('❌ API error. Kodam lagi cuti.');
            }

            if (!json.data || !json.data.url) {
                return m.reply('❌ Data dari API ga lengkap.');
            }

            const { url } = json.data;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    audio: { url },
                    mimetype: 'audio/mp4',
                    ptt: false,
                    contextInfo: {
                        mentionedJid: [m.sender],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.idch || '120363291726836483@newsletter',
                            serverMessageId: 100,
                            newsletterName: config.ownername
                        }
                    }
                },
                { quoted: m }
            );
        } catch (e) {
            if (e.name === 'AbortError') {
                return m.reply('❌ Request timeout. API kelamaan mikir.');
            }

            console.error('Cekkodam Error:', e);
            m.reply('❌ Terjadi error. Antara API rusak atau hidup lagi bercanda.');
        }
    }
};

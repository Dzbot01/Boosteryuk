module.exports = {
    name: 'cektolol',
    category: 'fun',
    commands: ['cektolol'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ m, Yudzxml, config }) {
        try {
            if (!m.mentionedJid?.length) {
                return m.reply('Tag target dulu. Jangan cek diri sendiri, sakit 😤');
            }

            const targetJid = m.mentionedJid[0];

            const targetName = (await Yudzxml.getName(targetJid)) || `@${targetJid.split('@')[0]}`;

            const isOwner = config.superowner === targetJid || config.superowner === targetJid.split('@')[0];

            const persenList = isOwner ? [0] : [5, 10, 15, 20, 25, 30, 40, 50, 60, 70, 80, 90, 100];

            const persen = persenList[Math.floor(Math.random() * persenList.length)];

            let status, gelar, efek;

            if (persen <= 10) {
                status = 'Otak masih berfungsi normal.';
                gelar = '🧠 Manusia Waras';
                efek = 'Logika masih online.';
            } else if (persen <= 30) {
                status = 'Kadang error kecil.';
                gelar = '🙂 Lemot Ringan';
                efek = 'Butuh restart pikiran.';
            } else if (persen <= 50) {
                status = 'Mulai ngawur.';
                gelar = '🤏 Setengah Tolol';
                efek = 'Loading lama, hasil random.';
            } else if (persen <= 70) {
                status = 'Kesalahan berpikir meningkat.';
                gelar = '😵 Tolol Aktif';
                efek = 'Sistem logika tidak stabil.';
            } else if (persen <= 90) {
                status = 'Bahaya intelektual.';
                gelar = '🤡 Tolol Kronis';
                efek = 'Sering ngomong tapi kosong.';
            } else {
                status = 'Tidak dapat diperbaiki.';
                gelar = '💀 Raja Tolol';
                efek = 'Otak not found.';
            }

            const teks = `
👤 *Target:* ${targetName}
📊 *Level Ketololan:* ${persen}%

🏷️ *Status:* ${status}
🎖️ *Gelar:* ${gelar}
⚡ *Efek:* ${efek}

_${persen === 0 ? 'Legenda mengatakan dia kebal kebodohan.' : 'Hasil scan ini tidak ilmiah, tapi menyakitkan.'}_
`;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    text: teks.trim(),
                    mentions: [targetJid]
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Scanner otak error. Coba lagi nanti.');
        }
    }
};

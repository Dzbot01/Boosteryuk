module.exports = {
    name: 'ceksange',
    category: 'fun',
    commands: ['ceksange'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ m, config }) {
        if (!m.mentionedJid?.length) return m.reply('Tag orangnya dulu dong 😏');

        const target = m.mentionedJid[0];

        const list =
            config.superowner === target || config.superowner === target.split('@')[0]
                ? ['0', '1']
                : ['10', '20', '30', '40', '50', '60', '70', '80', '90', '100'];

        const persen = Number(list[Math.floor(Math.random() * list.length)]);

        let kata =
            persen <= 20
                ? '😇 Masih suci.'
                : persen <= 40
                  ? '🙂 Aman terkendali.'
                  : persen <= 60
                    ? '😏 Mulai panas.'
                    : persen <= 80
                      ? '🔥 Overheat.'
                      : persen <= 95
                        ? '🥵 Tobat lur.'
                        : '💀 Nafsu 100%!';

        await m.reply(`📊 *Tingkat Sange:* ${persen}%\n\n${kata}`);
    }
};

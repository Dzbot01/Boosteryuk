module.exports = {
    name: 'ceklesbi',
    category: 'fun',
    commands: ['ceklesbi'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ m, config }) {
        if (!m.mentionedJid?.length) return m.reply('Tag orangnya dulu dong 🌈');

        const target = m.mentionedJid[0];

        const list =
            config.superowner === target || config.superowner === target.split('@')[0]
                ? ['0', '1']
                : ['5', '10', '20', '30', '40', '50', '60', '70', '80', '90', '100'];

        const persen = Number(list[Math.floor(Math.random() * list.length)]);

        let kata =
            persen <= 20
                ? '🌸 Masih normal.'
                : persen <= 40
                  ? '😅 Baper tipis.'
                  : persen <= 60
                    ? '💖 Ada getaran.'
                    : persen <= 80
                      ? '🌈 Mulai belok.'
                      : persen <= 95
                        ? '🔥 Fix lesbi.'
                        : '💘 Ratu pelangi.';

        await m.reply(`📊 *Tingkat Lesbi:* ${persen}%\n\n${kata}`);
    }
};

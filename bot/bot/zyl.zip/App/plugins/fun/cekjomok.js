module.exports = {
    name: 'cekjomok',
    category: 'fun',
    commands: ['cekjomok'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ m, Yudzxml, config }) {
        try {
            if (!m.mentionedJid?.length) {
                return m.reply('Tag target dulu. Masa jomok sendirian 😤');
            }

            const targetJid = m.mentionedJid[0];

            const targetName = (await Yudzxml.getName(targetJid)) || `@${targetJid.split('@')[0]}`;

            const isOwner = config.superowner === targetJid || config.superowner === targetJid.split('@')[0];

            const persenList = isOwner ? [0] : [5, 10, 15, 20, 25, 30, 40, 50, 60, 70, 80, 90, 100];

            const persen = persenList[Math.floor(Math.random() * persenList.length)];

            let status, gelar, efek;

            if (persen <= 10) {
                status = 'Masih lurus. Aman dari virus jomok.';
                gelar = '🛡️ Manusia Normal';
                efek = 'Aura sigma masih menyala terang.';
            } else if (persen <= 30) {
                status = 'Mulai mencurigakan.';
                gelar = '🤨 Zona Abu-Abu';
                efek = 'Kadang bengkok, kadang lurus.';
            } else if (persen <= 50) {
                status = 'Gejala awal sudah terlihat.';
                gelar = '😶‍🌫️ Setengah Belok';
                efek = 'Lingkungan mulai curiga.';
            } else if (persen <= 70) {
                status = 'Udah masuk jalur alternatif.';
                gelar = '🧭 Belok Terarah';
                efek = 'GPS moral mulai error.';
            } else if (persen <= 90) {
                status = 'Level bahaya.';
                gelar = '🚨 Jomok Aktif';
                efek = 'Lingkaran pertemanan mulai waspada.';
            } else {
                status = 'Tidak bisa diselamatkan.';
                gelar = '💀 Supreme Jomok';
                efek = 'Server maskulinitas telah down.';
            }

            const teks = `
👤 *Target:* ${targetName}
📊 *Level Jomok:* ${persen}%

🏷️ *Status:* ${status}
🎖️ *Gelar:* ${gelar}
⚡ *Efek:* ${efek}

_${persen === 0 ? 'Legenda mengatakan dia kebal.' : 'Hasil ini 97.3% tidak akurat, tapi sakit.'}_
`;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    text: teks.trim(),
                    mentions: [targetJid]
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Terjadi gangguan pada radar jomok. Coba lagi nanti.');
        }
    }
};

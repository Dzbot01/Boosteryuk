module.exports = {
    name: 'cekgay',
    category: 'fun',
    commands: ['cekgay'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ m, Yudzxml, config, ppuser }) {
        if (!m.mentionedJid?.length) return m.reply('Tag orangnya cuy 😭');

        const target = m.mentionedJid[0];
        const name = (await Yudzxml.getName(target)) || `@${target.split('@')[0]}`;

        const list =
            config.superowner === target || config.superowner === target.split('@')[0]
                ? ['0']
                : ['5', '10', '20', '30', '40', '50', '60', '70', '80', '90', '100'];

        const persen = Number(list[Math.floor(Math.random() * list.length)]);

        let kata =
            persen <= 10
                ? '😎 Lelaki sejati.'
                : persen <= 30
                  ? '🧐 Masih lurus.'
                  : persen <= 50
                    ? '🤔 Bingung arah.'
                    : persen <= 70
                      ? '🌈 Mulai goyah.'
                      : persen <= 90
                        ? '💅 Fabulous.'
                        : '🌈💖 Ratu pelangi!';

        const api =
            `https://api.siputzx.my.id/api/canvas/gay?` +
            `nama=${encodeURIComponent(name)}` +
            `&avatar=${encodeURIComponent(ppuser)}` +
            `&num=${persen}`;

        await Yudzxml.sendMessage(
            m.chat,
            {
                image: { url: api },
                caption: `👤 *${name}*\n📊 *Tingkat Gay:* ${persen}%\n\n${kata}`,
                mentions: [target]
            },
            { quoted: m }
        );
    }
};

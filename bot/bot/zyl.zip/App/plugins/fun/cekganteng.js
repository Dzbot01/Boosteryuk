module.exports = {
    name: 'cekganteng',
    category: 'fun',
    commands: ['cekganteng'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ m, Yudzxml, config }) {
        if (!m.mentionedJid?.length) return m.reply('Tag orangnya lur 😤');

        const target = m.mentionedJid[0];
        const name = (await Yudzxml.getName(target)) || `@${target.split('@')[0]}`;

        const list =
            config.superowner === target || config.superowner === target.split('@')[0]
                ? ['100']
                : ['5', '10', '20', '30', '40', '50', '60', '70', '80', '90', '100'];

        const persen = Number(list[Math.floor(Math.random() * list.length)]);

        let kata =
            persen <= 10
                ? '😬 Upgrade wajah dulu.'
                : persen <= 30
                  ? '🙂 Lumayan.'
                  : persen <= 50
                    ? '😎 Ganteng tetangga.'
                    : persen <= 70
                      ? '🔥 Ganteng FTV.'
                      : persen <= 90
                        ? '🤩 Aura idol.'
                        : '💖 GANTENG MAX!';

        await Yudzxml.sendMessage(
            m.chat,
            {
                text: `👤 *${name}*\n📊 *Tingkat Kegantengan:* ${persen}%\n\n${kata}`,
                mentions: [target]
            },
            { quoted: m }
        );
    }
};

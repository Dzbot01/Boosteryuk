const axios = require('axios');

module.exports = {
    name: 'xnxxdl',
    category: 'nsfw',
    commands: ['xnxxdl'],
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,
    isPremium: true,
    async execute({ Yudzxml, m, text, config, prefix }) {
        try {
            if (!text) {
                return m.reply(
                    `Masukkan URL video XNXX yang valid.\n\nContoh:\n*${prefix}xnxxdl https://www.xnxx.com/video-xxxxxxx*`
                );
            }

            const url = text.trim();

            const endpoint = config?.apikey?.endpoint;
            const key = config?.apikey?.key;

            if (!endpoint || !key) {
                return m.reply('Konfigurasi API belum tersedia.');
            }

            const apiUrl = `${endpoint}/api/nsfw/xnxx/download?url=${encodeURIComponent(url)}&apikey=${key}`;

            const res = await axios.get(apiUrl).catch(() => null);

            if (!res?.data || res.data.status !== 200 || !res.data.data) {
                return m.reply('Gagal mengambil data video. Pastikan URL valid atau coba lagi nanti.');
            }

            const result = res.data.data;

            const videoUrl = result.highQualUrl || result.lowQualUrl;

            if (!videoUrl) {
                return m.reply('Link video tidak tersedia dari API.');
            }

            const caption = `✅ *Berhasil Didownload*\n🔗 *Source:* ${url}`;

            await Yudzxml.sendMessage(
                m.sender,
                {
                    video: { url: videoUrl },
                    caption: caption,
                    mimetype: 'video/mp4'
                },
                { quoted: m }
            );

            m.reply('Video Dikirim kechat pribadi bot, silahkan cek inbox atau pesan masuk');
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan saat mengirim video.');
        }
    }
};

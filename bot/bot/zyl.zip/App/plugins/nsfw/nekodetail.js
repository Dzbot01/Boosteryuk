const axios = require('axios');
const { prepareWAMessageMedia } = require('baileys');

module.exports = {
    name: 'nekodetail',
    category: 'nsfw',
    commands: ['nekodetail'],
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,
    isPremium: true,
    async execute({ Yudzxml, m, text, config, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan ID seri Nekopoi.\n\nContoh:\n*${prefix}nekodetail 54354*`);
            }

            const endpoint = config?.apikey?.endpoint;
            const key = config?.apikey?.key;

            if (!endpoint || !key) {
                return m.reply('Konfigurasi API belum tersedia.');
            }

            const id = text.trim();
            const apiUrl = `${endpoint}/api/nsfw/nekopoi/series?id=${id}&apikey=${key}`;

            const res = await axios.get(apiUrl).catch(() => null);

            if (!res?.data || res.data.status !== 200 || !res.data.data) {
                return m.reply('Seri tidak ditemukan atau ID tidak valid.');
            }

            const data = res.data.data;
            const meta = data.info_meta || {};
            const episodes = data.episode || [];

            if (!episodes.length) {
                return m.reply('Tidak ada episode yang tersedia untuk seri ini.');
            }

            const cards = [];

            for (const eps of episodes) {
                const thumbUrl = eps.image || data.image;

                if (!thumbUrl) continue;

                const media = await prepareWAMessageMedia(
                    { image: { url: thumbUrl } },
                    { upload: Yudzxml.waUploadToServer }
                );

                let displayTitle = eps.title.replace(/Subtitle Indonesia/gi, '').trim();
                if (displayTitle.length > 25) displayTitle = displayTitle.substring(0, 25) + '...';

                cards.push({
                    header: {
                        title: data.title || 'Nekopoi Series',
                        hasMediaAttachment: true,
                        imageMessage: media.imageMessage
                    },
                    body: {
                        text: `📅 *Rilis:* ${eps.date}\n📝 *Title:* ${eps.title}`
                    },
                    footer: {
                        text: `ID: ${eps.id}`
                    },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: 'quick_reply',
                                buttonParamsJson: JSON.stringify({
                                    display_text: `⬇️ Download`,
                                    id: `${prefix}nekodl ${eps.id}`
                                })
                            }
                        ]
                    }
                });
            }

            if (!cards.length) {
                return m.reply('Gagal memuat media episode.');
            }

            const interactiveMessage = {
                body: {
                    text: `📺 *SERI DETAIL*\n🎬 *Title:* ${data.title}\n📊 *Status:* ${meta.status}\n⏱️ *Durasi:* ${meta.durasi}\n📝 *Total Episode:* ${episodes.length}`
                },
                footer: {
                    text: `Pilih episode untuk mendownload`
                },
                carouselMessage: {
                    cards
                }
            };

            await Yudzxml.relayMessage(
                m.chat,
                {
                    viewOnceMessageV2Extension: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadata: {},
                                deviceListMetadataVersion: 2
                            },
                            interactiveMessage
                        }
                    }
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan internal saat mengambil detail seri.');
        }
    }
};

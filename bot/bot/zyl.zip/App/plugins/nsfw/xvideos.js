const axios = require('axios');
const { prepareWAMessageMedia } = require('baileys');

module.exports = {
    name: 'xvideos',
    category: 'nsfw',
    commands: ['xvideos'],
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,
    isPremium: true,
    async execute({ Yudzxml, m, text, config, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan kata kunci pencarian.\n\nContoh:\n*${prefix}xvideos uniform*`);
            }

            const endpoint = config?.apikey?.endpoint;
            const key = config?.apikey?.key;

            if (!endpoint || !key) {
                return m.reply('Konfigurasi API belum tersedia.');
            }

            const apiUrl = `${endpoint}/api/nsfw/xvideos/search?q=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await axios.get(apiUrl).catch(() => null);

            if (!res?.data || res.data.status !== 200 || !res.data.data) {
                return m.reply('Hasil pencarian tidak ditemukan.');
            }

            const videos = res.data.data;

            if (!videos.length) {
                return m.reply('Tidak ada video yang ditemukan.');
            }

            const cards = [];

            for (const video of videos.slice(0, 5)) {
                const thumbUrl = video.thumbnail;

                if (!thumbUrl) continue;

                const media = await prepareWAMessageMedia(
                    { image: { url: thumbUrl } },
                    { upload: Yudzxml.waUploadToServer }
                );

                const author = video.author ? video.author : 'Unknown';

                cards.push({
                    header: {
                        title: video.title || 'No Title',
                        hasMediaAttachment: true,
                        imageMessage: media.imageMessage
                    },
                    body: {
                        text: `👤 *Author:* ${author}\n⏱️ *Duration:* ${video.duration}`
                    },
                    footer: {
                        text: ''
                    },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: 'quick_reply',
                                buttonParamsJson: JSON.stringify({
                                    display_text: '🔗 Tonton Video',
                                    id: `${prefix}xvideosdl ${video.url}`
                                })
                            }
                        ]
                    }
                });
            }

            if (!cards.length) {
                return m.reply('Gagal memuat media thumbnail.');
            }

            const interactiveMessage = {
                body: {
                    text: `🔥 *XVIDEOS SEARCH*\n🔍 *Query:* ${text}\n📝 *Total Hasil:* ${videos.length} video`
                },
                footer: {
                    text: `Menampilkan ${cards.length} teratas`
                },
                carouselMessage: {
                    cards
                }
            };

            await Yudzxml.relayMessage(
                m.chat,
                {
                    viewOnceMessageV2Extension: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadata: {},
                                deviceListMetadataVersion: 2
                            },
                            interactiveMessage
                        }
                    }
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan internal saat mencari video.');
        }
    }
};

const axios = require('axios');
const { prepareWAMessageMedia } = require('baileys');

module.exports = {
    name: 'nekodl',
    category: 'nsfw',
    commands: ['nekodl'],
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,
    isPremium: true,
    async execute({ Yudzxml, m, text, config }) {
        try {
            if (!text) {
                return m.reply(`Masukkan ID episode Nekopoi.\n\nContoh:\n*.nekodl 54384*`);
            }

            const endpoint = config?.apikey?.endpoint;
            const key = config?.apikey?.key;

            if (!endpoint || !key) {
                return m.reply('Konfigurasi API belum tersedia.');
            }

            const id = text.trim();
            const apiUrl = `${endpoint}/api/nsfw/nekopoi/detail?id=${id}&apikey=${key}`;

            const res = await axios.get(apiUrl).catch(() => null);

            if (!res?.data || res.data.status !== 200 || !res.data.data) {
                return m.reply('Episode tidak ditemukan atau ID tidak valid.');
            }

            const data = res.data.data;
            const streamLinks = data.stream || [];
            const downloadLinks = data.download || [];

            let headerMedia;
            if (data.image) {
                try {
                    const prepared = await prepareWAMessageMedia(
                        { image: { url: data.image } },
                        { upload: Yudzxml.waUploadToServer }
                    );
                    headerMedia = prepared.imageMessage;
                } catch (e) {
                    console.error('Gagal upload thumbnail', e);
                }
            }

            const cards = [];

            if (streamLinks.length > 0) {
                const streamButtons = streamLinks.slice(0, 4).map((s, index) => ({
                    name: 'cta_url',
                    buttonParamsJson: JSON.stringify({
                        display_text: `▶️ Stream ${index + 1}`,
                        url: s.link
                    })
                }));

                cards.push({
                    header: {
                        title: '📺 STREAMING',
                        hasMediaAttachment: !!headerMedia,
                        imageMessage: headerMedia
                    },
                    body: {
                        text: `Judul: ${data.title}\n\n${data.streamnote || 'Klik tombol di bawah untuk streaming.'}`
                    },
                    footer: { text: 'Nekopoi Stream' },
                    nativeFlowMessage: { buttons: streamButtons }
                });
            }

            for (const quality of downloadLinks) {
                const qType = quality.type;

                const dlButtons = quality.links.slice(0, 4).map((host) => ({
                    name: 'cta_url',
                    buttonParamsJson: JSON.stringify({
                        display_text: `📥 ${host.name}`,
                        url: host.link
                    })
                }));

                if (dlButtons.length > 0) {
                    cards.push({
                        header: {
                            title: `⬇️ DOWNLOAD ${qType}P`,
                            hasMediaAttachment: !!headerMedia,
                            imageMessage: headerMedia
                        },
                        body: {
                            text: `Pilih server untuk download kualitas ${qType}p.\n\nSize Info: ${data.content.split('Size :')[1]?.split('\n')[0] || 'Check info'}`
                        },
                        footer: { text: `Quality: ${qType}p` },
                        nativeFlowMessage: { buttons: dlButtons }
                    });
                }
            }

            if (!cards.length) {
                return m.reply('Tidak ada link stream atau download yang tersedia.');
            }

            const interactiveMessage = {
                body: {
                    text: `🔞 *NEKOPOI DOWNLOAD*\n📺 *Title:* ${data.title}\n🆔 *ID:* ${data.id}\n\n📋 Silahkan swipe kartu untuk melihat pilihan Streaming dan Download berbagai kualitas.`
                },
                footer: {
                    text: 'Gunakan dengan bijak.'
                },
                carouselMessage: {
                    cards
                }
            };

            await Yudzxml.relayMessage(
                m.chat,
                {
                    viewOnceMessageV2Extension: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadata: {},
                                deviceListMetadataVersion: 2
                            },
                            interactiveMessage
                        }
                    }
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan internal saat mengambil link download.');
        }
    }
};

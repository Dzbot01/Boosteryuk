const axios = require('axios');
const { prepareWAMessageMedia } = require('baileys');

module.exports = {
    name: 'nekolatest',
    category: 'nsfw',
    commands: ['nekolatest'],
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,
    isPremium: true,
    async execute({ Yudzxml, m, text, config, prefix }) {
        try {
            const endpoint = config?.apikey?.endpoint;
            const key = config?.apikey?.key;

            if (!endpoint || !key) {
                return m.reply('Konfigurasi API belum tersedia.');
            }

            const apiUrl = `${endpoint}/api/nsfw/nekopoi/latest?apikey=${key}`;

            const res = await axios.get(apiUrl).catch(() => null);

            if (!res?.data || res.data.status !== 200 || !res.data.data || !res.data.data.carousel) {
                return m.reply('Gagal mengambil data terbaru dari Nekopoi.');
            }

            const items = res.data.data.carousel;

            if (!items.length) {
                return m.reply('Belum ada update terbaru.');
            }

            const cards = [];

            for (const item of items.slice(0, 5)) {
                const thumbUrl = item.image;

                if (!thumbUrl) continue;

                const media = await prepareWAMessageMedia(
                    { image: { url: thumbUrl } },
                    { upload: Yudzxml.waUploadToServer }
                );

                const desc = item.description
                    ? item.description.length > 150
                        ? item.description.substring(0, 150) + '...'
                        : item.description
                    : 'Tidak ada deskripsi.';

                cards.push({
                    header: {
                        title: item.title || 'No Title',
                        hasMediaAttachment: true,
                        imageMessage: media.imageMessage
                    },
                    body: {
                        text: `📅 *Date:* ${item.date}\n📝 *Synopsis:* ${desc}`
                    },
                    footer: {
                        text: ''
                    },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: 'quick_reply',
                                buttonParamsJson: JSON.stringify({
                                    display_text: '🔗 Baca Selengkapnya',
                                    url: `${prefix}nekodetail ${item.id}`
                                })
                            }
                        ]
                    }
                });
            }

            if (!cards.length) {
                return m.reply('Gagal memuat media thumbnail.');
            }

            const interactiveMessage = {
                body: {
                    text: `🌸 *NEKOPOI LATEST*\n📝 Update terbaru dari Nekopoi.`
                },
                footer: {
                    text: `Menampilkan ${cards.length} teratas`
                },
                carouselMessage: {
                    cards
                }
            };

            await Yudzxml.relayMessage(
                m.chat,
                {
                    viewOnceMessageV2Extension: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadata: {},
                                deviceListMetadataVersion: 2
                            },
                            interactiveMessage
                        }
                    }
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan internal saat mengambil data.');
        }
    }
};

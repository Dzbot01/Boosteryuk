const axios = require('axios');
const { prepareWAMessageMedia } = require('baileys');

module.exports = {
    name: 'nekopoi',
    category: 'nsfw',
    commands: ['neko', 'nekopoi'],
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,
    isPremium: true,
    async execute({ Yudzxml, m, text, config, prefix }) {
        try {
            if (!text) {
                return m.reply(`Masukkan kata kunci pencarian.\n\nContoh:\n*${prefix}nekopoi guilty*`);
            }

            const endpoint = config?.apikey?.endpoint;
            const key = config?.apikey?.key;

            if (!endpoint || !key) {
                return m.reply('Konfigurasi API belum tersedia.');
            }

            const page = 1;
            const query = text.trim();
            const apiUrl = `${endpoint}/api/nsfw/nekopoi/search?q=${encodeURIComponent(query)}&page=${page}&apikey=${key}`;

            const res = await axios.get(apiUrl).catch(() => null);

            if (!res?.data || res.data.status !== 200 || !res.data.data || !res.data.data.result) {
                return m.reply('Hasil pencarian tidak ditemukan.');
            }

            const results = res.data.data.result;
            const total = res.data.data.total;

            if (!results.length) {
                return m.reply('Tidak ada hasil yang cocok.');
            }

            const cards = [];

            for (const item of results.slice(0, 5)) {
                const thumbUrl = item.image;
                if (!thumbUrl) continue;

                const media = await prepareWAMessageMedia(
                    { image: { url: thumbUrl } },
                    { upload: Yudzxml.waUploadToServer }
                );

                const title = item.title.length > 50 ? item.title.substring(0, 50) + '...' : item.title;

                const type = item.type?.toLowerCase();

                const command = type === 'post' ? 'nekodl' : type === 'hentai' ? 'nekodetail' : 'nekodetail';

                cards.push({
                    header: {
                        title: title,
                        hasMediaAttachment: true,
                        imageMessage: media.imageMessage
                    },
                    body: {
                        text: `📅 *Date:* ${item.date}\n🏷️ *Type:* ${item.type.toUpperCase()}\n🆔 *ID:* ${item.id}`
                    },
                    footer: {
                        text: 'Nekopoi Search'
                    },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: 'quick_reply',
                                buttonParamsJson: JSON.stringify({
                                    display_text: '🔍 Lihat Detail',
                                    id: `${prefix}${command} ${item.id}`
                                })
                            }
                        ]
                    }
                });
            }

            if (!cards.length) {
                return m.reply('Gagal memuat media thumbnail.');
            }

            const interactiveMessage = {
                body: {
                    text: `🔞 *NEKOPOI SEARCH*\n🔍 *Query:* ${query}\n📝 *Total Hasil:* ${total} ditemukan`
                },
                footer: {
                    text: `Menampilkan ${cards.length} teratas`
                },
                carouselMessage: {
                    cards
                }
            };

            await Yudzxml.relayMessage(
                m.chat,
                {
                    viewOnceMessageV2Extension: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadata: {},
                                deviceListMetadataVersion: 2
                            },
                            interactiveMessage
                        }
                    }
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan internal saat mencari.');
        }
    }
};

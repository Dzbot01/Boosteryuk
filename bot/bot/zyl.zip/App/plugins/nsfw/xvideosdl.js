const axios = require('axios');

module.exports = {
    name: 'xvideosdl',
    category: 'nsfw',
    commands: ['xvideosdl'],
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,
    isPremium: true,
    async execute({ Yudzxml, m, text, config, prefix }) {
        try {
            if (!text) {
                return m.reply(
                    `Masukkan URL video XVideos yang valid.\n\nContoh:\n*${prefix}xvideosdl https://www.xvideos.com/videoxxxx*`
                );
            }

            const url = text.trim();

            const endpoint = config?.apikey?.endpoint;
            const key = config?.apikey?.key;

            if (!endpoint || !key) {
                return m.reply('Konfigurasi API belum tersedia.');
            }

            const apiUrl = `${endpoint}/api/nsfw/xvideos/detail?url=${encodeURIComponent(url)}&apikey=${key}`;

            const res = await axios.get(apiUrl).catch(() => null);

            if (!res?.data || res.data.status !== 200 || !res.data.data) {
                return m.reply('Gagal mengambil data video. Pastikan URL valid atau coba lagi nanti.');
            }

            const result = res.data.data;

            const videoUrl = result.contentUrl;

            if (!videoUrl) {
                return m.reply('Link video tidak tersedia dari API.');
            }

            const title = result.name || 'Tanpa Judul';
            const duration = result.duration || '-';
            const views = result.interactionStatistic?.userInteractionCount || '0';

            const caption = `✅ *Berhasil Didownload*
🎬 *Judul:* ${title}
⏱️ *Durasi:* ${duration}
👁️ *Views:* ${views}
🔗 *Source:* ${url}`;

            await Yudzxml.sendMessage(
                m.sender,
                {
                    video: { url: videoUrl },
                    caption: caption,
                    mimetype: 'video/mp4'
                },
                { quoted: m }
            );

            m.reply('Video dikirim ke chat pribadi bot. Cek inbox, jangan pura-pura polos.');
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan saat mengirim video.');
        }
    }
};

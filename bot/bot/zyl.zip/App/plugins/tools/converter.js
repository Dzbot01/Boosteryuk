const axios = require('axios');

module.exports = {
    name: 'converter',
    category: 'tools',
    commands: ['tomp4', 'tomp3', 'toptt', 'topng', 'tojpg', 'togif', 'towebp', 'tovn'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,

    async execute({ Yudzxml, m, command, config, YudzCdn }) {
        const id = m.chat;

        try {
            const { endpoint, key } = config.apikey;

            const normalizeCommand = (cmd) => {
                const base = cmd.replace(/^to/i, '').toLowerCase();
                return { vn: 'opus', ptt: 'opus' }[base] || base;
            };

            const to = normalizeCommand(command);

            let buffer = null;
            try {
                buffer = await m.download();
            } catch (e) {
                buffer = await m.quoted?.download();
            }

            if (!buffer) return m.reply('Reply media dulu!');

            const url = await YudzCdn(buffer, 'expired');
            const ext = (url.split('.').pop() || '').split('?')[0];

            const apiUrl = `${endpoint}/api/tools/converter?url=${encodeURIComponent(
                url
            )}&from=${ext}&to=${to}&apikey=${key}`;

            const { data } = await axios.get(apiUrl, {
                responseType: 'arraybuffer'
            });

            const resultBuffer = Buffer.from(data);
            const caption = config.mess.success;

            if (command === 'togif') {
                return Yudzxml.sendMessage(
                    id,
                    {
                        video: resultBuffer,
                        gifPlayback: true,
                        caption
                    },
                    { quoted: m }
                );
            }

            if (to === 'mp3' || to === 'opus') {
                return Yudzxml.sendMessage(
                    id,
                    {
                        audio: resultBuffer,
                        ptt: command === 'tovn' || command === 'toptt'
                    },
                    { quoted: m }
                );
            }

            if (['png', 'jpg', 'webp'].includes(to)) {
                return Yudzxml.sendMessage(
                    id,
                    {
                        image: resultBuffer,
                        caption
                    },
                    { quoted: m }
                );
            }

            return Yudzxml.sendMessage(
                id,
                {
                    video: resultBuffer,
                    caption
                },
                { quoted: m }
            );
        } catch (err) {
            console.error('CONVERTER ERROR:', err);
            return m.reply('Converter error');
        }
    }
};

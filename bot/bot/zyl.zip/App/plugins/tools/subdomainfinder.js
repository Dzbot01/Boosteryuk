const axios = require('axios');

module.exports = {
    name: 'subdomainfinder',
    category: 'tools',
    commands: ['subdofinder'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, config }) {
        const id = m.chat;

        if (!text) {
            return Yudzxml.sendMessage(
                id,
                {
                    text: '❌ Masukkan domain.\nContoh:\n.subdomain facebook.com'
                },
                { quoted: m }
            );
        }

        try {
            const { endpoint, key } = config.apikey;

            const res = await axios.get(`${endpoint}/api/tools/subdomainfinder`, {
                params: {
                    host: text.trim(),
                    apikey: key
                }
            });

            const data = res.data?.data;
            if (!Array.isArray(data) || data.length === 0) {
                throw new Error('Subdomain tidak ditemukan');
            }

            const total = data.length;
            const preview = data.slice(0, 30);

            let msg = `🌐 *SUBDOMAIN FINDER*\n`;
            msg += `🔎 Host: ${text}\n`;
            msg += `📊 Total ditemukan: ${total}\n\n`;

            preview.forEach((d, i) => {
                msg += `${i + 1}. ${d}\n`;
            });

            if (total > preview.length) {
                msg += `\n…dan ${total - preview.length} subdomain lainnya.`;
                msg += `\nGunakan *mode file* untuk full list.`;
            }

            await Yudzxml.sendMessage(id, { text: msg.trim() }, { quoted: m });
        } catch (err) {
            console.error(err);
            await Yudzxml.sendMessage(id, { text: '❌ Gagal mencari subdomain.' }, { quoted: m });
        }
    }
};

const axios = require('axios');
const fs = require('fs');

module.exports = {
    name: 'whatmusic',
    category: 'tools',
    commands: ['whatmusic', 'wmusic', 'findsong'],
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,

    async execute({ Yudzxml, m, isAudio, quoted, YudzCdn, config }) {
        const id = m.chat;

        try {
            if (!isAudio) {
                return m.reply('❌ Kirim atau reply audio untuk mendeteksi lagu.\n\nContoh:\n.whatmusic');
            }

            const target = quoted || m;
            const mediaPath = await Yudzxml.downloadAndSaveMediaMessage(target);
            const fileUrl = await YudzCdn(mediaPath, 'expired');
            fs.unlinkSync(mediaPath);

            const { endpoint, key } = config.apikey;

            const res = await axios.get(`${endpoint}/api/tools/whatmusic`, {
                params: {
                    url: fileUrl,
                    apikey: key
                },
                timeout: 60000
            });

            const result = res.data?.data;
            if (!result || !result.best_match) {
                throw new Error('Lagu tidak ditemukan');
            }

            const best = result.best_match;
            let text = `🎧 *WhatMusic Result*\n\n`;
            text += `📀 *Judul:* ${best.title}\n`;
            text += `🎤 *Artist:* ${best.artist}\n`;
            text += `⭐ *Score:* ${best.score}%\n`;
            text += `📅 *Release:* ${best.release}\n`;
            text += `⏱️ *Durasi:* ${best.duration}\n\n`;

            text += `🔗 *Link Musik:*\n`;
            if (best.youtube) text += `▶️ YouTube: ${best.youtube}\n`;
            if (best.spotify) text += `🎧 Spotify: ${best.spotify}\n`;
            if (best.deezer) text += `🎵 Deezer: ${best.deezer}\n`;

            if (result.raw && result.raw.length > 1) {
                text += `\n📊 *Kemungkinan Lain:*\n`;
                result.raw.slice(1, 3).forEach((item, i) => {
                    text += `\n${i + 1}. ${item.title} — ${item.artist} (${item.score}%)`;
                });
            }

            await m.reply(text);
        } catch (err) {
            console.error(err);
            await m.reply('❌ Gagal mendeteksi lagu. Coba kirim audio yang lebih jelas.');
        }
    }
};

const axios = require('axios');

module.exports = {
    name: 'ssweb',
    category: 'tools',
    commands: ['ssweb'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, config }) {
        const id = m.chat;

        try {
            const args = text?.trim().split(' ') || [];

            if (!args[0] || !args[0].startsWith('http')) {
                return Yudzxml.sendMessage(
                    id,
                    {
                        text: '❌ Masukkan URL website yang valid. Contoh:\n.ssweb https://example.com phone'
                    },
                    { quoted: m }
                );
            }

            const url = args[0];
            const device = args[1] || 'desktop';
            const allowed = ['phone', 'tablet', 'desktop'];

            if (!allowed.includes(device)) {
                return Yudzxml.sendMessage(
                    id,
                    {
                        text: '❌ Device harus salah satu: phone, tablet, desktop'
                    },
                    { quoted: m }
                );
            }

            const { endpoint, key } = config.apikey;

            const response = await axios.get(`${endpoint}/api/tools/ssweb`, {
                params: {
                    url,
                    device,
                    apikey: key
                },
                responseType: 'arraybuffer'
            });

            const buffer = Buffer.from(response.data);

            await Yudzxml.sendMessage(
                id,
                {
                    image: buffer,
                    caption: `📸 Screenshot: ${url}\n🎛️ Device: ${device}`
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            await Yudzxml.sendMessage(id, { text: '❌ Gagal mengambil screenshot website.' }, { quoted: m });
        }
    }
};

const axios = require('axios');

module.exports = {
    name: '2fa',
    category: 'tools',
    commands: ['2fa'],
    isOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ m, text, config, Yudzxml, proto }) {
        try {
            const { endpoint, key } = config.apikey;
            const query = text ? encodeURIComponent(text) : '';
            const url = `${endpoint}/api/tools/2fa?q=${query}&apikey=${key}`;

            const res = await axios.get(url);
            const result = res.data;

            if (!result || result.status !== 200 || !result.data) {
                return m.reply('❌ Gagal menghasilkan kode 2FA.');
            }

            const otp = String(result.data);

            const caption = `
🔐 *2FA AUTH TOKEN*

📟 *Kode OTP*
${otp}

⚠️ Gunakan segera.
Jangan bagikan ke siapa pun, kecuali ke diri sendiri yang lupa. 😄
`.trim();

            const interactiveMsg = proto.Message.InteractiveMessage.create({
                header: proto.Message.InteractiveMessage.Header.create({
                    title: '🔐 TWO-FACTOR AUTHENTICATION',
                    hasMediaAttachment: false
                }),

                body: proto.Message.InteractiveMessage.Body.create({
                    text: caption
                }),

                footer: proto.Message.InteractiveMessage.Footer.create({
                    text: config.botname
                }),

                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                    buttons: [
                        {
                            name: 'cta_copy',
                            buttonParamsJson: JSON.stringify({
                                display_text: '📋 Copy Kode OTP',
                                copy_code: otp
                            })
                        }
                    ]
                })
            });

            await Yudzxml.relayMessage(
                m.chat,
                {
                    viewOnceMessageV2Extension: {
                        message: {
                            interactiveMessage: interactiveMsg
                        }
                    }
                },
                { quoted: m }
            );
        } catch (err) {
            console.error('[2FA ERROR]', err);
            m.reply('⚠️ Terjadi kesalahan saat membuat kode 2FA.');
        }
    }
};

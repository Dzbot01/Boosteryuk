const logger = require('@App/function/logger');

module.exports = {
    name: 'cekidch',
    category: 'tools',
    commands: ['cekidch', 'infoidch'],
    isOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ Yudzxml, m, args, prefix, command, config, proto, prepareWAMessageMedia }) {
        let inviteCode = '';

        const extractInvite = (input = '') => {
            if (!input) return null;
            const clean = input.trim();
            const last = clean.split('/').pop();
            return /^[0-9A-Za-z]+$/.test(last) ? last : null;
        };

        if (args[0]) inviteCode = extractInvite(args[0]);
        else if (m.quoted?.text) inviteCode = extractInvite(m.quoted.text);

        if (!inviteCode) {
            return m.reply(
                `📌 *Cara Penggunaan:*\n\n` +
                    `${prefix + command} <link/kode channel>\n` +
                    `Atau reply pesan channel dengan perintah ${prefix + command}`
            );
        }

        try {
            const meta = await Yudzxml.newsletterMetadata('invite', inviteCode);
            if (!meta || !meta.thread_metadata) {
                throw new Error('Metadata tidak valid');
            }

            const { id, state, thread_metadata } = meta;

            const {
                creation_time,
                description,
                invite,
                name,
                picture,
                preview,
                settings,
                subscribers_count,
                verification
            } = thread_metadata;

            const reaction_codes = settings?.reaction_codes?.value || 'UNKNOWN';

            const thumb = preview?.direct_path
                ? `https://mmg.whatsapp.net${preview.direct_path}`
                : picture
                  ? `https://mmg.whatsapp.net${picture}`
                  : 'https://telegra.ph/file/6880771a42bad09dd6087.jpg';

            const text = `
━━〔 *CHANNEL METADATA* 〕━━

📢 *Nama Channel*
${name?.text || 'Tidak diketahui'}

🆔 *ID Channel*
${id}

📌 *Status*        : ${state?.type || 'UNKNOWN'}
👥 *Subscriber*   : ${subscribers_count || 0}
🛡️ *Verifikasi*   : ${verification || 'UNKNOWN'}
🎭 *Reaction*     : ${reaction_codes}
📅 *Dibuat*
${creation_time ? new Date(Number(creation_time) * 1000).toLocaleString('id-ID') : 'N/A'}

📝 *Deskripsi Channel*
${description?.text || '-'}

🔗 *Invite Code*
${invite}

━━〔 *INFO* 〕━━
_Source By ${config.botname}_
`.trim();

            const media = await prepareWAMessageMedia({ image: { url: thumb } }, { upload: Yudzxml.waUploadToServer });

            const interactiveMsg = proto.Message.InteractiveMessage.create({
                header: proto.Message.InteractiveMessage.Header.create({
                    title: '📡 CHANNEL INFORMATION',
                    hasMediaAttachment: true,
                    imageMessage: media.imageMessage
                }),

                body: proto.Message.InteractiveMessage.Body.create({
                    text
                }),

                footer: proto.Message.InteractiveMessage.Footer.create({
                    text: config.botname
                }),

                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                    buttons: [
                        {
                            name: 'cta_copy',
                            buttonParamsJson: JSON.stringify({
                                display_text: '🆔 Copy Channel ID',
                                copy_code: id
                            })
                        },
                        {
                            name: 'cta_copy',
                            buttonParamsJson: JSON.stringify({
                                display_text: '🔗 Copy Invite Code',
                                copy_code: invite
                            })
                        }
                    ]
                })
            });

            await Yudzxml.relayMessage(
                m.chat,
                {
                    viewOnceMessageV2Extension: {
                        message: {
                            interactiveMessage: interactiveMsg
                        }
                    }
                },
                { quoted: m }
            );
        } catch (err) {
            logger.error('[CEKIDCH] ' + (err?.message || err));
            return m.reply('❌ Gagal mengambil metadata channel.\n' + 'Invite tidak valid atau akses dibatasi.');
        }
    }
};

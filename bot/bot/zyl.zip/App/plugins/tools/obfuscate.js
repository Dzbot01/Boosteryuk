const axios = require('axios');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: 'obfuscate',
    category: 'tools',
    commands: ['enc', 'obfuscate', 'obf'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,

    async execute({ Yudzxml, m, text, quoted, YudzCdn, config }) {
        const id = m.chat;

        try {
            if (!text && !quoted) {
                return m.reply(
                    '🔒 *Obfuscate JS*\n\n' +
                        '1️⃣ `.obf low console.log("halo")`\n' +
                        '2️⃣ `.obf medium https://example.com/file.js`\n' +
                        '3️⃣ Reply file .js dengan `.obf hard`\n\n' +
                        'Level: low | medium | hard | extreme'
                );
            }

            const args = text ? text.split(' ').filter(Boolean) : [];
            const levelList = ['low', 'medium', 'hard', 'extreme'];
            let level = 'low';

            if (args[0] && levelList.includes(args[0].toLowerCase())) {
                level = args.shift().toLowerCase();
            }

            let targetUrl;
            let tempFilePath;

            if (args.length > 0 && !args[0].startsWith('http')) {
                const rawCode = args.join(' ');
                const tempName = `temp-${Date.now()}.js`;
                tempFilePath = path.join(__dirname, tempName);
                fs.writeFileSync(tempFilePath, rawCode);
                targetUrl = await YudzCdn(tempFilePath, 'expired');
                fs.unlinkSync(tempFilePath);
            }

            if (!targetUrl && args[0]?.startsWith('http')) {
                targetUrl = args[0];
            }

            if (!targetUrl && quoted) {
                const mime = quoted.mimetype || '';
                if (!mime.includes('javascript') && !mime.includes('text')) {
                    return m.reply('❌ Reply file .js yang valid.');
                }

                const mediaPath = await Yudzxml.downloadAndSaveMediaMessage(quoted);
                targetUrl = await YudzCdn(mediaPath, 'expired');
                fs.unlinkSync(mediaPath);
            }

            if (!targetUrl) {
                return m.reply('❌ Tidak ditemukan kode / URL / file untuk di obfuscate.');
            }

            const { endpoint, key } = config.apikey;

            const res = await axios.get(`${endpoint}/api/tools/obfuscate`, {
                params: {
                    url: targetUrl,
                    type: level,
                    apikey: key
                }
            });

            const data = res.data?.data;

            if (!data?.success || !data.code) {
                throw new Error('Obfuscate gagal');
            }

            const filename = `obfuscated-${level}-${Date.now()}.js`;
            const filepath = path.join(__dirname, filename);

            fs.writeFileSync(filepath, data.code);

            await Yudzxml.sendMessage(
                id,
                {
                    document: fs.readFileSync(filepath),
                    fileName: filename,
                    mimetype: 'application/javascript',
                    caption:
                        '🔒 *Obfuscate Berhasil*\n\n' +
                        `Level: *${data.level || level}*\n` +
                        `Size: *${data.size || data.code.length} bytes*`
                },
                { quoted: m }
            );

            fs.unlinkSync(filepath);
        } catch (err) {
            console.error(err);
            m.reply('❌ Gagal melakukan obfuscate file.');
        }
    }
};

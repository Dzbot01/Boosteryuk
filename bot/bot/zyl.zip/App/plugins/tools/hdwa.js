const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

let ffprobePath = 'ffprobe';
try {
    ffprobePath = require('ffprobe-static').path;
} catch (_) {}

function getDuration(filePath) {
    return new Promise((resolve, reject) => {
        const proc = spawn(ffprobePath, [
            '-v',
            'error',
            '-show_entries',
            'format=duration',
            '-of',
            'default=noprint_wrappers=1:nokey=1',
            filePath
        ]);

        let data = '';

        proc.stdout.on('data', (chunk) => {
            data += chunk.toString();
        });

        proc.on('close', () => {
            resolve(parseFloat(data));
        });

        proc.on('error', reject);
    });
}

function runFFmpeg(input, output, scale) {
    return new Promise((resolve, reject) => {
        const args = [
            '-i',
            input,
            '-vf',
            scale,
            '-c:v',
            'libx264',
            '-preset',
            'slow',
            '-crf',
            '18',
            '-pix_fmt',
            'yuv420p',
            '-profile:v',
            'high',
            '-level',
            '4.1',
            '-c:a',
            'aac',
            '-b:a',
            '192k',
            '-movflags',
            '+faststart',
            output
        ];

        const ff = spawn('ffmpeg', args);

        ff.on('close', (code) => {
            if (code === 0) resolve(output);
            else reject(new Error('FFMPEG_ERROR'));
        });

        ff.on('error', reject);
    });
}

async function optimizeWhatsAppVideo(input, output) {
    const duration = await getDuration(input);

    if (duration > 60) {
        throw new Error('DURATION_LIMIT');
    }

    const scale = duration <= 30 ? "scale='min(1920,iw)':-2" : "scale='min(1280,iw)':-2";

    return await runFFmpeg(input, output, scale);
}

module.exports = {
    name: 'hdwa',
    category: 'tools',
    commands: ['hdwa'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    isPremium: true,

    async execute({ Yudzxml, m, isVideo }) {
        const inputPath = path.join(process.cwd(), 'tmp', `input_${Date.now()}.mp4`);
        const outputPath = path.join(process.cwd(), 'tmp', `output_${Date.now()}.mp4`);

        try {
            if (!isVideo && !m.quoted) {
                return m.reply(
                    '❌ Kirim atau reply video dulu, disarankan kirim video dalam bentuk document dengan caption .hdwa'
                );
            }

            const buffer = await (m.download ? m.download() : m.quoted.download());
            fs.writeFileSync(inputPath, buffer);

            let resultPath;

            try {
                resultPath = await optimizeWhatsAppVideo(inputPath, outputPath);
            } catch (err) {
                if (err.message === 'DURATION_LIMIT') {
                    return m.reply('❌ Minimal durasi video harus di bawah 1 menit');
                }
                throw err;
            }

            await Yudzxml.sendMessage(m.chat, {
                video: fs.readFileSync(resultPath),
                mimetype: 'video/mp4',
                caption: `✅ Video berhasil Kompress

ℹ️ Informasi Penting
Harap jangan *memotong* atau *mengedit* ulang video agar kualitas tetap optimal.

📌 Cara upload ke Status WhatsApp:
1. Tekan dan tahan video
2. Pilih "Bagikan"
3. Pilih WhatsApp
4. Pilih "Status Saya"
5. Tunggu hingga proses upload selesai

Thanks for using this feature ✨`
            });
        } catch (err) {
            console.error(err);
            m.reply('❌ Gagal proses video');
        } finally {
            if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath);
            if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
        }
    }
};

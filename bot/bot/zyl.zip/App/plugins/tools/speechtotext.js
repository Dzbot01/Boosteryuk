const axios = require('axios');
const fs = require('fs');

module.exports = {
    name: 'spechtotext',
    category: 'tools',
    commands: ['speechtotext'],
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,
    async execute({ Yudzxml, m, isMedia, quoted, YudzCdn, config }) {
        const id = m.chat;

        try {
            if (!isMedia && !quoted) {
                return Yudzxml.sendMessage(
                    id,
                    {
                        text: '❌ Kirim atau reply audio/voice untuk ditranskrip.\n\nContoh:\n.stt'
                    },
                    { quoted: m }
                );
            }

            const target = quoted || m;
            const mediaPath = await Yudzxml.downloadAndSaveMediaMessage(target);
            const audioUrl = await YudzCdn(mediaPath, 'expired');

            fs.unlinkSync(mediaPath);

            const { endpoint, key } = config.apikey;

            const res = await axios.get(`${endpoint}/api/tools/spechtotext`, {
                params: {
                    url: audioUrl,
                    apikey: key
                }
            });

            const textResult = res.data?.data;
            if (!textResult || typeof textResult !== 'string') {
                throw new Error('Transkripsi gagal');
            }

            await Yudzxml.sendMessage(id, { text: `🗣️ *Hasil Transkripsi:* \n\n${textResult}` }, { quoted: m });
        } catch (err) {
            console.error(err);
            await Yudzxml.sendMessage(id, { text: '❌ Gagal mentranskripsikan audio.' }, { quoted: m });
        }
    }
};

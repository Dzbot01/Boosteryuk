const axios = require('axios');

const BLOCKED_HOSTS = [
    'localhost',
    '127.0.0.1',
    '0.0.0.0',
    '10.',
    '172.16.',
    '172.17.',
    '172.18.',
    '172.19.',
    '172.20.',
    '172.21.',
    '172.22.',
    '172.23.',
    '172.24.',
    '172.25.',
    '172.26.',
    '172.27.',
    '172.28.',
    '172.29.',
    '172.30.',
    '172.31.',
    '192.168.',
    '169.254.',
    '::1',
    'fe80::',
    'fc00::'
];

function isBlockedUrl(url) {
    try {
        const parsed = new URL(url);
        const host = parsed.hostname.toLowerCase();
        return BLOCKED_HOSTS.some((b) => host === b || host.startsWith(b));
    } catch {
        return true;
    }
}

module.exports = {
    name: 'get',
    category: 'tools',
    commands: ['get'],
    description: 'Mengambil konten dari URL (auto MIME handler)',
    isGroup: false,
    isAdmin: false,
    isOwner: false,
    isPremium: true,
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ m, Yudzxml, text, command, prefix }) {
        if (!text) {
            return Yudzxml.sendMessage(m.chat, { text: `${prefix + command} https://google.com` }, { quoted: m });
        }

        if (isBlockedUrl(text)) {
            return m.reply('❌ URL tidak diizinkan (akses internal diblokir).');
        }

        try {
            const res = await axios.get(text, {
                headers: {
                    accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
                    'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
                    'cache-control': 'no-cache',
                    pragma: 'no-cache',
                    referer: 'https://www.google.com/',
                    'user-agent':
                        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116 Safari/537.36'
                },
                responseType: 'arraybuffer',
                timeout: 15000,
                maxRedirects: 5
            });

            const contentType = res.headers['content-type'] || '';
            const buffer = Buffer.from(res.data);

            if (/json/i.test(contentType)) {
                const json = JSON.parse(buffer.toString('utf8'));
                const jsonStr = JSON.stringify(json, null, 2);
                return Yudzxml.sendMessage(
                    m.chat,
                    { text: jsonStr.length > 5000 ? jsonStr.slice(0, 5000) + '\n\n... (truncated)' : jsonStr },
                    { quoted: m }
                );
            }

            if (/text\/html/i.test(contentType)) {
                let htmlContent = buffer.toString('utf8');
                const MAX_HTML = 5000;
                if (htmlContent.length > MAX_HTML) {
                    htmlContent =
                        htmlContent.slice(0, MAX_HTML) + '\n\n... (truncated, ' + buffer.length + ' bytes total)';
                }
                return Yudzxml.sendMessage(m.chat, { text: htmlContent }, { quoted: m });
            }

            if (/image\/webp/i.test(contentType) || text.endsWith('.webp')) {
                return Yudzxml.sendMessage(m.chat, { sticker: buffer }, { quoted: m });
            }

            if (/image/i.test(contentType)) {
                return Yudzxml.sendMessage(
                    m.chat,
                    {
                        image: buffer,
                        caption: `🖼️ Type: ${contentType}`
                    },
                    { quoted: m }
                );
            }

            if (/video/i.test(contentType)) {
                return Yudzxml.sendMessage(
                    m.chat,
                    {
                        video: buffer,
                        caption: `🎥 Type: ${contentType}`
                    },
                    { quoted: m }
                );
            }

            if (/audio/i.test(contentType) || text.endsWith('.mp3')) {
                return Yudzxml.sendMessage(
                    m.chat,
                    {
                        audio: buffer,
                        mimetype: 'audio/mp4',
                        ptt: false
                    },
                    { quoted: m }
                );
            }

            if (/application\/zip|application\/x-zip-compressed/i.test(contentType)) {
                return Yudzxml.sendMessage(
                    m.chat,
                    {
                        document: buffer,
                        fileName: 'file.zip',
                        mimetype: contentType
                    },
                    { quoted: m }
                );
            }

            if (/application\/pdf/i.test(contentType)) {
                return Yudzxml.sendMessage(
                    m.chat,
                    {
                        document: buffer,
                        fileName: 'file.pdf',
                        mimetype: contentType
                    },
                    { quoted: m }
                );
            }

            let fallbackText = `MIME : ${contentType}\n\n${buffer.toString('utf8')}`;
            if (fallbackText.length > 5000) {
                fallbackText = fallbackText.slice(0, 5000) + '\n\n... (truncated)';
            }
            return Yudzxml.sendMessage(m.chat, { text: fallbackText }, { quoted: m });
        } catch (err) {
            console.error('[GET ERROR]', err);
            return Yudzxml.sendMessage(
                m.chat,
                {
                    text: `❌ Terjadi kesalahan saat mengakses URL:\n${err.message}`
                },
                { quoted: m }
            );
        }
    }
};

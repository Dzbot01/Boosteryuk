const axios = require('axios');

module.exports = {
    name: 'shorturl',
    category: 'tools',
    commands: ['shorturl'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ Yudzxml, m, text, config }) {
        const chatId = m.chat;

        if (!text) {
            return Yudzxml.sendMessage(
                chatId,
                {
                    text: 'Masukkan URL yang ingin dipendekkan.\nContoh: .shorturl https://google.com'
                },
                { quoted: m }
            );
        }

        try {
            const { endpoint, key } = config.apikey;

            const res = await axios.get(`${endpoint}/api/tools/shorturl`, {
                params: {
                    url: text,
                    apikey: key
                },
                timeout: 15000
            });

            if (!res.data || res.data.status !== 200) {
                throw new Error('Url di banned dari platform, silahkan input url lain');
            }

            const data = res.data.data;
            const shortUrl = data.short;
            const originalUrl = data.original;
            const host = data.host;

            const messageText =
                `🔗 *SHORT URL BERHASIL*\n\n` +
                `🌐 Host : ${host}\n` +
                `📎 Original : ${originalUrl}\n` +
                `⚡ Short : ${shortUrl}`;

            await Yudzxml.sendMessage(
                chatId,
                {
                    text: messageText
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);

            await Yudzxml.sendMessage(
                chatId,
                {
                    text: '❌ Gagal membuat short URL. Pastikan link valid.'
                },
                { quoted: m }
            );
        }
    }
};

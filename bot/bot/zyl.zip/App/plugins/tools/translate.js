const axios = require('axios');

module.exports = {
    name: 'translate',
    category: 'tools',
    commands: ['translate', 'tr', 'terjemahan'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ Yudzxml, m, args, text, config }) {
        const id = m.chat;

        const languages = {
            Abkhaz: 'ab',
            Aceh: 'ace',
            Acholi: 'ach',
            Afrika: 'af',
            Albania: 'sq',
            Alur: 'alz',
            Amhara: 'am',
            Arabic: 'ar',
            Armenia: 'hy',
            Assam: 'as',
            Awadhi: 'awa',
            Aymara: 'ay',
            Azerbaijani: 'az',
            Bali: 'ban',
            Bambara: 'bm',
            Bashkir: 'ba',
            Basque: 'eu',
            'Batak Karo': 'btx',
            'Batak Simalungun': 'bts',
            'Batak Toba': 'bbc',
            Belarusia: 'be',
            Bemba: 'bem',
            Bengali: 'bn',
            Betawi: 'bew',
            Bhojpuri: 'bho',
            Bikol: 'bik',
            Bosnia: 'bs',
            Breton: 'br',
            Bulgaria: 'bg',
            Buryat: 'bua',
            Kanton: 'yue',
            Catalan: 'ca',
            Cebu: 'ceb',
            'Chichewa (Nyanja)': 'ny',
            'China (Aksara Sederhana)': 'zh-CN',
            'China (Aksara Tradisional)': 'zh-TW',
            Chuvash: 'cv',
            Korsika: 'co',
            'Crimean Tatar': 'crh',
            Kroasia: 'hr',
            Ceko: 'cs',
            Denmark: 'da',
            Dinka: 'din',
            Divehi: 'dv',
            Dogri: 'doi',
            Dombe: 'dov',
            Belanda: 'nl',
            Dzongkha: 'dz',
            Inggris: 'en',
            Esperanto: 'eo',
            Estonia: 'et',
            Ewe: 'ee',
            Fiji: 'fj',
            'Filipino (Tagalog)': 'fil',
            Finlandia: 'fi',
            Prancis: 'fr',
            'Prancis (Prancis)': 'fr-FR',
            'Prancis (Kanada)': 'fr-CA',
            Frisian: 'fy',
            Fulfulde: 'ff',
            Ga: 'gaa',
            Galisia: 'gl',
            'Ganda (Luganda)': 'lg',
            Georgia: 'ka',
            Jerman: 'de',
            Yunani: 'el',
            Guarani: 'gn',
            Gujarati: 'gu',
            'Kreol Haiti': 'ht',
            'Hakha Chin': 'cnh',
            Hausa: 'ha',
            Hawaii: 'haw',
            Ibrani: 'he',
            Hiligaynon: 'hil',
            Hindi: 'hi',
            Hmong: 'hmn',
            Hungaria: 'hu',
            Hunsrik: 'hrx',
            Islan: 'is',
            Igbo: 'ig',
            Iloko: 'ilo',
            Indonesia: 'id',
            Irlandia: 'ga',
            Italia: 'it',
            Jepang: 'ja',
            Jawa: 'jv',
            Kannada: 'kn',
            Kapampangan: 'pam',
            Kazakh: 'kk',
            Khmer: 'km',
            Kiga: 'cgg',
            Kinyarwanda: 'rw',
            Kituba: 'ktu',
            Konkani: 'gom',
            Korean: 'ko',
            Krio: 'kri',
            'Kurdi (Kurmanji)': 'ku',
            'Kurdi (Sorani)': 'ckb',
            Kyrgyz: 'ky',
            Laos: 'lo',
            Latgalia: 'ltg',
            Latin: 'la',
            Latvia: 'lv',
            Liguria: 'lij',
            Limburgia: 'li',
            Lingala: 'ln',
            Lituania: 'lt',
            Lombard: 'lmo',
            Luo: 'luo',
            Luksemburg: 'lb',
            Makedonia: 'mk',
            Maithili: 'mai',
            Makassar: 'mak',
            Malagasi: 'mg',
            Melayu: 'ms',
            'Melayu (Jawi)': 'ms-Arab',
            Malayalam: 'ml',
            Malta: 'mt',
            Maori: 'mi',
            Marathi: 'mr',
            'Meadow Mari': 'chm',
            'Meitei (Manipur)': 'mni-Mtei',
            Minang: 'min',
            Mizo: 'lus',
            Mongolia: 'mn',
            'Myanmar (Burma)': 'my',
            'Ndebele (Selatan)': 'nr',
            'Nepal Bhasa (Newari)': 'new',
            Nepal: 'ne',
            'Sotho Utara (Sepedi)': 'nso',
            Norwegia: 'no',
            Nuer: 'nus',
            Occitan: 'oc',
            'Odia (Oriya)': 'or',
            Oromo: 'om',
            Pangasinan: 'pag',
            Papiamento: 'pap',
            Pashto: 'ps',
            Persia: 'fa',
            Polski: 'pl',
            Portugis: 'pt',
            'Portugis (Portugal)': 'pt-PT',
            'Portugis (Brasil)': 'pt-BR',
            Punjabi: 'pa',
            'Punjabi (Shahmukhi)': 'pa-Arab',
            Quechua: 'qu',
            Rumania: 'ro',
            Rundi: 'rn',
            Rusia: 'ru',
            Samoa: 'sm',
            Sango: 'sg',
            Sanskrit: 'sa',
            'Gaelik Skotlandia': 'gd',
            Serbia: 'sr',
            Sesotho: 'st',
            'Kreol Seychelles': 'crs',
            'Kreol Mauritius': 'mfe',
            Sunda: 'su',
            Swahili: 'sw',
            Swedia: 'sv',
            Tagalog: 'tl',
            Tajik: 'tg',
            Tamil: 'ta',
            Tatar: 'tt',
            Telugu: 'te',
            Thai: 'th',
            Tibet: 'bo',
            Tigrinya: 'ti',
            Turki: 'tr',
            Turkmen: 'tk',
            Ukraina: 'uk',
            Urdu: 'ur',
            Uzbek: 'uz',
            Vietnam: 'vi',
            Welsh: 'cy',
            Wolof: 'wo',
            Xhosa: 'xh',
            Yoruba: 'yo',
            Zulu: 'zu'
        };

        const langNameByCode = Object.fromEntries(Object.entries(languages).map(([name, code]) => [code, name]));

        try {
            if (!text) {
                let helpText = '❌ Harap masukkan teks atau kode bahasa.\n\n';
                helpText += 'Contoh:\n';
                helpText += '1. .translate Halo apa kabar (Otomatis ke Indonesia)\n';
                helpText += '2. .translate en Halo apa kabar (Ke Inggris)\n';
                helpText += '3. .translate ja Konnichiwa (Ke Jepang)\n\n';
                helpText += '📋 *Beberapa Kode Bahasa Umum:*\n';
                helpText += 'Indonesia: id | Inggris: en | Jepang: ja\n';
                helpText += 'Korea: ko | Arab: ar | Sunda: su | Jawa: jv';

                return m.reply(helpText);
            }

            let targetLang = 'id';
            let textToTranslate = '';
            let detectedCode = '';

            const inputParts = text.split(' ');
            const possibleLang = inputParts[0];

            if (langNameByCode[possibleLang] && inputParts.length > 1) {
                targetLang = possibleLang;
                textToTranslate = inputParts.slice(1).join(' ');
            } else {
                textToTranslate = text;
            }

            if (!textToTranslate) {
                throw new Error('Teks untuk diterjemahkan kosong.');
            }

            const { endpoint, key } = config.apikey;

            const res = await axios.get(`${endpoint}/api/tools/translate`, {
                params: {
                    q: textToTranslate,
                    tl: targetLang,
                    apikey: key
                },
                timeout: 60000
            });

            const translatedText = res.data?.data;
            if (!translatedText) {
                throw new Error('Gagal mendapatkan hasil terjemahan.');
            }

            const langDisplay = langNameByCode[targetLang] || targetLang.toUpperCase();

            let message = `🌐 *Translate Result*\n\n`;
            message += `🔤 *To:* ${langDisplay} (${targetLang})\n`;
            message += `✍️ *Original:* ${textToTranslate}\n`;
            message += `➡️ *Translated:* ${translatedText}`;

            await m.reply(message);
        } catch (err) {
            console.error(err);
            await Yudzxml.sendMessage(
                id,
                { text: '❌ Gagal menerjemahkan teks. Coba periksa kode bahasa atau koneksi Anda.' },
                { quoted: m }
            );
        }
    }
};

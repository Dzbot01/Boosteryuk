module.exports = {
    name: 'weather',
    category: 'tools',
    commands: ['cuaca'],
    isOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ m, text, config }) {
        try {
            if (!text) return m.reply('Masukkan nama desa / kelurahan.\n\nContoh:\n.weather Sawang Selatan');

            const { endpoint, key } = config.apikey;
            const url = `${endpoint}/api/tools/weather?q=${encodeURIComponent(text)}&apikey=${key}`;

            const res = await fetch(url);
            if (!res.ok) throw new Error('Gagal mengambil data cuaca');

            const json = await res.json();
            if (json.status !== 200) throw new Error('Data cuaca tidak tersedia');

            const lokasi = json.data.lokasi;
            const today = json.data.data[0].cuaca[0][0];

            let output = `🌦️ *INFO CUACA*\n\n`;
            output += `📍 *Lokasi*\n`;
            output += `• Desa : ${lokasi.desa}\n`;
            output += `• Kecamatan : ${lokasi.kecamatan}\n`;
            output += `• Kab/Kota : ${lokasi.kotkab}\n`;
            output += `• Provinsi : ${lokasi.provinsi}\n\n`;

            output += `🕒 *Waktu*\n`;
            output += `• ${today.local_datetime}\n\n`;

            output += `🌡️ *Cuaca*\n`;
            output += `• Kondisi : ${today.weather_desc}\n`;
            output += `• Suhu : ${today.t}°C\n`;
            output += `• Kelembaban : ${today.hu}%\n`;
            output += `• Angin : ${today.ws} km/j (${today.wd})\n`;
            output += `• Jarak Pandang : ${today.vs_text}\n`;

            m.reply(output);
        } catch (err) {
            m.reply(`❌ Error:\n${err.message}`);
        }
    }
};

const axios = require('axios');

module.exports = {
    name: 'cekhost',
    category: 'tools',
    commands: ['cekhost'],
    isOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ m, text, config, Yudzxml }) {
        try {
            if (!text) {
                return m.reply(
                    `📝 *Penggunaan:*\n${m.prefix}checkhost [host] [type]\n\n📌 *Type yang tersedia:*\n- ping\n- http\n- info\n\n💡 *Contoh:*\n${m.prefix}checkhost google.com ping`
                );
            }

            const args = text.split(' ');
            const host = args[0];
            const type = args[1] ? args[1].toLowerCase() : 'ping';

            if (!['ping', 'http', 'info'].includes(type)) {
                return m.reply('❌ Tipe tidak valid. Pilih: ping, http, atau info.');
            }

            const { endpoint, key } = config.apikey;
            const url = `${endpoint}/api/tools/checkhost?host=${encodeURIComponent(host)}&type=${type}&apikey=${key}`;

            m.reply('🔄 *Memproses permintaan...*');

            const res = await axios.get(url);
            const result = res.data;

            if (!result || result.status !== 200 || !result.data) {
                return m.reply('❌ Gagal mengambil data dari server check-host.');
            }

            const data = result.data;
            let message = '';

            if (type === 'info') {
                const dbip = data['db-ip'] || {};
                const ipgeo = data['ipgeolocation.io'] || {};

                message = `🌐 *HOST INFORMATION*

🖥️ *Target IP*    : ${dbip.ip_address || ipgeo.ip_address || '-'}
🌍 *Hostname*     : ${dbip.host_name || ipgeo.host_name || '-'}
📡 *ISP / Org*    : ${dbip['isp_/org'] || ipgeo['isp/org'] || '-'}
🏢 *ASN*          : ${dbip.asn || ipgeo.asn || '-'}
🏳️ *Negara*       : ${dbip.country || ipgeo.country || '-'} ${dbip.country_flag_emoji || ipgeo.country_flag_emoji || ''}

📍 *Lokasi Detail*
• Kota      : ${dbip.city || ipgeo.city || '-'}
• Region    : ${dbip.region || ipgeo.region || '-'}
• Pos Code  : ${dbip.postal_code || ipgeo.postal_code || '-'}
• Timezone  : ${dbip.time_zone || ipgeo.time_zone || '-'}`;
            } else {
                const nodes = data.result || {};
                const hostTarget = data.host || host;
                const checkType = data.type || type;

                let header = '';
                if (checkType === 'ping') {
                    header = `📡 *PING RESULT: ${hostTarget}*`;
                } else {
                    header = `🌐 *HTTP RESULT: ${hostTarget}*`;
                }

                let nodeList = '';
                let count = 0;

                for (const [node, val] of Object.entries(nodes)) {
                    if (count >= 15) break;

                    if (!val) continue;

                    const country = val.country_name || 'Unknown';
                    const flag = val.country_flag_emoji || '';

                    let statusLine = '';

                    if (checkType === 'ping') {
                        const pings = val['0'];
                        if (pings && Array.isArray(pings)) {
                            const time = pings[0] && pings[0][1] ? pings[0][1] * 1000 : 0;

                            statusLine = `✅ ${pings[0][1]}s`;
                        } else {
                            statusLine = `❌ No Data`;
                        }
                    } else {
                        const httpData = val['0'];
                        if (httpData && Array.isArray(httpData)) {
                            const time = httpData[1];
                            const code = httpData[3];
                            statusLine = `✅ ${code} (${time}s)`;
                        } else if (val['1'] && val['1'].message) {
                            statusLine = `❌ ${val['1'].message}`;
                        } else {
                            statusLine = `❌ Error`;
                        }
                    }

                    const shortNode = node.split('.')[0];

                    nodeList += `\n${flag} *${shortNode}* [${country}]\n   ${statusLine}`;
                    count++;
                }

                message = `${header}\n\n${nodeList}\n\n_Menampilkan 15 node teratas._`;
            }

            await Yudzxml.sendMessage(m.chat, { text: message }, { quoted: m });
        } catch (err) {
            console.error('[CHECKHOST ERROR]', err);

            if (err.response && err.response.data) {
                m.reply(`❌ Error: ${JSON.stringify(err.response.data)}`);
            } else {
                m.reply('⚠️ Terjadi kesalahan saat memproses permintaan.');
            }
        }
    }
};

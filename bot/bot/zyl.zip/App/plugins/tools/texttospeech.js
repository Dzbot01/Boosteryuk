const axios = require('axios');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: 'texttospeech',
    category: 'tools',
    commands: ['tts', 'texttospech'],
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, config }) {
        const id = m.chat;

        if (!text) {
            return Yudzxml.sendMessage(
                id,
                {
                    text: '❌ Masukkan teks yang ingin diubah menjadi suara.\n\nContoh:\n.tts Halo semuanya'
                },
                { quoted: m }
            );
        }

        try {
            const { endpoint, key } = config.apikey;

            const apiUrl = `${endpoint}/api/tools/texttospech`;

            const res = await axios.get(apiUrl, {
                params: {
                    q: text,
                    apikey: key
                }
            });

            const audioUrl = res.data?.data;
            if (!audioUrl) {
                throw new Error('URL suara tidak valid');
            }

            const mp3Res = await axios.get(audioUrl, {
                responseType: 'arraybuffer'
            });

            const buffer = Buffer.from(mp3Res.data);

            await Yudzxml.sendMessage(
                id,
                {
                    audio: buffer,
                    mimetype: 'audio/mpeg'
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            await Yudzxml.sendMessage(id, { text: '❌ Gagal konversi teks ke suara.' }, { quoted: m });
        }
    }
};

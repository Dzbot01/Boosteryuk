const { add, listByUser, remove, parseDuration, formatDuration } = require('@App/function/reminderStore');

module.exports = {
    name: 'reminder',
    category: 'tools',
    commands: ['reminder', 'remind'],
    description: 'Set reminder / scheduler: .reminder 30m Minum air',
    isPrivate: false,

    /**
     * Reminder / scheduler plugin (F11).
     *
     * Usage:
     *   .reminder 30m Minum air
     *   .reminder 2h Meeting klien
     *   .reminder 1d Ulang tahun Sarah
     *   .reminder list    — tampilkan reminder aktif
     *   .reminder del <id> — hapus reminder
     *
     * Disimpan di database (namespace `reminders`), survive restart.
     *
     * @param {Object} ctx - Plugin context
     */
    async execute(ctx) {
        const { m, args } = ctx;

        const subcmd = String(args[0] || '').toLowerCase();

        // ── list ──
        if (subcmd === 'list' || subcmd === 'ls') {
            const items = listByUser(m.sender);
            if (!items.length) {
                return m.reply('📭 Tidak ada reminder aktif.');
            }
            const lines = items
                .map((r, i) => {
                    const remaining = r.fireAt - Date.now();
                    const inStr = remaining > 0 ? `dalam ${formatDuration(remaining)}` : 'sudah lewat';
                    return `${i + 1}. *${r.message}*\n   ID: \`${r.id}\`\n   Fire: ${inStr}`;
                })
                .join('\n\n');
            return m.reply(`📋 *DAFTAR REMINDER AKTIF*\n\n${lines}`);
        }

        // ── delete ──
        if (subcmd === 'del' || subcmd === 'rm') {
            const id = args[1];
            if (!id) return m.reply('❌ Format: .reminder del <id>');
            const ok = remove(id, m.sender);
            return m.reply(ok ? '✅ Reminder dihapus.' : '❌ Reminder tidak ditemukan.');
        }

        // ── add ──
        const durationStr = args[0];
        const messageText = args.slice(1).join(' ').trim();
        if (!durationStr || !messageText) {
            return m.reply(
                '⏰ *REMINDER*\n\n' +
                    'Usage:\n' +
                    '  .reminder 30m Minum air\n' +
                    '  .reminder 2h Meeting klien\n' +
                    '  .reminder 1d Ulang tahun Sarah\n' +
                    '  .reminder list\n' +
                    '  .reminder del <id>\n\n' +
                    'Durasi unit: s / m / h / d'
            );
        }

        const ms = parseDuration(durationStr);
        if (!ms) {
            return m.reply('❌ Format durasi tidak valid. Contoh: 30m, 2h, 1d, 45s');
        }

        const fireAt = Date.now() + ms;
        const reminder = add({
            userJid: m.sender,
            chatId: m.chat,
            fireAt,
            message: messageText
        });

        return m.reply(
            `✅ Reminder diset!\n\n` +
                `📝 Pesan: ${messageText}\n` +
                `⏱️ Dalam: ${formatDuration(ms)}\n` +
                `📅 Fire: ${new Date(fireAt).toLocaleString('id-ID')}\n` +
                `🆔 ID: \`${reminder.id}\`\n\n` +
                `Bot akan kirim pesan reminder ke chat ini.`
        );
    }
};

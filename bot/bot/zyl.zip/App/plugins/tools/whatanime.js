const axios = require('axios');
const fs = require('fs');

module.exports = {
    name: 'whatanime',
    category: 'tools',
    commands: ['whatanime'],
    isLimit: true,
    requiredLimit: 3,
    isRateLimit: true,

    async execute({ Yudzxml, m, isImage, quoted, YudzCdn, config }) {
        const id = m.chat;
        try {
            if (!isImage) {
                return m.reply('❌ Kirim atau reply gambar untuk mencari sumber anime.\n\nContoh:\n.whatanime');
            }

            const target = quoted || m;
            const mediaPath = await Yudzxml.downloadAndSaveMediaMessage(target);

            const fileUrl = await YudzCdn(mediaPath, 'expired');
            fs.unlinkSync(mediaPath);
            const { endpoint, key } = config.apikey;

            const res = await axios.get(`${endpoint}/api/tools/whatanime`, {
                params: {
                    url: fileUrl,
                    apikey: key
                },
                timeout: 60000
            });

            const results = res.data?.data?.result;
            if (!results || results.length === 0) {
                throw new Error('Anime tidak ditemukan');
            }

            const best = results[0];
            const anime = best.anilist;

            const formatTime = (seconds) => {
                const m = Math.floor(seconds / 60);
                const s = Math.floor(seconds % 60);
                return `${m}:${s.toString().padStart(2, '0')}`;
            };

            const similarity = (best.similarity * 100).toFixed(1) + '%';
            const title = anime.title.romaji || anime.title.english || 'Unknown';
            const native = anime.title.native || '';
            const studios = anime.studios.edges.map((e) => e.node.name).join(', ');

            let text = `🎬 *WhatAnime Result*\n\n`;
            text += `✨ *Title:* ${title}\n`;
            if (native) text += `🎌 *Native:* ${native}\n`;
            text += `📺 *Episode:* ${best.episode}\n`;
            text += `⏱️ *Timestamp:* ${formatTime(best.from)} - ${formatTime(best.to)}\n`;
            text += `🎯 *Similarity:* ${similarity}\n`;
            text += `📚 *Genres:* ${anime.genres.join(', ')}\n`;
            text += `🏢 *Studio:* ${studios}\n`;
            text += `📅 *Status:* ${anime.status}\n\n`;

            text += `🔗 *Anilist:* ${anime.siteUrl}\n`;

            if (results.length > 1) {
                text += `\n📊 *Kemungkinan Lain:*\n`;
                results.slice(1, 4).forEach((item, i) => {
                    const rTitle = item.anilist.title.romaji;
                    const rSim = (item.similarity * 100).toFixed(1) + '%';
                    const rEp = item.episode;
                    text += `\n${i + 2}. ${rTitle} (Ep ${rEp} - ${rSim})`;
                });
            }

            if (best.video && best.video.trim() !== '') {
                await Yudzxml.sendMessage(
                    id,
                    {
                        video: { url: best.video },
                        caption: text,
                        gifPlayback: true,
                        mimetype: 'video/mp4'
                    },
                    { quoted: m }
                );
                return;
            }

            const sceneImage = best.image;
            const coverImage = anime.coverImage.large;

            if (sceneImage || coverImage) {
                let imageToSend = sceneImage || coverImage;

                await Yudzxml.sendMessage(
                    id,
                    {
                        image: { url: imageToSend },
                        caption: text
                    },
                    { quoted: m }
                );
                return;
            }

            await m.reply(text);
        } catch (err) {
            console.error(err);
            m.reply('❌ Gagal mendeteksi anime. Pastikan gambar jelas dan bukan blur.');
        }
    }
};

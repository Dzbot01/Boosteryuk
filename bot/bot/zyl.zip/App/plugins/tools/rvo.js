'use strict';

module.exports = {
    name: 'rvo',
    category: 'tools',
    commands: ['rvo'],
    isOwner: false,
    isPremium: false,
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ m, Yudzxml, text }) {
        try {
            if (!m.quoted) {
                return m.reply('Silakan reply pesan view-once yang ingin dibuka.');
            }

            const quoted = m.quoted;

            if (!quoted.viewOnce) {
                return m.reply(`Pesan ini bukan view-once (tipe: ${quoted.mtype}).`);
            }

            const type = quoted.mtype;
            const caption = quoted.text || quoted.caption || '';
            const buffer = await quoted.download();

            if (!buffer) {
                return m.reply('Gagal mengambil media dari pesan tersebut.');
            }

            const options = { quoted: m };

            switch (type) {
                case 'imageMessage':
                    await Yudzxml.sendMessage(m.chat, { image: buffer, caption }, options);
                    break;

                case 'videoMessage':
                    await Yudzxml.sendMessage(m.chat, { video: buffer, caption }, options);
                    break;

                case 'audioMessage':
                    await Yudzxml.sendMessage(m.chat, { audio: buffer, mimetype: 'audio/mpeg' }, options);
                    break;

                default:
                    await m.reply(`Tipe media tidak didukung: ${type}`);
            }
        } catch (err) {
            console.error('[ADD COMMAND ERROR]', err);
            await m.reply('Terjadi kesalahan saat memproses pesan.');
        }
    }
};

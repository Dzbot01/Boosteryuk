module.exports = {
    name: 'sidompul',
    category: 'tools',
    commands: ['sidompul', 'cekkartu', 'cekkouta'],
    isOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ fetchJson, m, text, config, Yudzxml }) {
        try {
            if (!text) {
                return m.reply('📱 *Masukkan nomor HP yang valid.*\n\n' + `Contoh:\n${m.prefix}sidompul 083872031397`);
            }

            const { endpoint, key } = config.apikey;
            const url = `${endpoint}/api/tools/cekkouta?number=${encodeURIComponent(text.trim())}&apikey=${key}`;

            const res = await fetchJson(url);

            if (!res.data?.data) {
                return m.reply('⚠️ *Gagal mengambil data.* Pastikan nomor valid atau API sedang gangguan.');
            }

            const info = res.data.data.subs_info;
            const packages = res.data.data.package_info?.packages || [];

            let teks = `📱 *INFO NOMOR*\n`;
            teks += `━━━━━━━━━━━━━━━━━━\n`;
            teks += `• *Nomor*      : ${info.msisdn}\n`;
            teks += `• *Operator*   : ${info.operator}\n`;
            teks += `• *Jaringan*   : ${info.net_type}\n`;
            teks += `• *Umur Kartu* : ${info.tenure}\n`;
            teks += `• *Masa Aktif* : ${info.exp_date}\n`;
            teks += `• *Tenggang*   : ${info.grace_until}\n`;
            teks += `• *Dukcapil*   : ${info.id_verified}\n\n`;

            teks += `📶 *INFO VOLT*\n`;
            teks += `━━━━━━━━━━━━━━━━━━\n`;
            const vStatus = (val) => (val ? '✅ Aktif' : '❌ Tidak');
            teks += `• *Perangkat* : ${vStatus(info.volte?.device)}\n`;
            teks += `• *Wilayah*    : ${vStatus(info.volte?.area)}\n`;
            teks += `• *SIM Card*   : ${vStatus(info.volte?.simcard)}\n\n`;

            teks += `📦 *DAFTAR PAKET*\n`;
            teks += `━━━━━━━━━━━━━━━━━━\n`;

            if (packages.length > 0) {
                packages.forEach((pkg) => {
                    teks += `🌐 *${pkg.name}*\n`;
                    teks += `📅 Berakhir: ${pkg.expiry}\n`;

                    if (pkg.quotas?.length) {
                        let quotaDetails = '';
                        pkg.quotas.forEach((q) => {
                            const percent = q.percent ?? 0;

                            const filled = Math.round(percent / 10);
                            const empty = 10 - filled;
                            const bar = '▰'.repeat(filled) + '▱'.repeat(empty);

                            quotaDetails += `\n  • ${q.name}\n`;
                            quotaDetails += `    ${bar} ${percent.toFixed(0)}%\n`;
                            quotaDetails += `    Sisa: *${q.remaining}* / *${q.total}*`;
                        });
                        teks += quotaDetails + '\n';
                    }
                    teks += `━━━━━━━━━━━━━━━━━━\n`;
                });
            } else {
                teks += `Tidak ada paket kuota aktif.\n`;
            }

            teks += `\n👤 _Source By Yudz-Api's_`;

            await m.reply(teks);
        } catch (err) {
            console.error('[SIDOMPUL SYSTEM ERROR]', err);
            m.reply('⚠️ *Terjadi kesalahan sistem.*\nSilakan coba lagi nanti atau hubungi owner.');
        }
    }
};

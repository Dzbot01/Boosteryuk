'use strict';

module.exports = {
    name: 'reactch',
    category: 'tools',
    commands: ['reactch'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    isOwner: true,
    isPremium: true,

    async execute({ m, Yudzxml, text }) {
        if (!text) {
            return m.reply('Contoh:\n' + '.reactch https://whatsapp.com/channel/xxx/123 🔥');
        }

        const hurufGaya = {
            a: '🅐',
            b: '🅑',
            c: '🅒',
            d: '🅓',
            e: '🅔',
            f: '🅕',
            g: '🅖',
            h: '🅗',
            i: '🅘',
            j: '🅙',
            k: '🅚',
            l: '🅛',
            m: '🅜',
            n: '🅝',
            o: '🅞',
            p: '🅟',
            q: '🅠',
            r: '🅡',
            s: '🅢',
            t: '🅣',
            u: '🅤',
            v: '🅥',
            w: '🅦',
            x: '🅧',
            y: '🅨',
            z: '🅩',
            0: '⓿',
            1: '➊',
            2: '➋',
            3: '➌',
            4: '➍',
            5: '➎',
            6: '➏',
            7: '➐',
            8: '➑',
            9: '➒'
        };

        const args = text.trim().split(/\s+/);
        const link = args[0];
        const teks = args.slice(1).join(' ').trim();

        if (!link.includes('https://whatsapp.com/channel/')) {
            return m.reply('❌ Link tidak valid.');
        }

        const channelId = link.split('/')[4];
        const rawMessageId = link.split('/')[5];

        console.log(channelId);

        if (!channelId || !rawMessageId) {
            return m.reply('❌ Link channel tidak lengkap.');
        }

        if (!teks) {
            return m.reply('❌ Masukkan emoji / teks reaction.');
        }

        const emoji = teks
            .toLowerCase()
            .split('')
            .map((c) => (c === ' ' ? '―' : hurufGaya[c] || c))
            .join('');

        try {
            const metadata = await Yudzxml.newsletterMetadata('invite', channelId);

            await Yudzxml.newsletterReactMessage(metadata.id, rawMessageId, emoji);

            m.reply(
                `✅ Reaction *${emoji}* berhasil dikirim\n` + `📢 Channel: *${metadata.thread_metadata.name.text}*`
            );
        } catch (err) {
            console.error(err);
            m.reply('❌ Gagal memproses reaction channel.');
        }
    }
};

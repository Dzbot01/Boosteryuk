const axios = require('axios');

module.exports = {
    name: 'sswebv2',
    category: 'tools',
    commands: ['sswebv2'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,
    async execute({ Yudzxml, m, text, config }) {
        const id = m.chat;

        try {
            const args = text?.trim().split(' ') || [];

            const url = args[0];
            if (!url || !url.match(/^https?:\/\//i)) {
                return Yudzxml.sendMessage(
                    id,
                    {
                        text: '❌ Masukkan URL website yang valid.\nContoh:\n.sswebv2 https://example.com desktop true'
                    },
                    { quoted: m }
                );
            }

            const device = (args[1] || 'desktop').toLowerCase();
            const fullpage = (args[2] || 'false').toLowerCase() === 'true';

            const allowedDevices = ['desktop', 'desktophd', 'phone', 'mobile', 'tablet'];

            if (!allowedDevices.includes(device)) {
                return Yudzxml.sendMessage(
                    id,
                    {
                        text: '❌ Device tidak valid. Pilih salah satu:\n`desktop desktophd phone mobile tablet`'
                    },
                    { quoted: m }
                );
            }

            const { endpoint, key } = config.apikey;

            const res = await axios.get(`${endpoint}/api/tools/sswebv2`, {
                params: {
                    url,
                    device,
                    fullpage,
                    apikey: key
                },
                responseType: 'arraybuffer'
            });

            const buffer = Buffer.from(res.data);

            await Yudzxml.sendMessage(
                id,
                {
                    image: buffer,
                    caption: `📸 Screenshot V2\n🔗 URL: ${url}\n🖥️ Device: ${device}\n📄 Fullpage: ${fullpage}`
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            await Yudzxml.sendMessage(id, { text: '❌ Gagal mengambil screenshot website (sswebv2).' }, { quoted: m });
        }
    }
};

const axios = require('axios');

module.exports = {
    name: 'styletext',
    category: 'tools',
    commands: ['styletext'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ proto, Yudzxml, m, text, config, applyStyle }) {
        const id = m.chat;

        if (!text) {
            return Yudzxml.sendMessage(
                id,
                {
                    text: '❌ Masukkan teks.\n\nContoh:\n.styletext Yudzxml'
                },
                { quoted: m }
            );
        }

        try {
            const { endpoint, key } = config.apikey;

            const res = await axios.get(`${endpoint}/api/tools/styletext`, {
                params: {
                    q: text,
                    apikey: key
                }
            });

            let data = res.data?.data || [];

            if (!Array.isArray(data)) {
                data = [];
            }

            let appleStyle = text;

            try {
                const styled = await applyStyle(text);

                if (styled?.done) {
                    appleStyle = styled.done;
                }
            } catch (e) {
                console.error('Apple Style Error:', e);
            }

            data.unshift({
                name: 'Apple Style',
                result: appleStyle
            });

            const uniqueData = [];
            const seen = new Set();

            for (const item of data) {
                if (!item?.result) continue;

                if (!seen.has(item.result)) {
                    seen.add(item.result);
                    uniqueData.push(item);
                }
            }

            let bodyText =
                `🎨 *STYLE TEXT GENERATOR*\n` + `📝 Text: ${text}\n\n` + `Pilih tombol untuk menyalin style:\n`;

            const buttons = [];

            uniqueData.slice(0, 20).forEach((item, i) => {
                bodyText += `\n${i + 1}. ${item.name}`;

                buttons.push({
                    name: 'cta_copy',
                    buttonParamsJson: JSON.stringify({
                        display_text: `${i + 1}. ${item.name}`,
                        copy_code: item.result
                    })
                });
            });

            const interactiveMsg = proto.Message.InteractiveMessage.create({
                header: proto.Message.InteractiveMessage.Header.create({
                    title: '🎨 STYLE TEXT GENERATOR',
                    subtitle: 'Copy style favoritmu',
                    hasMediaAttachment: false
                }),

                body: proto.Message.InteractiveMessage.Body.create({
                    text: bodyText
                }),

                footer: proto.Message.InteractiveMessage.Footer.create({
                    text: 'YUDZXML • Apple Style Added '
                }),

                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                    buttons
                })
            });

            await Yudzxml.relayMessage(
                m.chat,
                {
                    viewOnceMessageV2Extension: {
                        message: {
                            interactiveMessage: interactiveMsg
                        }
                    }
                },
                { quoted: m }
            );
        } catch (err) {
            console.error('StyleText Error:', err);

            await Yudzxml.sendMessage(
                id,
                {
                    text: '❌ Gagal memproses style text.\nCoba lagi nanti.'
                },
                { quoted: m }
            );
        }
    }
};

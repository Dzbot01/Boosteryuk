const tourlSession = new Map();

module.exports = {
    name: 'tourl',
    category: 'tools',
    commands: ['tourl'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,

    async execute({ Yudzxml, m, text, prefix, command, isMedia, quoted, YudzCdn, proto }) {
        const id = m.chat;
        const sender = m.sender;

        try {
            if (text === 'expired' || text === 'permanent') {
                const session = tourlSession.get(sender);

                if (!session) {
                    return m.reply('❌ Session habis. Kirim media ulang.');
                }

                const url = await YudzCdn(session.mediaPath, text);
                tourlSession.delete(sender);

                const buttons = [
                    {
                        name: 'cta_copy',
                        buttonParamsJson: JSON.stringify({
                            display_text: '📋 Copy URL',
                            copy_code: url
                        })
                    }
                ];

                const interactiveMsg = proto.Message.InteractiveMessage.create({
                    header: proto.Message.InteractiveMessage.Header.create({
                        title: '✅ Upload Berhasil',
                        hasMediaAttachment: false
                    }),

                    body: proto.Message.InteractiveMessage.Body.create({
                        text:
                            `🔗 URL: ${url}\n` +
                            `📦 Tipe: ${text.toUpperCase()}\n` +
                            (text === 'expired' ? '⏳ Berlaku 1 jam' : '♾️ Permanen')
                    }),

                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: ''
                    }),

                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons
                    })
                });

                return await Yudzxml.relayMessage(
                    id,
                    {
                        viewOnceMessage: {
                            message: {
                                interactiveMessage: interactiveMsg
                            }
                        }
                    },
                    { quoted: m }
                );
            }

            if (!isMedia && !quoted) {
                return m.reply('❌ Kirim atau reply media terlebih dahulu.');
            }

            const target = quoted || m;
            const mediaPath = await Yudzxml.downloadAndSaveMediaMessage(target);

            tourlSession.set(sender, {
                mediaPath,
                createdAt: Date.now()
            });

            const buttons = [
                {
                    buttonId: `${prefix + command} expired`,
                    buttonText: { displayText: '⏳ EXPIRED (1 JAM)' },
                    type: 1
                },
                {
                    buttonId: `${prefix + command} permanent`,
                    buttonText: { displayText: '♾️ PERMANENT' },
                    type: 1
                }
            ];

            await Yudzxml.sendMessage(
                id,
                {
                    text: 'Pilih jenis URL:',
                    footer: 'Upload Media to URL',
                    buttons,
                    headerType: 1
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);

            await Yudzxml.sendMessage(
                id,
                {
                    text: '❌ Terjadi kesalahan saat memproses media.'
                },
                { quoted: m }
            );
        }
    }
};

const axios = require('axios');

const sessions = new Map();

module.exports = {
    name: 'voicechanger',
    category: 'tools',
    commands: ['voicechanger'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,

    async execute({ Yudzxml, m, isAudio, isVideo, YudzCdn, config, prefix, command, text, args }) {
        const id = m.chat;
        const sender = m.sender;

        const characters = [
            { id: 'tupai', label: '🐿 Tupai' },
            { id: 'bayi', label: '👶 Bayi' },
            { id: 'alien', label: '👽 Alien' },
            { id: 'robot', label: '🤖 Robot' },
            { id: 'monster', label: '👹 Monster' },
            { id: 'raksasa', label: '🗿 Raksasa' },
            { id: 'kakek', label: '👴 Kakek' }
        ];

        try {
            if (isAudio || isVideo) {
                let buffer = null;
                try {
                    buffer = m.quoted ? await m.quoted.download() : await m.download();
                } catch {
                    buffer = await m.download();
                }

                if (!buffer) throw new Error('Gagal download media');

                sessions.set(sender, buffer);

                const buttons = characters.map((char) => ({
                    buttonId: `${prefix + command} ${char.id}`,
                    buttonText: { displayText: char.label },
                    type: 1
                }));

                return Yudzxml.sendMessage(
                    id,
                    {
                        text: '🎙 Pilih karakter voice changer:',
                        footer: '',
                        buttons: buttons,
                        headerType: 1
                    },
                    { quoted: m }
                );
            }

            if (text) {
                const inputChar = args[0] ? args[0].toLowerCase() : text.toLowerCase();
                const isValidChar = characters.some((c) => c.id === inputChar);
                if (!isValidChar) return;

                const buffer = sessions.get(sender);
                if (!buffer) {
                    return Yudzxml.sendMessage(
                        id,
                        {
                            text: '❌ Sesi audio tidak ditemukan atau sudah expired. Kirim ulang audio/video terlebih dahulu.'
                        },
                        { quoted: m }
                    );
                }

                const url = await YudzCdn(buffer);
                if (!url) throw new Error('Gagal upload CDN');

                const { endpoint, key } = config.apikey;

                const finalUrl = `${endpoint}/api/tools/voicechanger?url=${encodeURIComponent(url)}&character=${inputChar}&apikey=${key}`;

                await Yudzxml.sendMessage(
                    id,
                    {
                        audio: { url: finalUrl },
                        mimetype: 'audio/mpeg',
                        ptt: false
                    },
                    { quoted: m }
                );

                sessions.delete(sender);
            }
        } catch (err) {
            console.error(err);
            sessions.delete(sender);
            await Yudzxml.sendMessage(id, { text: '❌ Gagal memproses voice changer.' }, { quoted: m });
        }
    }
};

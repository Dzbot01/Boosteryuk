const axios = require('axios');
const { performance } = require('perf_hooks');
const { sleep } = require('@App/function/handler');

async function performRequest({ url, timeout }) {
    const start = performance.now();

    await axios.get(url, {
        timeout,
        maxRedirects: 5,
        validateStatus: () => true,
        headers: {
            'User-Agent': 'PingMonitor/1.0',
            Accept: '*/*'
        }
    });

    return performance.now() - start;
}

async function pingHttp({ url = 'https://www.google.com', attempts = 3, timeout = 8000, delay = 700 } = {}) {
    if (!url || typeof url !== 'string') {
        throw new Error('Invalid url parameter');
    }

    const results = [];
    const errorMessages = new Set();

    for (let i = 0; i < attempts; i++) {
        try {
            const latency = await performRequest({ url, timeout });
            results.push(latency);
        } catch (err) {
            results.push(null);
            if (err.code === 'ECONNABORTED') {
                errorMessages.add('Timeout');
            } else {
                errorMessages.add(err.code || 'Network Error');
            }
        }

        if (i < attempts - 1) await sleep(delay);
    }

    const success = results.filter((v) => v !== null);

    if (!success.length) {
        return {
            status: 'offline',
            target: url,
            attempts,
            success: 0,
            error: [...errorMessages].join(', ') || 'Connection failed',
            stats: { min: null, max: null, avg: null },
            raw: results
        };
    }

    const min = Math.min(...success);
    const max = Math.max(...success);
    const avg = success.reduce((a, b) => a + b, 0) / success.length;

    return {
        status: 'online',
        target: url,
        attempts,
        success: success.length,
        stats: {
            min: Math.round(min),
            max: Math.round(max),
            avg: Number(avg.toFixed(2))
        },
        formatted: {
            min: `${Math.round(min)} ms`,
            max: `${Math.round(max)} ms`,
            avg: `${avg.toFixed(2)} ms`
        },
        raw: results
    };
}

function formatPingHuman(res) {
    if (res.status !== 'online') {
        return (
            `❌ *KONEKSI GAGAL*\n\n` +
            `🌐 Target : ${res.target}\n` +
            `📴 Status : Tidak dapat dijangkau\n` +
            `⚠ Error  : ${res.error || '-'}`
        );
    }

    let quality = '🔴 Lambat';
    if (res.stats.avg <= 150) quality = '🟢 Sangat Cepat';
    else if (res.stats.avg <= 300) quality = '🟡 Normal';

    return (
        `📶 *STATUS KONEKSI*\n\n` +
        `🌐 Target   : ${res.target}\n` +
        `📡 Kondisi  : ${quality}\n` +
        `🔁 Percobaan: ${res.success}/${res.attempts}\n\n` +
        `⏱ *Respon Time*\n` +
        `• Tercepat : ${res.formatted.min}\n` +
        `• Terlama  : ${res.formatted.max}\n` +
        `• Rata-rata: ${res.formatted.avg}\n\n` +
        `ℹ Angka lebih kecil = koneksi lebih gesit`
    );
}

module.exports = {
    name: 'cekping',
    category: 'tools',
    commands: ['cekping'],
    isLimit: true,
    requiredLimit: 1,
    isRateLimit: true,
    async execute({ m, args }) {
        try {
            const target = args[0] || 'https://google.com';

            const res = await pingHttp({
                url: target,
                attempts: 3,
                timeout: 5000,
                delay: 800
            });

            const message = formatPingHuman(res);
            await m.reply(message);
        } catch (err) {
            await m.reply(`❌ Terjadi kesalahan:\n${err.message}`);
        }
    }
};

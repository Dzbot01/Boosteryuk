const axios = require('axios');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: 'deobfuscate',
    category: 'tools',
    commands: ['deobfuscate', 'deobf'],
    isLimit: true,
    requiredLimit: 2,
    isRateLimit: true,

    async execute({ Yudzxml, m, text, quoted, YudzCdn, config }) {
        const id = m.chat;

        try {
            if (!text && !quoted) {
                return m.reply(
                    '🔓 *Deobfuscate JS*\n\n' +
                        '1️⃣ `.deobf https://example.com/file.js`\n' +
                        '2️⃣ `.deobf console.log("halo")`\n' +
                        '3️⃣ Reply file .js dengan `.deobf`'
                );
            }

            let targetUrl;
            let tempFilePath;

            if (text && text.startsWith('http')) {
                targetUrl = text.trim();
            }

            if (!targetUrl && text && !text.startsWith('http')) {
                const tempName = `temp-${Date.now()}.js`;
                tempFilePath = path.join(__dirname, tempName);
                fs.writeFileSync(tempFilePath, text);
                targetUrl = await YudzCdn(tempFilePath, 'expired');
                fs.unlinkSync(tempFilePath);
            }

            if (!targetUrl && quoted) {
                const mime = quoted.mimetype || '';
                if (!mime.includes('javascript') && !mime.includes('text')) {
                    return m.reply('❌ Reply file .js yang valid.');
                }

                const mediaPath = await Yudzxml.downloadAndSaveMediaMessage(quoted);
                targetUrl = await YudzCdn(mediaPath, 'expired');
                fs.unlinkSync(mediaPath);
            }

            if (!targetUrl) {
                return m.reply('❌ Tidak ditemukan kode / URL / file untuk di proses.');
            }

            m.reply('⏳ Sedang memproses deobfuscate...');

            const { endpoint, key } = config.apikey;

            const res = await axios.get(`${endpoint}/api/tools/deobfuscate`, {
                params: {
                    url: targetUrl,
                    apikey: key
                }
            });

            const code = res.data?.data;

            if (!code || typeof code !== 'string') {
                throw new Error('Hasil tidak valid');
            }

            const filename = `deobfuscated-${Date.now()}.js`;
            const filepath = path.join(__dirname, filename);

            fs.writeFileSync(filepath, code);

            await Yudzxml.sendMessage(
                id,
                {
                    document: fs.readFileSync(filepath),
                    fileName: filename,
                    mimetype: 'application/javascript'
                },
                { quoted: m }
            );

            fs.unlinkSync(filepath);
        } catch (err) {
            console.error(err);
            m.reply('❌ Gagal melakukan deobfuscate file.');
        }
    }
};

module.exports = {
    name: 'savekontak',
    category: 'superowner',
    commands: ['savekontak'],
    isSuperOwner: true,
    async execute({ m, Yudzxml, args, prefix, command }) {
        try {
            if (!args[0]) {
                return m.reply(
                    `❌ *Format Penggunaan Salah!*\n\n` +
                        `📝 Cara penggunaan:\n` +
                        `${prefix + command} <link_grup>\n\n` +
                        `📌 Contoh:\n` +
                        `${prefix + command} https://chat.whatsapp.com/ABC123`
                );
            }

            const linkGroup = args[0];

            const inviteCode = linkGroup.split('https://chat.whatsapp.com/')[1];
            if (!inviteCode) {
                return m.reply('❌ *Link Grup Tidak Valid!*\nPastikan link dimulai dengan https://chat.whatsapp.com/');
            }

            await m.reply('⏳ *Sedang Memproses...*\nMengambil data grup, harap tunggu sebentar.');

            const res = await Yudzxml.query({
                tag: 'iq',
                attrs: { type: 'get', xmlns: 'w:g2', to: '@g.us' },
                content: [{ tag: 'invite', attrs: { code: inviteCode } }]
            });

            const groupData = res?.content?.[0]?.attrs;

            if (!groupData || !groupData.id) {
                return m.reply(
                    '❌ *Gagal Mengambil Info Grup.*\nPastikan link valid atau bot telah dibatasi oleh WhatsApp.'
                );
            }

            const groupId = groupData.id + '@g.us';

            const metadata = await Yudzxml.groupMetadata(groupId);
            if (!metadata || !metadata.participants) {
                return m.reply('❌ *Gagal Mengambil Peserta Grup.*');
            }

            const participants = metadata.participants.map((p) => p.id);
            const uniqueContacts = [...new Set(participants)].filter(
                (jid) => jid !== Yudzxml.user.id.split(':')[0] + '@s.whatsapp.net'
            );

            await m.reply(
                `✅ *Berhasil Masuk Grup:*\n${metadata.subject}\n\n👥 *Total Kontak:* ${uniqueContacts.length} orang\n\n📂 *Sedang membuat file VCard...*`
            );

            const vcardContent = uniqueContacts
                .map((jid) => {
                    const number = jid.split('@')[0];

                    const fullName = `BUYER ${number}`;

                    return [
                        'BEGIN:VCARD',
                        'VERSION:3.0',
                        `FN:${fullName}`,
                        `TEL;type=CELL;type=VOICE;waid=${number}:+${number}`,
                        'END:VCARD',
                        ''
                    ].join('\n');
                })
                .join('');

            await Yudzxml.sendMessage(
                m.sender,
                {
                    document: Buffer.from(vcardContent),
                    mimetype: 'text/vcard',
                    fileName: `Kontak_${metadata.subject.replace(/\s+/g, '_')}.vcf`,
                    caption: `📂 *File Kontak Grup: ${metadata.subject}*\n\nTotal: ${uniqueContacts.length} kontak tersimpan.\n\n_Silakan buka file untuk menyimpan ke kontak HP Anda._`
                },
                { quoted: m }
            );
        } catch (error) {
            console.error('System Error:', error);
            m.reply('❌ *Terjadi kesalahan sistem.*\nPastikan bot tidak dikeluarkan dari grup dan link aktif.');
        }
    }
};

const jadibotManager = require('../../../src/core/jadibot');

module.exports = {
    name: 'listjadibot',
    category: 'superowner',
    commands: ['listjadibot', 'jadibots'],
    description: 'Daftar semua bot jadibot terdaftar',
    isSuperOwner: true,
    isGroup: false,

    async execute({ m }) {
        const all = jadibotManager.listAll();

        if (!all.length) {
            return m.reply('_Belum ada bot jadibot terdaftar._');
        }

        const statusIcon = {
            active: '🟢',
            pending_pairing: '🟡',
            reconnecting: '🟠',
            expired: '🔴',
            stopped: '⚫'
        };

        const now = Date.now();
        const lines = all.map((e, i) => {
            const daysLeft = Math.max(0, Math.ceil((e.expired - now) / 86400000));
            return (
                `${statusIcon[e.status] || '⚪'} *${i + 1}. +${e.number}*\n` +
                `   📦 ${e.package} | ${e.status}\n` +
                `   ⏳ Sisa ${daysLeft} hari | 💬 ${e.stats?.messages || 0} pesan\n` +
                `   🏪 ${e.identity?.storename || '-'}`
            );
        });

        const stats = jadibotManager.stats();

        const text =
            `🤖 *DAFTAR BOT JADIBOT*\n\n` +
            `${lines.join('\n\n')}\n\n` +
            `━━━━━━━━━━━━━━━━━━\n` +
            `📊 Total: ${stats.total} | Online: ${stats.online}\n` +
            `🟢 Aktif: ${stats.active} | 🟡 Pending: ${stats.pending}\n` +
            `🔴 Expired: ${stats.expired} | ⚫ Stop: ${stats.stopped}\n\n` +
            `*Manajemen:*\n` +
            `• .addjadibot <nomor> <hari>\n` +
            `• .deljadibot <nomor>\n` +
            `• API: POST /api/jadibot/stop (body: { "number": "628xxx" })`;

        return m.reply(text);
    }
};

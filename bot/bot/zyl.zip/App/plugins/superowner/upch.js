const logger = require('@App/function/logger');

module.exports = {
    name: 'upch',
    category: 'superowner',
    commands: ['upch'],
    description:
        'Upload/reply pesan ke channel (bot utama: superowner; bot jadibot: owner instance). Support argumen: link saluran / kode invite / ID saluran',
    isOwner: true,

    async execute({ m, Yudzxml, args, config, isSuperOwner, toPTT }) {
        const isInstance = Boolean(Yudzxml.isJadibot);

        let targetIdch;
        let targetOwnername;

        if (isInstance) {
            targetOwnername = Yudzxml.identity?.ownername;
        } else {
            if (!isSuperOwner) {
                return m.reply(config.mess.superowner);
            }
            targetOwnername = config.ownername;
        }

        // ── Argumen opsional: link saluran / kode invite / ID saluran ─────────
        // .upch <link>              (reply pesan + link)
        // .upch <kode invite>       (contoh: 0029VbA78K82f3EGd78yGU28)
        // .upch <id saluran>        (contoh: 120363426771378655@newsletter)
        // tanpa argumen → pakai idch bawaan (config.idch / settings jadibot).
        const arg0 = String(args[0] || '').trim();

        if (arg0 && arg0 !== '-' && arg0 !== 'default') {
            const extractInvite = (input = '') => {
                const clean = input.trim();
                const last = clean.split('/').pop();
                return /^[0-9A-Za-z]+$/.test(last) ? last : null;
            };

            if (/^\d{5,}@newsletter$/i.test(arg0)) {
                targetIdch = arg0;
            } else if (/^\d{5,}$/.test(arg0.replace(/\D/g, '')) && !/whatsapp\.com/i.test(arg0)) {
                targetIdch = `${arg0.replace(/\D/g, '')}@newsletter`;
            } else {
                const inviteCode = extractInvite(arg0);
                if (!inviteCode) {
                    return m.reply(
                        '❌ Format tidak dikenal.\n' +
                            'Kirim *link saluran* (`https://whatsapp.com/channel/xxx`), ' +
                            '*kode invite*, atau *ID saluran* (`123...@newsletter`).'
                    );
                }

                try {
                    const meta = await Yudzxml.newsletterMetadata('invite', inviteCode);
                    if (!meta?.id) throw new Error('Metadata saluran tidak ditemukan.');
                    targetIdch = meta.id;
                } catch (err) {
                    logger.error('[UPCH] Gagal resolve saluran: ' + (err?.message || err));
                    return m.reply(
                        '❌ Gagal mengambil ID dari link/kode saluran itu.\n' +
                            '_Pastikan link valid & bot punya akses ke saluran._'
                    );
                }
            }
        }

        if (!targetIdch) {
            if (isInstance) {
                const instanceChannel = Yudzxml.jadibotEntry?.settings?.idch;

                if (!instanceChannel) {
                    return m.reply(
                        '📡 *CHANNEL BELUM DIPASANG*\n\n' +
                            'Pasang dulu ID channel milikmu supaya konten tidak terkirim ke channel bot utama:\n\n' +
                            '1. Ambil ID channel: .cekidch <link channel>\n' +
                            '2. Pasang: .setidch <id>@newsletter\n' +
                            '3. (Opsional) Branding: .setownername <nama>\n\n' +
                            '💡 _Atau upload langsung: .upch <link saluranmu>_'
                    );
                }

                targetIdch = instanceChannel;
            } else {
                targetIdch = config.idch;
            }
        }

        if (!targetIdch) {
            return m.reply('❌ ID channel belum dikonfigurasi. Set config.idch atau gunakan .setidch (bot jadibot).');
        }

        try {
            const q = m.quoted || m;

            if (!m.quoted) {
                return m.reply(
                    '— Reply pesan yang ingin dikirim ke channel.\n\n' +
                        `💡 Bisa juga dengan target: *${(m.body || '').split(' ')[0]} <link saluran>*`
                );
            }

            const type = q.mtype;
            const msg = q.message || {};

            const contextInfo = {
                mentionedJid: [m.sender],
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: targetIdch,
                    newsletterName: targetOwnername || config.ownername
                }
            };

            let msgContent = {};

            if (type === 'conversation' || type === 'extendedTextMessage') {
                msgContent = {
                    text: q.text || msg?.conversation || msg?.extendedTextMessage?.text || '',
                    contextInfo
                };
            } else if (type === 'imageMessage') {
                const buffer = await q.download();

                msgContent = {
                    image: buffer,
                    caption: q.caption || '',
                    mimetype: msg?.imageMessage?.mimetype || 'image/jpeg',
                    contextInfo
                };
            } else if (type === 'videoMessage') {
                const buffer = await q.download();

                msgContent = {
                    video: buffer,
                    caption: q.caption || '',
                    mimetype: msg?.videoMessage?.mimetype || 'video/mp4',
                    ptv: msg?.videoMessage?.ptv || false,
                    gifPlayback: msg?.videoMessage?.gifPlayback || false,
                    contextInfo
                };
            } else if (type === 'audioMessage') {
                const rawBuffer = await q.download();

                let finalBuffer = rawBuffer;

                const { data } = await toPTT(finalBuffer);

                msgContent = {
                    audio: data,
                    mimetype: 'audio/ogg; codecs=opus',
                    ptt: true,
                    contextInfo
                };
            } else if (type === 'documentMessage') {
                const buffer = await q.download();

                msgContent = {
                    document: buffer,
                    mimetype: msg?.documentMessage?.mimetype || 'application/octet-stream',
                    fileName: msg?.documentMessage?.fileName || 'file',
                    fileLength: msg?.documentMessage?.fileLength,
                    contextInfo
                };
            } else if (type === 'stickerMessage') {
                const buffer = await q.download();

                msgContent = {
                    sticker: buffer,
                    contextInfo
                };
            } else {
                return m.reply(`❌ Type *${type}* belum didukung`);
            }

            await Yudzxml.sendMessage(targetIdch, msgContent);

            m.reply(`✅ Berhasil upload *${type}* ke channel\n🆔 \`${targetIdch}\``);
        } catch (err) {
            logger.error('[UPCH] ' + (err?.message || err));
            m.reply('⚠️ Gagal upload ke channel.');
        }
    }
};

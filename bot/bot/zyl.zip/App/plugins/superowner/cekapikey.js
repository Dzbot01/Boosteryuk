const axios = require('axios');

function formatExpired(timestamp) {
    if (!timestamp || timestamp <= 0) return 'Tidak diketahui';
    const date = new Date(Number(timestamp));
    return date.toLocaleString('id-ID', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

module.exports = {
    name: 'cekapikey',
    category: 'superowner',
    commands: ['cekapikey', 'checkapikey'],
    description: 'Cek status API key bot utama (diatur superowner di config.js)',
    isOwner: false,
    isSuperOwner: true,
    isGroup: false,
    isAdmin: false,
    isPremium: false,

    async execute({ m, config }) {
        try {
            const endpoint = config.apikey?.endpoint;
            const key = config.apikey?.key;

            if (!endpoint || !key) {
                return m.reply(
                    '❌ API key bot utama belum diset.\n\nPerbaiki bagian `apikey` di config.js (khusus superowner).'
                );
            }

            const apiUrl = `${endpoint}/api/user/cekapikey?apikey=${key}`;

            const res = await axios.get(apiUrl);
            const result = res.data;

            if (!result || result.status !== 200 || !result.data) {
                return m.reply('❌ API Key tidak valid atau sudah tidak aktif.');
            }

            const data = result.data;

            const message = `🔐 *CEK API KEY BOT UTAMA*

📊 *Limit*     : ${data.limit.toLocaleString()}
⏰ *Expired*   : ${formatExpired(data.expired)}

✅ Status: *AKTIF*
`;

            m.reply(message);
        } catch (err) {
            console.error('[CEKAPIKEY ERROR]', err);
            m.reply('Terjadi kesalahan saat mengecek API Key.');
        }
    }
};

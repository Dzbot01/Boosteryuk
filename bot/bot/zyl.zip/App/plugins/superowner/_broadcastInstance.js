'use strict';

/**
 * broadcastInstance.js
 * -----------------------------------------------------------------------------
 * Helper untuk plugin broadcast (pushkontak, jpm, jpmswgc, autojpm) — P2.
 *
 * Memastikan plugin-plugin broadcast bisa dipakai PER jadibot instance tanpa
 * mengganggu main bot atau bot lain. Setiap instance jadibot punya:
 *   - Socket sendiri (Yudzxml sudah otomatis instance yang benar)
 *   - Storage folder sendiri: Storage/jadibot_data/<number>/
 *   - Config jpm sendiri (jpm.json)
 *
 * Plugin tetap bisa dijalankan oleh superowner di main bot (menggunakan
 * Storage/jpm.json global). Tidak ada perubahan behavior untuk superowner.
 * -----------------------------------------------------------------------------
 */

const path = require('path');
const fs = require('fs');
const { loadDB: loadDBLayer, saveDB: saveDBLayer } = require('../../../database/wrappers/storage');
const jadibotManager = require('../../../src/core/jadibot');

/**
 * Resolve path konfigurasi broadcast berdasarkan instance.
 *
 * @param {Object} ctx — plugin ctx
 * @param {string} fileName — nama file config, mis. 'jpm.json'
 * @returns {{dbPath: string, isInstance: boolean, instanceNumber: string|null}}
 */
function resolveBroadcastPath(ctx, fileName = 'jpm.json') {
    const isInstance = Boolean(ctx?.isJadibot);
    const instanceNumber = isInstance ? ctx?.jadibotEntry?.number : null;

    if (isInstance && instanceNumber) {
        // Per-instance storage — TIDAK mengganggu main bot.
        const folder = path.join(__dirname, '../../../Storage/jadibot_data', instanceNumber);
        if (!fs.existsSync(folder)) fs.mkdirSync(folder, { recursive: true });
        return { dbPath: path.join(folder, fileName), isInstance: true, instanceNumber };
    }

    // Main bot — global storage (backward compat).
    return {
        dbPath: path.join(__dirname, '../../../Storage', fileName),
        isInstance: false,
        instanceNumber: null
    };
}

/**
 * Load config broadcast untuk instance aktif.
 *
 * @param {Object} ctx
 * @param {string} fileName
 * @param {Object} defaultValue
 */
function loadBroadcastConfig(ctx, fileName = 'jpm.json', defaultValue = {}) {
    const { dbPath } = resolveBroadcastPath(ctx, fileName);
    const data = loadDBLayer(dbPath, defaultValue);
    return { ...defaultValue, ...(data || {}), config: { ...(defaultValue.config || {}), ...((data && data.config) || {}) } };
}

/**
 * Simpan config broadcast untuk instance aktif.
 */
function saveBroadcastConfig(ctx, data, fileName = 'jpm.json') {
    const { dbPath } = resolveBroadcastPath(ctx, fileName);
    try {
        saveDBLayer(dbPath, data);
        return true;
    } catch (err) {
        console.error(`[broadcastInstance] Gagal simpan ${fileName}:`, err);
        return false;
    }
}

/**
 * Verifikasi bahwa pengirim diizinkan menjalankan broadcast untuk instance ini.
 *
 * - Main bot: superowner only (sesuai isSuperOwner di plugin).
 * - Jadibot instance: owner bot itu sendiri (sesuai jadibotManager.getOwnerList).
 *
 * Ini memastikan broadcast dari jadibot TIDAK bocor ke grup/chats bot lain.
 */
function canBroadcast(ctx) {
    if (!ctx) return false;
    if (ctx.isSuperOwner) return true;
    if (ctx.isJadibot && ctx.jadibotJid && ctx.m?.sender) {
        const owners = jadibotManager.getOwnerList(ctx.jadibotJid);
        const normalize = (v) => String(v).replace(/[^0-9]/g, '');
        return owners.some((o) => normalize(o) === normalize(ctx.m.sender));
    }
    return false;
}

module.exports = {
    resolveBroadcastPath,
    loadBroadcastConfig,
    saveBroadcastConfig,
    canBroadcast
};

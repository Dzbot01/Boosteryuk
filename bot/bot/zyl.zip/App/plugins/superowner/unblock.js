module.exports = {
    name: 'unblock',
    category: 'superowner',
    commands: ['unblock'],
    isOwner: true,
    isSuperOwner: true,
    isGroup: false,

    async execute({ m, Yudzxml, args }) {
        let jid;

        if (m.mentionedJid?.[0]) {
            jid = m.mentionedJid[0];
        } else if (args[0]) {
            let number = args[0].replace(/[^0-9]/g, '');
            if (number.startsWith('0')) number = '62' + number.slice(1);
            jid = number + '@s.whatsapp.net';
        }

        if (!jid) {
            return m.reply('Gunakan mention atau nomor.\nContoh: .unblock @user / .unblock 62812xxxx');
        }

        try {
            await Yudzxml.updateBlockStatus(jid, 'unblock');
            m.reply('✅ Nomor berhasil dibuka blokirnya.');
        } catch (err) {
            console.error(err);
            m.reply('❌ Gagal membuka blokir.');
        }
    }
};

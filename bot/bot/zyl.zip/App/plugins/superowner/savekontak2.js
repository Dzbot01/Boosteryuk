module.exports = {
    name: 'savekontak2',
    category: 'superowner',
    commands: ['savekontak2'],
    isSuperOwner: true,
    isGroup: true,

    async execute({ m, Yudzxml, config }) {
        try {
            const groupId = m.chat;

            const metadata = await Yudzxml.groupMetadata(groupId);
            if (!metadata?.participants?.length) {
                return m.reply('❌ Gagal mengambil data peserta grup.');
            }

            const participants = metadata.participants
                .map((p) => p.jid)
                .filter((jid) => jid && jid.endsWith('@s.whatsapp.net'));

            const botJid = Yudzxml.user.id.split(':')[0] + '@s.whatsapp.net';
            const targets = participants.filter((jid) => jid !== botJid);

            if (!targets.length) {
                return m.reply('❌ Tidak ada kontak yang bisa disimpan.');
            }

            const vcard = targets
                .map((jid, i) => {
                    const number = jid.split('@')[0];
                    return [
                        'BEGIN:VCARD',
                        'VERSION:3.0',
                        `FN:MEMBER ${i + 1}`,
                        `TEL;type=CELL;waid=${number}:${number}`,
                        'END:VCARD',
                        ''
                    ].join('\n');
                })
                .join('');

            await Yudzxml.sendMessage(
                m.sender,
                {
                    document: Buffer.from(vcard),
                    mimetype: 'text/vcard',
                    fileName: `SAVEKONTAK_${metadata.subject}.vcf`,
                    caption:
                        `📂 *SAVE KONTAK GRUP*\n\n` +
                        `🏷 Grup : ${metadata.subject}\n` +
                        `👥 Total: ${targets.length} kontak\n` +
                        `📌 Status: Berhasil disimpan`
                },
                { quoted: m }
            );
        } catch (err) {
            console.error(err);
            m.reply('❌ Terjadi kesalahan saat menyimpan kontak.');
        }
    }
};

module.exports = {
    name: 'setnamebot',
    category: 'superowner',
    commands: ['setnamebot'],
    description: 'Mengubah nama bot',
    isGroup: false,
    isOwner: true,
    isSuperOwner: true,

    async execute({ m, Yudzxml }) {
        if (!m.text) {
            return m.reply('❌ Masukkan nama bot baru.');
        }

        try {
            await Yudzxml.updateProfileName(m.text);
            m.reply('✅ Nama bot berhasil diperbarui.');
        } catch (err) {
            console.error('[SETNAMEBOT ERROR]', err);
            m.reply('❌ Gagal mengubah nama bot.');
        }
    }
};

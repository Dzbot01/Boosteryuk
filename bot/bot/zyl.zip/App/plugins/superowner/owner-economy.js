module.exports = {
    name: 'owner-economy',
    category: 'superowner',
    commands: ['adduser', 'addmoney', 'addlimit', 'addlevel', 'resetlimit'],
    isOwner: true,
    isSuperOwner: true,

    async execute({ Yudzxml, m, command, args, addUser, getUser, addMoney, addLimit, addLevel, resetLimit }) {
        const resolveTarget = () => {
            if (m.mentionedJid?.length) return m.mentionedJid[0];

            if (args[0] && /^\d{8,15}$/.test(args[0])) {
                return args[0] + '@s.whatsapp.net';
            }

            return m.sender;
        };

        const target = resolveTarget();
        const tag = `@${target.split('@')[0]}`;

        const send = (text) => Yudzxml.sendMessage(m.chat, { text, mentions: [target] }, { quoted: m });

        const amount = Number(args[args.length - 1]);
        const isValidAmount = Number.isInteger(amount) && amount > 0;

        if (command === 'adduser') {
            const success = addUser(target);

            return send(success ? `✅ *USER BERHASIL DIDAFTARKAN*\n👤 ${tag}` : `ℹ️ *USER SUDAH TERDAFTAR*\n👤 ${tag}`);
        }

        const userData = getUser(target);
        if (!userData) {
            return send(
                `❌ *USER BELUM TERDAFTAR*\n\n` + `📌 Gunakan *.adduser* terlebih dahulu\n` + `👤 Target : ${tag}`
            );
        }

        if (['addmoney', 'addlimit', 'addlevel'].includes(command) && !isValidAmount) {
            return send(`❌ *Jumlah tidak valid*\n` + `📌 Gunakan angka bulat > 0`);
        }

        if (command === 'addmoney') {
            addMoney(target, amount);

            return send(`✅ *ADD MONEY BERHASIL*\n\n` + `💸 Jumlah : ${amount}\n` + `👤 User   : ${tag}`);
        }

        if (command === 'addlimit') {
            addLimit(target, amount);

            return send(`✅ *ADD LIMIT BERHASIL*\n\n` + `🎟️ Jumlah : ${amount}\n` + `👤 User   : ${tag}`);
        }

        if (command === 'addlevel') {
            addLevel(target, amount);

            return send(`✅ *ADD LEVEL BERHASIL*\n\n` + `⬆️ Jumlah : ${amount}\n` + `👤 User   : ${tag}`);
        }

        if (command === 'resetlimit') {
            resetLimit(target);

            return send(`✅ *RESET LIMIT BERHASIL*\n\n` + `🎟️ Limit dikembalikan ke default\n` + `👤 User : ${tag}`);
        }
    }
};

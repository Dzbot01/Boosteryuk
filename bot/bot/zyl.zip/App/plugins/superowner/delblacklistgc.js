const { readBlacklist, removeBlacklistEntry } = require('@App/function/groupBlacklist');

module.exports = {
    name: 'delblacklistgc',
    category: 'superowner',
    commands: ['delblacklistgc'],
    isSuperOwner: true,

    async execute({ m, args }) {
        const data = readBlacklist();
        if (data.length === 0) {
            return m.reply('Blacklist grup kosong.');
        }

        if (!args[0]) {
            return m.reply('Masukkan nomor atau ID grup.');
        }

        let removed;

        if (/^\d+$/.test(args[0])) {
            const index = Number(args[0]) - 1;
            if (!data[index]) {
                return m.reply('Nomor tidak valid.');
            }
            removed = removeBlacklistEntry(data[index].id);
        } else {
            removed = removeBlacklistEntry(args[0]);
            if (!removed) {
                return m.reply('ID grup tidak ditemukan.');
            }
        }

        return m.reply(`BLACKLIST DIHAPUS\n\n` + `Nama : ${removed.name || '-'}\n` + `ID : ${removed.id}`);
    }
};

const jadibotManager = require('../../../src/core/jadibot');

module.exports = {
    name: 'public',
    category: 'superowner',
    commands: ['public'],
    isOwner: true,
    isSuperOwner: true,
    isGroup: false,

    async execute({ m, config, isJadibot, Yudzxml }) {
        try {
            if (isJadibot && Yudzxml.jadibotJid) {
                const entry = jadibotManager.get(Yudzxml.jadibotJid);
                if (!entry) return m.reply('_Data bot tidak ditemukan._');
                if (entry.public !== false) {
                    return m.reply('ℹ️ Bot sudah dalam mode *PUBLIC*.');
                }
                jadibotManager.setPublicMode(Yudzxml.jadibotJid, true);
                return m.reply(
                    '🌐 Mode *PUBLIC* diaktifkan untuk bot ini.\nBot jadibot sekarang merespons semua pengguna.'
                );
            }

            if (config.public === true) {
                return m.reply('ℹ️ Bot sudah dalam mode *PUBLIC*.');
            }
            config.public = true;
            m.reply('🌐 Mode *PUBLIC* diaktifkan.\nBot sekarang merespons semua pengguna.');
        } catch (err) {
            console.error(err);
            m.reply('❌ Gagal mengaktifkan mode PUBLIC.');
        }
    }
};

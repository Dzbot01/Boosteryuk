module.exports = {
    name: 'setbiobot',
    category: 'superowner',
    commands: ['setbiobot', 'setaboutbot'],
    description: 'Mengubah bio bot',
    isGroup: false,
    isOwner: true,
    isSuperOwner: true,

    async execute({ m, Yudzxml }) {
        if (!m.text) {
            return m.reply('❌ Masukkan bio bot.');
        }

        try {
            await Yudzxml.updateProfileStatus(m.text);
            m.reply('✅ Bio bot berhasil diperbarui.');
        } catch (err) {
            console.error('[SETBIOBOT ERROR]', err);
            m.reply('❌ Gagal mengubah bio bot.');
        }
    }
};

module.exports = {
    name: 'backup',
    category: 'superowner',
    commands: ['backup'],
    isSuperOwner: true,
    async execute({ m, Yudzxml, performBackup }) {
        await performBackup(Yudzxml);
    }
};

module.exports = {
    name: 'ban',
    category: 'superowner',
    commands: ['ban'],
    isOwner: true,
    isSuperOwner: true,
    isGroup: false,

    async execute({ m, args, BannedDB }) {
        let jid;

        if (m.mentionedJid?.[0]) {
            jid = m.mentionedJid[0];
        } else if (args[0]) {
            let number = args[0].replace(/[^0-9]/g, '');
            if (number.startsWith('0')) number = '62' + number.slice(1);
            jid = number + '@s.whatsapp.net';
        }

        const duration = args[1];
        const reason = args.slice(2).join(' ') || 'Tidak ada alasan';

        if (!jid || !duration) {
            return m.reply('Format:\n.ban @user 1day alasan\n.ban 62812xxx 1hour spam');
        }

        const result = BannedDB({
            userId: jid,
            action: 'ban',
            duration,
            reason
        });

        if (result?.error) return m.reply(`❌ ${result.error}`);

        m.reply(`🚫 User berhasil dibanned

🕒 Durasi: ${duration}
📝 Alasan: ${reason}`);
    }
};

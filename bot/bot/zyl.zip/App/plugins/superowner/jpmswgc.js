const { isBlacklisted } = require('@App/function/groupBlacklist');
const { sleep } = require('@App/function/handler');
const { canBroadcast } = require('./_broadcastInstance');

module.exports = {
    name: 'jpmswgc',
    category: 'superowner',
    commands: ['jpmswgc'],
    isSuperOwner: true,
    allowJadibotOwner: true,
    isRateLimit: true,

    /**
     * P2: JPMSWGC per-instance.
     * Bila dipanggil owner jadibot, broadcast ke status grup dikirim via socket
     * instance tersebut (Yudzxml = instance socket).
     *
     * @param {Object} ctx - Plugin context
     */
    async execute(ctx) {
        const { Yudzxml, m, text, args, isImage, isVideo, isAudio, config, isJadibot, jadibotJid } = ctx;

        // P2: izin broadcast per-instance — owner jadibot juga boleh.
        if (!canBroadcast(ctx)) {
            return m.reply('❌ Hanya owner bot ini yang dapat melakukan JPM SW GC.');
        }

        const caption = text || args.join(' ') || m.quoted?.text || '';
        const { mess } = config.mess;

        let buffer = null;

        try {
            buffer = await m.download();
        } catch {
            try {
                buffer = await m.quoted?.download();
            } catch {
                buffer = null;
            }
        }

        const groups = await Yudzxml.groupFetchAllParticipating();
        const groupIds = Object.keys(groups);

        const delay = 1200;

        const type = isImage ? 'image' : isVideo ? 'video' : isAudio ? 'audio' : caption ? 'text' : null;

        let skipped = 0;

        for (const jid of groupIds) {
            if (isBlacklisted(jid)) {
                skipped++;
                continue;
            }

            try {
                if (!buffer || type === 'text') {
                    await Yudzxml.sendMessage(jid, {
                        groupStatusMessage: {
                            text: caption || ' '
                        }
                    });
                } else if (type === 'image') {
                    await Yudzxml.sendMessage(jid, {
                        groupStatusMessage: {
                            image: buffer,
                            caption
                        }
                    });
                } else if (type === 'video') {
                    await Yudzxml.sendMessage(jid, {
                        groupStatusMessage: {
                            video: buffer,
                            caption
                        }
                    });
                } else if (type === 'audio') {
                    await Yudzxml.sendMessage(jid, {
                        groupStatusMessage: {
                            audio: buffer,
                            mimetype: 'audio/ogg; codecs=opus',
                            ptt: true
                        }
                    });
                }

                await sleep(delay);
            } catch (err) {
                console.log(`Gagal kirim SW ke ${jid}`, err);
            }
        }

        return m.reply(`${config.mess.success}${skipped ? ` (skipped: ${skipped})` : ''}`);
    }
};

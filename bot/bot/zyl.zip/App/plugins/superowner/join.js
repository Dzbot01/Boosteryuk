module.exports = {
    name: 'join',
    category: 'superowner',
    commands: ['join'],
    description: 'Owner memerintahkan bot masuk ke grup via link undangan',
    isSuperOwner: true,
    async execute({ Yudzxml, m, args }) {
        try {
            if (!args[0]) {
                return m.reply('❌ Masukkan link undangan grup.\n\n' + 'Contoh:\n.join https://chat.whatsapp.com/xxxx');
            }

            const link = args[0];
            const code = link.split('https://chat.whatsapp.com/')[1];

            if (!code) {
                return m.reply('❌ Link undangan tidak valid.');
            }

            await Yudzxml.groupAcceptInvite(code);

            m.reply('✅ Bot berhasil masuk ke grup.\nTenang, bot datang dengan niat baik.');
        } catch (error) {
            console.error('[OWNER JOIN ERROR]', error);
            m.reply(
                '⚠️ Gagal masuk ke grup.\n' +
                    'Kemungkinan:\n' +
                    '- Link sudah tidak valid\n' +
                    '- Bot diblokir\n' +
                    '- Grup penuh'
            );
        }
    }
};

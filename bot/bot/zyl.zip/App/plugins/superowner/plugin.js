module.exports = {
    name: 'plugin',
    category: 'superowner',
    commands: ['plugin'],
    isOwner: true,
    isSuperOwner: true,

    async execute({ m, args, loadPlugins, addPlugins, removePlugins, listPlugins, getPlugins, refreshPlugins }) {
        const action = args[0];

        try {
            switch (action) {
                case 'list': {
                    const data = listPlugins();
                    if (Object.keys(data).length === 0) {
                        return m.reply('📭 Tidak ada plugin yang terdaftar.');
                    }

                    let text = '📦 *DAFTAR PLUGIN*\n\n';
                    for (const [category, files] of Object.entries(data)) {
                        text += `📁 *${category}*\n`;
                        files.forEach((p) => {
                            text += `• ${p.name}\n`;
                        });
                        text += '\n';
                    }

                    return m.reply(text.trim());
                }

                case 'get': {
                    const category = args[1];
                    const pluginName = args[2];

                    if (!category || !pluginName) {
                        return m.reply(
                            '❌ Format salah\n\n' + '📌 Gunakan:\n' + '➡️ *.plugin get <category> <pluginName>*'
                        );
                    }

                    const plugin = getPlugins(category, pluginName);

                    const text =
                        `📦 *PLUGIN DETAIL*\n\n` +
                        `📁 Kategori : ${plugin.category}\n` +
                        `📄 File     : ${plugin.file}\n\n` +
                        `🧩 *KODE:*\n` +
                        '```js\n' +
                        plugin.code.trim() +
                        '\n```';

                    return m.reply(text);
                }

                case 'add': {
                    const category = args[1];
                    const pluginName = args[2];

                    if (!category || !pluginName) {
                        return m.reply(
                            '❌ Format salah\n\n' +
                                '📌 Gunakan:\n' +
                                '➡️ *.plugin add <category> <pluginName>*\n' +
                                '📎 Reply pesan berisi kode plugin'
                        );
                    }

                    if (!/^[a-zA-Z0-9]+$/.test(category)) {
                        return m.reply('❌ Nama category hanya boleh huruf dan angka.');
                    }

                    if (!/^[a-zA-Z0-9]+$/.test(pluginName)) {
                        return m.reply('❌ Nama plugin hanya boleh huruf dan angka.');
                    }

                    if (!m.quoted || !m.quoted.text) {
                        return m.reply('❌ Reply pesan yang berisi kode plugin.');
                    }

                    const code = m.quoted.text;

                    if (!code.includes('module.exports')) {
                        return m.reply(
                            '❌ Kode plugin harus mengandung `module.exports`. Pastikan format plugin benar.'
                        );
                    }

                    const dangerousPatterns = [
                        /process\.exit/,
                        /child_process/,
                        /require\(['"]fs['"]\).*unlink/,
                        /require\(['"]fs['"]\).*rmdir/,
                        /require\(['"]fs['"]\).*rmSync/
                    ];
                    for (const pattern of dangerousPatterns) {
                        if (pattern.test(code)) {
                            return m.reply('❌ Kode mengandung pola berbahaya yang tidak diizinkan.');
                        }
                    }

                    const result = addPlugins(category, pluginName, code);
                    return m.reply(result);
                }

                case 'del':
                case 'remove': {
                    const category = args[1];
                    const pluginName = args[2];

                    if (!category || !pluginName) {
                        return m.reply(
                            '❌ Format salah\n\n' + '📌 Gunakan:\n' + '➡️ *.plugin del <category> <pluginName>*'
                        );
                    }

                    const result = removePlugins(category, pluginName);
                    return m.reply(result);
                }

                case 'reload': {
                    refreshPlugins();
                    return m.reply('♻️ Semua plugin berhasil di-reload.');
                }

                default:
                    return m.reply(
                        '🔌 *PLUGIN MANAGER*\n\n' +
                            '📌 Perintah tersedia:\n' +
                            '• *.plugin list*\n' +
                            '• *.plugin add <category> <name>*\n' +
                            '• *.plugin del <category> <name>*\n' +
                            '• *.plugin reload*'
                    );
            }
        } catch (err) {
            console.error('[PLUGIN MANAGER ERROR]', err);
            return m.reply('❌ Terjadi kesalahan saat memproses plugin.\n' + '📄 Detail telah dicatat di log.');
        }
    }
};

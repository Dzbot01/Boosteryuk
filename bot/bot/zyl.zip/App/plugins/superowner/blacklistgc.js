const {
    readBlacklist,
    writeBlacklist,
    isBlacklisted,
    setBlacklistStatus
} = require('@App/function/groupBlacklist');

const parseAction = (arg) => {
    if (!arg) return null;
    const v = arg.toLowerCase();
    if (['on', 'true', '1'].includes(v)) return true;
    if (['off', 'false', '0'].includes(v)) return false;
    if (['status', 'cek'].includes(v)) return 'status';
    return null;
};

module.exports = {
    name: 'blacklistgc',
    category: 'superowner',
    commands: ['blacklistgc'],
    isSuperOwner: true,

    normalizeInvite(text) {
        const m = text?.match(/chat\.whatsapp\.com\/([A-Za-z0-9_-]{10,})/i);
        return m ? m[1] : null;
    },

    async getGroupFromInvite(bot, code) {
        const res = await bot.query({
            tag: 'iq',
            attrs: { type: 'get', xmlns: 'w:g2', to: '@g.us' },
            content: [{ tag: 'invite', attrs: { code } }]
        });

        const d = res?.content?.[0]?.attrs;
        if (!d?.id || !d?.subject) throw new Error('Gagal mengambil data grup');

        return {
            id: d.id.endsWith('@g.us') ? d.id : `${d.id}@g.us`,
            name: d.subject
        };
    },

    async execute({ Yudzxml, m, args }) {
        let groupData;
        let action;

        if (m.isGroup) {
            const meta = await Yudzxml.groupMetadata(m.chat);
            groupData = { id: m.chat, name: meta.subject };
            action = parseAction(args[0]);
        } else {
            if (!args[0] || !args[1]) {
                return m.reply('Gunakan: .blacklistgc <link_grup> on/off/status');
            }

            const code = this.normalizeInvite(args[0]);
            if (!code) return m.reply('Link grup tidak valid.');

            groupData = await this.getGroupFromInvite(Yudzxml, code);
            action = parseAction(args[1]);
        }

        if (action === null) {
            return m.reply('Gunakan: on / off / status');
        }

        if (action === 'status') {
            return m.reply(
                `STATUS BLACKLIST GRUP\n\n` +
                    `Nama : ${groupData.name}\n` +
                    `ID : ${groupData.id}\n` +
                    `BanCmd : ${isBlacklisted(groupData.id) ? 'ON ✅' : 'OFF ❌'}`
            );
        }

        setBlacklistStatus(groupData, action);

        return m.reply(
            `STATUS BLACKLIST GRUP\n\n` +
                `Nama : ${groupData.name}\n` +
                `ID : ${groupData.id}\n` +
                `BanCmd : ${action ? 'ON ✅' : 'OFF ❌'}`
        );
    }
};

const jadibotManager = require('../../../src/core/jadibot');

module.exports = {
    name: 'self',
    category: 'superowner',
    commands: ['self'],
    isOwner: true,
    isSuperOwner: true,
    isGroup: false,

    async execute({ m, config, isJadibot, Yudzxml }) {
        try {
            if (isJadibot && Yudzxml.jadibotJid) {
                const entry = jadibotManager.get(Yudzxml.jadibotJid);
                if (!entry) return m.reply('_Data bot tidak ditemukan._');
                if (entry.public === false) {
                    return m.reply('ℹ️ Bot sudah dalam mode *SELF*.');
                }
                jadibotManager.setPublicMode(Yudzxml.jadibotJid, false);
                return m.reply('🔒 Mode *SELF* diaktifkan untuk bot ini.\nBot jadibot sekarang hanya merespons owner.');
            }

            if (config.public === false) {
                return m.reply('ℹ️ Bot sudah dalam mode *SELF*.');
            }
            config.public = false;
            m.reply('🔒 Mode *SELF* diaktifkan.\nBot sekarang hanya merespons owner.');
        } catch (err) {
            console.error(err);
            m.reply('❌ Gagal mengaktifkan mode SELF.');
        }
    }
};

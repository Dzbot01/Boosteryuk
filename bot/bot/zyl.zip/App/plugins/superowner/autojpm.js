const { loadBroadcastConfig, saveBroadcastConfig, canBroadcast } = require('./_broadcastInstance');

const DEFAULT_JPM = {
    active: false,
    lastSent: 0,
    config: {
        type: 'text',
        url: '',
        text_promo: '',
        time: 6
    }
};

const saveConfig = (ctx, data) => saveBroadcastConfig(ctx, data, 'jpm.json');
const getConfig = (ctx) => loadBroadcastConfig(ctx, 'jpm.json', DEFAULT_JPM);

module.exports = {
    name: 'autojpm',
    category: 'superowner',
    commands: ['setautojpm'],
    isSuperOwner: true,
    allowJadibotOwner: true,
    isOwner: false,
    isGroup: false,
    isAdmin: false,
    isPremium: false,

    /**
     * Plugin autojpm — sekarang per-instance (P2).
     *
     * Bila dijalankan oleh owner jadibot (bukan superowner), config disimpan
     * di Storage/jadibot_data/<number>/jpm.json — terpisah dari main bot.
     *
     * @param {Object} ctx - Plugin context (lihat src/handler/contextBuilder.js)
     */
    async execute(ctx) {
        const { m, Yudzxml, isImage, isVideo, YudzCdn, quoted, args, isJadibot, jadibotJid } = ctx;

        // P2: izin broadcast per-instance — owner jadibot juga boleh.
        if (!canBroadcast(ctx)) {
            return m.reply('❌ Hanya owner bot ini yang dapat mengatur auto JPM.');
        }

        try {
            let jpmData = getConfig(ctx);
            const inputCommand = (args[0] || '').toLowerCase();

            if (inputCommand === 'on') {
                jpmData.active = true;
                const isSaved = saveConfig(ctx, jpmData);
                return m.reply(
                    isSaved
                        ? `✅ *Auto JPM diaktifkan*${isJadibot ? ` (instance ${jadibotJid?.split('@')[0]})` : ''}.`
                        : '❌ Gagal mengaktifkan JPM.'
                );
            }

            if (inputCommand === 'off') {
                jpmData.active = false;
                const isSaved = saveConfig(ctx, jpmData);
                return m.reply(
                    isSaved
                        ? `✅ *Auto JPM dimatikan*${isJadibot ? ` (instance ${jadibotJid?.split('@')[0]})` : ''}.`
                        : '❌ Gagal mematikan JPM.'
                );
            }

            let timeArg = parseInt(args[0]);
            let messageText = args.join(' ');

            if (!isNaN(timeArg)) {
                jpmData.config.time = timeArg;
                messageText = args.slice(1).join(' ');
            }

            jpmData.active = true;

            if (isImage) {
                if (!quoted) return m.reply('❌ Mohon reply/balas gambar yang ingin digunakan!');
                const media = await Yudzxml.downloadAndSaveMediaMessage(quoted);
                const url = YudzCdn(media, 'permanent');
                jpmData.config.type = 'image';
                jpmData.config.url = url;
                jpmData.config.text_promo = messageText || '';
                await m.reply(
                    `✅ *Auto JPM (Image)* diatur!\n\n📸 URL: ${url}\n⏱️ Delay: ${jpmData.config.time} Jam\n🟢 Status: Aktif`
                );
            } else if (isVideo) {
                if (!quoted) return m.reply('❌ Mohon reply/balas video yang ingin digunakan!');
                const media = await Yudzxml.downloadAndSaveMediaMessage(quoted);
                const url = YudzCdn(media, 'permanent');
                jpmData.config.type = 'video';
                jpmData.config.url = url;
                jpmData.config.text_promo = messageText || '';
                await m.reply(
                    `✅ *Auto JPM (Video)* diatur!\n\n🎥 URL: ${url}\n⏱️ Delay: ${jpmData.config.time} Jam\n🟢 Status: Aktif`
                );
            } else {
                if (!messageText) {
                    return m.reply(
                        '❌ Mohon berikan teks promo dan waktu.\n\nContoh: .setautojpm 10 Halo ini promo\nAtau ketik .setautojpm on / .setautojpm off'
                    );
                }
                jpmData.config.type = 'text';
                jpmData.config.text_promo = messageText;
                if (!isNaN(timeArg)) jpmData.config.time = timeArg;
                await m.reply(
                    `✅ *Auto JPM (Text)* diatur!\n\n📝 Teks: ${messageText}\n⏱️ Delay: ${jpmData.config.time} Jam\n🟢 Status: Aktif`
                );
            }

            saveConfig(ctx, jpmData);
        } catch (error) {
            console.error('Error in setautojpm command:', error);
            await m.reply(`❌ Terjadi kesalahan sistem: ${error.message}`);
        }
    }
};

const fs = require('fs');
const path = require('path');

const { saveDB } = require('../../../database/wrappers/storage');

const OWNER_PATH = path.resolve(__dirname, '../../../Storage/owner.json');

module.exports = {
    name: 'addowner',
    category: 'superowner',
    commands: ['addowner'],
    description: 'Tambah owner global bot utama (khusus superowner, di bot utama)',
    isOwner: false,
    isSuperOwner: true,
    isGroup: false,
    isAdmin: false,
    isPremium: false,

    async execute({ m, db_owner, args, isJadibot, config }) {
        if (isJadibot) {
            return m.reply('_Perintah ini hanya bisa dijalankan di bot utama._');
        }

        let targetJid = m.mentionedJid[0] || m.quoted?.sender || args[0];
        if (!targetJid) {
            return m.reply('Silakan tag, reply atau input nomor yang ingin ditetapkan sebagai owner.');
        }

        const user = targetJid.split('@')[0].replace(/[^0-9]/g, '');

        if (!user) {
            return m.reply('Nomor user tidak valid.');
        }

        if (db_owner.includes(user)) {
            return m.reply('User tersebut sudah terdaftar sebagai owner.');
        }

        db_owner.push(user);

        saveDB(OWNER_PATH, db_owner);

        return m.reply(`✅ @${user} berhasil ditambahkan sebagai Owner.`, m.chat, {
            mentionedJid: [user + '@s.whatsapp.net']
        });
    }
};

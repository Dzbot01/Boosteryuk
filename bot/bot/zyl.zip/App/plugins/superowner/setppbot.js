module.exports = {
    name: 'setppbot',
    category: 'superowner',
    commands: ['setppbot'],
    description: 'Mengubah foto profil bot',
    isGroup: false,
    isOwner: true,
    isSuperOwner: true,

    async execute({ botNumber, m, Yudzxml, isImage, YudzCdn }) {
        try {
            if (!isImage) {
                return m.reply('❌ Reply atau kirim gambar untuk dijadikan foto bot.');
            }

            let buffer = null;

            try {
                buffer = m.quoted ? await m.quoted.download() : await m.download();
            } catch {
                buffer = await m.download();
            }

            const url = await YudzCdn(buffer, 'expired');

            await Yudzxml.updateProfilePicture(botNumber, { url });

            m.reply('✅ Foto profil bot berhasil diperbarui.');
        } catch (err) {
            console.error('[SETPPBOT ERROR]', err);
            m.reply('❌ Gagal mengubah foto bot.');
        }
    }
};

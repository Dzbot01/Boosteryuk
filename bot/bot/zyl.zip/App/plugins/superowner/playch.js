module.exports = {
    name: 'playch',
    category: 'superowner',
    commands: ['playch'],
    description: 'Kirim lagu ke channel (bot utama: superowner; bot jadibot: owner instance)',
    isOwner: true,

    async execute({ m, text, Yudzxml, config, isSuperOwner, fetchJson, getBuffer, toPTT }) {
        const isInstance = Boolean(Yudzxml.isJadibot);

        let targetIdch;
        let targetOwnername;

        if (isInstance) {
            const instanceChannel = Yudzxml.jadibotEntry?.settings?.idch;

            if (!instanceChannel) {
                return m.reply(
                    '📡 *CHANNEL BELUM DIPASANG*\n\n' +
                        'Pasang dulu ID channel milikmu supaya konten tidak terkirim ke channel bot utama:\n\n' +
                        '1. Ambil ID channel: .cekidch <link channel>\n' +
                        '2. Pasang: .setidch <id>@newsletter\n' +
                        '3. (Opsional) Branding: .setownername <nama>'
                );
            }

            targetIdch = instanceChannel;
            targetOwnername = Yudzxml.identity?.ownername;
        } else {
            if (!isSuperOwner) {
                return m.reply(config.mess.superowner);
            }
            targetIdch = config.idch;
            targetOwnername = config.ownername;
        }

        try {
            if (!text) {
                return m.reply('— Masukkan judul lagu atau URL YouTube.');
            }

            const credentials = config.apikey;

            if (!credentials?.endpoint || !credentials?.key) {
                return m.reply(
                    '🔑 *API KEY BOT UTAMA BELUM DIPASANG*\n\n' +
                        'Fitur ini memakai API key bot utama yang diatur superowner di config.js.\n' +
                        'Hubungi owner bot utama untuk mengaktifkannya.'
                );
            }

            const { endpoint, key } = credentials;

            let videoUrl = text.trim();
            let title = 'Audio';

            const isUrl = /^https?:\/\//i.test(videoUrl);

            if (!isUrl) {
                const search = await fetchJson(
                    `${endpoint}/api/search/youtube?q=${encodeURIComponent(videoUrl)}&apikey=${key}`
                );

                if (!Array.isArray(search?.data) || !search.data.length) {
                    return m.reply('❌ Lagu tidak ditemukan.');
                }

                const video = search.data[0];
                videoUrl = video.url;
                title = video.title;
            }

            const download = await fetchJson(
                `${endpoint}/api/download/youtubev3?url=${encodeURIComponent(videoUrl)}&format=mp3&quality=128&apikey=${key}`
            );

            const downloadUrl = download?.data?.downloadUrl;

            if (!downloadUrl) {
                return m.reply('❌ Gagal mengambil audio.');
            }

            const buffer = await getBuffer(downloadUrl);
            const { data } = await toPTT(buffer);

            await Yudzxml.sendMessage(targetIdch, {
                audio: data,
                mimetype: 'audio/ogg; codecs=opus',
                ptt: true,
                contextInfo: {
                    mentionedJid: [m.sender],
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: targetIdch,
                        newsletterName: targetOwnername || config.ownername
                    }
                }
            });

            await m.reply(`✅ Audio berhasil dikirim ke channel.\n🎵 ${title}`);
        } catch (err) {
            console.error('[PLAYCH ERROR]', err);
            await m.reply('⚠️ Terjadi kesalahan internal. Coba lagi nanti.');
        }
    }
};

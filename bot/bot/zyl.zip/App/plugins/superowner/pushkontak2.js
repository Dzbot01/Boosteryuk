module.exports = {
    name: 'pushkontak2',
    category: 'superowner',
    commands: ['pushkontak2'],
    isSuperOwner: true,
    isGroup: true,

    async execute({ m, Yudzxml, args, prefix, command, config }) {
        try {
            if (!args[0]) {
                return m.reply(
                    `❌ *Format Penggunaan Salah!*\n\n` +
                        `📝 Cara penggunaan:\n` +
                        `${prefix + command} <pesan>\n\n` +
                        `📌 Contoh:\n` +
                        `${prefix + command} Halo member, ada info baru!`
                );
            }

            const messageText = args.join(' ');
            const groupId = m.chat;

            const metadata = await Yudzxml.groupMetadata(groupId);
            if (!metadata?.participants?.length) {
                return m.reply('❌ *Gagal Mengambil Peserta Grup.*');
            }

            const participants = metadata.participants.map((p) => p.jid).filter(Boolean);

            const botNumber = Yudzxml.user.id.split(':')[0] + '@s.whatsapp.net';
            const targets = participants.filter((jid) => jid !== botNumber);

            const randomDelay = (min = 1000, max = 7000) => Math.floor(Math.random() * (max - min + 1)) + min;

            let successCount = 0;
            let failedCount = 0;

            for (let i = 0; i < targets.length; i++) {
                const jid = targets[i];
                try {
                    const delay = randomDelay();
                    await new Promise((r) => setTimeout(r, delay));
                    await Yudzxml.sendMessage(jid, { text: messageText });
                    successCount++;
                } catch {
                    failedCount++;
                }
            }

            const reportText =
                `*📋 LAPORAN PUSH KONTAK*\n\n` +
                `📢 *Grup:* ${metadata.subject}\n` +
                `👥 *Total Target:* ${targets.length}\n` +
                `✅ *Berhasil:* ${successCount}\n` +
                `❌ *Gagal:* ${failedCount}\n\n` +
                `🤖 *Status:* Selesai (Delay Acak 1–7 Detik)`;

            await Yudzxml.sendMessage(m.sender, { text: reportText });

            const uniqueContacts = [...new Set(targets)];
            const vcardContent = uniqueContacts
                .map((contact) => {
                    const number = contact.split('@')[0];
                    return [
                        'BEGIN:VCARD',
                        'VERSION:3.0',
                        `FN:MEMBER [ ${config.ownername} ] ${number}`,
                        `TEL;type=CELL;type=VOICE;waid=${number}:+${number}`,
                        'END:VCARD',
                        ''
                    ].join('\n');
                })
                .join('');

            await Yudzxml.sendMessage(
                m.sender,
                {
                    document: Buffer.from(vcardContent),
                    mimetype: 'text/vcard',
                    fileName: `Contacts_${metadata.subject}.vcf`,
                    caption: `📂 *File Kontak Grup*\n👥 Total: ${uniqueContacts.length} kontak`
                },
                { quoted: m }
            );
        } catch (error) {
            console.error(error);
        }
    }
};

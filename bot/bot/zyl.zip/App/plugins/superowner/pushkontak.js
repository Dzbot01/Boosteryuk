const { canBroadcast } = require('./_broadcastInstance');

module.exports = {
    name: 'pushkontak',
    category: 'superowner',
    commands: ['pushkontak'],
    isSuperOwner: true,
    allowJadibotOwner: true,
    /**
     * P2: Push kontak per-instance.
     *
     * Bila dipanggil oleh owner jadibot (bukan superowner), broadcast
     * dikirim via socket instance tersebut (Yudzxml sudah otomatis instance
     * yang benar — lihat src/handler/main.js). Tidak mengganggu main bot.
     *
     * @param {Object} ctx - Plugin context
     */
    async execute(ctx) {
        const { m, Yudzxml, args, prefix, command, config, isJadibot, jadibotJid } = ctx;

        // P2: izin broadcast per-instance — owner jadibot juga boleh.
        if (!canBroadcast(ctx)) {
            return m.reply('❌ Hanya owner bot ini yang dapat menggunakan push kontak.');
        }

        try {
            if (!args[0] || !args[1]) {
                return m.reply(
                    `❌ *Format Penggunaan Salah!*\n\n` +
                        `📝 Cara penggunaan:\n` +
                        `${prefix + command} <link_grup> <pesan>\n\n` +
                        `📌 Contoh:\n` +
                        `${prefix + command} https://chat.whatsapp.com/ABC123 Halo member, ada info baru!`
                );
            }

            const input = args.join(' ');
            const linkGroup = args[0];
            const messageText = input.slice(linkGroup.length).trim();

            const inviteCode = linkGroup.split('https://chat.whatsapp.com/')[1];
            if (!inviteCode) return m.reply('❌ *Link Grup Tidak Valid!*');

            await m.reply('⏳ *Sedang Memproses...*\nMengambil metadata grup, harap tunggu sebentar.');

            const res = await Yudzxml.query({
                tag: 'iq',
                attrs: { type: 'get', xmlns: 'w:g2', to: '@g.us' },
                content: [{ tag: 'invite', attrs: { code: inviteCode } }]
            });

            const groupData = res?.content?.[0]?.attrs;
            if (!groupData || !groupData.id) return m.reply('❌ *Gagal Mengambil Info Grup.*');

            const groupId = groupData.id + '@g.us';
            const metadata = await Yudzxml.groupMetadata(groupId);
            if (!metadata || !metadata.participants) return m.reply('❌ *Gagal Mengambil Peserta Grup.*');

            const participants = metadata.participants.map((p) => p.jid).filter(Boolean);

            const targets = participants.filter((jid) => jid !== Yudzxml.user.id.split(':')[0] + '@s.whatsapp.net');

            await m.reply(
                `✅ *Target Terkunci:* ${metadata.subject}\n👥 *Total:* ${targets.length} orang\n\n🚀 *Memulai Push Kontak dengan Mode Aman...*`
            );

            let successCount = 0;
            let failedCount = 0;

            const BATCH_SIZE = 20;
            const COOLDOWN_TIME = 30000;

            for (let i = 0; i < targets.length; i++) {
                const jid = targets[i];

                try {
                    const randomDelay = Math.floor(Math.random() * (7000 - 3000 + 1) + 3000);
                    await new Promise((resolve) => setTimeout(resolve, randomDelay));

                    await Yudzxml.sendMessage(jid, { text: messageText });
                    successCount++;

                    console.log(`[SUCCESS] Terkirim ke ${i + 1}/${targets.length}`);

                    if ((i + 1) % BATCH_SIZE === 0 && i + 1 < targets.length) {
                        console.log(`[SYSTEM] Pausing for ${COOLDOWN_TIME / 1000}s to avoid Rate Limit...`);
                        await m.reply(
                            `⏸️ *Sistem Istirahat Sejenak...*\nTerlindungi dari deteksi spam.\nMelanjutkan dalam 30 detik.`
                        );
                        await new Promise((resolve) => setTimeout(resolve, COOLDOWN_TIME));
                    }
                } catch (err) {
                    console.error(`[FAILED] Gagal mengirim ke ${jid}:`, err);
                    failedCount++;
                }
            }

            const reportText =
                `*📋 LAPORAN PUSH KONTAK*\n\n` +
                `📢 *Grup:* ${metadata.subject}\n` +
                `✅ *Berhasil:* ${successCount}\n` +
                `❌ *Gagal:* ${failedCount}\n` +
                `📊 *Total Target:* ${targets.length}\n\n` +
                `🛡️ *Status:* Proses Selesai (Mode Aman).`;

            await m.reply(reportText);

            try {
                const uniqueContacts = [...new Set(targets)];
                const vcardContent = uniqueContacts
                    .map((contact) => {
                        const number = contact.split('@')[0];
                        return [
                            'BEGIN:VCARD',
                            'VERSION:3.0',
                            `FN:MEMBER [ ${config.ownername} ] ${number}`,
                            `TEL;type=CELL;type=VOICE;waid=${number}:+${number}`,
                            'END:VCARD',
                            ''
                        ].join('\n');
                    })
                    .join('');

                await Yudzxml.sendMessage(
                    m.sender,
                    {
                        document: Buffer.from(vcardContent),
                        mimetype: 'text/vcard',
                        fileName: `Contacts_${metadata.subject}.vcf`,
                        caption: `📂 *File Kontak Grup: ${metadata.subject}*\nTotal: ${uniqueContacts.length} kontak`
                    },
                    { quoted: m }
                );
            } catch (vcardError) {
                console.error('Gagal membuat vcard:', vcardError);
            }
        } catch (error) {
            console.error('System Error:', error);
            m.reply('❌ *Terjadi kesalahan sistem.*');
        }
    }
};

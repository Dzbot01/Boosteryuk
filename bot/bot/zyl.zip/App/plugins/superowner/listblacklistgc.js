const { readBlacklist } = require('@App/function/groupBlacklist');

module.exports = {
    name: 'listblacklistgc',
    category: 'superowner',
    commands: ['listblacklistgc'],
    isSuperOwner: true,

    async execute({ m }) {
        const data = readBlacklist();
        if (data.length === 0) {
            return m.reply('Blacklist grup masih kosong.');
        }

        let text = `LIST BLACKLIST GROUP\n\n`;

        data.forEach((g, i) => {
            text += `${i + 1}. ${g.name || '-'}\n`;
            text += `   ID : ${g.id}\n`;
            if (g.time || g.createdAt || g.updatedAt) {
                const t = g.time || g.createdAt || g.updatedAt;
                text += `   Date : ${new Date(t).toLocaleString('id-ID')}\n`;
            }
            text += `\n`;
        });

        return m.reply(text.trim());
    }
};

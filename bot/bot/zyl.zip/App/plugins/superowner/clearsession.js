const clearSessions = require('../../../App/function/clearSessions');
const { buildWebsiteNotice } = require('@App/function/jadibotWebsite');

module.exports = {
    name: 'clearsession',
    category: 'superowner',
    commands: ['clearsession'],
    description: 'Bersihkan file session sampah (bot utama / superowner)',
    isOwner: true,

    async execute({ m, Yudzxml, config, isSuperOwner }) {
        if (Yudzxml.isJadibot) {
            return m.reply(buildWebsiteNotice('Bersihkan file session bot kamu lewat website.'));
        }

        if (!isSuperOwner) {
            return m.reply(config.mess.superowner);
        }

        await clearSessions();

        await m.reply('✅ Semua session berhasil dibersihkan.');
    }
};

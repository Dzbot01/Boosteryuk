module.exports = {
    name: 'unban',
    category: 'superowner',
    commands: ['unban'],
    isOwner: true,
    isSuperOwner: true,
    isGroup: false,

    async execute({ m, args, BannedDB }) {
        let jid;

        if (m.mentionedJid?.[0]) {
            jid = m.mentionedJid[0];
        } else if (args[0]) {
            let number = args[0].replace(/[^0-9]/g, '');
            if (number.startsWith('0')) number = '62' + number.slice(1);
            jid = number + '@s.whatsapp.net';
        }

        if (!jid) {
            return m.reply('Format:\n.unban @user\n.unban 62812xxxx');
        }

        BannedDB({
            userId: jid,
            action: 'unban'
        });

        m.reply('✅ User berhasil diunban.');
    }
};

const { isBlacklisted } = require('@App/function/groupBlacklist');
const { canBroadcast } = require('./_broadcastInstance');

module.exports = {
    name: 'jpm',
    category: 'superowner',
    commands: ['jpm'],
    description: 'Broadcast Pesan (Media + Button) ke seluruh grup',
    isGroup: false,
    isOwner: true,
    isSuperOwner: true,
    allowJadibotOwner: true,

    /**
     * P2: JPM per-instance.
     *
     * Bila dipanggil owner jadibot (bukan superowner), broadcast dikirim via
     * socket instance itu sendiri (Yudzxml = instance socket). Grup target
     * terbatas pada grup yang diikuti instance tersebut.
     *
     * @param {Object} ctx - Plugin context
     */
    async execute(ctx) {
        const {
            m,
            Yudzxml,
            args,
            isImage,
            isVideo,
            isAudio,
            isDocument,
            proto,
            generateWAMessageFromContent,
            prepareWAMessageMedia,
            config,
            isJadibot,
            jadibotJid
        } = ctx;

        // P2: izin broadcast per-instance — owner jadibot juga boleh.
        if (!canBroadcast(ctx)) {
            return m.reply('❌ Hanya owner bot ini yang dapat melakukan JPM.');
        }

        try {
            const textInput = args.join(' ');
            let media = null;

            if (isImage || isVideo || isAudio || isDocument) {
                if (m.download) media = await m.download();
                else if (m.quoted?.download) media = await m.quoted.download();
            }

            if (!textInput && !media && !m.quoted) {
                return m.reply('❌ Masukkan teks atau reply media.');
            }

            const caption = textInput || m.quoted?.caption || m.quoted?.text || '📢 Informasi';

            let mediaMessage = {};
            if (media) {
                mediaMessage = await prepareWAMessageMedia(
                    isImage
                        ? { image: media }
                        : isVideo
                          ? { video: media }
                          : isAudio
                            ? { audio: media, mimetype: 'audio/mp4' }
                            : {
                                  document: media,
                                  mimetype: m.quoted?.mimetype,
                                  fileName: m.quoted?.fileName || 'File'
                              },
                    { upload: Yudzxml.waUploadToServer }
                );
            }

            const ownerUrl = `https://wa.me/${config.superowner}`;
            let buttons = [];

            const links = (caption || '').match(/https?:\/\/[^\s]+/g) || [];

            for (const link of links) {
                if (link.startsWith('https://whatsapp.com/channel')) {
                    buttons.push({
                        name: 'cta_url',
                        buttonParamsJson: JSON.stringify({
                            display_text: 'Join Saluran',
                            url: link,
                            merchant_url: link
                        })
                    });
                } else if (link.startsWith('https://chat.whatsapp.com') || link.startsWith('https://whatsapp.com')) {
                    buttons.push({
                        name: 'cta_url',
                        buttonParamsJson: JSON.stringify({
                            display_text: 'Join Group',
                            url: link,
                            merchant_url: link
                        })
                    });
                }
            }

            buttons.push({
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                    display_text: 'Chat Owner',
                    url: ownerUrl,
                    merchant_url: ownerUrl
                })
            });

            const groups = await Yudzxml.groupFetchAllParticipating();
            const groupIds = Object.keys(groups);

            if (!groupIds.length) {
                return m.reply('⚠️ Bot tidak tergabung di grup manapun.');
            }

            await m.reply(`📣 *JPM Dimulai*\n` + `🎯 Target: ${groupIds.length} Grup`);

            let success = 0;
            let failed = 0;
            let skipped = 0;

            for (const groupId of groupIds) {
                if (isBlacklisted(groupId)) {
                    skipped++;
                    continue;
                }

                try {
                    const msg = generateWAMessageFromContent(
                        groupId,
                        proto.Message.fromObject({
                            viewOnceMessage: {
                                message: {
                                    interactiveMessage: {
                                        header: {
                                            hasMediaAttachment: !!media,
                                            ...mediaMessage
                                        },
                                        body: { text: caption },
                                        footer: { text: '' },
                                        nativeFlowMessage: {
                                            buttons
                                        }
                                    }
                                }
                            }
                        }),
                        { userJid: Yudzxml.user.id }
                    );

                    await Yudzxml.relayMessage(groupId, msg.message, {
                        messageId: msg.key.id
                    });

                    success++;
                    await delay(1500);
                } catch {
                    failed++;
                }
            }

            await m.reply(
                `✅ *JPM Selesai*\n\n` +
                    `✅ Berhasil : ${success}\n` +
                    `⛔ Diblokir : ${skipped}\n` +
                    `❌ Gagal    : ${failed}\n` +
                    `📊 Total    : ${groupIds.length}`
            );
        } catch {
            m.reply('❌ Terjadi kesalahan sistem.');
        }
    }
};

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

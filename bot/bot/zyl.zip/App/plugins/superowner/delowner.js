const fs = require('fs');
const path = require('path');

const { saveDB } = require('../../../database/wrappers/storage');

const OWNER_PATH = path.resolve(__dirname, '../../../Storage/owner.json');

module.exports = {
    name: 'delowner',
    category: 'superowner',
    commands: ['delowner', 'dellowner'],
    description: 'Hapus owner global bot utama (khusus superowner, di bot utama)',
    isOwner: false,
    isSuperOwner: true,
    isGroup: false,
    isAdmin: false,
    isPremium: false,

    async execute({ m, args, db_owner, isJadibot }) {
        if (isJadibot) {
            return m.reply('_Perintah ini hanya bisa dijalankan di bot utama._');
        }

        let targetJid =
            m.mentionedJid?.[0] ||
            m.quoted?.sender ||
            (args?.[0] ? args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : null);

        if (!targetJid) {
            return m.reply('Format: .delowner @tag / reply / nomor');
        }

        const user = targetJid.split('@')[0].replace(/[^0-9]/g, '');

        if (!user) {
            return m.reply('Nomor user tidak valid.');
        }

        if (!Array.isArray(db_owner) || !db_owner.includes(user)) {
            return m.reply('User tersebut bukan owner bot.');
        }

        const updatedOwner = db_owner.filter((v) => v !== user);

        saveDB(OWNER_PATH, updatedOwner);

        return m.reply(`🗑️ Owner berhasil dihapus\n\n👤 User: @${user}`, m.chat, { mentionedJid: [targetJid] });
    }
};

const jadibotManager = require('../../../src/core/jadibot');

module.exports = {
    name: 'addjadibot',
    category: 'superowner',
    commands: ['addjadibot'],
    description: 'Aktivasi manual bot jadibot (gratis)',
    isSuperOwner: true,
    isGroup: false,

    async execute({ m, args }) {
        const number = String(args[0] || '').replace(/[^0-9]/g, '');
        const days = Number(args[1]) || 30;

        if (!number) {
            return m.reply(
                '❌ Format salah.\n\nContoh: .addjadibot 62812xxxx 30\n\n30 = jumlah hari aktif (default 30).'
            );
        }

        try {
            await m.reply('⏳ *Membuat instance jadibot...*');

            const { entry, pairingCode } = await jadibotManager.createJadibot(number, {
                days,
                packageName: `ADMIN (${days}d)`,
                activation: 'admin'
            });

            return m.reply(
                `✅ *JADIBOT DIAKTIFKAN MANUAL*\n\n` +
                    `📱 Nomor : +${entry.number}\n` +
                    `📦 Durasi : ${days} hari\n` +
                    `⏳ Expired : ${new Date(entry.expired).toLocaleString('id-ID')}\n\n` +
                    (pairingCode
                        ? `🔑 *KODE PAIRING:*\n*${pairingCode}*\n\n` +
                          `_Minta pemilik nomor membuka WhatsApp > Perangkat Tertaut > Tautkan dengan Nomor Telepon._`
                        : `_Nomor sudah pernah pairing & akan tersambung otomatis._`)
            );
        } catch (err) {
            return m.reply(`❌ *Gagal:* ${err.message}`);
        }
    }
};

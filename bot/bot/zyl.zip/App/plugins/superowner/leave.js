module.exports = {
    name: 'leave',
    category: 'superowner',
    commands: ['leave', 'out'],
    description: 'Owner memerintahkan bot keluar dari grup',
    isGroup: true,
    isSuperOwner: true,

    async execute({ Yudzxml, m }) {
        try {
            await Yudzxml.groupLeave(m.chat);
        } catch (error) {
            console.error('[OWNER LEAVE ERROR]', error);
            await Yudzxml.sendMessage(m.chat, {
                text: '⚠️ Gagal keluar dari grup. Periksa izin bot.'
            });
        }
    }
};

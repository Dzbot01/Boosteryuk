const jadibotManager = require('../../../src/core/jadibot');

module.exports = {
    name: 'deljadibot',
    category: 'superowner',
    commands: ['deljadibot'],
    description: 'Hapus bot jadibot beserta session-nya',
    isSuperOwner: true,
    isGroup: false,

    async execute({ m, args }) {
        const number = String(args[0] || '').replace(/[^0-9]/g, '');

        if (!number) {
            return m.reply('❌ Format salah.\n\nContoh: .deljadibot 62812xxxx');
        }

        const entry = jadibotManager.getByNumber(number);
        if (!entry) {
            return m.reply('_Nomor tersebut tidak terdaftar sebagai jadibot._');
        }

        try {
            await jadibotManager.deleteJadibot(entry.jid);
            return m.reply(
                `✅ Bot jadibot +${entry.number} berhasil dihapus permanen.\n\nSession & data sewa instance dibersihkan.`
            );
        } catch (err) {
            return m.reply(`❌ *Gagal:* ${err.message}`);
        }
    }
};

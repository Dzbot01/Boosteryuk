const pteroFactory = require('@App/function/ptreodactylClient');
const config = require('@Config');

module.exports = {
    name: 'panel',
    category: 'cpanel',
    commands: [
        'panel',
        'listuser',
        'listserver',
        'deluser',
        'delserver',
        'suspend',
        'unsuspend',
        'userinfo',
        'serverinfo',
        'userservers',
        'panelstats'
    ],
    description: 'Management Pterodactyl Panel',
    isGroup: false,
    isRateLimit: true,
    isOwner: true,
    isSuperOwner: false,

    async execute({ Yudzxml, m, args, command, isJadibot, jadibotEntry, jadibotJid }) {
        try {
            const ptero = pteroFactory.getPteroForContext({ isJadibot, jadibotEntry, jadibotJid });
            if (!ptero) {
                return m.reply(
                    '🔒 *Kredensial Panel Belum Diset*\n\n' +
                        (isJadibot
                            ? 'Bot jadibot kamu belum punya kredensial Pterodactyl sendiri.\n' +
                              'Pasang kredensial panel kamu lewat *website* (menu kredensial bot jadibot).\n\n' +
                              'Setelah itu, semua operasi panel akan pakai akun panel kamu sendiri.'
                            : 'Konfigurasi cpanel di config.js belum lengkap (BASE/PLTA placeholder).')
                );
            }

            switch (command) {
                case 'listuser': {
                    const page = Number(args[0]) || 1;

                    const res = await ptero.getUsers(page);

                    if (!res.success) {
                        return m.reply(`❌ ${res.message}`);
                    }

                    let text = `👤 *LIST USERS*\n`;
                    text += `📄 Page: ${page}\n\n`;

                    for (const user of res.data) {
                        text += `🆔 ${user.id}\n` + `👤 ${user.username}\n` + `📧 ${user.email}\n` + `━━━━━━━━━━━━━━\n`;
                    }

                    return m.reply(text);
                }

                case 'userinfo': {
                    const id = args[0];

                    if (!id) {
                        return m.reply('Example:\n.userinfo 1');
                    }

                    const res = await ptero.getUser(id);

                    if (!res.success) {
                        return m.reply(`❌ ${res.message}`);
                    }

                    const user = res.data;

                    return m.reply(
                        `👤 USER INFO\n\n` +
                            `🆔 ID: ${user.id}\n` +
                            `👤 Username: ${user.username}\n` +
                            `📧 Email: ${user.email}\n` +
                            `📅 Created: ${user.created_at}`
                    );
                }

                case 'deluser': {
                    const id = args[0];

                    if (!id) {
                        return m.reply('Example:\n.deluser 1');
                    }

                    const res = await ptero.deleteUser(id);

                    if (!res.success) {
                        return m.reply(`❌ ${res.message}`);
                    }

                    return m.reply(`✅ User ${id} berhasil dihapus`);
                }

                case 'listserver': {
                    const page = Number(args[0]) || 1;

                    const res = await ptero.getServers(page);

                    if (!res.success) {
                        return m.reply(`❌ ${res.message}`);
                    }

                    let text = `🖥️ *LIST SERVER*\n`;
                    text += `📄 Page: ${page}\n\n`;

                    for (const server of res.data) {
                        text +=
                            `🆔 ${server.id}\n` +
                            `📦 ${server.name}\n` +
                            `💾 RAM : ${server.memory} MB\n` +
                            `💿 Disk: ${server.disk} MB\n` +
                            `⚙️ CPU : ${server.cpu}%\n` +
                            `🚫 Suspend: ${server.suspended ? 'Yes' : 'No'}\n` +
                            `━━━━━━━━━━━━━━\n`;
                    }

                    return m.reply(text);
                }

                case 'serverinfo': {
                    const id = args[0];

                    if (!id) {
                        return m.reply('Example:\n.serverinfo 1');
                    }

                    const res = await ptero.getServer(id);

                    if (!res.success) {
                        return m.reply(`❌ ${res.message}`);
                    }

                    const s = res.data;

                    return m.reply(
                        `🖥️ SERVER INFO\n\n` +
                            `🆔 ID: ${s.id}\n` +
                            `📦 Name: ${s.name}\n` +
                            `👤 User: ${s.user}\n` +
                            `💾 RAM : ${s.limits.memory} MB\n` +
                            `💿 Disk: ${s.limits.disk} MB\n` +
                            `⚙️ CPU : ${s.limits.cpu}%`
                    );
                }

                case 'delserver': {
                    const id = args[0];

                    if (!id) {
                        return m.reply('Example:\n.delserver 1');
                    }

                    const res = await ptero.deleteServer(id);

                    if (!res.success) {
                        return m.reply(`❌ ${res.message}`);
                    }

                    return m.reply(`✅ Server ${id} berhasil dihapus`);
                }

                case 'panel': {
                    const sub = args[0];

                    if (sub === 'deleteall') {
                        const serverId = args[1];
                        const userId = args[2];

                        if (!serverId || !userId) {
                            return m.reply('.panel deleteall <serverid> <userid>');
                        }

                        const res = await ptero.deleteUserAndServer(serverId, userId);

                        if (!res.success) {
                            return m.reply(`❌ ${res.message}`);
                        }

                        return m.reply(`✅ Server ${serverId} & User ${userId} berhasil dihapus`);
                    }

                    return m.reply(
                        `📋 PANEL MENU

.listuser
.userinfo <id>
.deluser <id>

.listserver
.serverinfo <id>
.delserver <id>

.suspend <serverid>
.unsuspend <serverid>

.userservers <userid>

.panelstats

.panel deleteall <serverid> <userid>`
                    );
                }

                case 'suspend': {
                    const id = args[0];

                    if (!id) {
                        return m.reply('.suspend <serverid>');
                    }

                    const res = await ptero.suspendServer(id);

                    if (!res.success) {
                        return m.reply(`❌ ${res.message}`);
                    }

                    return m.reply(`✅ Server ${id} disuspend`);
                }

                case 'unsuspend': {
                    const id = args[0];

                    if (!id) {
                        return m.reply('.unsuspend <serverid>');
                    }

                    const res = await ptero.unsuspendServer(id);

                    if (!res.success) {
                        return m.reply(`❌ ${res.message}`);
                    }

                    return m.reply(`✅ Server ${id} diaktifkan kembali`);
                }

                case 'userservers': {
                    const userId = args[0];

                    if (!userId) {
                        return m.reply('.userservers <userid>');
                    }

                    const res = await ptero.getUserServers(userId);

                    if (!res.success) {
                        return m.reply(`❌ ${res.message}`);
                    }

                    if (!res.data.length) {
                        return m.reply('User tidak memiliki server');
                    }

                    let text = `📦 SERVER USER ${userId}\n\n`;

                    for (const srv of res.data) {
                        text +=
                            `🆔 ${srv.id}\n` +
                            `📦 ${srv.name}\n` +
                            `💾 ${srv.memory} MB\n` +
                            `💿 ${srv.disk} MB\n` +
                            `⚙️ ${srv.cpu}%\n\n`;
                    }

                    return m.reply(text);
                }

                case 'panelstats': {
                    const res = await ptero.getStats();

                    if (!res.success) {
                        return m.reply(`❌ ${res.message}`);
                    }

                    return m.reply(
                        `📊 PANEL STATS\n\n` +
                            `👤 Total User : ${res.data.totalUsers}\n` +
                            `🖥️ Total Server : ${res.data.totalServers}`
                    );
                }
            }
        } catch (err) {
            console.error('[panel]', err);
            return m.reply(`❌ ${err.message}`);
        }
    }
};

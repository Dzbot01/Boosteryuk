const config = require('@Config');
const db = require('@App/function/cpanelDB');

module.exports = {
    name: 'createserver',
    category: 'cpanel',
    commands: ['createserver'],
    description: 'Buat server panel (Node.js/Python) dengan pembayaran QRIS',
    isGroup: false,
    isOwner: true,
    isSuperOwner: false,

    async execute({
        Yudzxml,
        m,
        args,
        isOwner,
        isSuperOwner,
        command,
        config,
        fotomenunya,
        isJadibot,
        jadibotEntry,
        jadibotJid,
        instanceConfig
    }) {
        try {
            const prefix = instanceConfig?.prefix === false ? '' : config.prefix || '.';

            const pteroFactory = require('@App/function/ptreodactylClient');
            const pakasirFactory = require('@App/function/pakasirClient');
            const ptero = pteroFactory.getPteroForContext({ isJadibot, jadibotEntry, jadibotJid });
            const pakasir = pakasirFactory.getPakasirForContext({ isJadibot, jadibotEntry, jadibotJid });

            if (isJadibot && (!ptero || !pakasir)) {
                const missing = [];
                if (!ptero) missing.push('• Panel Pterodactyl → pasang lewat website (menu kredensial bot jadibot)');
                if (!pakasir) missing.push('• Payment Pakasir → pasang lewat website (menu kredensial bot jadibot)');
                return await Yudzxml.sendMessage(
                    m.chat,
                    {
                        text:
                            `🔒 *Lengkapi Kredensial Dulu*\n\n` +
                            `Bot jadibot kamu belum punya kredensial sendiri untuk jualan panel:\n\n` +
                            missing.join('\n') +
                            `\n\n` +
                            `Setelah lengkap, kamu bisa mulai jualan panel via ${prefix}createserver.`,
                        contextInfo: {
                            mentionedJid: [m.sender],
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.idch || '',
                                newsletterName: config.ownername || 'Bot'
                            }
                        }
                    },
                    { quoted: m }
                );
            }

            const cpanelCfg =
                isJadibot && jadibotEntry?.credentials?.cpanel ? jadibotEntry.credentials.cpanel : config.cpanel;
            const ramList = cpanelCfg?.LISTPANEL || config.cpanel?.LISTPANEL;

            if (!ramList || !Array.isArray(ramList) || ramList.length === 0) {
                return await Yudzxml.sendMessage(
                    m.chat,
                    {
                        text: '❌ Konfigurasi LISTPANEL tidak ditemukan atau kosong.\nSilakan hubungi admin.',
                        contextInfo: {
                            mentionedJid: [m.sender],
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.idch || '',
                                newsletterName: config.ownername || 'Bot'
                            }
                        }
                    },
                    { quoted: m }
                );
            }

            if (args.length > 0) {
                return await Yudzxml.sendMessage(
                    m.chat,
                    {
                        text: `ℹ️  Penggunaan: \`${prefix}createserver\`\nTanpa argumen untuk melihat list package.`,
                        contextInfo: {
                            mentionedJid: [m.sender],
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.idch || '',
                                newsletterName: config.ownername || 'Bot'
                            }
                        }
                    },
                    { quoted: m }
                );
            }

            if (db.hasActiveSession(m.sender)) {
                const existingSession = db.getByUserId(m.sender);
                const statusMessages = {
                    CEKUSER: 'sedang memilih tipe order',
                    WAIT_EMAIL: 'menunggu input email',
                    WAIT_PASSWORD: 'menunggu input password',
                    WAIT_TYPE: 'sedang memilih runtime',
                    WAIT_PAYMENT: 'menunggu pembayaran QRIS',
                    PROCESSING: 'sedang memproses server'
                };

                const statusText = statusMessages[existingSession.data.status] || existingSession.data.status;

                return await Yudzxml.sendMessage(
                    m.chat,
                    {
                        text:
                            `⏳ *Kamu masih punya sesi aktif!*\n\n` +
                            `Status: ${statusText}\n\n` +
                            `Ketik *batal* untuk membatalkan sesi sebelumnya,\n` +
                            `atau lanjutkan proses yang sedang berjalan.`,
                        contextInfo: {
                            mentionedJid: [m.sender],
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.idch || '',
                                newsletterName: config.ownername || 'Bot'
                            }
                        }
                    },
                    { quoted: m }
                );
            }

            let priceListText =
                `╭━━━━━━━━━━━━━━━━━━━━━━━━━━╮\n` +
                `│   ✦  *LIST PANEL CPANEL*  ✦   │\n` +
                `╰━━━━━━━━━━━━━━━━━━━━━━━━━━╯\n\n`;

            ramList.forEach((pkg, index) => {
                const num = String(index + 1).padStart(2, '0');
                priceListText +=
                    `${num}. *${pkg.name}*\n` +
                    `   ├ RAM  : ${formatRam(pkg.ram)}\n` +
                    `   ├ Disk : ${formatDisk(pkg.disk)}\n` +
                    `   ├ CPU  : ${pkg.cpu}%\n` +
                    `   └ Harga: ${formatCurrency(pkg.price)}\n\n`;
            });

            priceListText +=
                `▸ Pilih package di bawah untuk memulai\n` +
                `▸ Pembayaran via *QRIS*\n` +
                `▸ Server otomatis expired 30 hari`;

            const kategoriRows = ramList.map((pkg) => ({
                title: `˖ ࣪ ݂ ❥  ${pkg.name} — ${formatCurrency(pkg.price)}`,
                description: `RAM: ${formatRam(pkg.ram)} | Disk: ${formatDisk(pkg.disk)} | CPU: ${pkg.cpu}%`,
                id: `cpanel_ram_${pkg.name}`
            }));

            const msgPayload = {
                caption: priceListText,
                headerType: 4,
                viewOnce: true,
                buttons: [
                    {
                        buttonId: 'action',
                        buttonText: { displayText: '📂 Lihat List Panel' },
                        type: 4,
                        nativeFlowInfo: {
                            name: 'single_select',
                            paramsJson: JSON.stringify({
                                title: '˖ ࣪ ݂ ✤ LIST CPANEL',
                                sections: [
                                    {
                                        title: 'PILIH PACKAGE',
                                        rows: kategoriRows
                                    }
                                ]
                            })
                        }
                    }
                ],
                contextInfo: {
                    mentionedJid: [m.sender],
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.idch || '',
                        newsletterName: config.ownername || 'Bot'
                    }
                }
            };

            if (fotomenunya) {
                msgPayload.image = { url: fotomenunya };
                msgPayload.fileName = config.ownername || 'menu';
                msgPayload.mimetype = 'image/png';
            }

            await Yudzxml.sendMessage(m.chat, msgPayload, { quoted: m });

            console.log(`[createserver] Price list sent to ${m.sender}`);
        } catch (error) {
            console.error('[createserver] Error:', error);
            await Yudzxml.sendMessage(
                m.chat,
                {
                    text: `❌ Terjadi kesalahan: ${error.message}`,
                    contextInfo: {
                        mentionedJid: [m.sender],
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.idch || '',
                            newsletterName: config.ownername || 'Bot'
                        }
                    }
                },
                { quoted: m }
            );
        }
    }
};

function formatRam(mb) {
    if (mb >= 1024) {
        const gb = mb / 1024;
        return gb % 1 === 0 ? `${gb} GB` : `${gb.toFixed(1)} GB`;
    }
    return `${mb} MB`;
}

function formatDisk(mb) {
    if (mb >= 1024) {
        const gb = mb / 1024;
        return gb % 1 === 0 ? `${gb} GB` : `${gb.toFixed(1)} GB`;
    }
    return `${mb} MB`;
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(amount);
}

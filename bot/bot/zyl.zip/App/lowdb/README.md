# `App/lowdb/` — Vendored copy of `lowdb`

> Status: **VENDORED** (fork internal)
> Upstream: https://github.com/typicode/lowdb (v1.x — CommonJS / sync API)
> Date vendored: 2024-Q4

## Why this folder exists

This folder is a snapshot of the **old lowdb v1.x** API (`Low`, `LowSync`,
`JSONFile`, `JSONFileSync`, `Memory`, `MemorySync`, `TextFile`,
`TextFileSync`, `LocalStorage`, `MissingAdapterError`). The new
`DatabaseManager` (`database/index.js`) does **not** use it — it is kept
exclusively for `database/wrappers/globalDB.js` (`LowDBCompat`) which
shims the legacy `global.db` API used by some plugins.

## Plan to remove

`global.db` is now **deprecated** (see `D1` in the refactoring notes). After
all plugins have been migrated to `DatabaseManager.getInstance().getDoc(...)`,
this folder and `LowDBCompat` will be deleted in **v3.0.0**.

## Local modifications

None at the moment. The code is byte-for-byte identical to upstream v1.x
(except for formatting).

## DO NOT

- Add new code that depends on `App/lowdb/` — always use `DatabaseManager`.
- Edit files in this folder directly — if a patch is needed, fork upstream
  into a separate branch and document the diff here.

const fs = require('fs');
const path = require('path');
const FormData = require('form-data');
const axios = require('axios');
const config = require('../../config');
const { fromBuffer } = require('file-type');
const mime = require('mime-types');

class YudzCDNService {
    constructor() {
        this.apiBaseUrl = 'https://cdn.yudzapi.my.id/api';
        this.apiKey = config?.apikey?.key;

        if (!this.apiKey) {
            throw new Error('API Key tidak ditemukan di config atau environment variables.');
        }
    }

    async _resolveInput(input) {
        if (Buffer.isBuffer(input)) {
            const fileType = await fromBuffer(input);

            return {
                type: 'buffer',
                value: input,
                ext: fileType?.ext || 'bin',
                mime: fileType?.mime || 'application/octet-stream'
            };
        }

        if (typeof input === 'string') {
            const resolved = path.resolve(input);

            if (!fs.existsSync(resolved)) {
                throw new Error(`File tidak ditemukan: ${resolved}`);
            }

            const ext = path.extname(resolved).slice(1);
            const mimeType = mime.lookup(ext) || 'application/octet-stream';

            return {
                type: 'path',
                value: resolved,
                ext,
                mime: mimeType
            };
        }

        throw new Error('Input harus berupa Buffer atau filePath string.');
    }

    async _uploadRequest(endpoint, input) {
        const source = await this._resolveInput(input);
        const form = new FormData();

        if (source.type === 'buffer') {
            form.append('file', source.value, {
                filename: `upload_${Date.now()}.${source.ext}`,
                contentType: source.mime
            });
        } else {
            form.append('file', fs.createReadStream(source.value), {
                filename: path.basename(source.value),
                contentType: source.mime
            });
        }

        try {
            const response = await axios.post(`${this.apiBaseUrl}${endpoint}?apikey=${this.apiKey}`, form, {
                headers: {
                    ...form.getHeaders()
                },
                maxContentLength: Infinity,
                maxBodyLength: Infinity
            });

            if (response.data?.success) {
                return response.data.result;
            }

            throw new Error(response.data?.message || 'Gagal mengunggah file tanpa pesan error dari server.');
        } catch (error) {
            if (error.response) {
                console.error(`[YudzCDN Error] Server Response: ${error.response.status}`, error.response.data);

                throw new Error(error.response.data?.message || 'Server mengembalikan error.');
            }

            if (error.request) {
                console.error('[YudzCDN Error] Tidak ada respon dari server.');
                throw new Error('Gagal terhubung ke server.');
            }

            console.error('[YudzCDN Error]', error.message);
            throw error;
        }
    }

    async uploadExpiring(input) {
        const result = await this._uploadRequest('/v2/upload', input);
        return result.url;
    }

    async uploadPermanent(input) {
        const result = await this._uploadRequest('/v1/upload', input);
        return result.url;
    }

    async uploadFile(input, type = 'expired') {
        if (!input) {
            throw new Error('Parameter input wajib diisi.');
        }

        try {
            return type === 'permanent' ? await this.uploadPermanent(input) : await this.uploadExpiring(input);
        } catch (error) {
            console.error(`[YudzCDN] Proses upload gagal untuk tipe '${type}':`, error.message);

            throw error;
        }
    }
}

const yudzCdnService = new YudzCDNService();

const YudzCdn = async (input, type = 'expired') => {
    return await yudzCdnService.uploadFile(input, type);
};

module.exports = YudzCdn;

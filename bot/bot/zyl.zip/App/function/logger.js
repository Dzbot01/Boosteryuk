const chalk = require('chalk');
const moment = require('moment-timezone');

/**
 * logger.js — Logger utama bot (ramah layar kecil / console Pterodactyl).
 * -----------------------------------------------------------------------------
 * Format:  [ HH:MM ] TAG  pesan
 *   - Tag 1 karakter + spasi, semua baris rata → tidak berantakan saat wrap.
 *   - Pesan multi-baris: baris ke-2 dst. di-indent dengan "└" sehingga blok
 *     error panjang tetap terbaca di layar sempit.
 *   - Anti-spam: pesan identik yang beruntun (≤10 detik) dicetak maksimal 3x,
 *     sisanya ditekan (penanda x2, x3). Setelah 60 detik jendela di-reset.
 *   - TANPA uppercase paksa — teks dicetak apa adanya supaya kalimat panjang
 *     mudah dibaca (dulu semua huruf besar + wrap acak = berantakan).
 *
 * INFO & SUCCESS hanya muncul bila `config.debug: true`; WARNING & ERROR
 * selalu tampil. Log pesan masuk Baileys dikontrol flag yang sama
 * (lihat src/handler/main.js).
 *
 * NOTE: config.js me-require logger ini (hot-reload watcher), jadi config
 * dibaca lazy via require() per-panggilan untuk menghindari circular-import.
 */

const debugEnabled = () => {
    try {
        const config = require('@Config');
        return config?.debug === true;
    } catch (_) {
        return false;
    }
};

// ── Anti-spam (dedupe pesan identik) ─────────────────────────────────────────
const DEDUP_WINDOW_MS = 10 * 1000;  // jarak antar-pesan dianggap "beruntun"
const DEDUP_RESET_MS = 60 * 1000;   // jendela maksimum sebelum counter reset
const DEDUP_MAX_SHOWN = 3;          // tampil maksimal 3x per jendela
const dedupMap = new Map();         // key → { count, shown, firstAt, lastAt }

function dedupeFilter(key) {
    const now = Date.now();
    const st = dedupMap.get(key);

    if (!st || now - st.lastAt > DEDUP_WINDOW_MS || now - st.firstAt > DEDUP_RESET_MS) {
        dedupMap.set(key, { count: 1, shown: 1, firstAt: now, lastAt: now });
        return { show: true, count: 1 };
    }

    st.count += 1;
    st.lastAt = now;

    if (st.shown < DEDUP_MAX_SHOWN) {
        st.shown += 1;
        return { show: true, count: st.count };
    }

    return { show: false, count: st.count };
}

// Bersih-bersih map agar tidak membengkak.
setInterval(() => {
    const now = Date.now();
    for (const [key, st] of dedupMap) {
        if (now - st.lastAt > DEDUP_RESET_MS * 2) dedupMap.delete(key);
    }
}, 5 * 60 * 1000).unref?.();

// ── Inti cetak ───────────────────────────────────────────────────────────────
const INDENT = '           ';        // 11 spasi = lebar "[ HH:MM ] TAG " sekira
const CONT = chalk.gray('└ ');

function clean(text) {
    return String(text ?? '')
        .replace(/\r/g, '')
        .replace(/[ \t]+\n/g, '\n')
        .replace(/\n{3,}/g, '\n\n')
        .trim();
}

function emit(color, tag, text, { dedupe = true } = {}) {
    const msg = clean(text);
    if (!msg) return;

    if (dedupe) {
        const { show, count } = dedupeFilter(`${tag}|${msg}`);
        if (!show) return;
        if (count > 1) return write(color, tag, `${msg} ${chalk.gray(`(x${count})`)}`);
    }
    write(color, tag, msg);
}

function write(color, tag, msg) {
    const jammenit = moment().tz('Asia/Jakarta').format('HH:mm');
    const stamp = color.bold(`[ ${jammenit} ]`);
    const lines = msg.split('\n');

    const head = `${stamp} ${color.bold(tag)} ${lines[0]}`;
    const rest = lines.slice(1).filter((l) => l.length > 0).map((l) => `${INDENT}${CONT}${l}`);

    console.log(rest.length ? [head, ...rest].join('\n') : head);
}

module.exports = {
    success(text = 'success') {
        if (!debugEnabled()) return;
        emit(chalk.green, '✓', text);
    },

    error(text = 'error') {
        emit(chalk.red, '✖', text);
    },

    warning(text = 'warning') {
        emit(chalk.yellow, '!', text);
    },

    warn(text = 'warning') {
        emit(chalk.yellow, '!', text);
    },

    info(text = 'info') {
        if (!debugEnabled()) return;
        emit(chalk.blue, '»', text);
    },

    /** Log tanpa dedupe (untuk pesan yang memang harus tampil berulang). */
    raw(text = '') {
        write(chalk.white, '·', text);
    }
};

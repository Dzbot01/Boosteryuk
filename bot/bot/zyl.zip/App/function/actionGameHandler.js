/**
 * actionGameHandler.js — Entry lama semua handler game (kompatibilitas).
 * Logic sudah dipisah per game di folder ./games/ (1 game = 1 file).
 * File ini hanya forwarder agar require('@App/function/actionGameHandler') tetap jalan.
 */
module.exports = require('./games');

const path = require('path');

const { loadDB: loadDBFile, saveDB: saveDBFile } = require('../../database/wrappers/storage');

const groupSettingsPath = path.join(__dirname, '../../Storage/groupSettings.json');

function getGroupSettings() {
    try {
        const data = loadDBFile(groupSettingsPath, {});
        return data && typeof data === 'object' && !Array.isArray(data) ? data : {};
    } catch (err) {
        console.error('Gagal membaca groupSettings:', err);
        return {};
    }
}

function saveGroupSettings(settings) {
    saveDBFile(groupSettingsPath, settings);
}

module.exports = {
    getGroupSettings,
    saveGroupSettings
};

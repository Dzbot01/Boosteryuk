/**
 * rpgEngine/index.js — API publik engine RPG (daftar ekspor SAMA PERSIS dengan rpg.js lama).
 */
const actions = require('./actions');
const shop = require('./shop');
const core = require('./core');

module.exports = {
    hunt: actions.hunt,
    boss: actions.boss,
    dungeon: actions.dungeon,
    fish: actions.fish,
    mining: actions.mining,
    adventure: actions.adventure,
    work: actions.work,
    plant: actions.plant,
    farm: actions.farm,
    harvest: actions.harvest,
    daily: actions.daily,
    buy: shop.buy,
    sell: shop.sell,
    use: shop.use,
    equip: shop.equip,
    unequip: shop.unequip,
    inventory: shop.inventory,
    profile: shop.profile,
    heal: shop.heal,
    fishList: shop.fishList,
    cropList: shop.cropList,
    monsterList: shop.monsterList,
    shop: shop.shopList,
    giveMoney: shop.giveMoney,
    giveItem: shop.giveItem,
    addRpgUser: core.addRpgUser,
    getRpgUser: core.getRpgUser,
    saveRpgUser: core.saveRpgUser,
    getRpgLeaderboard: core.getRpgLeaderboard
};

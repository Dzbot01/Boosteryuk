/**
 * rpgEngine/shop.js — Toko, inventaris & interaksi item.
 */
const { COOLDOWN, FISHES, CROPS, MINERALS, SHOP_ITEMS, MONSTERS, ELITES, BOSSES } = require('./data');
const { addItem, addMana, addMoney, getExpNeeded, getPlayerStats, getRemainingTime, getRpgUser, isCooldown, loadUserDB, removeItem, saveUserDB, setArmor, setCooldown, setWeapon } = require('./core');

function buy(jid, itemName) {
    const item = SHOP_ITEMS.find((i) => i.name.toLowerCase() === itemName.toLowerCase());
    if (!item) return `Item "${itemName}" tidak ada di toko. Ketik .rpg shop untuk melihat list.`;

    const user = getRpgUser(jid);
    if (user.money < item.price) return `Uang tidak cukup! Butuh $${item.price}, kamu punya $${user.money}.`;

    addMoney(jid, -item.price);
    addItem(jid, item.name, 1);
    return `Berhasil membeli ${item.name} seharga $${item.price}.`;
}

function sell(jid, itemName) {
    const user = getRpgUser(jid);
    const inv = user.inventory;
    const itemKey = Object.keys(inv).find((k) => k.toLowerCase() === itemName.toLowerCase());

    if (!itemKey || !inv[itemKey]) return `Kamu tidak memiliki item "${itemName}".`;

    let sellPrice = 0;
    const shopItem = SHOP_ITEMS.find((i) => i.name === itemKey);
    if (shopItem) {
        if (shopItem.type === 'seed' || shopItem.type === 'tool') {
            sellPrice = Math.floor(shopItem.price / 5);
        } else {
            sellPrice = Math.floor(shopItem.price / 2);
        }
    } else {
        const fishItem = FISHES.find((i) => i.name === itemKey);
        if (fishItem) sellPrice = fishItem.price;

        const mineralItem = MINERALS.find((i) => i.name === itemKey);
        if (mineralItem) sellPrice = mineralItem.price;

        const cropItem = Object.values(CROPS).find((c) => c.seedName.replace(' Seed', '') === itemKey);
        if (cropItem) sellPrice = cropItem.money;
    }

    if (sellPrice <= 0) sellPrice = 1;

    removeItem(jid, itemKey, 1);
    addMoney(jid, sellPrice);

    return `Berhasil menjual ${itemKey} seharga $${sellPrice}.`;
}

function use(jid, itemName) {
    const user = getRpgUser(jid);
    const inv = user.inventory;
    const itemKey = Object.keys(inv).find((k) => k.toLowerCase() === itemName.toLowerCase());

    if (!itemKey || !inv[itemKey]) return `Kamu tidak memiliki item ${itemName}.`;

    const itemData = SHOP_ITEMS.find((i) => i.name === itemKey);
    if (!itemData) return `Item ini tidak bisa digunakan (bisa dijual).`;

    if (itemData.type === 'potion') {
        removeItem(jid, itemKey, 1);
        const userDb = loadUserDB(jid);
        const healAmount = itemData.effect;
        userDb.hp = Math.min(userDb.maxHp, userDb.hp + healAmount);
        saveUserDB(jid, userDb);
        return `Meminum ${itemData.name}. HP +${healAmount}.`;
    } else if (itemData.type === 'mana') {
        removeItem(jid, itemKey, 1);
        addMana(jid, itemData.effect);
        return `Meminum ${itemData.name}. Mana +${itemData.effect}.`;
    } else if (itemData.type === 'boost_attack') {
        removeItem(jid, itemKey, 1);
        const userDb = loadUserDB(jid);
        userDb.boostAttack += itemData.value;
        saveUserDB(jid, userDb);
        return `Membaca ${itemData.name}. Attack permanen +${itemData.value}.`;
    } else if (itemData.type === 'boost_defense') {
        removeItem(jid, itemKey, 1);
        const userDb = loadUserDB(jid);
        userDb.boostDefense += itemData.value;
        saveUserDB(jid, userDb);
        return `Membaca ${itemData.name}. Defense permanen +${itemData.value}.`;
    } else if (itemData.type === 'exp_boost') {
        removeItem(jid, itemKey, 1);
        const userDb = loadUserDB(jid);
        userDb.expMultiplier = itemData.value;
        saveUserDB(jid, userDb);
        return `Menggunakan ${itemData.name}. Exp Multiplier sekarang x${itemData.value}.`;
    } else if (itemData.type === 'pet') {
        removeItem(jid, itemKey, 1);
        const userDb = loadUserDB(jid);
        userDb.pet = itemData.name;
        saveUserDB(jid, userDb);
        return `Memanggil ${itemData.name} sebagai pet!`;
    } else if (itemData.type === 'weapon' || itemData.type === 'armor') {
        return `Gunakan command .rpg equip ${itemKey} untuk memasang item ini.`;
    } else if (itemData.type === 'tool') {
        return `Peralatan ini pasif (otomatis terpakai saat mancing/mining).`;
    }

    return `Item ini tidak bisa digunakan langsung.`;
}

function equip(jid, itemName) {
    const user = getRpgUser(jid);
    const inv = user.inventory;
    const itemKey = Object.keys(inv).find((k) => k.toLowerCase() === itemName.toLowerCase());

    if (!itemKey || !inv[itemKey]) return `Kamu tidak punya item ${itemName}.`;

    const itemData = SHOP_ITEMS.find((i) => i.name === itemKey);
    if (!itemData) return `Item tersebut tidak bisa dipakai.`;

    if (itemData.type === 'weapon') {
        setWeapon(jid, itemKey);
        return `Memasang senjata: ${itemKey}`;
    } else if (itemData.type === 'armor') {
        setArmor(jid, itemKey);
        return `Memasang armor: ${itemKey}`;
    } else {
        return `Item ${itemData.type} tidak bisa dipasang.`;
    }
}

function unequip(jid, type) {
    const userDb = loadUserDB(jid);
    if (!userDb) return false;

    let msg = '';
    if (type === 'weapon') {
        const current = userDb.weapon;
        if (current === 'Fist') return 'Kamu sedang bertelanjang (Tangan kosong).';
        userDb.weapon = 'Fist';
        msg = `Berhasil melepas ${current}.`;
    } else if (type === 'armor') {
        const current = userDb.armor;
        if (current === 'None') return 'Kamu tidak memakai armor apapun.';
        userDb.armor = 'None';
        msg = `Berhasil melepas ${current}.`;
    } else {
        return 'Tipe tidak valid (weapon/armor).';
    }

    saveUserDB(jid, userDb);
    return msg;
}

function inventory(jid) {
    const user = getRpgUser(jid);
    const inv = user.inventory;
    const items = Object.keys(inv);

    if (items.length === 0) return `Inventory kosong.`;

    let txt = `*🎒 INVENTORY*\n`;
    items.forEach((item) => {
        txt += `- ${item} (x${inv[item]})\n`;
    });
    return txt;
}

function profile(jid) {
    const user = getPlayerStats(jid);
    const expNeeded = getExpNeeded(user.level);
    let farmStatus = 'Kosong';
    if (user.farming && user.farming.plant) {
        const remaining = Math.ceil((user.farming.readyAt - Date.now()) / 1000);
        const minutes = Math.floor(remaining / 60);
        farmStatus = `Menanam ${user.farming.plant} (${minutes}m)`;
    }

    return `
*👤 PROFILE RPG*
-------------------
Nama: @${jid.split('@')[0]}
Level: ${user.level} (${user.exp}/${expNeeded} Exp)
HP: ${user.hp} / ${user.maxHp}
Mana: ${user.mana} / ${user.maxMana}
Money: $${user.money}

📊 Stats:
Attack: ${user.attack} (+${user.totalAttack - user.attack} Gear/Pet/Boost)
Defense: ${user.defense} (+${user.totalDefense - user.defense} Gear/Boost)
Exp Multiplier: x${user.expMultiplier}

🛡️ Equipment:
Weapon: ${user.weapon}
Armor: ${user.armor}
Pet: ${user.pet || 'None'}

🌾 Farm Status: ${farmStatus}
`;
}

function heal(jid) {
    const user = getRpgUser(jid);
    if (user.hp >= user.maxHp && user.mana >= user.maxMana) return `HP & Mana sudah penuh.`;

    if (user.inventory['Mega Potion'] && user.inventory['Mega Potion'] > 0) {
        removeItem(jid, 'Mega Potion', 1);
        const userDb = loadUserDB(jid);
        userDb.hp = userDb.maxHp;
        saveUserDB(jid, userDb);
        return `Meminum Mega Potion. HP Penuh!`;
    } else if (user.inventory['Large Potion'] && user.inventory['Large Potion'] > 0) {
        removeItem(jid, 'Large Potion', 1);
        const userDb = loadUserDB(jid);
        userDb.hp = Math.min(userDb.maxHp, userDb.hp + 350);
        saveUserDB(jid, userDb);
        return `Meminum Large Potion. HP +350.`;
    } else if (user.inventory['Small Potion'] && user.inventory['Small Potion'] > 0) {
        removeItem(jid, 'Small Potion', 1);
        const userDb = loadUserDB(jid);
        userDb.hp = Math.min(userDb.maxHp, userDb.hp + 50);
        saveUserDB(jid, userDb);
        return `Meminum Small Potion. HP +50.`;
    } else {
        if (isCooldown(jid, 'lastHeal', COOLDOWN.heal)) {
            const time = getRemainingTime(jid, 'lastHeal', COOLDOWN.heal);
            return `Cooldown Heal! Tunggu ${time} detik.\nAtau beli Potion di shop.`;
        }

        const userDb = loadUserDB(jid);
        userDb.hp = userDb.maxHp;
        userDb.mana = userDb.maxMana;
        saveUserDB(jid, userDb);
        setCooldown(jid, 'lastHeal');
        return `Istirahat sejenak... HP & Mana pulih penuh!`;
    }
}

function fishList() {
    let txt = `*🐟 FISH ENCYCLOPEDIA*\n`;
    txt += `━━━━━━━━━━━━━━━━━━━\n`;
    const rarities = ['Mythic', 'Legendary', 'Epic', 'Rare', 'Uncommon', 'Common'];

    rarities.forEach((rarity) => {
        const fishRarity = FISHES.filter((f) => f.rarity === rarity);
        if (fishRarity.length > 0) {
            txt += `\n【 ${rarity} 】\n`;
            fishRarity.forEach((f) => {
                txt += `▸ ${f.name}\n   ├ Exp: ${f.exp} | Jual: $${f.price}\n   └ Money: $${f.money}\n`;
            });
        }
    });
    return txt;
}

function cropList() {
    let txt = `*🌾 CROP ENCYCLOPEDIA*\n`;
    txt += `━━━━━━━━━━━━━━━━━━━\n`;
    const rarities = ['Mythic', 'Legendary', 'Epic', 'Rare', 'Uncommon', 'Common'];

    rarities.forEach((rarity) => {
        const cropsRarity = Object.values(CROPS).filter((c) => c.rarity === rarity);
        if (cropsRarity.length > 0) {
            txt += `\n【 ${rarity} 】\n`;
            cropsRarity.forEach((c) => {
                const seedPrice = SHOP_ITEMS.find((i) => i.name === c.seedName)?.price || 0;
                txt += `▸ ${c.seedName}\n`;
                txt += `   ├ Waktu: ${c.duration / 60}m\n`;
                txt += `   ├ Exp: ${c.exp} | Hasil Jual: $${c.money}\n`;
                txt += `   └ Bibit: $${seedPrice} (Hasil: ${c.min}-${c.max})\n`;
            });
        }
    });
    return txt;
}

function monsterList() {
    let txt = `*👹 MONSTER LIST (Base Template)*\n`;
    txt += `━━━━━━━━━━━━━━━━━━━\n`;
    txt += `*Catatan: Stats monster akan bertambah sesuai levelmu!*\n\n`;

    txt += `*Normal Monsters:*\n`;
    MONSTERS.forEach((m) => {
        txt += `Lvl ${m.level} ${m.name} | HP: ${m.hp} | Def: ${m.defense}\n`;
    });

    txt += `\n*Elite Monsters (Lvl 10+):*\n`;
    ELITES.forEach((m) => {
        txt += `💀 Lvl ${m.level} ${m.name} | HP: ${m.hp} | Def: ${m.defense}\n`;
    });

    txt += `\n*World Bosses (1 Hour Cooldown):*\n`;
    BOSSES.forEach((m) => {
        txt += `👑 Lvl ${m.level} ${m.name} | HP: ${m.hp} | Def: ${m.defense}\n`;
    });

    return txt;
}

function shopList() {
    let txt = `*🏪 RPG SHOP*\n`;
    txt += `─────────────────────\n`;

    const categories = {
        Potions: 'potion',
        Tools: 'tool',
        Weapons: 'weapon',
        Armors: 'armor',
        Seeds: 'seed',
        Pets: 'pet',
        Boosts: 'boost_attack'
    };

    for (const [catName, type] of Object.entries(categories)) {
        const items = SHOP_ITEMS.filter(
            (i) =>
                i.type === type ||
                (type === 'boost_attack' && i.type === 'boost_defense') ||
                (type === 'boost_attack' && i.type === 'exp_boost')
        );
        if (items.length > 0) {
            txt += `\n*${catName}*\n`;
            items.forEach((item) => {
                let stats = '';
                if (item.type === 'weapon') stats = `(Atk +${item.attack})`;
                else if (item.type === 'armor') stats = `(Def +${item.defense})`;
                else if (item.type === 'potion') stats = `(Heal +${item.effect})`;
                else if (item.type === 'mana') stats = `(Mana +${item.effect})`;
                else if (item.type === 'boost_attack') stats = `(Perm Atk +${item.value})`;
                else if (item.type === 'boost_defense') stats = `(Perm Def +${item.value})`;
                else if (item.type === 'exp_boost') stats = `(Exp x${item.value})`;
                else if (item.type === 'pet') stats = `(Atk +${item.attack})`;
                else if (item.type === 'seed') stats = `(Tanaman)`;
                else if (item.type === 'tool') stats = `(Peralatan)`;

                txt += `• ${item.name} - $${item.price} ${stats}\n`;
            });
        }
    }
    return txt;
}

function giveMoney(jid, targetJid, amount) {
    if (jid === targetJid) return 'Tidak bisa mengirim uang ke diri sendiri.';
    if (amount <= 0) return 'Jumlah uang tidak valid.';
    if (!Number.isInteger(amount)) return 'Jumlah harus berupa angka bulat.';

    const sender = getRpgUser(jid);
    if (sender.money < amount) return `Uang kamu tidak cukup! Kamu punya $${sender.money}`;

    addMoney(jid, -amount);
    addMoney(targetJid, amount);

    return `Berhasil mengirim $${amount} ke @${targetJid.split('@')[0]}`;
}

function giveItem(jid, targetJid, itemName, amount = 1) {
    if (jid === targetJid) return 'Tidak bisa mengirim item ke diri sendiri.';
    if (amount <= 0) return 'Jumlah item tidak valid.';

    const sender = getRpgUser(jid);
    const inv = sender.inventory;
    const itemKey = Object.keys(inv).find((k) => k.toLowerCase() === itemName.toLowerCase());

    if (!itemKey || !inv[itemKey] || inv[itemKey] < amount) {
        return `Kamu tidak memiliki ${itemName} sebanyak ${amount}.`;
    }

    removeItem(jid, itemKey, amount);
    addItem(targetJid, itemKey, amount);

    return `Berhasil mengirim x${amount} ${itemKey} ke @${targetJid.split('@')[0]}`;
}

module.exports = { buy, sell, use, equip, unequip, inventory, profile, heal, fishList, cropList, monsterList, shopList, giveMoney, giveItem };

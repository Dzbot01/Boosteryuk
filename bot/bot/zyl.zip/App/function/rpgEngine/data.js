/**
 * rpgEngine/data.js — Data statis game RPG (ikan, tanaman, mineral, monster, toko, dll).
 * Ubah balancing / tambah konten game di sini tanpa menyentuh logic.
 */

const COOLDOWN = {
    hunt: 60 * 1000,
    mining: 120 * 1000,
    fishing: 90 * 1000,
    adventure: 300 * 1000,
    dungeon: 900 * 1000,
    boss: 3600 * 1000,
    work: 1800 * 1000,
    heal: 30000,
    daily: 86400000
};
const FISHES = [
    { name: 'Trash', chance: 20, exp: 0, money: 0, price: 1, rarity: 'Common' },
    { name: 'Old Boot', chance: 15, exp: 1, money: 2, price: 3, rarity: 'Common' },
    { name: 'Tin Can', chance: 12, exp: 1, money: 3, price: 5, rarity: 'Common' },
    { name: 'Sardine', chance: 40, exp: 5, money: 15, price: 20, rarity: 'Common' },
    { name: 'Anchovy', chance: 38, exp: 5, money: 18, price: 25, rarity: 'Common' },
    { name: 'Herring', chance: 35, exp: 7, money: 20, price: 30, rarity: 'Common' },
    { name: 'Mackerel', chance: 30, exp: 10, money: 30, price: 40, rarity: 'Uncommon' },
    { name: 'Catfish', chance: 28, exp: 12, money: 35, price: 50, rarity: 'Uncommon' },
    { name: 'Tilapia', chance: 25, exp: 15, money: 40, price: 60, rarity: 'Uncommon' },
    { name: 'Salmon', chance: 18, exp: 20, money: 60, price: 90, rarity: 'Rare' },
    { name: 'Barracuda', chance: 12, exp: 25, money: 80, price: 120, rarity: 'Rare' },
    { name: 'Tuna', chance: 8, exp: 20, money: 70, price: 100, rarity: 'Rare' },
    { name: 'Swordfish', chance: 5, exp: 40, money: 150, price: 220, rarity: 'Epic' },
    { name: 'Electric Eel', chance: 4, exp: 45, money: 170, price: 250, rarity: 'Epic' },
    { name: 'Golden Carp', chance: 3, exp: 60, money: 250, price: 350, rarity: 'Epic' },
    { name: 'Shark', chance: 2, exp: 50, money: 200, price: 300, rarity: 'Legendary' },
    { name: 'Hammerhead Shark', chance: 1.5, exp: 75, money: 350, price: 500, rarity: 'Legendary' },
    { name: 'Whale Shark', chance: 1, exp: 120, money: 700, price: 1000, rarity: 'Legendary' },
    { name: 'Sea Dragon', chance: 0.5, exp: 300, money: 2000, price: 3000, rarity: 'Mythic' },
    { name: 'Kraken Tentacle', chance: 0.2, exp: 500, money: 5000, price: 8000, rarity: 'Mythic' },
    { name: 'Leviathan', chance: 0.05, exp: 1500, money: 15000, price: 25000, rarity: 'Mythic' }
];
const CROPS = {
    Wheat: { seedName: 'Wheat Seed', duration: 30, exp: 10, money: 15, min: 2, max: 5, rarity: 'Common' },
    Corn: { seedName: 'Corn Seed', duration: 60, exp: 25, money: 40, min: 2, max: 4, rarity: 'Common' },
    Potato: { seedName: 'Potato Seed', duration: 90, exp: 30, money: 50, min: 2, max: 6, rarity: 'Common' },
    Carrot: { seedName: 'Carrot Seed', duration: 120, exp: 40, money: 80, min: 1, max: 3, rarity: 'Uncommon' },
    Tomato: { seedName: 'Tomato Seed', duration: 180, exp: 70, money: 120, min: 2, max: 4, rarity: 'Rare' },
    Pumpkin: { seedName: 'Pumpkin Seed', duration: 300, exp: 100, money: 180, min: 1, max: 3, rarity: 'Rare' },
    Rose: { seedName: 'Rose Seed', duration: 300, exp: 100, money: 250, min: 1, max: 2, rarity: 'Rare' },
    Lavender: { seedName: 'Lavender Seed', duration: 600, exp: 200, money: 500, min: 1, max: 2, rarity: 'Epic' },
    'Blue Orchid': {
        seedName: 'Blue Orchid Seed',
        duration: 900,
        exp: 350,
        money: 900,
        min: 1,
        max: 2,
        rarity: 'Epic'
    },
    'Golden Apple': {
        seedName: 'Golden Apple Seed',
        duration: 1800,
        exp: 700,
        money: 2500,
        min: 1,
        max: 2,
        rarity: 'Legendary'
    },
    'Dragon Fruit': {
        seedName: 'Dragon Fruit Seed',
        duration: 2400,
        exp: 1000,
        money: 4000,
        min: 1,
        max: 2,
        rarity: 'Legendary'
    },
    'Phoenix Flower': {
        seedName: 'Phoenix Flower Seed',
        duration: 3600,
        exp: 2500,
        money: 10000,
        min: 1,
        max: 1,
        rarity: 'Mythic'
    },
    'World Tree': {
        seedName: 'World Tree Seed',
        duration: 7200,
        exp: 5000,
        money: 25000,
        min: 1,
        max: 1,
        rarity: 'Mythic'
    }
};
const MINERALS = [
    { name: 'Stone', chance: 50, price: 5, exp: 2, rarity: 'Common' },
    { name: 'Coal', chance: 25, price: 15, exp: 5, rarity: 'Common' },
    { name: 'Iron Ore', chance: 15, price: 50, exp: 15, rarity: 'Uncommon' },
    { name: 'Gold Ore', chance: 7, price: 150, exp: 30, rarity: 'Rare' },
    { name: 'Diamond', chance: 2.5, price: 500, exp: 80, rarity: 'Epic' },
    { name: 'Mythicril Ore', chance: 0.5, price: 2000, exp: 200, rarity: 'Legendary' }
];
const ADVENTURE_EVENTS = [
    { type: 'chest', text: 'Kamu menemukan peti harta karun tersembunyi!', rewardMoney: [100, 500], rewardExp: 20 },
    {
        type: 'monster',
        text: 'Kamu diserang oleh perampok liar!',
        damage: [10, 30],
        rewardMoney: [50, 150],
        rewardExp: 40
    },
    { type: 'trap', text: 'Kamu terjatuh ke dalam lubang jebakan!', damage: [5, 15], rewardMoney: 0, rewardExp: 5 },
    { type: 'shrine', text: 'Kamu menemukan altar kuno dan berdoa.', heal: [20, 50], rewardMoney: 0, rewardExp: 10 },
    {
        type: 'merchant',
        text: 'Kamu bertemu pedagang keliling dan menjual barang jarangan.',
        rewardMoney: [200, 400],
        rewardExp: 10
    }
];
const SHOP_ITEMS = [
    { name: 'Small Potion', price: 100, type: 'potion', effect: 50 },
    { name: 'Medium Potion', price: 300, type: 'potion', effect: 150 },
    { name: 'Large Potion', price: 800, type: 'potion', effect: 350 },
    { name: 'Mega Potion', price: 2000, type: 'potion', effect: 1000 },
    { name: 'Mana Potion', price: 500, type: 'mana', effect: 50 },
    { name: 'Mega Mana', price: 1500, type: 'mana', effect: 200 },

    { name: 'Fishing Rod', price: 1500, type: 'tool', desc: 'Wajib untuk mancing' },
    { name: 'Wooden Pickaxe', price: 1000, type: 'tool', desc: 'Alat tambang dasar' },
    { name: 'Stone Pickaxe', price: 2500, type: 'tool', desc: 'Alat tambang kuat' },
    { name: 'Iron Pickaxe', price: 5000, type: 'tool', desc: 'Alat tambang besi' },
    { name: 'Diamond Pickaxe', price: 15000, type: 'tool', desc: 'Alat tambang terbaik' },

    { name: 'Wooden Sword', price: 200, type: 'weapon', attack: 5 },
    { name: 'Sword', price: 500, type: 'weapon', attack: 10 },
    { name: 'Iron Sword', price: 1000, type: 'weapon', attack: 18 },
    { name: 'Axe', price: 1200, type: 'weapon', attack: 25 },
    { name: 'Knight Blade', price: 2500, type: 'weapon', attack: 40 },
    { name: 'Dragon Slayer', price: 4000, type: 'weapon', attack: 60 },
    { name: 'Excalibur', price: 5000, type: 'weapon', attack: 75 },
    { name: 'Celestial Sword', price: 12000, type: 'weapon', attack: 120 },

    { name: 'Leather Armor', price: 500, type: 'armor', defense: 5 },
    { name: 'Iron Armor', price: 1500, type: 'armor', defense: 15 },
    { name: 'Knight Armor', price: 3000, type: 'armor', defense: 25 },
    { name: 'Diamond Armor', price: 6000, type: 'armor', defense: 40 },
    { name: 'Dragon Armor', price: 12000, type: 'armor', defense: 70 },
    { name: 'Celestial Armor', price: 25000, type: 'armor', defense: 120 },

    { name: 'Attack Scroll', price: 2500, type: 'boost_attack', value: 5 },
    { name: 'Defense Scroll', price: 2500, type: 'boost_defense', value: 5 },
    { name: 'EXP Booster', price: 5000, type: 'exp_boost', value: 2 },

    { name: 'Wolf Pet', price: 5000, type: 'pet', attack: 10 },
    { name: 'Dragon Pet', price: 20000, type: 'pet', attack: 30 },
    { name: 'Phoenix Pet', price: 50000, type: 'pet', attack: 50 },

    { name: 'Wheat Seed', price: 50, type: 'seed' },
    { name: 'Corn Seed', price: 100, type: 'seed' },
    { name: 'Potato Seed', price: 150, type: 'seed' },
    { name: 'Carrot Seed', price: 200, type: 'seed' },
    { name: 'Tomato Seed', price: 500, type: 'seed' },
    { name: 'Pumpkin Seed', price: 800, type: 'seed' },
    { name: 'Rose Seed', price: 1000, type: 'seed' },
    { name: 'Lavender Seed', price: 2000, type: 'seed' },
    { name: 'Blue Orchid Seed', price: 3500, type: 'seed' },
    { name: 'Golden Apple Seed', price: 10000, type: 'seed' },
    { name: 'Dragon Fruit Seed', price: 15000, type: 'seed' },
    { name: 'Phoenix Flower Seed', price: 40000, type: 'seed' },
    { name: 'World Tree Seed', price: 100000, type: 'seed' }
];
const MONSTERS = [
    { name: 'Slime', level: 1, hp: 20, attack: 2, defense: 0, exp: 10, money: 20 },
    { name: 'Baby Spider', level: 2, hp: 30, attack: 3, defense: 1, exp: 15, money: 30 },
    { name: 'Goblin', level: 3, hp: 50, attack: 5, defense: 2, exp: 25, money: 50 },
    { name: 'Skeleton', level: 4, hp: 70, attack: 7, defense: 3, exp: 35, money: 70 },
    { name: 'Wolf', level: 5, hp: 80, attack: 10, defense: 3, exp: 40, money: 80 },
    { name: 'Zombie', level: 6, hp: 100, attack: 12, defense: 4, exp: 50, money: 100 },
    { name: 'Bandit', level: 8, hp: 120, attack: 13, defense: 5, exp: 60, money: 120 },
    { name: 'Orc', level: 10, hp: 150, attack: 15, defense: 5, exp: 80, money: 150 },
    { name: 'Dark Mage', level: 12, hp: 200, attack: 20, defense: 8, exp: 120, money: 200 },
    { name: 'Dragon', level: 15, hp: 300, attack: 25, defense: 10, exp: 150, money: 300 },
    { name: 'Ancient Dragon', level: 18, hp: 500, attack: 35, defense: 15, exp: 250, money: 500 }
];
const ELITES = [
    { name: 'Elite Goblin', level: 10, hp: 250, attack: 18, defense: 10, exp: 120, money: 250 },
    { name: 'Elite Orc', level: 15, hp: 400, attack: 30, defense: 15, exp: 200, money: 400 },
    { name: 'Elite Dragon', level: 20, hp: 700, attack: 45, defense: 20, exp: 350, money: 700 }
];
const BOSSES = [
    { name: 'Demon King', level: 20, hp: 1000, attack: 50, defense: 20, exp: 500, money: 1000 },
    { name: 'Dark Knight', level: 25, hp: 1500, attack: 60, defense: 25, exp: 700, money: 1500 },
    { name: 'Ancient Dragon Lord', level: 30, hp: 2500, attack: 80, defense: 35, exp: 1200, money: 2500 },
    { name: 'Void Reaper', level: 40, hp: 4000, attack: 120, defense: 50, exp: 2500, money: 5000 },
    { name: 'Shadow Emperor', level: 50, hp: 7000, attack: 180, defense: 80, exp: 5000, money: 10000 },
    { name: 'Titan God', level: 60, hp: 12000, attack: 250, defense: 120, exp: 10000, money: 25000 },
    { name: 'Chaos Beast', level: 80, hp: 20000, attack: 400, defense: 200, exp: 25000, money: 50000 }
];
const LOOTS = [
    { name: 'Iron Ore', chance: 50 },
    { name: 'Gold Ore', chance: 30 },
    { name: 'Diamond', chance: 15 },
    { name: 'Dragon Scale', chance: 5 },
    { name: 'Phoenix Feather', chance: 2 },
    { name: 'Legendary Crystal', chance: 1 }
];
const DEFAULT_RPG = {
    level: 1,
    exp: 0,
    money: 0,
    hp: 100,
    maxHp: 100,
    mana: 50,
    maxMana: 50,
    attack: 10,
    defense: 5,
    weapon: 'Fist',
    armor: 'None',
    pet: null,
    boostAttack: 0,
    boostDefense: 0,
    expMultiplier: 1,
    inventory: {},
    lastHunt: 0,
    lastBoss: 0,
    lastDungeon: 0,
    lastHeal: 0,
    lastFish: 0,
    lastDaily: 0,
    lastMining: 0,
    lastAdventure: 0,
    lastWork: 0,
    farming: {
        plant: null,
        plantedAt: 0,
        readyAt: 0
    }
};

module.exports = { COOLDOWN, FISHES, CROPS, MINERALS, ADVENTURE_EVENTS, SHOP_ITEMS, MONSTERS, ELITES, BOSSES, LOOTS, DEFAULT_RPG };

/**
 * rpgEngine/actions.js — Aksi / aktivitas RPG.
 */
const { COOLDOWN, FISHES, CROPS, MINERALS, ADVENTURE_EVENTS, SHOP_ITEMS, MONSTERS, ELITES, BOSSES, LOOTS } = require('./data');
const { addExp, addItem, addMana, addMoney, getPlayerStats, getRemainingTime, getRpgUser, isCooldown, loadUserDB, removeItem, saveUserDB, scaleMonster, setCooldown, updateHp } = require('./core');

function hunt(jid) {
    if (isCooldown(jid, 'lastHunt', COOLDOWN.hunt)) {
        const time = getRemainingTime(jid, 'lastHunt', COOLDOWN.hunt);
        return `Cooldown! Tunggu ${time} detik lagi.`;
    }

    const user = getPlayerStats(jid);
    if (user.hp <= 0) return `HP Anda 0. Silakan heal atau respawn!`;

    let monster;
    let isElite = false;

    const minMlvl = Math.max(1, user.level - 5);
    const maxMlvl = user.level + 2;

    if (Math.random() < 0.1 && user.level >= 10) {
        const template = ELITES[Math.floor(Math.random() * ELITES.length)];
        monster = scaleMonster(template, Math.max(minMlvl, user.level));
        isElite = true;
    }

    if (!monster) {
        let possibleMonsters = MONSTERS.filter((m) => m.level >= minMlvl && m.level <= maxMlvl);

        if (possibleMonsters.length === 0) {
            const strongestMonster = MONSTERS[MONSTERS.length - 1];
            const targetLvl = Math.floor(Math.random() * (maxMlvl - minMlvl + 1)) + minMlvl;
            monster = scaleMonster(strongestMonster, targetLvl);
        } else {
            monster = possibleMonsters[Math.floor(Math.random() * possibleMonsters.length)];
        }
    }

    let levelDiff = user.level - monster.level;
    let actualExpGain = monster.exp;
    if (levelDiff > 5) {
        actualExpGain = Math.floor(monster.exp * 0.1);
        if (actualExpGain < 1) actualExpGain = 1;
    }

    let playerHp = user.hp;
    let monsterHp = monster.hp;

    while (playerHp > 0 && monsterHp > 0) {
        const dmgToMob = Math.max(1, user.totalAttack - monster.defense);
        monsterHp -= dmgToMob;
        if (monsterHp <= 0) break;

        const dmgToPlayer = Math.max(1, monster.attack - user.totalDefense);
        playerHp -= dmgToPlayer;
    }

    let resultText = `\n*🗡️ HUNT RESULT*\n------------------\n`;

    if (playerHp > 0) {
        addExp(jid, actualExpGain);
        addMoney(jid, monster.money);

        let dropText = '';

        LOOTS.forEach((lore) => {
            if (Math.random() * 100 < lore.chance) {
                addItem(jid, lore.name, 1);
                dropText += `\n+1 ${lore.name} (Rare Drop)`;
            }
        });

        if (Math.random() > 0.8) {
            addItem(jid, 'Small Potion', 1);
            dropText += `\n+1 Small Potion`;
        }

        updateHp(jid, playerHp);
        setCooldown(jid, 'lastHunt');

        resultText += `Status: *MENANG*\nTarget: ${isElite ? '💀 ' : ''}${monster.name} (Lvl ${monster.level})\nExp Gained: +${actualExpGain} ${levelDiff > 5 ? '(Low Lvl)' : ''}\nMoney Gained: +$${monster.money}${dropText}\nSisa HP: ${playerHp}/${user.maxHp}`;
    } else {
        updateHp(jid, 0);
        setCooldown(jid, 'lastHunt');

        const currentUser = getRpgUser(jid);
        const lostMoney = Math.floor(currentUser.money * 0.1);
        if (lostMoney > 0) addMoney(jid, -lostMoney);

        resultText += `Status: *KALAH*\nTarget: ${isElite ? '💀 ' : ''}${monster.name} (Lvl ${monster.level})\nKamu pingsan dan kehilangan 10% uang ($${lostMoney}).\nKetik .heal untuk bangun.`;
    }

    return resultText;
}

function boss(jid) {
    if (isCooldown(jid, 'lastBoss', COOLDOWN.boss)) {
        const time = getRemainingTime(jid, 'lastBoss', COOLDOWN.boss);
        const minutes = Math.ceil(time / 60);
        return `Boss belum spawn! Tunggu ${minutes} menit lagi.`;
    }

    const user = getPlayerStats(jid);
    if (user.hp <= 0) return `HP Anda 0.`;

    const baseBoss = BOSSES[Math.floor(Math.random() * BOSSES.length)];
    const monster = scaleMonster(baseBoss, user.level);

    let playerHp = user.hp;
    let monsterHp = monster.hp;

    for (let i = 0; i < 15; i++) {
        if (playerHp <= 0 || monsterHp <= 0) break;
        const dmgToMob = Math.max(1, user.totalAttack - monster.defense);
        monsterHp -= dmgToMob;
        if (monsterHp > 0) {
            const dmgToPlayer = Math.max(1, monster.attack - user.totalDefense);
            playerHp -= dmgToPlayer;
        }
    }

    if (playerHp > 0 && monsterHp <= 0) {
        addExp(jid, monster.exp);
        addMoney(jid, monster.money);

        const rareItems = SHOP_ITEMS.filter((i) => i.price >= 2000 && i.type !== 'boost');
        const randomItem = rareItems[Math.floor(Math.random() * rareItems.length)];
        addItem(jid, randomItem.name, 1);

        updateHp(jid, playerHp);
        setCooldown(jid, 'lastBoss');

        return `*👑 BOSS HUNTER*\nKamu mengalahkan ${monster.name} (Lvl ${monster.level})!\n+${monster.exp} Exp\n+$${monster.money}\n*Item Rare: +1 ${randomItem.name}*`;
    } else {
        updateHp(jid, 0);
        setCooldown(jid, 'lastBoss');
        return `Kamu dikalahkan ${monster.name} (Lvl ${monster.level})! Pulihkan dirimu.`;
    }
}

function dungeon(jid) {
    if (isCooldown(jid, 'lastDungeon', COOLDOWN.dungeon)) {
        const time = getRemainingTime(jid, 'lastDungeon', COOLDOWN.dungeon);
        return `Masih cooldown Dungeon! Tunggu ${Math.ceil(time / 60)} menit.`;
    }

    const user = getPlayerStats(jid);
    if (user.hp < user.maxHp / 2) return `HP minimal 50% untuk masuk dungeon!`;

    const dungeonPrefix = ['Goblin', 'Dark', 'Dragon', 'Shadow', 'Demon', 'Celestial', 'Void', 'Chaos'];
    const dungeonSuffix = ['Cave', 'Forest', 'Nest', 'Castle', 'Abyss', 'Sanctuary', 'Realm'];
    const pIndex = Math.min(Math.floor(user.level / 20), dungeonPrefix.length - 1);
    const sIndex = Math.min(Math.floor(user.level / 15), dungeonSuffix.length - 1);
    const dName = `${dungeonPrefix[pIndex] || 'Mysterious'} ${dungeonSuffix[sIndex] || 'Dungeon'}`;

    const baseReward = 500;
    const baseExp = 100;
    const rewardMoney = Math.floor(baseReward * Math.pow(1.1, user.level - 1));
    const rewardExp = Math.floor(baseExp * Math.pow(1.1, user.level - 1));

    let currentHp = user.hp;

    const baseMob = MONSTERS[Math.floor(Math.random() * MONSTERS.length)];
    const dungeonMob = scaleMonster(baseMob, user.level + 2);

    for (let i = 0; i < 5; i++) {
        const mob = { ...dungeonMob };
        const dmgToMob = Math.max(1, user.totalAttack - mob.defense);
        mob.hp -= dmgToMob;

        if (mob.hp <= 0) {
        } else {
            const dmgToPlayer = Math.max(1, mob.attack - user.totalDefense);
            currentHp -= dmgToPlayer;
        }

        if (currentHp <= 0) break;
    }

    let result = `*🏰 DUNGEON: ${dName}*\n`;

    if (currentHp > 0) {
        addExp(jid, rewardExp);
        addMoney(jid, rewardMoney);
        updateHp(jid, currentHp);
        result += `Kamu menyelesaikan dungeon!\nTotal Exp: +${rewardExp}\nTotal Money: +$${rewardMoney}\nSisa HP: ${currentHp}`;
    } else {
        updateHp(jid, 0);
        result += `Kamu gugur di dalam dungeon...`;
    }

    setCooldown(jid, 'lastDungeon');
    return result;
}

function fish(jid) {
    if (isCooldown(jid, 'lastFish', COOLDOWN.fishing)) {
        const time = getRemainingTime(jid, 'lastFish', COOLDOWN.fishing);
        return `Cooldown mancing! Tunggu ${time} detik lagi.`;
    }

    const user = getRpgUser(jid);
    if (!user.inventory['Fishing Rod']) return `Kamu tidak memiliki *Fishing Rod*!\nBeli di shop terlebih dahulu.`;

    const baitCost = 5;
    if (user.money < baitCost) return `Uangmu tidak cukup untuk membeli umpan (Biaya: $${baitCost}).`;

    addMoney(jid, -baitCost);
    const totalWeight = FISHES.reduce((acc, f) => acc + f.chance, 0);
    let rand = Math.random() * totalWeight;
    let caught = null;

    for (const f of FISHES) {
        if (rand < f.chance) {
            caught = f;
            break;
        }
        rand -= f.chance;
    }

    if (!caught) caught = FISHES[0];

    addExp(jid, caught.exp);
    addMoney(jid, caught.money);
    addItem(jid, caught.name, 1);
    setCooldown(jid, 'lastFish');

    return `
*🎣 FISHING RESULT*
------------------
Peralatan: Fishing Rod
Biaya Umpan: -$${baitCost}
Hasil: ${caught.name} (${caught.rarity})
Exp: +${caught.exp}
Money (Jual): +$${caught.money}
Item: +1 ${caught.name}
    `;
}

function mining(jid) {
    if (isCooldown(jid, 'lastMining', COOLDOWN.mining)) {
        const time = getRemainingTime(jid, 'lastMining', COOLDOWN.mining);
        return `Cooldown Mining! Tunggu ${Math.floor(time / 60)} menit ${time % 60} detik lagi.`;
    }

    const user = getRpgUser(jid);
    const pickaxes = ['Wooden Pickaxe', 'Stone Pickaxe', 'Iron Pickaxe', 'Diamond Pickaxe'];
    const hasPickaxe = pickaxes.some((p) => user.inventory[p] > 0);

    if (!hasPickaxe) return `Kamu tidak memiliki *Pickaxe*!\nBeli di shop terlebih dahulu (.rpg buy Wooden Pickaxe).`;

    let bonusChance = 0;
    if (user.inventory['Diamond Pickaxe']) bonusChance = 5;
    else if (user.inventory['Iron Pickaxe']) bonusChance = 3;
    else if (user.inventory['Stone Pickaxe']) bonusChance = 1;

    const totalWeight = MINERALS.reduce((acc, m) => acc + m.chance, 0);
    let rand = Math.random() * totalWeight;
    let mined = null;

    for (const m of MINERALS) {
        let adjustedChance = m.chance;
        if (m.rarity !== 'Common') adjustedChance += bonusChance;

        if (rand < adjustedChance) {
            mined = m;
            break;
        }
        rand -= adjustedChance;
    }

    if (!mined) mined = MINERALS[0];
    const amount = Math.floor(Math.random() * 2) + 1;

    const miningExp = mined.exp * amount + Math.floor(user.level * 0.5);

    addExp(jid, miningExp);
    addItem(jid, mined.name, amount);
    setCooldown(jid, 'lastMining');

    return `
*⛏️ MINING RESULT*
------------------
Peralatan: ${pickaxes.find((p) => user.inventory[p] > 0)}
Hasil: x${amount} ${mined.name} (${mined.rarity})
Exp: +${miningExp}
Ketik .rpg sell ${mined.name} untuk menjual.
    `;
}

function adventure(jid) {
    if (isCooldown(jid, 'lastAdventure', COOLDOWN.adventure)) {
        const time = getRemainingTime(jid, 'lastAdventure', COOLDOWN.adventure);
        return `Cooldown Adventure! Tunggu ${Math.floor(time / 60)} menit lagi.`;
    }

    const user = getPlayerStats(jid);
    if (user.hp < user.maxHp * 0.8) return `HP minimal 80% untuk berpetualang!\nSaat ini: ${user.hp}/${user.maxHp}`;

    let logs = [];
    let totalMoney = 0;
    let totalExp = 0;
    let currentHp = user.hp;

    for (let i = 0; i < 3; i++) {
        const event = ADVENTURE_EVENTS[Math.floor(Math.random() * ADVENTURE_EVENTS.length)];

        if (event.type === 'chest') {
            const scaledMoney =
                Math.floor(Math.random() * (event.rewardMoney[1] - event.rewardMoney[0])) +
                event.rewardMoney[0] +
                user.level * 10;
            totalMoney += scaledMoney;
            totalExp += event.rewardExp;
            logs.push(`💰 [Event] ${event.text} (+$${scaledMoney})`);
        } else if (event.type === 'monster') {
            const dmg = Math.floor(Math.random() * (event.damage[1] - event.damage[0])) + event.damage[0] + user.level;
            const money =
                Math.floor(Math.random() * (event.rewardMoney[1] - event.rewardMoney[0])) +
                event.rewardMoney[0] +
                user.level * 5;

            const actualDmg = Math.max(5, dmg - Math.floor(user.totalDefense / 2));
            currentHp -= actualDmg;

            totalMoney += money;
            totalExp += event.rewardExp;
            logs.push(`⚔️ [Event] ${event.text} (-${actualDmg} HP, +$${money})`);
        } else if (event.type === 'trap') {
            const dmg =
                Math.floor(Math.random() * (event.damage[1] - event.damage[0])) +
                event.damage[0] +
                Math.floor(user.level / 2);
            const actualDmg = Math.max(1, dmg - Math.floor(user.totalDefense / 3));
            currentHp -= actualDmg;
            logs.push(`💥 [Event] ${event.text} (-${actualDmg} HP)`);
        } else if (event.type === 'shrine') {
            const heal = Math.floor(Math.random() * (event.heal[1] - event.heal[0])) + event.heal[0] + user.level * 2;
            currentHp = Math.min(user.maxHp, currentHp + heal);
            logs.push(`🙏 [Event] ${event.text} (+${heal} HP)`);
        } else if (event.type === 'merchant') {
            const money =
                Math.floor(Math.random() * (event.rewardMoney[1] - event.rewardMoney[0])) +
                event.rewardMoney[0] +
                user.level * 15;
            totalMoney += money;
            logs.push(`🎒 [Event] ${event.text} (+$${money})`);
        }

        if (currentHp <= 0) break;
    }

    let status = 'Selesai';
    if (currentHp <= 0) {
        currentHp = 0;
        status = 'Gagal (HP Habis)';
        totalMoney = Math.floor(totalMoney / 2);
    }

    addMoney(jid, totalMoney);
    addExp(jid, totalExp);
    updateHp(jid, currentHp);
    setCooldown(jid, 'lastAdventure');

    let resultText = `*🗺️ ADVENTURE LOG*\n------------------\nStatus: ${status}\n\n`;
    logs.forEach((log) => (resultText += `${log}\n`));
    resultText += `\n*TOTAL REWARD*\nMoney: +$${totalMoney}\nExp: +${totalExp}\nSisa HP: ${currentHp}/${user.maxHp}`;

    return resultText;
}

function work(jid) {
    if (isCooldown(jid, 'lastWork', COOLDOWN.work)) {
        const time = getRemainingTime(jid, 'lastWork', COOLDOWN.work);
        return `Kamu masih kelelahan bekerja!\nIstirahatlah ${Math.floor(time / 60)} menit lagi.`;
    }

    const user = getRpgUser(jid);
    if (user.mana < 20) return `Manamu kurang (< 20) untuk bekerja!\nKetik .heal atau minum mana potion.`;

    const baseSalary = 500;
    const levelBonus = user.level * 200;
    const totalSalary = baseSalary + levelBonus;

    addMoney(jid, totalSalary);
    addMana(jid, -20);
    addExp(jid, 10 + Math.floor(user.level * 0.5));
    setCooldown(jid, 'lastWork');

    return `
*👷 WORK RESULT*
------------------
Kamu bekerja keras sebagai tentara bayaran.
Gaji: +$${totalSalary}
Mana Terpakai: -20
Exp: +${10 + Math.floor(user.level * 0.5)}
    `;
}

function plant(jid, seedName) {
    const user = getRpgUser(jid);
    if (user.farming.plant !== null) {
        const crop = CROPS[user.farming.plant];
        const remaining = Math.ceil((user.farming.readyAt - Date.now()) / 1000);
        const minutes = Math.floor(remaining / 60);
        const seconds = remaining % 60;
        return `Kamu sedang menanam ${user.farming.plant}.\nSisa waktu: ${minutes} menit ${seconds} detik.\nKetik .rpg harvest untuk memanen.`;
    }

    const seedItem = SHOP_ITEMS.find((i) => i.name.toLowerCase() === seedName.toLowerCase() && i.type === 'seed');
    if (!seedItem) return `Bibit "${seedName}" tidak valid atau tidak ada di shop.`;

    const inv = user.inventory;
    const itemKey = Object.keys(inv).find((k) => k.toLowerCase() === seedName.toLowerCase());

    if (!itemKey || !inv[itemKey] || inv[itemKey] <= 0) return `Kamu tidak punya bibit ${seedName}. Beli di shop dulu.`;

    let cropName = seedItem.name.replace(' Seed', '');
    let cropData = CROPS[cropName];
    if (!cropData) {
        const foundEntry = Object.entries(CROPS).find(([k, v]) => v.seedName === seedItem.name);
        if (foundEntry) {
            cropName = foundEntry[0];
            cropData = foundEntry[1];
        } else {
            return `Error Data: Tanaman untuk bibit ${seedItem.name} belum dikonfigurasi.`;
        }
    }

    removeItem(jid, itemKey, 1);

    const userDb = loadUserDB(jid);
    userDb.farming = {
        plant: cropName,
        plantedAt: Date.now(),
        readyAt: Date.now() + cropData.duration * 1000
    };
    saveUserDB(jid, userDb);

    return `
*🌱 FARMING PLANT*
------------------
Berhasil menanam ${seedName}!
Biaya: -1 ${seedItem.name}
Estimasi panen: ${cropData.duration / 60} menit lagi.
    `;
}

function farm(jid) {
    const user = getRpgUser(jid);
    if (user.farming.plant === null)
        return `Lahan kosong. Tanam sesuatu dengan .rpg plant <bibit>.\nKetik .rpg farmlist untuk lihat bibit.`;

    const cropData = CROPS[user.farming.plant];
    const remaining = Math.ceil((user.farming.readyAt - Date.now()) / 1000);

    if (remaining > 0) {
        const minutes = Math.floor(remaining / 60);
        const seconds = remaining % 60;
        return `
*🌾 FARM STATUS*
------------------
Tanaman: ${user.farming.plant} (${cropData.rarity})
Sisa Waktu: ${minutes} menit ${seconds} detik.
        `;
    } else {
        return `
*🌾 FARM STATUS*
------------------
Tanaman: ${user.farming.plant}
Status: *SIAP PANEN!*
Ketik .rpg harvest untuk mengambil hasil.
        `;
    }
}

function harvest(jid) {
    const user = getRpgUser(jid);
    if (user.farming.plant === null) return `Tidak ada tanaman yang bisa dipanen.`;

    const cropData = CROPS[user.farming.plant];
    if (Date.now() < user.farming.readyAt) {
        const remaining = Math.ceil((user.farming.readyAt - Date.now()) / 1000);
        return `Tanaman belum siap panen! Tunggu ${remaining} detik lagi.`;
    }

    const yieldAmount = Math.floor(Math.random() * (cropData.max - cropData.min + 1)) + cropData.min;

    addExp(jid, cropData.exp);
    addMoney(jid, cropData.money);
    addItem(jid, user.farming.plant, yieldAmount);

    const userDb = loadUserDB(jid);
    const harvestedPlant = user.farming.plant;
    userDb.farming = { plant: null, plantedAt: 0, readyAt: 0 };
    saveUserDB(jid, userDb);

    return `
*🌾 FARM HARVEST*
------------------
Berhasil memanen ${harvestedPlant}!
Hasil: x${yieldAmount}
Exp: +${cropData.exp}
Money (Jual): +$${cropData.money}
    `;
}

function daily(jid) {
    if (isCooldown(jid, 'lastDaily', COOLDOWN.daily)) {
        const time = getRemainingTime(jid, 'lastDaily', COOLDOWN.daily);
        const hours = Math.floor(time / 3600);
        const minutes = Math.floor((time % 3600) / 60);
        return `Kamu sudah mengambil daily hari ini!\nKembali lagi dalam ${hours} jam ${minutes} menit.`;
    }

    const user = getRpgUser(jid);
    const rewardMoney = 500 + user.level * 100;
    const rewardExp = 50 + user.level * 20;

    addMoney(jid, rewardMoney);
    addExp(jid, rewardExp);
    setCooldown(jid, 'lastDaily');

    return `
*📅 DAILY CLAIM*
------------------
Selamat datang kembali!
Level: ${user.level}
Reward Money: +$${rewardMoney}
Reward Exp: +${rewardExp}

Jangan lupa claim besok ya!
    `;
}

module.exports = { hunt, boss, dungeon, fish, mining, adventure, work, plant, farm, harvest, daily };

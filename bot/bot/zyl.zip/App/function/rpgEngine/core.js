/**
 * rpgEngine/core.js — Inti engine RPG: database user, EXP, uang, mana, HP, cooldown, item.
 */
const fs = require('fs');
const path = require('path');
const { loadDB: loadDBLayer, saveDB: saveDBLayer } = require('../../../database/wrappers/storage');
const { DEFAULT_RPG, COOLDOWN, SHOP_ITEMS } = require('./data');

const DATA_DIR = path.join(__dirname, '../../../Storage/rpg');

if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
}

function getUserPath(jid) {
    return path.join(DATA_DIR, `${jid}.json`);
}

function loadUserDB(jid) {
    const userPath = getUserPath(jid);
    try {
        const data = loadDBLayer(userPath, null);
        if (data === null || data === undefined) {
            saveDBLayer(userPath, { ...DEFAULT_RPG });
            return { ...DEFAULT_RPG };
        }
        return data;
    } catch {
        return { ...DEFAULT_RPG };
    }
}

function saveUserDB(jid, data) {
    try {
        saveDBLayer(getUserPath(jid), data);
    } catch (e) {
        console.error('Gagal save user DB:', e);
    }
}

function getExpNeeded(level) {
    if (level < 1) return 100;
    return Math.floor(100 * Math.pow(1.15, level - 1));
}

function scaleMonster(baseMonster, targetLevel) {
    const levelDiff = targetLevel - baseMonster.level;
    const multiplier = Math.pow(1.2, levelDiff);

    const newHp = Math.floor(baseMonster.hp * multiplier);
    const newAtk = Math.floor(baseMonster.attack * multiplier);
    const newDef = Math.floor(baseMonster.defense * multiplier);
    const newExp = Math.floor(baseMonster.exp * multiplier);
    const newMoney = Math.floor(baseMonster.money * multiplier);

    return {
        ...baseMonster,
        level: targetLevel,
        hp: newHp,
        attack: newAtk,
        defense: newDef,
        exp: newExp,
        money: newMoney
    };
}

function addRpgUser(jid) {
    const user = loadUserDB(jid);
    return true;
}

function getRpgUser(jid) {
    const user = loadUserDB(jid);
    let needSave = false;
    if (typeof user.money === 'undefined') {
        user.money = 0;
        needSave = true;
    }
    if (typeof user.mana === 'undefined') {
        user.mana = 50;
        user.maxMana = 50;
        needSave = true;
    }
    if (typeof user.pet === 'undefined') {
        user.pet = null;
        needSave = true;
    }
    if (typeof user.boostAttack === 'undefined') {
        user.boostAttack = 0;
        needSave = true;
    }
    if (typeof user.boostDefense === 'undefined') {
        user.boostDefense = 0;
        needSave = true;
    }
    if (typeof user.expMultiplier === 'undefined') {
        user.expMultiplier = 1;
        needSave = true;
    }
    if (typeof user.farming === 'undefined') {
        user.farming = { plant: null, plantedAt: 0, readyAt: 0 };
        needSave = true;
    }
    if (typeof user.lastMining === 'undefined') {
        user.lastMining = 0;
        needSave = true;
    }
    if (typeof user.lastAdventure === 'undefined') {
        user.lastAdventure = 0;
        needSave = true;
    }
    if (typeof user.lastWork === 'undefined') {
        user.lastWork = 0;
        needSave = true;
    }

    if (needSave) saveUserDB(jid, user);
    return user;
}

function saveRpgUser(jid, data) {
    saveUserDB(jid, data);
    return true;
}

function getPlayerStats(jid) {
    const user = getRpgUser(jid);

    let weaponAtk = 0;
    let armorDef = 0;

    const weaponData = SHOP_ITEMS.find((i) => i.name === user.weapon && i.type === 'weapon');
    if (weaponData) weaponAtk = weaponData.attack;

    const armorData = SHOP_ITEMS.find((i) => i.name === user.armor && i.type === 'armor');
    if (armorData) armorDef = armorData.defense;

    let petAtk = 0;
    if (user.pet) {
        const petData = SHOP_ITEMS.find((i) => i.name === user.pet && i.type === 'pet');
        if (petData) petAtk = petData.attack;
    }

    return {
        ...user,
        totalAttack: user.attack + weaponAtk + user.boostAttack + petAtk,
        totalDefense: user.defense + armorDef + user.boostDefense
    };
}

function addExp(jid, amount = 0) {
    if (amount <= 0) return false;
    const user = getRpgUser(jid);

    const finalExp = amount * user.expMultiplier;
    user.exp += finalExp;

    let leveledUp = false;
    while (user.exp >= getExpNeeded(user.level)) {
        user.exp -= getExpNeeded(user.level);
        user.level += 1;
        user.maxHp += 10;
        user.maxMana += 5;
        user.attack += 2;
        user.defense += 1;
        user.hp = user.maxHp;
        user.mana = user.maxMana;
        leveledUp = true;
    }

    saveUserDB(jid, user);
    return true;
}

function addMoney(jid, amount = 0) {
    const user = getRpgUser(jid);
    user.money = Math.max(0, user.money + amount);
    saveUserDB(jid, user);
    return true;
}

function addMana(jid, amount = 0) {
    const user = getRpgUser(jid);
    user.mana = Math.min(user.maxMana, user.mana + amount);
    saveUserDB(jid, user);
    return true;
}

function updateHp(jid, newHp) {
    const user = getRpgUser(jid);
    user.hp = Math.min(user.maxHp, Math.max(0, newHp));
    saveUserDB(jid, user);
    return true;
}

function setCooldown(jid, type) {
    const user = getRpgUser(jid);
    user[type] = Date.now();
    saveUserDB(jid, user);
    return true;
}

function isCooldown(jid, type, cooldownTimeMs) {
    const user = getRpgUser(jid);
    if (!user[type]) return false;
    const now = Date.now();
    const diff = now - user[type];
    return diff < cooldownTimeMs;
}

function getRemainingTime(jid, type, cooldownTimeMs) {
    const user = getRpgUser(jid);
    if (!user[type]) return 0;
    const now = Date.now();
    const diff = now - user[type];
    const remaining = cooldownTimeMs - diff;
    return remaining > 0 ? Math.ceil(remaining / 1000) : 0;
}

function addItem(jid, item, amount = 1) {
    if (amount <= 0) return false;
    const userDb = loadUserDB(jid);
    const inventory = userDb.inventory;
    inventory[item] = (inventory[item] || 0) + amount;
    saveUserDB(jid, userDb);
    return true;
}

function removeItem(jid, item, amount = 1) {
    const userDb = loadUserDB(jid);
    const inventory = userDb.inventory;
    if (!inventory[item]) return false;
    inventory[item] -= amount;
    if (inventory[item] <= 0) delete inventory[item];
    saveUserDB(jid, userDb);
    return true;
}

function setWeapon(jid, weapon) {
    const userDb = loadUserDB(jid);
    userDb.weapon = weapon;
    saveUserDB(jid, userDb);
    return true;
}

function setArmor(jid, armor) {
    const userDb = loadUserDB(jid);
    userDb.armor = armor;
    saveUserDB(jid, userDb);
    return true;
}

function getRpgLeaderboard(limit = 10) {
    let allUsers = [];
    try {
        const files = fs.readdirSync(DATA_DIR);
        files.forEach((file) => {
            if (file.endsWith('.json')) {
                try {
                    const jid = file.replace('.json', '');
                    const data = JSON.parse(fs.readFileSync(path.join(DATA_DIR, file)));
                    allUsers.push({ jid, ...data });
                } catch (e) {}
            }
        });
    } catch (e) {
        console.error('Error reading leaderboard dir', e);
    }

    const topLevel = allUsers
        .map((u) => ({ jid: u.jid, level: u.level || 0 }))
        .sort((a, b) => b.level - a.level)
        .slice(0, limit);

    const topMoney = allUsers
        .map((u) => ({ jid: u.jid, money: u.money || 0 }))
        .sort((a, b) => b.money - a.money)
        .slice(0, limit);

    const topExp = allUsers
        .map((u) => ({ jid: u.jid, exp: u.exp || 0 }))
        .sort((a, b) => b.exp - a.exp)
        .slice(0, limit);

    const line = '━━━━━━━━━━━━━━━━━━━━━━';

    let text = `🏆 *RPG GLOBAL LEADERBOARD*\n`;
    text += `${line}\n`;
    text += `👥 Total Player : ${allUsers.length}\n`;
    text += `${line}\n\n`;

    text += `🏅 *TOP LEVEL*\n`;
    text += `╭─────────────────\n`;

    topLevel.forEach((u, i) => {
        const medal = ['🥇', '🥈', '🥉'][i] || '🏅';
        text += `│ ${medal} @${u.jid.split('@')[0]}\n`;
        text += `│    ➤ Level : ${u.level}\n`;
    });

    text += `╰─────────────────\n\n`;

    text += `💰 *TOP MONEY*\n`;
    text += `╭─────────────────\n`;

    topMoney.forEach((u, i) => {
        const medal = ['🥇', '🥈', '🥉'][i] || '🏅';
        text += `│ ${medal} @${u.jid.split('@')[0]}\n`;
        text += `│    ➤ Money : ${u.money.toLocaleString()}\n`;
    });

    text += `╰─────────────────\n\n`;

    text += `⚡ *TOP EXP*\n`;
    text += `╭─────────────────\n`;

    topExp.forEach((u, i) => {
        const medal = ['🥇', '🥈', '🥉'][i] || '🏅';
        text += `│ ${medal} @${u.jid.split('@')[0]}\n`;
        text += `│    ➤ EXP : ${u.exp.toLocaleString()}\n`;
    });

    text += `╰─────────────────`;

    const mentions = [
        ...new Set([...topLevel.map((v) => v.jid), ...topMoney.map((v) => v.jid), ...topExp.map((v) => v.jid)])
    ];

    return {
        text,
        mentions
    };
}

module.exports = { DATA_DIR, getUserPath, loadUserDB, saveUserDB, getExpNeeded, scaleMonster, addRpgUser, getRpgUser, saveRpgUser, getPlayerStats, addExp, addMoney, addMana, updateHp, setCooldown, isCooldown, getRemainingTime, addItem, removeItem, setWeapon, setArmor, getRpgLeaderboard };

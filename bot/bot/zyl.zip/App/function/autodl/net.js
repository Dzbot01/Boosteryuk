/**
 * autodl/net.js — Util jaringan auto-download: ukuran file & deteksi tipe konten.
 * fetchJson TIDAK lagi diduplikat di sini — pakai satu sumber dari handlers/network.js.
 */
const axios = require('axios');
const { fetchJson } = require('@App/function/handlers/network');

async function getFileSize(url) {
    try {
        const res = await axios.head(url);
        const length = res.headers['content-length'];
        return length ? Number(length) : 0;
    } catch {
        return 0;
    }
}

async function detectContentType(url) {
    try {
        const res = await fetch(url, { method: 'HEAD' });
        const type = res.headers.get('content-type') || '';
        const disposition = res.headers.get('content-disposition') || '';

        if (type.startsWith('image/')) return 'image';
        if (type.startsWith('video/')) return 'video';
        if (type.startsWith('audio/')) return 'audio';

        if (disposition) {
            const filenameMatch = disposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/);
            if (filenameMatch && filenameMatch[1]) {
                const filename = filenameMatch[1].replace(/['"]/g, '');
                const ext = filename.split('.').pop().toLowerCase();
                const imageExts = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
                const videoExts = ['mp4', 'webm', 'mkv', 'mov', 'avi'];
                const audioExts = ['mp3', 'm4a', 'wav', 'aac', 'flac'];

                if (imageExts.includes(ext)) return 'image';
                if (videoExts.includes(ext)) return 'video';
                if (audioExts.includes(ext)) return 'audio';
            }
        }

        return 'unknown';
    } catch {
        return 'unknown';
    }
}

module.exports = { getFileSize, detectContentType, fetchJson };

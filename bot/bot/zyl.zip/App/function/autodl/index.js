/**
 * autodl/index.js — Dispatcher auto-download (deteksi platform -> handler platform).
 * Tambah platform baru: buat file di platforms/ lalu daftarkan di switch detectPlatform.
 */
const { loading, success } = require('@App/function/handler');
const { reduceLimit } = require('@App/function/user');
const config = require('@Config');
const { downloadTikTok } = require('./platforms/downloadTikTok');
const { downloadCapcut } = require('./platforms/downloadCapcut');
const { downloadInstagram } = require('./platforms/downloadInstagram');
const { downloadYouTube } = require('./platforms/downloadYouTube');

function detectPlatform(url) {
    if (typeof url !== 'string') return null;

    if (/^(https?:\/\/)?([a-z0-9-]+\.)*tiktok\.com/i.test(url)) return 'tiktok';

    if (/^(https?:\/\/)?([a-z0-9-]+\.)*capcut\.com/i.test(url)) return 'capcut';

    if (/^(https?:\/\/)?(www\.)?(instagram\.com|instagr\.am)/i.test(url)) return 'instagram';

    if (/^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)/i.test(url)) return 'youtube';

    return null;
}

async function handleDownload(conn, m, url, isSpecialUser) {
    const platform = detectPlatform(url);
    const { endpoint, key } = config.apikey;

    if (!platform) return null;

    if (!isSpecialUser && !reduceLimit(m.sender, 3)) {
        return m.reply(config.mess.limit);
    }

    await loading(conn, m);

    let result;
    switch (platform) {
        case 'tiktok':
            result = await downloadTikTok(conn, m, endpoint, url, key);
            break;

        case 'capcut':
            result = await downloadCapcut(conn, m, endpoint, url, key);
            break;

        case 'instagram':
            result = await downloadInstagram(conn, m, endpoint, url, key);
            break;

        case 'youtube':
            result = await downloadYouTube(conn, m, endpoint, url, key);
            break;

        default:
            return null;
    }
    await success(conn, m);
    return result;
}

module.exports = { handleDownload };

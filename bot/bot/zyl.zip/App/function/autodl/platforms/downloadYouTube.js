/**
 * autodl/platforms/downloadYouTube.js — Auto-download YouTube.
 * Dipisah dari handleAutodownload.js: 1 platform = 1 file.
 */
const { fetchJson } = require('../net');
const { getFileSize } = require('../net');
const { sendDownloadLink } = require('../sender');
const { MAX_WA_SIZE } = require('../sender');

async function downloadYouTube(conn, m, endpoint, url, key) {
    const res = await fetchJson(
        `${endpoint}/api/download/youtube?url=${encodeURIComponent(url)}&format=360&apikey=${key}`
    );

    if (!res || res.status !== 200 || !res.data?.download) {
        return conn.sendMessage(m.chat, { text: 'Gagal mengambil data YouTube.' }, { quoted: m });
    }

    const { title = '', type, download, thumbnail, quality } = res?.data || {};

    const fileSize = await getFileSize(download);

    if (!fileSize || fileSize > MAX_WA_SIZE) {
        return sendDownloadLink(conn, m, download, thumbnail);
    }

    if (type === 'video') {
        await conn.sendMessage(
            m.chat,
            {
                video: { url: download },
                caption: `${title}\nQuality: ${quality}p`,
                mimetype: 'video/mp4'
            },
            { quoted: m }
        );
        await conn.sendMessage(m.chat, {
            audio: { url: download },
            mimetype: 'audio/mp4',
            ptt: false
        });
    }
}

module.exports = { downloadYouTube };

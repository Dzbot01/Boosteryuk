/**
 * autodl/platforms/downloadInstagram.js — Auto-download Instagram.
 * Dipisah dari handleAutodownload.js: 1 platform = 1 file.
 */
const { fetchJson } = require('../net');
const { detectContentType } = require('../net');
const { loading, success } = require('@App/function/handler');

async function downloadInstagram(conn, m, endpoint, url, key) {
    const res = await fetchJson(`${endpoint}/api/download/instagram?url=${encodeURIComponent(url)}&apikey=${key}`);

    if (!res || res.status !== 200 || !res.data?.success) {
        return conn.sendMessage(m.chat, { text: 'Gagal mengambil data Instagram.' }, { quoted: m });
    }

    const results = res.data.result;
    if (!Array.isArray(results) || results.length === 0) {
        return conn.sendMessage(m.chat, { text: 'Konten Instagram tidak ditemukan.' }, { quoted: m });
    }

    let audioSource = null;

    for (const item of results) {
        const mediaUrl = item.url;
        const thumbUrl = item.thumbnail;
        const mediaType = await detectContentType(mediaUrl);

        switch (mediaType) {
            case 'image':
                await conn.sendMessage(
                    m.chat,
                    {
                        image: { url: mediaUrl }
                    },
                    { quoted: m }
                );
                break;

            case 'video':
                await conn.sendMessage(
                    m.chat,
                    {
                        video: { url: mediaUrl }
                    },
                    { quoted: m }
                );
                if (!audioSource) audioSource = mediaUrl;
                break;

            default:
                await conn.sendMessage(m.chat, { text: 'Media tidak dikenali oleh server.' }, { quoted: m });
        }
    }

    if (audioSource) {
        await conn.sendMessage(m.chat, {
            audio: { url: audioSource },
            mimetype: 'audio/mp4',
            ptt: false
        });
    }
}

module.exports = { downloadInstagram };

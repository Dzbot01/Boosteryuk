/**
 * autodl/platforms/downloadCapcut.js — Auto-download CapCut.
 * Dipisah dari handleAutodownload.js: 1 platform = 1 file.
 */
const { fetchJson } = require('../net');

async function downloadCapcut(conn, m, endpoint, url, key) {
    const res = await fetchJson(`${endpoint}/api/download/capcut?url=${encodeURIComponent(url)}&apikey=${key}`);

    if (!res || res.status !== 200 || res.data?.error) {
        return conn.sendMessage(m.chat, { text: 'Gagal mengambil data CapCut.' }, { quoted: m });
    }

    const { title = '', thumbnail, medias = [] } = res.data;

    if (!Array.isArray(medias) || medias.length === 0) {
        return conn.sendMessage(m.chat, { text: 'Media CapCut tidak ditemukan.' }, { quoted: m });
    }

    const video =
        medias.find((v) => /hd/i.test(v.quality) && /no watermark/i.test(v.quality)) ||
        medias.find((v) => /no watermark/i.test(v.quality)) ||
        medias.find((v) => v.type === 'video');

    const audioSource =
        medias.find((v) => /watermark/i.test(v.quality)) ||
        medias.find((v) => /no watermark/i.test(v.quality)) ||
        medias.find((v) => v.type === 'video');

    if (video?.url) {
        await conn.sendMessage(
            m.chat,
            {
                video: { url: video.url },
                caption: title || 'CapCut Video'
            },
            { quoted: m }
        );
    }

    if (audioSource?.url) {
        await conn.sendMessage(m.chat, {
            audio: { url: audioSource.url },
            mimetype: 'audio/mp4',
            ptt: false
        });
    }
}

module.exports = { downloadCapcut };

/**
 * autodl/platforms/downloadTikTok.js — Auto-download TikTok.
 * Dipisah dari handleAutodownload.js: 1 platform = 1 file.
 */
const { fetchJson } = require('../net');
const { loading, success } = require('@App/function/handler');
const { generateWAMessageFromContent, prepareWAMessageMedia, proto } = require('baileys');

async function downloadTikTok(conn, m, endpoint, url, key) {
    try {
        const res = await fetchJson(`${endpoint}/api/download/tiktok?url=${encodeURIComponent(url)}&apikey=${key}`);

        if (!res || res.status !== 200 || !res.data?.success || !res.data?.data) {
            return conn.sendMessage(m.chat, { text: 'Gagal mengambil data TikTok.' }, { quoted: m });
        }

        const data = res.data.data;
        const { type, title = '', thumbnail, downloadUrl, author = {}, stats = {}, images = [], videoDuration } = data;

        if (type === 'carousel' || images.length > 0) {
            if (images.length === 1) {
                await conn.sendMessage(
                    m.chat,
                    {
                        image: { url: images[0].downloadUrl || images[0].url },
                        caption: title
                    },
                    { quoted: m }
                );
            } else if (images.length > 1) {
                const medias = await Promise.all(
                    images.map((img) =>
                        prepareWAMessageMedia(
                            {
                                image: {
                                    url: img.downloadUrl || img.url
                                }
                            },
                            {
                                upload: conn.waUploadToServer
                            }
                        )
                    )
                );

                const album = generateWAMessageFromContent(
                    m.chat,
                    {
                        albumMessage: proto.Message.AlbumMessage.fromObject({
                            expectedImageCount: medias.length,
                            caption: title
                        })
                    },
                    { quoted: m }
                );

                await conn.relayMessage(m.chat, album.message, {
                    messageId: album.key.id
                });

                for (const media of medias) {
                    const imgMsg = generateWAMessageFromContent(
                        m.chat,
                        {
                            imageMessage: media.imageMessage
                        },
                        {
                            quoted: album
                        }
                    );

                    await conn.relayMessage(m.chat, imgMsg.message, {
                        messageId: imgMsg.key.id
                    });
                }
            }

            if (downloadUrl) {
                await conn.sendMessage(
                    m.chat,
                    {
                        audio: { url: downloadUrl },
                        mimetype: 'audio/mp4',
                        ptt: false
                    },
                    { quoted: m }
                );
            }

            return;
        }

        if (type === 'video' || downloadUrl) {
            const videoUrl = downloadUrl;

            if (videoUrl) {
                await conn.sendMessage(
                    m.chat,
                    {
                        video: { url: videoUrl },
                        caption: title,
                        mimetype: 'video/mp4'
                    },
                    { quoted: m }
                );
            }

            if (downloadUrl) {
                await conn.sendMessage(
                    m.chat,
                    {
                        audio: { url: downloadUrl },
                        mimetype: 'audio/mp4',
                        ptt: false
                    },
                    { quoted: m }
                );
            }

            return;
        }

        return conn.sendMessage(m.chat, { text: 'Format TikTok tidak didukung.' }, { quoted: m });
    } catch (error) {
        console.error('TikTok Downloader Error:', error);

        return conn.sendMessage(
            m.chat,
            {
                text: `Gagal mengambil data TikTok.\n${error.message || 'Terjadi kesalahan.'}`
            },
            { quoted: m }
        );
    }
}

module.exports = { downloadTikTok };

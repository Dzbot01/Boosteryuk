/**
 * autodl/sender.js — Kirim pesan hasil auto-download (link + thumbnail) ke chat.
 */
const { generateWAMessageFromContent, prepareWAMessageMedia, proto } = require('baileys');
const config = require('@Config');

const MAX_WA_SIZE = 20 * 1024 * 1024;

async function sendDownloadLink(conn, m, url, thumbnail) {
    const media = await prepareWAMessageMedia(
        {
            image: {
                url: thumbnail
            }
        },
        { upload: conn.waUploadToServer }
    );

    const interactiveMsg = proto.Message.InteractiveMessage.fromObject({
        body: proto.Message.InteractiveMessage.Body.fromObject({
            text: 'File terlalu besar silahkan tap button di bawah untuk mendownload video'
        }),
        footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: `` }),
        header: proto.Message.InteractiveMessage.Header.fromObject({
            hasMediaAttachment: true,
            ...media
        }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
            buttons: [
                {
                    name: 'cta_url',
                    buttonParamsJson: JSON.stringify({
                        display_text: 'Download',
                        url: url,
                        merchant_url: url
                    })
                }
            ]
        }),
        contextInfo: {
            mentionedJid: [m.sender],
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: config.idch || '120363291726836483@newsletter',
                serverMessageId: 100,
                newsletterName: config.ownername
            }
        }
    });

    await conn.relayMessage(
        m.chat,
        { viewOnceMessageV2Extension: { message: { interactiveMessage: interactiveMsg } } },
        { quoted: m }
    );
}

module.exports = { MAX_WA_SIZE, sendDownloadLink };

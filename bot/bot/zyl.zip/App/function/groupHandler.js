const chalk = require('chalk');
const fs = require('fs');
const path = require('path');
const logger = require('@App/function/logger');
const { loadTextToxic } = require('./toxicHandler');
const config = require('../../config');
const { handleDownload } = require('./handleAutodownload');
const autoAi = require('./handleAutoai');

const REGEX = {
    allLink: /\b(?:https?:\/\/)?(?:www\.)?[a-zA-Z0-9-]+\.[a-zA-Z]{2,}(?:\/[^\s]*)?/gi,

    waLink: /\b(?:https?:\/\/)?(?:www\.)?(?:wa\.me|chat\.whatsapp\.com|api\.whatsapp\.com|whatsapp\.com)\/[^\s]+/gi,

    tiktokLink: /\b(?:https?:\/\/)?(?:www\.)?(?:tiktok\.com|vt\.tiktok\.com)\/[^\s]+/gi,

    antiPromosi: new RegExp(
        [
            '(\\+?62|08)\\d{8,13}(?:\\s*(chat|hubungi|wa|pm|call))?',

            '\\b(j\\W*u\\W*a\\W*l|pr\\W*o\\W*m\\W*o|d\\W*i\\W*s\\W*k\\W*o\\W*n|open\\W*order?|ready)\\b(?:\\s*(murah|harga|slot|order))?',

            '\\b(o\\W*r\\W*d\\W*e\\W*r|pesan|beli|checkout)\\b(?:\\s*(sekarang|yuk|disini|di\\s*wa)?)',

            '\\b(slot|gacor|maxwin|jackpot|bet|casino|togel)\\b',

            '\\b(follow|subscribe|join)\\b\\s*(ig|instagram|yt|youtube|tiktok|tele)?',

            'wa\\.me\\/\\d+',

            '(bit\\.ly|tinyurl|s\\.id|linktr\\.ee)',

            'https?:\\/\\/(?:www\\.)?(?:t\\.me|instagram\\.com|youtube\\.com|tiktok\\.com)\\/[^\\s]+'
        ].join('|'),
        'i'
    ),

    antiNSFW: new RegExp(
        [
            '(porn|porno|bokep|jav|hentai|xxx|nsfw|18\\+)',
            '(sex|seks|ngentot|ngewe|coli|masturbasi|handjob|blowjob|threesome)',
            '(memek|kontol|ngaceng|titit|pentil|susu|payudara|tetek|vagina|penis)',
            '(video\\s*panas|video\\s*dewasa|film\\s*dewasa)',
            '(open\\s*vc|vc\\s*panas|open\\s*bo|booking\\s*out|open\\s*ml)',
            '(escort|prostitute|camgirl|onlyfans|fansly)',
            '(bugil|telanjang|nude|nudity)',
            '(https?:\\/\\/|www\\.)',
            '(xvideos|xnxx|pornhub|redtube|youporn|spankbang|hclips)'
        ].join('|'),
        'i'
    )
};

const toxicMap = new Map();
const spamMap = new Map();
const SPAM_INTERVAL = 10_000;
const WARN_AT = 5;
const SPAM_LIMIT = 8;

const deleteMessage = async (Yudzxml, chat, key) => {
    try {
        await Yudzxml.sendMessage(chat, { delete: key });
    } catch (err) {}
};

const kickUser = async (Yudzxml, chat, sender) => {
    try {
        await Yudzxml.groupParticipantsUpdate(chat, [sender], 'remove');
    } catch (err) {}
};

const sendWarning = async (m, chat, text, mentions = []) => {
    try {
        await m.reply(text, chat, { mentionedJid: mentions });
    } catch (err) {}
};

module.exports = async (
    Yudzxml,
    m,
    groupSettings,
    body,
    isBotAdmins,
    isAdmins,
    pushname,
    jammenit,
    isImage,
    isDocument,
    isVideo,
    isSticker,
    isAudio,
    isContact,
    isPolling,
    isTagsw,
    isSpecialUser,
    botNumber
) => {
    try {
        const { singlemess } = config;
        const db = groupSettings[m.chat] || {};
        const sender = m.sender;
        const chatId = m.chat;
        const isTarget = !isAdmins && !m.fromMe;

        const handleAntiLink = async () => {
            if (!isTarget || !isBotAdmins) return;

            const isAllLink = REGEX.allLink.test(body);
            const isWaLink = REGEX.waLink.test(body);
            const isTiktokLink = REGEX.tiktokLink.test(body);

            if (db.antilink && isAllLink) {
                await sendWarning(m, chatId, singlemess.antilinkv1_detek, [sender]);
                return deleteMessage(Yudzxml, chatId, m.key);
            }

            if (db.antilinkv2 && isAllLink) {
                await deleteMessage(Yudzxml, chatId, m.key);
                await sendWarning(m, chatId, singlemess.antilinkv2_detek, [sender]);
                return kickUser(Yudzxml, chatId, sender);
            }

            if (db.antilinkwa && isWaLink) {
                await sendWarning(m, chatId, singlemess.antilinkwa_detek, [sender]);
                return deleteMessage(Yudzxml, chatId, m.key);
            }

            if (db.antilinkwav2 && isWaLink) {
                await deleteMessage(Yudzxml, chatId, m.key);
                await sendWarning(m, chatId, singlemess.antilinkwa_detek, [sender]);
                return kickUser(Yudzxml, chatId, sender);
            }

            if (db.antilinktt && isTiktokLink) {
                await sendWarning(m, chatId, singlemess.antilinktiktok_detek, [sender]);
                return deleteMessage(Yudzxml, chatId, m.key);
            }

            if (db.antilinkttv2 && isTiktokLink) {
                await deleteMessage(Yudzxml, chatId, m.key);
                await sendWarning(m, chatId, singlemess.antilinktiktok_detek, [sender]);
                return kickUser(Yudzxml, chatId, sender);
            }

            if (db.antibot && m.isBaileys) {
                await deleteMessage(Yudzxml, chatId, m.key);
                await sendWarning(m, chatId, singlemess.antibot_detek, [sender]);
                return kickUser(Yudzxml, chatId, sender);
            }
        };

        const handleAntiToxic = async () => {
            if (!db.antitoxic || !isTarget || !isBotAdmins) return;
            const textToxic = loadTextToxic(chatId);
            if (!textToxic.test(body)) return;

            const userKey = `${chatId}_${sender}`;
            let userData = toxicMap.get(userKey) || { count: 0, warned: false };

            userData.count++;
            await deleteMessage(Yudzxml, chatId, m.key);

            if (userData.count >= 3 && !userData.warned) {
                userData.warned = true;
                await sendWarning(m, chatId, singlemess.antibadword, [sender]);
            } else if (userData.warned) {
                await kickUser(Yudzxml, chatId, sender);
                return toxicMap.delete(userKey);
            }

            toxicMap.set(userKey, userData);
        };

        const handleAntiSpam = async () => {
            if (!db.antispamchat || !isTarget || !isBotAdmins) return;

            const now = Date.now();
            const key = `${chatId}-${sender}`;
            let data = spamMap.get(key);

            if (!data || now - data.lastTime > SPAM_INTERVAL) {
                data = { count: 1, lastTime: now, warned: false, kicked: false };
            } else {
                data.count++;
                data.lastTime = now;
            }

            spamMap.set(key, data);

            if (data.count === WARN_AT) {
                return sendWarning(m, chatId, singlemess.antispam1, [sender]);
            }

            if (data.count === SPAM_LIMIT && !data.warned) {
                data.warned = true;
                return sendWarning(m, chatId, singlemess.antispam2, [sender]);
            }

            if (data.count > SPAM_LIMIT && !data.kicked) {
                data.kicked = true;
                await kickUser(Yudzxml, chatId, sender);
                await sendWarning(m, chatId, `⛔ @${sender.split('@')[0]} ᴅɪᴋᴇʟᴜᴀʀᴋᴀɴ ᴋᴀʀᴇɴᴀ *ꜱᴘᴀᴍ ᴄʜᴀᴛ*.`, [sender]);
                spamMap.delete(key);
            }
        };

        const MIN_PROMO_LENGTH = 120;
        const isPromosi = (text = '') => typeof text === 'string' && REGEX.antiPromosi.test(text);
        const isPromosiPanjang = (text = '') => isPromosi(text) && text.length >= MIN_PROMO_LENGTH;
        const handleAntiPromosi = async () => {
            if (!isTarget || !isBotAdmins) return;
            if (!body || typeof body !== 'string') return;

            const pathDB = path.resolve(__dirname, '../../Storage/antipromo.json');
            const userKey = `${chatId}_${sender}`;
            const today = new Date().toLocaleDateString('en-CA');

            const detected = db.antipromosi
                ? isPromosiPanjang(body)
                : db.antipromosiv2 || db.antipromosiv3
                  ? isPromosiPanjang(body)
                  : false;

            if (!detected) return;

            try {
                const { loadDB, saveDB } = require('../../database/wrappers/storage');
                let antipromoDB = loadDB(pathDB, {});
                if (!antipromoDB || typeof antipromoDB !== 'object' || Array.isArray(antipromoDB)) antipromoDB = {};

                if (!antipromoDB[userKey] || antipromoDB[userKey].date !== today) {
                    antipromoDB[userKey] = { count: 0, date: today };
                }

                antipromoDB[userKey].count++;
                saveDB(pathDB, antipromoDB);

                if (db.antipromosi && antipromoDB[userKey].count > 3) {
                    await deleteMessage(Yudzxml, chatId, m.key);
                    return sendWarning(m, chatId, singlemess.antipromosi_limit, [sender]);
                }

                if (db.antipromosiv2) {
                    await deleteMessage(Yudzxml, chatId, m.key);
                    return sendWarning(m, chatId, singlemess.antipromosiv2_detek, [sender]);
                }

                if (db.antipromosiv3) {
                    await sendWarning(m, chatId, singlemess.antipromosiv3_detek, [sender]);
                    await deleteMessage(Yudzxml, chatId, m.key);
                    return kickUser(Yudzxml, chatId, sender);
                }
            } catch (err) {
                logger.error('[ANTIPROMO] ' + (err?.message || err));
            }
        };

        const handleAntiNSFW = async () => {
            if (!isTarget || !isBotAdmins) return;
            if (!REGEX.antiNSFW.test(body)) return;

            if (db.antinsfw) {
                await sendWarning(m, chatId, singlemess.antinsfwv1_detek, [sender]);
                await deleteMessage(Yudzxml, chatId, m.key);
            }

            if (db.antinsfwv2) {
                await sendWarning(m, chatId, singlemess.antinsfwv1_detek, [sender]);
                await deleteMessage(Yudzxml, chatId, m.key);
                return kickUser(Yudzxml, chatId, sender);
            }
        };

        const handleMediaFilters = async () => {
            if (!isTarget || !isBotAdmins) return;

            const filters = [
                { setting: 'antidocument', check: isDocument, mess: singlemess.antidocument },
                { setting: 'antigambar', check: isImage, mess: singlemess.antigambar },
                { setting: 'antivideo', check: isVideo, mess: singlemess.antivideo },
                { setting: 'antisticker', check: isSticker, mess: singlemess.antisticker },
                { setting: 'antiaudio', check: isAudio, mess: singlemess.antiaudio },
                { setting: 'antikontak', check: isContact, mess: singlemess.antikontak },
                { setting: 'antipolling', check: isPolling, mess: singlemess.antipolling }
            ];

            for (const f of filters) {
                if (db[f.setting] && f.check) {
                    await sendWarning(m, chatId, f.mess, [sender]);
                    await deleteMessage(Yudzxml, chatId, m.key);
                    break;
                }
            }

            if (!isTagsw) return;

            if (db.antisw) {
                await sendWarning(m, chatId, singlemess.antitagsw, [sender]);
                return deleteMessage(Yudzxml, chatId, m.key);
            }

            if (db.antiswv2) {
                await deleteMessage(Yudzxml, chatId, m.key);
                await sendWarning(m, chatId, singlemess.antitagswv2, [sender]);
                return kickUser(Yudzxml, chatId, sender);
            }
        };

        const handleAutoDownload = async () => {
            if (
                db.autodownload &&
                typeof body === 'string' &&
                (body.startsWith('http://') || body.startsWith('https://'))
            ) {
                return handleDownload(Yudzxml, m, body, isSpecialUser);
            }
        };

        const handleAutoAi = async () => {
            if (db.autoai) {
                return autoAi(m, botNumber, body, Yudzxml);
            }
        };

        await handleAntiLink();
        await handleAntiToxic();
        await handleAntiSpam();
        await handleAntiPromosi();
        await handleAntiNSFW();
        await handleMediaFilters();
        await handleAutoDownload();
        await handleAutoAi();
    } catch (err) {
        logger.error(
            `[GROUP HANDLER] Gagal memproses pesan dari ${pushname || 'unknown'}: ${err?.message || 'unknown error'}`
        );
    }
};

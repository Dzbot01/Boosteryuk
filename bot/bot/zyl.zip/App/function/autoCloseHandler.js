const moment = require('moment-timezone');
const path = require('path');

const { loadDB: loadDBFile, saveDB: saveDBFile } = require('../../database/wrappers/storage');

const DB_PATH = path.join(__dirname, '../../Storage/groupSchedule.json');
const TIME_REGEX = /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/;
const TIMEZONE = 'Asia/Jakarta';

const loadDB = () => {
    try {
        const data = loadDBFile(DB_PATH, {});
        return data && typeof data === 'object' && !Array.isArray(data) ? data : {};
    } catch (e) {
        console.error('Load DB Error:', e.message);
        return {};
    }
};

const saveDB = (data) => {
    try {
        saveDBFile(DB_PATH, data);
    } catch (e) {
        console.error('Save DB Error:', e.message);
    }
};

const getMinutesFromTime = (timeString) => {
    const [hour, minute] = timeString.split(':').map(Number);
    return hour * 60 + minute;
};

const validateTimeInput = (timeString) => {
    if (!TIME_REGEX.test(timeString)) {
        throw new Error('Format waktu salah (HH:mm)');
    }

    const now = moment().tz(TIMEZONE);
    const [hour, minute] = timeString.split(':').map(Number);
    let inputTime = now.clone().hour(hour).minute(minute).second(0);

    if (inputTime.isSameOrBefore(now)) {
        inputTime.add(1, 'day');
    }

    return inputTime;
};

const addSchedule = (groupId, type, time, text = null) => {
    if (!['open', 'close'].includes(type)) {
        throw new Error('Tipe harus open / close');
    }

    const inputMoment = validateTimeInput(time);
    const db = loadDB();

    if (!db[groupId]) db[groupId] = { open: null, close: null };

    db[groupId][type] = {
        minutes: getMinutesFromTime(time),
        timeString: time,
        text,
        lastExecutedDate: null,
        createdAt: Date.now()
    };

    saveDB(db);

    return {
        success: true,
        message: `Jadwal ${type.toUpperCase()} disimpan (${time} WIB)`
    };
};

const updateSchedule = (groupId, type, payload) => {
    const db = loadDB();
    if (!db[groupId] || !db[groupId][type]) throw new Error('Jadwal tidak ditemukan');

    if (payload.time) {
        validateTimeInput(payload.time);
        db[groupId][type].minutes = getMinutesFromTime(payload.time);
        db[groupId][type].timeString = payload.time;
        db[groupId][type].lastExecutedDate = null;
    }

    if (payload.text !== undefined) db[groupId][type].text = payload.text;
    db[groupId][type].updatedAt = Date.now();
    saveDB(db);
    return { success: true };
};

const deleteSchedule = (groupId, type = 'all') => {
    const db = loadDB();
    if (!db[groupId]) throw new Error('Data tidak ada');

    if (type === 'all') delete db[groupId];
    else if (db[groupId][type]) db[groupId][type] = null;

    saveDB(db);
    return { success: true };
};

const getTextSettings = (groupId) => {
    const db = loadDB();
    return {
        textOpen: db[groupId]?.open?.text ?? null,
        textClose: db[groupId]?.close?.text ?? null
    };
};

const setTextSettings = (groupId, type, text) => {
    const db = loadDB();
    if (!db[groupId]) db[groupId] = { open: null, close: null };
    if (!db[groupId][type]) db[groupId][type] = { minutes: null, timeString: null, text: null, lastExecutedDate: null };
    db[groupId][type].text = text;
    saveDB(db);
    return { success: true };
};

const checkGroupSchedule = async (Yudzxml, groupId) => {
    const db = loadDB();
    const group = db[groupId];
    if (!group) return;

    const nowMoment = moment().tz(TIMEZONE);
    const currentDateStr = nowMoment.format('YYYY-MM-DD');
    const currentTotalMinutes = nowMoment.hour() * 60 + nowMoment.minute();
    let changed = false;

    const execIfDue = async (type, action) => {
        const data = group[type];
        if (!data || data.minutes === null || !data.timeString) return;

        let targetMinutes = data.minutes;
        const isTimePassed = currentTotalMinutes >= targetMinutes;
        const alreadyExecutedToday = data.lastExecutedDate === currentDateStr;

        if (isTimePassed && !alreadyExecutedToday) {
            try {
                console.log(`[Executing ${type.toUpperCase()}] Group: ${groupId} @ ${nowMoment.format('HH:mm:ss')}`);
                await action();
                db[groupId][type] = { text: data.text };
                changed = true;
                console.log(`[Schedule Executed & Time Cleared] Group: ${groupId}, Type: ${type}`);
            } catch (e) {
                console.error(`[Schedule Error ${type}]:`, e.message);
            }
        }
    };

    await execIfDue('open', async () => {
        await Yudzxml.groupSettingUpdate(groupId, 'not_announcement');
        if (group.open.text) await Yudzxml.sendMessage(groupId, { text: group.open.text });
    });

    await execIfDue('close', async () => {
        await Yudzxml.groupSettingUpdate(groupId, 'announcement');
        if (group.close.text) await Yudzxml.sendMessage(groupId, { text: group.close.text });
    });

    if (changed) saveDB(db);
};

module.exports = {
    addSchedule,
    updateSchedule,
    deleteSchedule,
    checkGroupSchedule,
    getTextSettings,
    setTextSettings
};

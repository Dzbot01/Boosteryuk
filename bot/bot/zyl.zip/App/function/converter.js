const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

function getSecond(file) {
    return new Promise((resolve, reject) => {
        const p = spawn('ffprobe', [
            '-v',
            'error',
            '-show_entries',
            'format=duration',
            '-of',
            'default=noprint_wrappers=1:nokey=1',
            file
        ]);

        let out = '';
        p.stdout.on('data', (d) => (out += d));
        p.on('close', () => resolve(Math.floor(Number(out))));
        p.on('error', reject);
    });
}

function ffmpeg(buffer, args = [], ext = '', ext2 = '') {
    return new Promise(async (resolve, reject) => {
        try {
            const tmp = path.join(__dirname, '../../tmp', `${Date.now()}.${ext}`);
            const out = tmp + '.' + ext2;

            await fs.promises.writeFile(tmp, buffer);

            spawn('ffmpeg', ['-y', '-i', tmp, ...args, out])
                .on('error', reject)
                .on('close', async (code) => {
                    try {
                        await fs.promises.unlink(tmp);
                        if (code !== 0) return reject(code);

                        const seconds = await getSecond(out);

                        resolve({
                            data: await fs.promises.readFile(out),
                            filename: out,
                            seconds,
                            delete() {
                                return fs.promises.unlink(out);
                            }
                        });
                    } catch (e) {
                        reject(e);
                    }
                });
        } catch (e) {
            reject(e);
        }
    });
}

function toPTT(buffer) {
    return ffmpeg(buffer, ['-vn', '-c:a', 'libopus', '-b:a', '128k', '-vbr', 'on'], 'bin', 'opus');
}

function toAudio(buffer, ext = 'mp3') {
    return ffmpeg(
        buffer,
        ['-vn', '-c:a', 'libopus', '-b:a', '128k', '-vbr', 'on', '-compression_level', '10'],
        ext,
        'opus'
    );
}

function toVideo(buffer, ext) {
    return ffmpeg(
        buffer,
        ['-c:v', 'libx264', '-c:a', 'aac', '-ab', '128k', '-ar', '44100', '-crf', '32', '-preset', 'slow'],
        ext,
        'mp4'
    );
}

module.exports = {
    toAudio,
    toPTT,
    toVideo,
    ffmpeg
};

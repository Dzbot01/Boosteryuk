/**
 * order/creators.js — Pembuatan order baru (jadibot / sewabot / premium).
 * Semua validasi paket & pembuatan payload order ada di sini.
 * Dipisah dari orderManager.js; fungsi menerima (manager, opts).
 */
const crypto = require('crypto');
const { STATUS } = require('./constants');
const { saveOrder, genOrderId, findPackage, normalizeGroupLink, getConfig } = require('./store');
const { createPaymentFor } = require('./payment');
const logger = require('../logger');

/**
 * Config per order: order milik instance jadibot memakai config instance
 * (paket sewabot/premium per-instance yang di-set owner bot itu sendiri),
 * order bot utama memakai config global.
 */
function resolveOrderConfig(instanceJid) {
    const globalCfg = getConfig();
    if (!instanceJid) return globalCfg;
    try {
        const jadibotManager = require('../../../src/core/jadibot');
        if (jadibotManager.get(instanceJid)) {
            return jadibotManager.resolveConfig(instanceJid);
        }
    } catch (_) {}
    return globalCfg;
}

async function createJadibotOrder(manager, {
    number,
    packageName,
    buyerJid = null,
    source = 'api',
    gateway = null,
    method = null,
    customer = null
}) {
    const cfg = getConfig();
    if (cfg.jadibot?.enabled === false) {
        throw new Error('Fitur jadibot sedang nonaktif (config.jadibot.enabled = false).');
    }

    const cleanNumber = String(number || '').replace(/[^0-9]/g, '');
    if (!/^628\d{7,15}$/.test(cleanNumber)) {
        throw new Error('Nomor WhatsApp tidak valid. Gunakan format 628xxxxxxxxxx.');
    }

    const packages = cfg.jadibot?.packages || [];
    const pkg = findPackage(packages, packageName);
    if (!pkg) {
        throw new Error(`Paket tidak ditemukan. Paket tersedia: ${packages.map((p) => p.name).join(', ')}.`);
    }

    const jadibotManager = require('../../../src/core/jadibot');

    const pendingSame = manager.listOrders({ type: 'jadibot', status: STATUS.PENDING, limit: 300 }).find(
        (o) => o.number === cleanNumber
    );

    if (pendingSame) {
        throw new Error(
            `Kamu masih punya order jadibot yang belum dibayar (${pendingSame.id}). ` +
                `Selesaikan pembayaran, atau batalkan dengan command .orderstatus.`
        );
    }

    const orderToken = crypto.randomBytes(16).toString('hex');

    const orderId = genOrderId('JBOT');
    const amount = Number(pkg.price);

    const order = {
        id: orderId,
        type: 'jadibot',
        source,
        number: cleanNumber,
        buyerJid,
        package: pkg.name,
        days: pkg.days,
        amount,
        status: STATUS.PENDING,
        expiredAt: 0,
        createdAt: Date.now(),

        orderToken,

        pairingCode: null,
        pairingStartedAt: null,
        pairingConnectedAt: null,
        configToken: null,
        pairingAttempts: 0,
        pairingFailedAt: null,
        pairingFailureReason: null
    };

    const payment = await createPaymentFor(order, {
        method
    });
    Object.assign(order, payment);

    saveOrder(order);
    manager.startPolling(orderId);

    return order;
}

async function createSewabotOrder(manager, {
    groupLink,
    packageName,
    buyerJid = null,
    source = 'api',
    instanceJid = null,
    gateway = null,
    method = null,
    customer = null
}) {
    const cfg = resolveOrderConfig(instanceJid);
    if (cfg.sewabot?.enabled === false) {
        throw new Error('Fitur sewabot sedang nonaktif (config.sewabot.enabled = false).');
    }

    const link = normalizeGroupLink(groupLink);
    if (!link) {
        throw new Error('Link grup tidak valid. Gunakan format https://chat.whatsapp.com/xxxxxxxx.');
    }

    const packages = cfg.sewabot?.packages || [];
    const pkg = findPackage(packages, packageName);
    if (!pkg) {
        throw new Error(
            `Paket sewabot tidak ditemukan. Paket tersedia: ${packages.map((p) => p.name).join(', ')}.`
        );
    }

    const orderId = genOrderId('SEWA');
    const amount = Number(pkg.price);

    const order = {
        id: orderId,
        type: 'sewabot',
        source,
        groupLink: link.url,
        inviteCode: link.inviteCode,
        buyerJid,
        package: pkg.name,
        days: pkg.days,
        amount,
        status: STATUS.PENDING,
        expiredAt: 0,
        createdAt: Date.now(),
        instanceJid: instanceJid || null
    };

    const payment = await createPaymentFor(order, {
        method
    });
    Object.assign(order, payment);

    saveOrder(order);
    manager.startPolling(orderId);

    return order;
}

async function createPremiumOrder(manager, {
    number,
    packageName,
    buyerJid = null,
    source = 'api',
    instanceJid = null,
    gateway = null,
    method = null,
    customer = null
}) {
    const cfg = resolveOrderConfig(instanceJid);
    if (cfg.premium?.enabled === false) {
        throw new Error('Pembelian premium otomatis sedang nonaktif (config.premium.enabled = false).');
    }

    const cleanNumber = String(number || '').replace(/[^0-9]/g, '');
    if (!/^628\d{7,15}$/.test(cleanNumber)) {
        throw new Error('Nomor WhatsApp tidak valid. Gunakan format 628xxxxxxxxxx.');
    }

    const packages = cfg.premium?.packages || [];
    const pkg = findPackage(packages, packageName);
    if (!pkg) {
        throw new Error(
            `Paket premium tidak ditemukan. Paket tersedia: ${packages.map((p) => p.name).join(', ')}.`
        );
    }

    const orderId = genOrderId('PREM');
    const amount = Number(pkg.price);

    const order = {
        id: orderId,
        type: 'premium',
        source,
        number: cleanNumber,
        buyerJid: buyerJid || `${cleanNumber}@s.whatsapp.net`,
        package: pkg.name,
        days: pkg.days,
        amount,
        status: STATUS.PENDING,
        expiredAt: 0,
        createdAt: Date.now(),
        instanceJid: instanceJid || null
    };

    const payment = await createPaymentFor(order, {
        method
    });
    Object.assign(order, payment);

    saveOrder(order);
    manager.startPolling(orderId);

    return order;
}

module.exports = { createJadibotOrder, createSewabotOrder, createPremiumOrder };

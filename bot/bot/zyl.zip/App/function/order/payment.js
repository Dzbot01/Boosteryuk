/**
 * order/payment.js — Integrasi payment gateway (pakasir) untuk order.
 * Dipisah dari orderManager.js: client per-instance & pembuatan transaksi.
 */
const config = require('@Config');
const pakasir = require('../pakasirClient');
const logger = require('../logger');
const jadibotManagerLazy = () => require('../../../src/core/jadibot');

const clientForOrder = (order) => {
    // Payment HANYA lewat pakasir — dipakai command WhatsApp bot.
    // Website mengatur pembayaran sendiri dan memanggil REST API langsung.
    if (!order?.instanceJid) return pakasir;
    try {
        const jadibotManager = require('../../../src/core/jadibot');
        const entry = jadibotManager.get(order.instanceJid);
        const cred = entry?.credentials?.pakasir;
        if (cred && cred.key && cred.slug) {
            return pakasir.createPakasirClient(cred, entry.number);
        }
    } catch (_) {}
    return pakasir;
};

const pairingCodeTtlMs = () => Number(config.jadibot?.pairingCodeTtlMs) || 90000;

const createPaymentFor = async (order, { method } = {}) => {
    const client = clientForOrder({ ...order, gateway: 'pakasir' });
    if (order.instanceJid && client === pakasir) {
        throw new Error(
            'Kredensial pakasir bot jadibot tidak ditemukan. Pasang dulu lewat menu kredensial bot jadibot.'
        );
    }
    client.assertConfigured();
    const payment = await client.createTransaction(method, order.id, order.amount);
    // Kebijakan bot: QRIS SAJA (tanpa payment link / VA).
    // API v2: QRIS string ada di `qr_string`; "paymentNumber" = string yang
    // dirender jadi gambar QR untuk pembeli.
    const paymentNumber = payment.qr_string || payment.va_number || payment.payment_number || null;
    if (!paymentNumber) {
        throw new Error('QRIS tidak tersedia dari gateway — cek kembali konfigurasi Pakasir (metode qris).');
    }
    const expiredAtMs = payment.expired_at
        ? new Date(payment.expired_at).getTime()
        : Date.now() + 24 * 60 * 60 * 1000;

    return {
        gateway: 'pakasir',
        paymentMethod: 'qris',
        paymentNumber,
        fee: Number(payment.fee) || 0,
        totalPayment: Number(payment.total_payment) || order.amount,
        qrString: payment.qr_string || null,
        qrUrl: null,
        // v2 memakai txn_id sebagai kunci status/cancel — simpan di order.
        gatewayRef: payment.txn_id || order.id,
        txnId: payment.txn_id || null,
        expiredAt: Number.isFinite(expiredAtMs) ? expiredAtMs : Date.now() + 24 * 60 * 60 * 1000
    };
};

module.exports = { clientForOrder, pairingCodeTtlMs, createPaymentFor };

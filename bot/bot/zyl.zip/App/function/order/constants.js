/**
 * order/constants.js — Konstanta sistem order (status, interval polling, TTL).
 * Dipisah dari orderManager.js agar konstanta gampang dicari.
 */

const STATUS = {
    PENDING: 'pending',
    PAID: 'paid',
    PAIRING: 'pairing',
    COMPLETED: 'completed',
    PAIRING_FAILED: 'pairing_failed',
    FAILED: 'failed',
    CANCELLED: 'cancelled'
};

const POLL_INTERVAL = 5000;
const ORDER_TTL = 30 * 60 * 1000;
const MAX_SAVED_ORDERS = 1000;

module.exports = { STATUS, POLL_INTERVAL, ORDER_TTL, MAX_SAVED_ORDERS };

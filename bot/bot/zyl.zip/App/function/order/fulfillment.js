/**
 * order/fulfillment.js — Eksekusi order lunas: aktifkan jadibot / sewa / premium.
 * Dipisah dari orderManager.js; fungsi menerima (manager, order).
 */
const { STATUS } = require('./constants');
const { saveOrder, getConfig } = require('./store');
const logger = require('../logger');

async function _fulfillJadibot(manager, order) {
    const jadibotManager = require('../../../src/core/jadibot');

    const existingEntry = jadibotManager.getByNumber(order.number);

    if (existingEntry && (existingEntry.status === 'active' || jadibotManager.sockets.has(existingEntry.jid))) {
        existingEntry.package = order.package;
        jadibotManager.extendJadibot(existingEntry.jid, order.days);

        order.status = STATUS.COMPLETED;
        order.completedAt = Date.now();
        order.updatedAt = Date.now();
        order.jadibotJid = existingEntry.jid;
        saveOrder(order);

        logger.success(
            `[ORDER] Jadibot ${order.number} diperpanjang +${order.days} hari (${order.package}). Aktif hingga ${new Date(existingEntry.expired).toISOString()}`
        );

        return order;
    }

    const { entry, pairingCode } = await jadibotManager.createJadibot(order.number, {
        days: order.days,
        packageName: order.package,
        ownerJid: order.buyerJid || jadibotManager.toJid(order.number),
        activation: order.source === 'api' ? 'api' : 'whatsapp',
        orderId: order.id,
        orderToken: order.orderToken,
        source: order.source
    });

    order.status = STATUS.PAIRING;
    order.pairingCode = pairingCode;
    order.pairingStartedAt = Date.now();
    order.jadibotJid = entry.jid;
    order.updatedAt = Date.now();
    saveOrder(order);

    logger.success(
        `[ORDER] Jadibot ${order.number} pairing dimulai (${order.package}). Pairing code tersedia via API website.`
    );

    return order;
}

async function _fulfillSewabot(manager, order) {
    const { getConfig } = require('./store');
    const jadibotManager = require('../../../src/core/jadibot');

    const instanceJid = order.instanceJid || null;

    // Config instance (bonus premium & auto join per-instance), fallback global.
    let cfg;
    if (instanceJid && jadibotManager.get(instanceJid)) {
        try {
            cfg = jadibotManager.resolveConfig(instanceJid);
        } catch (_) {
            cfg = getConfig();
        }
    } else {
        cfg = getConfig();
    }

    const socket = instanceJid
        ? jadibotManager.sockets.get(instanceJid) || jadibotManager.mainSocket
        : jadibotManager.mainSocket;
    const sewaStore = instanceJid ? jadibotManager.getSewaStore(instanceJid) : require('../sewa');

    let groupId = order.targetGroupId || null;
    let groupName = order.groupLink;

    if (cfg.sewabot?.autoJoinGroup !== false && socket) {
        try {
            await socket.groupAcceptInvite(order.inviteCode);
            const res = await socket.query({
                tag: 'iq',
                attrs: { type: 'get', xmlns: 'w:g2', to: '@g.us' },
                content: [{ tag: 'invite', attrs: { code: order.inviteCode } }]
            });
            const attrs = res?.content?.[0]?.attrs;
            if (attrs?.id) {
                groupId = attrs.id.endsWith('@g.us') ? attrs.id : `${attrs.id}@g.us`;
                groupName = attrs.subject || groupName;
            }
        } catch (err) {
            logger.warning(`[ORDER] Gagal join grup ${order.inviteCode}: ${err.message}`);
        }
    }

    const target = groupId || `pending-${order.id}`;
    sewaStore.addSewa(target, groupName, order.days);

    order.status = STATUS.COMPLETED;
    order.targetGroupId = target;
    order.completedAt = Date.now();
    saveOrder(order);

    const minDays = Number(cfg.sewabot?.bonusPremiumMinDays) || 0;
    let bonusPremium = false;
    if (minDays > 0 && order.buyerJid && order.days >= minDays) {
        try {
            let addPremiumFn;
            if (instanceJid) {
                const premiumStore = jadibotManager.getPremiumStore(instanceJid);
                addPremiumFn = premiumStore.addPremiumUser;
            } else {
                addPremiumFn = require('../../../database/wrappers/premium').addPremiumUser;
            }
            const expired = addPremiumFn(order.buyerJid, `${order.days}d`);
            bonusPremium = true;
            logger.success(
                `[ORDER] Bonus premium untuk ${order.buyerJid} sampai ${new Date(expired).toLocaleDateString('id-ID')}`
            );
        } catch (err) {
            logger.error(`[ORDER] Gagal memberi bonus premium: ${err.message}`);
        }
    }

    manager.emit('completed', { order });
    manager.emit(`completed:${order.id}`, { order });

    logger.success(`[ORDER] Sewabot ${groupName} aktif (${order.package}).`);

    if (order.source === 'whatsapp' && order.buyerJid && jadibotManager.mainSocket) {
        const text =
            `✅ *PEMBAYARAN BERHASIL*\n\n` +
            `🆔 Order : ${order.id}\n` +
            `📦 Paket : ${order.package} (${order.days} hari)\n` +
            `🔗 Grup : ${groupName}\n\n` +
            `Bot akan segera join ke grup Anda.\n` +
            `⏳ Masa aktif: ${order.days} hari sejak pembayaran.` +
            (bonusPremium ? `\n🎁 Bonus: *PREMIUM USER* aktif ${order.days} hari!` : '');
        await jadibotManager.notifyOwner(order.buyerJid, text).catch(() => {});
    }

    return order;
}

async function _fulfillPremium(manager, order) {
    const jadibotManager = require('../../../src/core/jadibot');

    let addPremiumFn;
    if (order.instanceJid) {
        const premiumStore = jadibotManager.getPremiumStore(order.instanceJid);
        addPremiumFn = premiumStore.addPremiumUser;
    } else {
        addPremiumFn = require('../../../database/wrappers/premium').addPremiumUser;
    }

    const jid = `${order.number}@s.whatsapp.net`;
    const expired = addPremiumFn(jid, `${order.days}d`);

    order.status = STATUS.COMPLETED;
    order.premiumJid = jid;
    order.premiumExpired = expired;
    order.completedAt = Date.now();
    saveOrder(order);

    manager.emit('completed', { order });
    manager.emit(`completed:${order.id}`, { order });

    logger.success(
        `[ORDER] Premium ${order.number} aktif (${order.package}) sampai ${new Date(expired).toLocaleDateString('id-ID')}`
    );

    if (order.source === 'whatsapp' && jadibotManager.mainSocket) {
        const text =
            `✅ *PEMBAYARAN BERHASIL*\n\n` +
            `🆔 Order : ${order.id}\n` +
            `⭐ Paket : ${order.package} (${order.days} hari)\n` +
            `👤 Nomor : +${order.number}\n\n` +
            `🎉 *PREMIUM AKTIF!*\n` +
            `⏳ Aktif hingga: ${new Date(expired).toLocaleString('id-ID')}\n\n` +
            `_Nikmati fitur premium tanpa limit!_`;
        await jadibotManager.notifyOwner(order.buyerJid || jid, text).catch(() => {});
    }

    return order;
}

module.exports = {
    fulfillJadibot: _fulfillJadibot,
    fulfillSewabot: _fulfillSewabot,
    fulfillPremium: _fulfillPremium
};

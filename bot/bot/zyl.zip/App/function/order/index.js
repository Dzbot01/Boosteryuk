/**
 * order/index.js — Inti OrderManager: polling pembayaran, pembatalan & status order.
 *
 * Sebelumnya semua ada di satu file orderManager.js (±850 baris). Sekarang:
 *   constants.js  — STATUS, interval polling, TTL
 *   store.js      — I/O Storage/orders.json + helper data
 *   payment.js    — client pakasir per-instance & createTransaction
 *   creators.js   — pembuatan order jadibot/sewabot/premium
 *   fulfillment.js— eksekusi order lunas
 *   pairing.js    — siklus pairing order jadibot
 * File lama orderManager.js jadi forwarder ke folder ini.
 */
const { EventEmitter } = require('events');
const logger = require('../logger');
const { STATUS, POLL_INTERVAL, ORDER_TTL } = require('./constants');
const { readDB, saveOrder, maskNumber } = require('./store');
const { pairingCodeTtlMs, clientForOrder } = require('./payment');
const creators = require('./creators');
const fulfillment = require('./fulfillment');
const pairing = require('./pairing');

class OrderManager extends EventEmitter {
    constructor() {
        super();
        this.pollers = new Map();

        this.setMaxListeners(100);
    }
    getOrder(orderId) {
        return readDB().orders.find((o) => o.id === orderId) || null;
    }
    listOrders({ status = null, type = null, limit = 50 } = {}) {
        let orders = readDB().orders;
        if (status) orders = orders.filter((o) => o.status === status);
        if (type) orders = orders.filter((o) => o.type === type);
        return orders.slice(-limit).reverse();
    }
    getPublicOrder(order) {
        if (!order) return null;
        const data = {
            orderId: order.id,
            type: order.type,
            source: order.source,
            package: order.package,
            days: order.days,
            amount: order.amount,
            status: order.status,
            createdAt: order.createdAt,
            expiredAt: order.expiredAt
        };

        if (order.status === STATUS.PENDING) {
            data.payment = {
                gateway: order.gateway || 'pakasir',
                method: 'qris',

                paymentNumber: order.paymentNumber || null,
                fee: order.fee ?? null,
                totalPayment: order.totalPayment ?? order.amount,
                qrString: order.qrString || null,
                qrUrl: order.qrUrl || null
            };
        }

        if (order.type === 'jadibot') data.number = maskNumber(order.number);
        if (order.type === 'premium') data.number = maskNumber(order.number);
        if (order.pairingCode) data.pairingCode = order.pairingCode;
        if (order.failReason) data.failReason = order.failReason;
        if (order.fulfillError) data.fulfillError = order.fulfillError;
        if (order.completedAt) data.completedAt = order.completedAt;
        if (order.paidAt) data.paidAt = order.paidAt;
        if (order.premiumExpired) data.premiumExpired = order.premiumExpired;

        if (order.type === 'jadibot') {
            data.pairing = {
                status: order.status,
                attempts: order.pairingAttempts || 0,
                startedAt: order.pairingStartedAt || null,
                codeExpiresAt: order.pairingStartedAt ? order.pairingStartedAt + pairingCodeTtlMs() : null,
                connectedAt: order.pairingConnectedAt || null,
                failedAt: order.pairingFailedAt || null,
                failureReason: order.pairingFailureReason || null,
                botConnected: order.status === STATUS.COMPLETED,

                configToken: order.status === STATUS.COMPLETED ? order.configToken : null,

                orderTokenPreview: order.orderToken ? `${order.orderToken.slice(0, 8)}...` : null,
                canRepair: [STATUS.PAIRING, STATUS.PAIRING_FAILED, STATUS.COMPLETED].includes(order.status),
                repairEndpoint: 'POST /api/jadibot/pairing',
                statusEndpoint: 'GET /api/jadibot/status?number=' + order.number
            };

            if (order.status === STATUS.PAIRING || order.status === STATUS.PAIRING_FAILED) {
                data.pairingCode = order.pairingCode;
            }
        }

        return data;
    }
    async cancelOrder(orderId, { byJid = null, allowAny = false } = {}) {
        const order = this.getOrder(orderId);
        if (!order) throw new Error('Order tidak ditemukan.');

        if (!allowAny && byJid && order.buyerJid && order.buyerJid !== byJid) {
            throw new Error('Order ini bukan milikmu.');
        }

        if (order.status !== STATUS.PENDING) {
            throw new Error(`Order tidak bisa dibatalkan (status: ${order.status}).`);
        }

        this.stopPolling(orderId);

        try {
            await clientForOrder(order).cancelTransaction(orderId, Number(order.amount), order);
        } catch (err) {
            logger.warning(`[ORDER] Gagal cancel transaksi ${orderId}: ${err.message}`);
        }

        order.status = STATUS.CANCELLED;
        order.updatedAt = Date.now();
        saveOrder(order);

        this.emit('cancelled', { order });
        this.emit(`cancelled:${order.id}`, { order });
        return order;
    }
    startPolling(orderId) {
        if (this.pollers.has(orderId)) return;

        const order = this.getOrder(orderId);
        if (!order) return;

        const timer = setInterval(async () => {
            try {
                const current = this.getOrder(orderId);
                if (!current || current.status !== STATUS.PENDING) {
                    this.stopPolling(orderId);
                    return;
                }

                if (Date.now() > current.expiredAt || Date.now() - current.createdAt > ORDER_TTL) {
                    this.stopPolling(orderId);
                    await this._markFailed(current, 'Waktu pembayaran habis.');
                    try {
                        await clientForOrder(current).cancelTransaction(orderId, Number(current.amount), current);
                    } catch (_) {}
                    return;
                }

                const pollClient = clientForOrder(current);
                const transaction = await pollClient.syncTransaction(orderId, Number(current.amount), current);
                if (!transaction) return;

                if (transaction.status === pollClient.STATUS.COMPLETED) {
                    this.stopPolling(orderId);
                    await this._markPaid(current, 'polling');
                } else if (
                    transaction.status === pollClient.STATUS.CANCELLED ||
                    transaction.status === pollClient.STATUS.EXPIRED
                ) {
                    this.stopPolling(orderId);
                    await this._markFailed(
                        current,
                        transaction.status === pollClient.STATUS.EXPIRED
                            ? 'Waktu pembayaran habis.'
                            : 'Transaksi dibatalkan.'
                    );
                }
            } catch (err) {
                logger.error(`[ORDER] Polling error ${orderId}: ${err.message}`);
            }
        }, POLL_INTERVAL);

        this.pollers.set(orderId, timer);
    }
    stopPolling(orderId) {
        const timer = this.pollers.get(orderId);
        if (timer) {
            clearInterval(timer);
            this.pollers.delete(orderId);
        }
    }
    stopAllPolling() {
        for (const orderId of [...this.pollers.keys()]) {
            this.stopPolling(orderId);
        }
    }
    resumePendingOrders() {
        const pending = readDB().orders.filter((o) => o.status === STATUS.PENDING);
        let resumed = 0;
        for (const order of pending) {
            this.startPolling(order.id);
            resumed++;
        }
        if (resumed) logger.info(`[ORDER] ${resumed} order pending di-resume setelah start.`);
        return resumed;
    }
    async _markPaid(order, via = 'polling') {
        if (order.status !== STATUS.PENDING) return this.getOrder(order.id);

        order.status = STATUS.PAID;
        order.paidAt = Date.now();
        order.paidVia = via;
        saveOrder(order);

        this.emit('paid', { order });
        this.emit(`paid:${order.id}`, { order });

        await this.fulfill(this.getOrder(order.id));
        return this.getOrder(order.id);
    }
    async _markFailed(order, reason) {
        if (order.status !== STATUS.PENDING) return this.getOrder(order.id);

        order.status = STATUS.FAILED;
        order.failReason = reason;
        order.updatedAt = Date.now();
        saveOrder(order);

        this.emit('failed', { order, reason });
        this.emit(`failed:${order.id}`, { order, reason });
        return this.getOrder(order.id);
    }
    async fulfill(order) {
        try {
            if (order.type === 'jadibot') {
                return await this._fulfillJadibot(order);
            }

            if (order.type === 'sewabot') {
                return await this._fulfillSewabot(order);
            }

            if (order.type === 'premium') {
                return await this._fulfillPremium(order);
            }

            throw new Error(`Tipe order tidak dikenal: ${order.type}`);
        } catch (err) {
            logger.error(`[ORDER] Fulfill gagal ${order.id}: ${err.message}`);
            order.status = STATUS.PAID;
            order.fulfillError = err.message;
            saveOrder(order);
        }

        return order;
    }
    retryFulfill(orderId) {
        const order = this.getOrder(orderId);
        if (!order) throw new Error('Order tidak ditemukan.');
        if (order.status !== STATUS.PAID) {
            throw new Error('Hanya order berstatus PAID yang bisa diproses ulang.');
        }
        return this.fulfill(order);
    }
    /* ── Delegasi ke modul terpisah (creators / fulfillment / pairing) ────── */

    async createJadibotOrder(opts) {
        return creators.createJadibotOrder(this, opts);
    }

    async createSewabotOrder(opts) {
        return creators.createSewabotOrder(this, opts);
    }

    async createPremiumOrder(opts) {
        return creators.createPremiumOrder(this, opts);
    }

    async _fulfillJadibot(order) {
        return fulfillment.fulfillJadibot(this, order);
    }

    async _fulfillSewabot(order) {
        return fulfillment.fulfillSewabot(this, order);
    }

    async _fulfillPremium(order) {
        return fulfillment.fulfillPremium(this, order);
    }

    updateOrderPairing(orderId, opts = {}) {
        return pairing.updateOrderPairing(this, orderId, opts);
    }

    async markPairingSuccess(orderId, configToken, botConnectedAt) {
        return pairing.markPairingSuccess(this, orderId, configToken, botConnectedAt);
    }

    async markPairingFailed(orderId, reason) {
        return pairing.markPairingFailed(this, orderId, reason);
    }

    async repairOrder(orderId, orderToken) {
        return pairing.repairOrder(this, orderId, orderToken);
    }

    verifyOrderToken(orderId, orderToken) {
        return pairing.verifyOrderToken(this, orderId, orderToken);
    }
}

module.exports = new OrderManager();
module.exports.STATUS = STATUS;

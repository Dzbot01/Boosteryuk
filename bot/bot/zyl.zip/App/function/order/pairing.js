/**
 * order/pairing.js — Siklus hidup pairing order jadibot (sukses/gagal/repair/token).
 * Dipisah dari orderManager.js; fungsi menerima (manager, ...).
 */
const crypto = require('crypto');
const { STATUS } = require('./constants');
const { saveOrder } = require('./store');
const logger = require('../logger');

function updateOrderPairing(manager, orderId, { pairingCode = null } = {}) {
    const order = manager.getOrder(orderId);
    if (!order || order.type !== 'jadibot') return null;
    if (!pairingCode || order.pairingCode === pairingCode) return order;

    order.pairingCode = pairingCode;
    order.pairingStartedAt = Date.now();
    order.updatedAt = Date.now();
    if (order.status === STATUS.PAIRING_FAILED) order.status = STATUS.PAIRING;
    saveOrder(order);

    return order;
}

async function markPairingSuccess(manager, orderId, configToken, botConnectedAt) {
    const order = manager.getOrder(orderId);
    if (!order) return null;
    if (order.status === STATUS.COMPLETED) return order;

    order.status = STATUS.COMPLETED;
    order.configToken = configToken;
    order.pairingConnectedAt = botConnectedAt || Date.now();
    order.completedAt = Date.now();
    order.updatedAt = Date.now();
    saveOrder(order);

    manager.emit('completed', { order });
    manager.emit(`completed:${order.id}`, { order });

    logger.success(`[ORDER] Jadibot ${order.number} PAIRING SUCCESS.`);

    return order;
}

async function markPairingFailed(manager, orderId, reason) {
    const order = manager.getOrder(orderId);
    if (!order) return null;
    if (order.status === STATUS.PAIRING_FAILED) return order;

    order.status = STATUS.PAIRING_FAILED;
    order.pairingFailedAt = Date.now();
    order.pairingFailureReason = reason;
    order.updatedAt = Date.now();
    saveOrder(order);

    manager.emit('pairing_failed', { order, reason });
    manager.emit(`pairing_failed:${order.id}`, { order, reason });

    logger.error(`[ORDER] Jadibot ${order.number} PAIRING FAILED: ${reason}`);

    return order;
}

async function repairOrder(manager, orderId, orderToken) {
    const order = manager.getOrder(orderId);
    if (!order) throw new Error('Order tidak ditemukan.');

    if (!order.orderToken || !orderToken) {
        throw new Error('Order token tidak valid.');
    }
    try {
        if (!crypto.timingSafeEqual(Buffer.from(order.orderToken), Buffer.from(String(orderToken)))) {
            throw new Error('Token mismatch');
        }
    } catch (err) {
        throw new Error('Order token tidak valid.');
    }

    if (order.type !== 'jadibot') {
        throw new Error('Repair hanya berlaku untuk order jadibot.');
    }

    if (![STATUS.PAIRING, STATUS.PAIRING_FAILED, STATUS.COMPLETED].includes(order.status)) {
        throw new Error(
            `Order status '${order.status}' tidak bisa di-repair. Hanya PAIRING/PAIRING_FAILED/COMPLETED yang diizinkan.`
        );
    }

    const jadibotManager = require('../../../src/core/jadibot');
    const jid = jadibotManager.toJid(order.number);
    const { entry, pairingCode } = await jadibotManager.repairPairing(jid);

    order.status = STATUS.PAIRING;
    order.pairingCode = pairingCode;
    order.pairingStartedAt = Date.now();
    order.pairingFailedAt = null;
    order.pairingFailureReason = null;
    order.pairingConnectedAt = null;
    order.configToken = null;
    order.updatedAt = Date.now();
    saveOrder(order);

    return order;
}

function verifyOrderToken(manager, orderId, orderToken) {
    const order = manager.getOrder(orderId);
    if (!order || !order.orderToken || !orderToken) return null;
    try {
        if (crypto.timingSafeEqual(Buffer.from(order.orderToken), Buffer.from(String(orderToken)))) {
            return order;
        }
    } catch (_) {}
    return null;
}

module.exports = {
    updateOrderPairing,
    markPairingSuccess,
    markPairingFailed,
    repairOrder,
    verifyOrderToken
};

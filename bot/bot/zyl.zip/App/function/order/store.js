/**
 * order/store.js — Penyimpanan order (Storage/orders.json) & helper data.
 * Dipisah dari orderManager.js agar logika I/O terpusat di satu file.
 */
const path = require('path');
const crypto = require('crypto');
const { loadDB: loadDBFile, saveDB: saveDBFile } = require('../../../database/wrappers/storage');
const { MAX_SAVED_ORDERS } = require('./constants');

const ORDERS_PATH = path.join(__dirname, '../../../Storage/orders.json');

const getConfig = () => require('@Config');

const readDB = () => {
    try {
        const data = loadDBFile(ORDERS_PATH, { orders: [] });
        return data && Array.isArray(data.orders) ? data : { orders: [] };
    } catch (err) {
        return { orders: [] };
    }
};

const writeDB = (data) => {
    saveDBFile(ORDERS_PATH, data);
};

const saveOrder = (order) => {
    const db = readDB();
    const index = db.orders.findIndex((o) => o.id === order.id);
    if (index !== -1) db.orders[index] = order;
    else db.orders.push(order);

    if (db.orders.length > MAX_SAVED_ORDERS) {
        db.orders = db.orders.slice(-MAX_SAVED_ORDERS);
    }

    writeDB(db);
};

const genOrderId = (prefix) => {
    const rand = crypto.randomBytes(3).toString('hex').toUpperCase();
    return `${prefix}-${Date.now()}-${rand}`;
};

const findPackage = (packages, name) => {
    if (!Array.isArray(packages)) return null;
    return packages.find((p) => p.name === String(name || '').trim()) || null;
};

const normalizeGroupLink = (link) => {
    const match = String(link || '')
        .trim()
        .match(/^https?:\/\/chat\.whatsapp\.com\/([A-Za-z0-9]{20,40})$/i);
    if (!match) return null;
    return { url: `https://chat.whatsapp.com/${match[1]}`, inviteCode: match[1] };
};

function maskNumber(number) {
    const n = String(number || '');
    if (n.length < 6) return '***';
    return `${n.slice(0, 4)}****${n.slice(-3)}`;
}

module.exports = {
    ORDERS_PATH,
    getConfig,
    readDB,
    writeDB,
    saveOrder,
    genOrderId,
    findPackage,
    normalizeGroupLink,
    maskNumber
};

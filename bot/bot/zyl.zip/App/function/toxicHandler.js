const path = require('path');

const { loadDB: loadDBFile, saveDB: saveDBFile } = require('../../database/wrappers/storage');

const TOXIC_PATH = path.resolve(__dirname, '../../Storage/toxic.json');

function loadDB() {
    const data = loadDBFile(TOXIC_PATH, {});
    return data && typeof data === 'object' && !Array.isArray(data) ? data : {};
}

function saveDB(data) {
    saveDBFile(TOXIC_PATH, data);
}

function buildRegex(words = []) {
    if (!words.length) return null;

    const safe = words.map((w) => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));

    return new RegExp(`\\b(?:${safe.join('|')})\\b`, 'gi');
}

function loadTextToxic(group) {
    const db = loadDB();
    const words = db[group] || [];
    return buildRegex(words);
}

function addTextToxic(group, text) {
    const db = loadDB();
    const word = text.toLowerCase();

    if (!db[group]) db[group] = [];

    if (db[group].includes(word)) {
        return { status: false, message: 'Text sudah ada' };
    }

    db[group].push(word);
    saveDB(db);

    return { status: true, message: 'Text toxic ditambahkan' };
}

function delTextToxic(group, text) {
    const db = loadDB();
    const word = text.toLowerCase();

    if (!db[group] || !db[group].includes(word)) {
        return { status: false, message: 'Text tidak ditemukan' };
    }

    db[group] = db[group].filter((v) => v !== word);
    saveDB(db);

    return { status: true, message: 'Text toxic dihapus' };
}

function listTextToxic(group) {
    const db = loadDB();
    const words = db[group] || [];

    return {
        total: words.length,
        data: words
    };
}

module.exports = {
    loadTextToxic,
    addTextToxic,
    delTextToxic,
    listTextToxic
};

module.exports = require('../../database/wrappers/afkDb');

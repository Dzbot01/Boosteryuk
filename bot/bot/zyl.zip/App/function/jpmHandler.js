const path = require('path');
const chalk = require('chalk');
const config = require('../../config');
const { loadDB: loadDBFile, saveDB: saveDBFile } = require('../../database/wrappers/storage');
const { readBlacklist } = require('./groupBlacklist');
const ROOT_PATH = path.join(__dirname, '../..');
const STORAGE_PATH = path.join(ROOT_PATH, 'Storage');
const { proto, generateWAMessageFromContent, prepareWAMessageMedia } = require('baileys');

class JPMSystem {
    constructor(sock) {
        this.sock = sock;
        this.dbPath = path.join(__dirname, '../../Storage/jpm.json');
        this.data = { active: false, lastSent: 0, config: { type: 'text', text_promo: '', time: 6 } };
        this.intervalId = null;
        this.isRunning = false;
        this.loadDB();
    }

    loadDB() {
        try {
            const stored = loadDBFile(this.dbPath, this.data);
            if (stored && typeof stored === 'object') {
                this.data = stored;
            } else {
                this.saveDB();
            }
        } catch (e) {
            console.error(chalk.red('[JPM-DB] Error loading database:'), e);
        }
    }

    saveDB() {
        try {
            saveDBFile(this.dbPath, this.data);
        } catch (e) {
            console.error(chalk.red('[JPM-DB] Error saving database:'), e);
        }
    }

    loadBlacklistGC() {
        try {
            return readBlacklist().map((g) => g.id);
        } catch (e) {
            console.error(chalk.red('[JPM] Error loading blacklist GC:'), e);
            return [];
        }
    }

    sleep(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }

    async generateMessageContent() {
        const { type, text_promo, url } = this.data.config;
        const ownerUrl = `https://wa.me/${config.superowner}`;
        let buttons = [];

        const links = (text_promo || '').match(/https?:\/\/[^\s]+/g) || [];

        for (const link of links) {
            if (link.startsWith('https://whatsapp.com/channel')) {
                buttons.push({
                    name: 'cta_url',
                    buttonParamsJson: JSON.stringify({
                        display_text: 'Join Saluran',
                        url: link,
                        merchant_url: link
                    })
                });
            } else if (link.startsWith('https://chat.whatsapp.com') || link.startsWith('https://whatsapp.com')) {
                buttons.push({
                    name: 'cta_url',
                    buttonParamsJson: JSON.stringify({
                        display_text: 'Join Group',
                        url: link,
                        merchant_url: link
                    })
                });
            }
        }

        buttons.push({
            name: 'cta_url',
            buttonParamsJson: JSON.stringify({
                display_text: 'Chat Owner',
                url: ownerUrl,
                merchant_url: ownerUrl
            })
        });

        let header = undefined;

        if (type === 'image' && url) {
            const media = await prepareWAMessageMedia({ image: { url } }, { upload: this.sock.waUploadToServer });

            header = proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: true,
                ...media
            });
        } else if (type === 'video' && url) {
            const media = await prepareWAMessageMedia({ video: { url } }, { upload: this.sock.waUploadToServer });

            header = proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: true,
                ...media
            });
        }

        const interactiveMessage = proto.Message.InteractiveMessage.create({
            header,
            body: {
                text: text_promo || 'Promo Text Empty'
            },
            footer: {
                text: 'Click button below'
            },
            nativeFlowMessage: {
                buttons
            }
        });

        return {
            viewOnceMessageV2Extension: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage
                }
            }
        };
    }

    async execute() {
        if (this.isRunning) return;
        if (!this.data.active) return;
        if (!this.data.config?.text_promo) return;

        const now = Date.now();
        const intervalMs = (this.data.config.time || 6) * 60 * 60 * 1000;
        const nextRun = this.data.lastSent + intervalMs;
        if (now < nextRun) return;

        this.isRunning = true;

        try {
            const groups = await this.sock.groupFetchAllParticipating();
            const allGroupIds = Object.keys(groups);
            const blacklistGC = this.loadBlacklistGC();
            const groupIds = allGroupIds.filter((id) => !blacklistGC.includes(id));

            if (groupIds.length === 0) {
                console.log(chalk.yellow('[JPM] Semua grup masuk blacklist.'));
                this.isRunning = false;
                return;
            }

            console.log(
                chalk.blue(`[JPM] Target: ${groupIds.length} Groups (Skipped ${allGroupIds.length - groupIds.length})`)
            );

            const messageContent = await this.generateMessageContent();
            let successCount = 0;
            let failCount = 0;

            for (let i = 0; i < groupIds.length; i++) {
                const groupId = groupIds[i];

                try {
                    const msgii = await generateWAMessageFromContent(groupId, messageContent, {
                        userJid: this.sock.user.id,
                        quoted: null
                    });

                    await this.sock.relayMessage(groupId, msgii.message, {
                        messageId: msgii.key.id
                    });

                    successCount++;

                    if ((i + 1) % 50 === 0 || i === groupIds.length - 1) {
                        console.log(chalk.gray(`[JPM] Progress: ${i + 1}/${groupIds.length}`));
                    }
                } catch (err) {
                    failCount++;
                    if (!err.message.includes('403') && !err.message.includes('530')) {
                        console.error(chalk.red(`[JPM] Error @ ${groupId.split('@')[0]}: ${err.message}`));
                    }
                }

                await this.sleep(3000 + Math.random() * 5000);
            }

            this.data.lastSent = Date.now();
            this.saveDB();
            this.isRunning = false;

            console.log(chalk.green.bold(`[JPM] FINISHED. Success: ${successCount} | Failed: ${failCount}`));
        } catch (error) {
            console.error(chalk.red('[JPM] FATAL SYSTEM ERROR:'), error);
            this.isRunning = false;
        }
    }

    start() {
        if (this.intervalId) clearInterval(this.intervalId);

        this.intervalId = setInterval(() => {
            this.execute();
        }, 60 * 1000);

        this.execute();
    }
}

module.exports = JPMSystem;

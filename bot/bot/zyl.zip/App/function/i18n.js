'use strict';

/**
 * i18n.js — Lightweight i18n helper (F3).
 *
 * Pakai pola lookup sederhana dari `App/locales/<lang>.json`. Tidak ada
 * dependency tambahan — bisa diganti dengan `i18next` nanti kalau butuh
 * fitur lebih kompleks (plurals, gender, interpolation nested).
 *
 * Bahasa user disimpan di DatabaseManager namespace `users:<jid>.lang`.
 * Default: 'id'.
 */

const fs = require('fs');
const path = require('path');

const LOCALES_DIR = path.resolve(__dirname, '../locales');
const DEFAULT_LANG = 'id';
const SUPPORTED = ['id', 'en'];

const cache = new Map();

function loadLang(lang) {
    if (cache.has(lang)) return cache.get(lang);
    const file = path.join(LOCALES_DIR, `${lang}.json`);
    try {
        const data = JSON.parse(fs.readFileSync(file, 'utf-8'));
        cache.set(lang, data);
        return data;
    } catch (err) {
        if (lang !== DEFAULT_LANG) return loadLang(DEFAULT_LANG);
        cache.set(lang, {});
        return {};
    }
}

/**
 * Translate key dengan interpolation {{var}}.
 *
 * @param {string} lang - 'id' / 'en'
 * @param {string} key - dotted key, mis. 'common.success'
 * @param {Object} vars - {var: value}
 * @returns {string}
 */
function t(lang, key, vars = {}) {
    const dict = loadLang(lang) || {};
    const parts = String(key).split('.');
    let cur = dict;
    for (const p of parts) {
        if (cur && typeof cur === 'object' && p in cur) cur = cur[p];
        else {
            // Fallback default lang.
            if (lang !== DEFAULT_LANG) return t(DEFAULT_LANG, key, vars);
            return key;
        }
    }
    if (typeof cur !== 'string') return key;

    return cur.replace(/\{\{(\w+)\}\}/g, (_, name) => (vars[name] !== undefined ? String(vars[name]) : `{{${name}}}`));
}

function isSupported(lang) {
    return SUPPORTED.includes(String(lang).toLowerCase());
}

function listSupported() {
    return [...SUPPORTED];
}

/**
 * Resolve language preference for a user.
 * Reads from DatabaseManager `users:<jid>` doc, falls back to default.
 */
function getUserLang(userJid) {
    try {
        const { DatabaseManager } = require('@Database');
        const dbm = DatabaseManager.getInstance();
        const users = dbm.getDoc('user') || {};
        const u = users[userJid];
        if (u && u.lang && isSupported(u.lang)) return u.lang;
    } catch (_) {}
    return DEFAULT_LANG;
}

/**
 * Set language preference for a user.
 */
function setUserLang(userJid, lang) {
    if (!isSupported(lang)) return false;
    try {
        const { DatabaseManager } = require('@Database');
        const dbm = DatabaseManager.getInstance();
        const users = dbm.getDoc('user') || {};
        if (!users[userJid]) users[userJid] = {};
        users[userJid].lang = lang;
        dbm.setDoc('user', users);
        return true;
    } catch (err) {
        console.error('[i18n] setUserLang error:', err);
        return false;
    }
}

/**
 * Convenience: translate key using current user's language.
 */
function tUser(userJid, key, vars = {}) {
    return t(getUserLang(userJid), key, vars);
}

module.exports = {
    t,
    tUser,
    getUserLang,
    setUserLang,
    isSupported,
    listSupported,
    DEFAULT_LANG,
    SUPPORTED
};

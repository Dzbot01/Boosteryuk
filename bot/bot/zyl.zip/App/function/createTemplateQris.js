const { Jimp, JimpMime } = require('jimp');
const axios = require('axios');

async function loadImage(url) {
    const { data } = await axios.get(url, {
        responseType: 'arraybuffer'
    });

    return await Jimp.fromBuffer(Buffer.from(data));
}

const createTemplateQris = async (qrisString, frameUrl, config) => {
    const endpoint = config.apikey?.endpoint;
    const key = config.apikey?.key;

    if (!endpoint || !key) {
        throw new Error('QR API endpoint tidak tersedia');
    }

    const apiUrl = `${endpoint}/api/tools/create-qr?q=${encodeURIComponent(qrisString)}&size=660&apikey=${key}`;

    try {
        const qrImage = await loadImage(apiUrl);

        if (frameUrl) {
            const frame = await loadImage(frameUrl);

            const qrSize = 658;
            const offsetX = 20;
            const offsetY = 162;

            await qrImage.resize({
                w: qrSize,
                h: qrSize
            });

            const x = Math.floor((frame.bitmap.width - qrSize) / 2 + offsetX);
            const y = Math.floor((frame.bitmap.height - qrSize) / 2 + offsetY);

            frame.composite(qrImage, x, y);

            return await frame.getBuffer(JimpMime.png);
        }

        return await qrImage.getBuffer(JimpMime.png);
    } catch (error) {
        console.error('[QR] Error:', error);

        try {
            const qrImage = await loadImage(apiUrl);
            return await qrImage.getBuffer(JimpMime.png);
        } catch (retryError) {
            console.error('[QR] Retry gagal:', retryError);
            throw new Error('Gagal generate gambar QR. Silakan hubungi admin.');
        }
    }
};

module.exports = createTemplateQris;

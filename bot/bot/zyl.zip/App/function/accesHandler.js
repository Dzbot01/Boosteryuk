const logger = require('./logger');
const groupBlacklist = require('./groupBlacklist');
const isGroupBlacklisted = groupBlacklist.isBlacklisted;

/**
 * Anti-spam warning: pesan yang sama untuk chat yang sama hanya di-log
 * sekali per COOLDOWN_MS (dulu tiap pesan masuk → console banjir
 * "BOT HANYA BISA DIGUNAKAN DI GROUP" puluhan kali seperti di panel).
 */
const COOLDOWN_MS = 10 * 60 * 1000;
const lastWarn = new Map();

function warnOnce(key, text) {
    const now = Date.now();
    const last = lastWarn.get(key) || 0;
    if (now - last < COOLDOWN_MS) return;
    lastWarn.set(key, now);
    logger.warning(text);

    // Cegah map membesar tanpa batas.
    if (lastWarn.size > 500) {
        for (const [k, t] of lastWarn) {
            if (now - t > COOLDOWN_MS) lastWarn.delete(k);
        }
    }
}

module.exports = ({
    m,
    config,
    isOwner,
    isSuperOwner,
    isSpecialUser,
    pushname,
    jammenit,
    groupSettings,
    isAdmins,
    command,
    publicMode,
    isJadibot,
    jadibotEntry,
    instanceConfig
}) => {
    const isPublicMode = typeof publicMode === 'boolean' ? publicMode : config.public;

    if (!isPublicMode && !isOwner && !isSuperOwner) {
        warnOnce(`self|${m.chat}`, 'Mode self aktif — perintah dari non-owner diabaikan');
        return false;
    }

    if (m.isGroup) {
        if (!isOwner && !isSuperOwner && isGroupBlacklisted(m.chat)) {
            if (command) {
                m.reply(config.mess.blacklistgc);
            }
            return false;
        }

        const db = groupSettings[m.chat] || {};

        if (db.onlyadmin && !isAdmins) {
            warnOnce(`onlyadmin|${m.chat}`, 'Grup mode admin-only — perintah anggota biasa diabaikan');
            return false;
        }

        if (db.antigame) {
            const gameCommands = [
                'asahotak',
                'caklontong',
                'cekkodam',
                'math',
                'family100',
                'siapakahaku',
                'susunkata',
                'tebaklirik',
                'tebakkalimat',
                'tebaktebakan',
                'tekateki',
                'tebakemoji',
                'tebakkode',
                'tebakbendera',
                'tebakgambar',
                'tebakhewan',
                'tebakmakanan',
                'tebakepep',
                'tebakheroml',
                'tebaktempat',
                'tebakbom',
                'blackjack',
                'bj',
                'rpg',
                'suit',
                'tebakanime',
                'tictactoe',
                'ttt'
            ];

            if (gameCommands.includes(command)) {
                m.reply(config.singlemess.antigame);
                return false;
            }
        }

        if (db.mute && command !== 'unmute') {
            warnOnce(`mute|${m.chat}`, 'Grup sedang dimute — perintah diabaikan');
            return false;
        }
    }

    if (isSpecialUser) return true;

    const bypassCommands = ['sewabot', 'daftar'];
    if (bypassCommands.includes(command)) return true;

    const dest = instanceConfig?.botDestination || config.botDestination;

    if (dest === 'group' && !m.isGroup) {
        warnOnce(`destgroup|${m.chat}`, 'Bot mode grup-only — pesan private diabaikan');
        return false;
    }

    if (dest === 'private' && m.isGroup) {
        warnOnce(`destprivate|${m.chat}`, 'Bot mode private-only — pesan grup diabaikan');
        return false;
    }

    return true;
};

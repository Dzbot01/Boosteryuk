/**
 * cpanelHandler.js — Entry lama fitur cpanel (kompatibilitas).
 * Logic dipisah per-modul di folder ./cpanel/ agar mudah dirawat.
 */
module.exports = require('./cpanel');

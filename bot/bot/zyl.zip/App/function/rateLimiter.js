const config = require('../../config');
const rateLimiters = new Map();
const CLEANUP_INTERVAL = 60 * 60 * 1000;
const ENTRY_TTL = 2 * 60 * 60 * 1000;

function rateLimiter(chatId) {
    const now = Date.now();
    const cooldown = config.ratelimiter;

    const last = rateLimiters.get(chatId) || 0;
    const diff = now - last;

    if (diff < cooldown) {
        return {
            allowed: false,
            remaining: cooldown - diff
        };
    }

    rateLimiters.set(chatId, now);
    return { allowed: true };
}

setInterval(() => {
    const now = Date.now();
    for (const [key, ts] of rateLimiters) {
        if (now - ts > ENTRY_TTL) rateLimiters.delete(key);
    }
}, CLEANUP_INTERVAL);

module.exports = { rateLimiter };

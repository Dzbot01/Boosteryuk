'use strict';

/**
 * reminderStore.js — Persistent reminder store (F11).
 *
 * Disimpan di namespace `reminders` via DatabaseManager. Survive restart.
 * Scheduler dijalankan di main bot start — setiap 30 detik cek & fire.
 */

const path = require('path');
const logger = require('./logger');

const NAMESPACE = 'reminders';

function getDb() {
    try {
        const { DatabaseManager } = require('@Database');
        return DatabaseManager.getInstance();
    } catch (_) {
        return null;
    }
}

function getAll() {
    const dbm = getDb();
    if (!dbm) return [];
    const doc = dbm.getDoc(NAMESPACE);
    if (!doc || !Array.isArray(doc.items)) return [];
    return doc.items;
}

function saveAll(items) {
    const dbm = getDb();
    if (!dbm) return false;
    dbm.setDoc(NAMESPACE, { items: items || [], updatedAt: Date.now() });
    return true;
}

function add({ userJid, fireAt, message, chatId = null }) {
    const items = getAll();
    const id = `r_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
    const reminder = {
        id,
        userJid,
        chatId: chatId || userJid,
        fireAt: Number(fireAt),
        message: String(message || ''),
        createdAt: Date.now(),
        fired: false
    };
    items.push(reminder);
    saveAll(items);
    return reminder;
}

function remove(id, userJid) {
    const items = getAll();
    const idx = items.findIndex((r) => r.id === id && (!userJid || r.userJid === userJid));
    if (idx === -1) return false;
    items.splice(idx, 1);
    saveAll(items);
    return true;
}

function listByUser(userJid) {
    return getAll().filter((r) => r.userJid === userJid && !r.fired);
}

function listPending() {
    return getAll().filter((r) => !r.fired);
}

function markFired(id) {
    const items = getAll();
    const r = items.find((x) => x.id === id);
    if (!r) return false;
    r.fired = true;
    r.firedAt = Date.now();
    saveAll(items);
    return true;
}

function pruneFired() {
    const items = getAll();
    const now = Date.now();
    const cutoff = now - 7 * 24 * 60 * 60 * 1000; // keep fired for 7 days for history
    const kept = items.filter((r) => !r.fired || (r.firedAt && r.firedAt > cutoff));
    saveAll(kept);
}

/**
 * Parse duration string: "30m", "2h", "1d", "30s".
 */
function parseDuration(input) {
    const m = String(input || '').trim().match(/^(\d+)\s*(s|m|h|d)$/i);
    if (!m) return null;
    const n = Number(m[1]);
    const unit = m[2].toLowerCase();
    const ms = { s: 1000, m: 60_000, h: 3_600_000, d: 86_400_000 }[unit];
    return n * ms;
}

function formatDuration(ms) {
    if (ms < 60_000) return `${Math.round(ms / 1000)} detik`;
    if (ms < 3_600_000) return `${Math.round(ms / 60_000)} menit`;
    if (ms < 86_400_000) return `${Math.round(ms / 3_600_000)} jam`;
    return `${Math.round(ms / 86_400_000)} hari`;
}

let schedulerStarted = false;
let schedulerTimer = null;

/**
 * Start scheduler — cek reminder tiap 30 detik, fire yang sudah lewat waktu.
 *
 * @param {Function} sendFn - async (chatId, text) => void
 */
function startScheduler(sendFn) {
    if (schedulerStarted) return;
    schedulerStarted = true;
    const tick = async () => {
        try {
            const now = Date.now();
            const pending = listPending();
            for (const r of pending) {
                if (r.fireAt <= now) {
                    try {
                        await sendFn(r.chatId, `⏰ *Reminder*\n\n${r.message}`);
                        markFired(r.id);
                    } catch (err) {
                        logger.error(`[reminder] gagal kirim ke ${r.chatId}: ${err.message}`);
                    }
                }
            }
            // Periodic prune
            if (Math.random() < 0.1) pruneFired();
        } catch (err) {
            logger.error('[reminder] scheduler tick error: ' + err.message);
        }
    };
    tick();
    schedulerTimer = setInterval(tick, 30_000);
    if (typeof schedulerTimer.unref === 'function') schedulerTimer.unref();
    logger.info('[reminder] scheduler aktif (cek tiap 30 detik)');
}

function stopScheduler() {
    if (schedulerTimer) clearInterval(schedulerTimer);
    schedulerTimer = null;
    schedulerStarted = false;
}

module.exports = {
    NAMESPACE,
    add,
    remove,
    listByUser,
    listPending,
    markFired,
    pruneFired,
    parseDuration,
    formatDuration,
    startScheduler,
    stopScheduler
};

const chalk = require('chalk');

const getRootGameDB = () => {
    if (!global.db) global.db = {};
    if (!global.db.data) global.db.data = {};
    if (!global.db.data.game) global.db.data.game = {};
    return global.db.data.game;
};

const ensureGameType = (typegame) => {
    const gameDB = getRootGameDB();
    if (!gameDB[typegame]) gameDB[typegame] = {};
    return gameDB[typegame];
};

const saveGame = (typegame, chatId, payload = {}) => {
    const game = ensureGameType(typegame);

    game[chatId] = {
        ...payload,
        type: typegame,
        chatId,
        createdAt: Date.now()
    };

    return game[chatId];
};

const getGame = (typegame, chatId) => {
    const game = ensureGameType(typegame);
    return game[chatId] || null;
};

const hasGame = (typegame, chatId) => {
    const game = ensureGameType(typegame);
    return Boolean(game[chatId]);
};

const deleteGame = (typegame, chatId) => {
    const game = ensureGameType(typegame);
    if (!game[chatId]) return false;
    delete game[chatId];
    return true;
};

const hasAnyGameInChat = (chatId) => {
    const gameDB = getRootGameDB();

    for (const typegame in gameDB) {
        if (gameDB[typegame]?.[chatId]) {
            return true;
        }
    }
    return false;
};

const getActiveGameInChat = (chatId) => {
    const gameDB = getRootGameDB();

    for (const typegame in gameDB) {
        const game = gameDB[typegame]?.[chatId];
        if (game) {
            return {
                typegame,
                data: game
            };
        }
    }
    return null;
};

const forceDeleteAllGameInChat = (chatId) => {
    const gameDB = getRootGameDB();
    let deleted = false;

    for (const typegame in gameDB) {
        if (gameDB[typegame]?.[chatId]) {
            delete gameDB[typegame][chatId];
            deleted = true;
        }
    }
    return deleted;
};

const updateGame = (typegame, chatId, updater = {}) => {
    const game = ensureGameType(typegame);

    if (!game[chatId]) return null;

    const prevGame = game[chatId];
    const newData = typeof updater === 'function' ? updater(prevGame) : updater;

    game[chatId] = {
        ...prevGame,
        ...newData,
        updatedAt: Date.now()
    };

    return game[chatId];
};

const gameTimeouts = new Map();

const clearGameTimeout = (chatId) => {
    if (gameTimeouts.has(chatId)) {
        const timer = gameTimeouts.get(chatId);
        clearTimeout(timer);
        gameTimeouts.delete(chatId);
        console.log(chalk.gray(`[Timeout cleared] for ${chatId}`));
    }
};

const setGameTimeout = (chatId, durationMs, callback) => {
    clearGameTimeout(chatId);

    const timer = setTimeout(async () => {
        await callback();
        clearGameTimeout(chatId);
    }, durationMs);

    gameTimeouts.set(chatId, timer);
};

function getGameByPlayer(userId) {
    const gameDB = getRootGameDB();

    for (const typegame in gameDB) {
        const typeData = gameDB[typegame];

        for (const chatId in typeData) {
            const game = typeData[chatId];

            if (game.p1 === userId || game.p2 === userId || game.participants?.includes(userId)) {
                return {
                    typegame,
                    chatId,
                    data: game
                };
            }
        }
    }

    return null;
}

module.exports = {
    getGameByPlayer,
    saveGame,
    getGame,
    hasGame,
    deleteGame,
    hasAnyGameInChat,
    getActiveGameInChat,
    forceDeleteAllGameInChat,
    updateGame,
    gameTimeouts,
    clearGameTimeout,
    setGameTimeout
};

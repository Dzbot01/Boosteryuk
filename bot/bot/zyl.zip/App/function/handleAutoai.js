const axios = require('axios');
const config = require('@Config');
const logger = require('@App/function/logger');
const { getUser, reduceLimit } = require('@App/function/user');

const sessions = new Map();

const SESSION_TTL = 1000 * 60 * 30;
const MAX_HISTORY = 6;

function getSession(chatId) {
    if (!sessions.has(chatId)) {
        sessions.set(chatId, {
            messages: [],
            last: Date.now()
        });
    }
    return sessions.get(chatId);
}

setInterval(() => {
    const now = Date.now();
    for (const [k, v] of sessions.entries()) {
        if (now - v.last > SESSION_TTL) sessions.delete(k);
    }
}, 60000).unref?.();

/**
 * Ekstrak teks reply AI dari berbagai bentuk response.
 * Selalu return string (boleh kosong) — TIDAK pernah object/undefined,
 * supaya history & m.reply() tidak rusak.
 */
const pickAiText = (data) => {
    if (typeof data === 'string') return data.trim();
    if (data && typeof data === 'object') {
        for (const key of ['message', 'result', 'text', 'answer', 'reply', 'content', 'response']) {
            const v = data[key];
            if (typeof v === 'string' && v.trim()) return v.trim();
            if (v && typeof v === 'object' && typeof v.content === 'string' && v.content.trim()) return v.content.trim();
        }
    }
    return '';
};

async function fetchAi(chatId, text) {
    const session = getSession(chatId);

    session.messages.push({ role: 'user', content: text });
    session.last = Date.now();

    const apiKey = String(config.apikey?.key || '');
    if (!apiKey || apiKey === 'YOUR_KEY') {
        session.messages.pop();
        throw new Error(
            'API key AI belum dipasang. Owner harus isi config.apikey.key di config.js (key dari ' +
                (config.apikey?.endpoint || 'dashboard API') + ').'
        );
    }

    const endpoint = `${String(config.apikey?.endpoint || 'https://api.yydz.biz.id').replace(/\/+$/, '')}/api/ai/YudzAi`;

    let res;
    try {
        res = await fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                apikey: apiKey,
                message: session.messages.slice(-MAX_HISTORY)
            })
        });
    } catch (err) {
        session.messages.pop();
        throw new Error('Server AI tidak bisa dihubungi: ' + err.message);
    }

    let json = null;
    try {
        json = await res.json();
    } catch (_) {
        session.messages.pop();
        throw new Error(`Response AI bukan JSON valid (HTTP ${res.status}).`);
    }

    if (!res.ok || (typeof json?.status === 'number' && json.status >= 400)) {
        session.messages.pop();
        const serverMsg = json?.error || json?.message || `HTTP ${res.status}`;
        throw new Error(`AI error: ${serverMsg}`);
    }

    const data = pickAiText(json?.data ?? json?.result ?? json);
    if (!data) {
        session.messages.pop();
        throw new Error('AI tidak mengirim balasan teks.');
    }

    session.messages.push({ role: 'assistant', content: data });
    session.last = Date.now();

    return data;
}

function isTriggered(text, m, botNumber) {
    if (!text) return false;

    const t = text.toLowerCase();

    // Nomor bot (jid & bentuk telanjang) — mention nomor & reply pesan bot.
    const bareNumber = String(botNumber || '').split('@')[0].replace(/[^0-9]/g, '');
    if (bareNumber && t.includes(bareNumber)) return true;
    if (botNumber && t.includes(String(botNumber).toLowerCase())) return true;

    const quotedSender = String(m?.quoted?.sender || m?.quoted?.participant || '').replace(/[^0-9]/g, '');
    if (bareNumber && quotedSender === bareNumber) return true;

    if (/\bbot\b/i.test(t)) return true;
    if (/\bai\b/i.test(t)) return true;

    return false;
}

function extractQuery(text, botNumber) {
    let q = text;

    const bare = String(botNumber || '').split('@')[0].replace(/[^0-9]/g, '');
    const patterns = [botNumber, bare].filter(Boolean).map((n) => String(n).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
    if (patterns.length) q = q.replace(new RegExp(patterns.join('|'), 'gi'), '');

    q = q.replace(/\bbot\b/gi, '');
    q = q.replace(/\bai\b/gi, '');
    q = q.replace(/[,.\-!?:;'"/\\()]/g, ' ');
    q = q.replace(/\s+/g, ' ').trim();

    return q;
}

function detectType(query) {
    if (!query) return 'ai';

    const q = query.toLowerCase();

    const musicPattern =
        /\b(lagu|musik|play|youtube|mp3|song|nyanyi|dengar|putar|download\s*lagu|cari\s*lagu|yt\s*mp3|audio|youtubedownload|ytmp3)\b/i;
    const imagePattern =
        /\b(pinterest|gambar|foto|image|pic|picture|wallpaper|pp|profil|background|bg|thumbnail|cari\s*foto|cari\s*gambar|download\s*foto|download\s*gambar|photo|images)\b/i;

    if (musicPattern.test(q)) return 'music';
    if (imagePattern.test(q)) return 'image';

    return 'ai';
}

function extractSearchTerm(query, type) {
    let term = query;

    const musicStopwords = [
        'lagu',
        'musik',
        'play',
        'youtube',
        'mp3',
        'song',
        'nyanyi',
        'dengar',
        'putar',
        'download',
        'cari',
        'youtubedownload',
        'yt',
        'audio',
        'ytmp3',
        'yang',
        'dong',
        'deh',
        'banget',
        'pls',
        'please',
        'tolong',
        'kirim',
        'send',
        'buat',
        'dongle',
        'donlot',
        'donlod',
        'dwnlod',
        'mw',
        'mau',
        'pengen',
        'pengin',
        'minta'
    ];

    const imageStopwords = [
        'pinterest',
        'gambar',
        'foto',
        'image',
        'pic',
        'picture',
        'wallpaper',
        'pp',
        'profil',
        'background',
        'bg',
        'thumbnail',
        'download',
        'cari',
        'photo',
        'images',
        'yang',
        'dong',
        'deh',
        'banget',
        'pls',
        'please',
        'tolong',
        'kirim',
        'send',
        'buat',
        'dongle',
        'donlot',
        'donlod',
        'dwnlod',
        'mw',
        'mau',
        'pengen',
        'pengin',
        'minta'
    ];

    const stopwords = type === 'music' ? musicStopwords : imageStopwords;

    for (const sw of stopwords) {
        const regex = new RegExp(`\\b${sw}\\b`, 'gi');
        term = term.replace(regex, '');
    }

    term = term.replace(/[,.\-!?:;'"/\\()]/g, ' ');
    term = term.replace(/\s+/g, ' ').trim();

    return term;
}

module.exports = async function autoAi(m, botNumber, text, Yudzxml) {
    if (!text) return;
    if (m.fromMe) return;

    if (!isTriggered(text, m, botNumber)) return;

    // Limit HANYA untuk user terdaftar — user belum register tetap bisa nyapa AI,
    // dan kalau limit habis baru diberi tahu (tidak error diam-diam).
    const user = getUser(m.sender);
    if (user) {
        const limitOk = reduceLimit(m.sender, 1);
        if (!limitOk) {
            return m.reply(config.mess.limit);
        }
    }

    const query = extractQuery(text, botNumber);
    const type = detectType(query);

    try {
        if (type === 'ai') {
            const aiInput = query || 'halo';
            const reply = await fetchAi(m.chat, aiInput);
            return m.reply(reply);
        }

        if (type === 'music') {
            const searchTerm = extractSearchTerm(query, 'music');

            if (!searchTerm) {
                const reply = await fetchAi(m.chat, text);
                return m.reply(reply);
            }

            const searchUrl = `${config.apikey.endpoint}/api/search/youtube?q=${encodeURIComponent(searchTerm)}&apikey=${config.apikey.key}`;
            const searchRes = await axios.get(searchUrl, { timeout: 20000 }).catch(() => null);

            const videos = searchRes?.data?.data || [];
            if (!videos.length) {
                return m.reply(`❌ Tidak ditemukan lagu untuk "*${searchTerm}*"`);
            }

            const qualities = [320, 256, 192, 128, 96];
            let audioData = null;

            for (const q of qualities) {
                const dlUrl = `${config.apikey.endpoint}/api/download/youtubev4?url=${encodeURIComponent(videos[0].url)}&format=mp3&quality=${q}&apikey=${config.apikey.key}`;
                try {
                    const r = await axios.get(dlUrl, { timeout: 30000 });
                    if (r?.data?.status && r?.data?.data?.download) {
                        audioData = r.data.data;
                        break;
                    }
                } catch {}
            }

            if (!audioData || !audioData.download) {
                return m.reply(`❌ Gagal mengunduh lagu "*${searchTerm}*"`);
            }

            return await Yudzxml.sendMessage(
                m.chat,
                {
                    audio: { url: audioData.download },
                    mimetype: 'audio/mpeg',
                    ptt: false,
                    contextInfo: {
                        mentionedJid: [m.sender],
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.idch,
                            serverMessageId: 100,
                            newsletterName: config.ownername
                        }
                    }
                },
                { quoted: m }
            );
        }

        if (type === 'image') {
            const searchTerm = extractSearchTerm(query, 'image');

            if (!searchTerm) {
                const reply = await fetchAi(m.chat, text);
                return m.reply(reply);
            }

            const apiUrl = `${config.apikey.endpoint}/api/search/pinterest?q=${encodeURIComponent(searchTerm)}&apikey=${config.apikey.key}`;
            const res = await axios.get(apiUrl, { timeout: 15000 }).catch(() => null);

            const pins = res?.data?.data?.result?.pins || [];
            if (!pins.length) {
                return m.reply(`❌ Tidak ditemukan gambar untuk "*${searchTerm}*"`);
            }

            const image =
                pins[0]?.media?.images?.orig?.url ||
                pins[0]?.media?.images?.large?.url ||
                pins[0]?.media?.images?.xlarge?.url;

            if (!image) {
                return m.reply(`❌ Gagal mengambil gambar untuk "*${searchTerm}*"`);
            }

            return await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: image },
                    caption: `📸 _Sumber: Pinterest_`,
                    contextInfo: {
                        mentionedJid: [m.sender],
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.idch,
                            serverMessageId: 100,
                            newsletterName: config.ownername
                        }
                    }
                },
                { quoted: m }
            );
        }
    } catch (err) {
        // Error sebelumnya sebelumnya tertelan groupHandler → bot kelihatan "gamau respon".
        // Sekarang user SELALU dapat info penyebabnya.
        logger.error('[AUTO-AI] ' + (err?.message || err));
        return m.reply('⚠️ *Auto AI error:* ' + (err?.message || 'gagal memproses'));
    }

    return;
};

const fs = require('fs');
const path = require('path');
const logger = require('./logger');
const config = require('../../config');

const rootPath = path.resolve(__dirname, '../..');
const tmpPath = path.join(rootPath, 'tmp');
const storagePath = path.join(rootPath, 'Storage');
const backupsPath = path.join(storagePath, 'backups');
const statisticsPath = path.join(storagePath, 'statistics');
const rpgPath = path.join(storagePath, 'rpg');

const cfg = () => ({
    enabled: config.autoCleaner?.enabled !== false,
    intervalMinutes: Math.max(5, Number(config.autoCleaner?.intervalMinutes) || 30),
    tmp: config.autoCleaner?.tmp !== false,
    nodeCache: config.autoCleaner?.nodeCache !== false,
    statisticsRetentionDays: Number(config.autoCleaner?.statisticsRetentionDays) || 90,
    rpgRetentionDays: Number(config.autoCleaner?.rpgRetentionDays) || 60,
    backupsKeep: Number(config.autoCleaner?.backupsKeep) || Number(config.autoBackup?.keep) || 10,
    minFreeMB: Number(config.autoCleaner?.minFreeMB) || 0
});

const ageInDays = (p) => {
    try {
        return (Date.now() - fs.statSync(p).mtimeMs) / (24 * 60 * 60 * 1000);
    } catch {
        return 0;
    }
};

const removeSafe = (targetPath) => {
    try {
        if (!fs.existsSync(targetPath)) return false;
        fs.rmSync(targetPath, { recursive: true, force: true });
        return true;
    } catch (err) {
        logger.error(`CLEANER: Gagal hapus ${path.basename(targetPath)}: ${err.message}`);
        return false;
    }
};

const cleanTmp = () => {
    if (!fs.existsSync(tmpPath)) {
        fs.mkdirSync(tmpPath, { recursive: true });
        return 0;
    }
    let count = 0;
    for (const item of fs.readdirSync(tmpPath)) {
        const fullPath = path.join(tmpPath, item);
        const resolved = path.resolve(fullPath);
        if (!resolved.startsWith(path.resolve(tmpPath))) continue;
        if (removeSafe(fullPath)) count++;
    }
    return count;
};

const cleanNodeCaches = () => {
    let count = 0;
    const targets = [
        path.join(rootPath, '.cache'),
        path.join(rootPath, 'node_modules', '.cache'),
        path.join(rootPath, '.npm'),
        path.join(rootPath, '.npm-cache'),
        path.join(rootPath, '.yarn', 'cache'),
        path.join(rootPath, '.pnpm-store')
    ];
    for (const target of targets) {
        if (removeSafe(target)) count++;
    }
    return count;
};

const cleanOldZipBackups = () => {
    let count = 0;
    try {
        if (!fs.existsSync(storagePath)) return 0;
        for (const file of fs.readdirSync(storagePath)) {
            if (file.startsWith('Backup_X7_') && file.endsWith('.zip')) {
                if (removeSafe(path.join(storagePath, file))) count++;
            }
        }
    } catch {}
    return count;
};

const pruneDataBackups = (keep) => {
    try {
        if (!fs.existsSync(backupsPath)) return 0;
        const files = fs
            .readdirSync(backupsPath)
            .filter((f) => f.endsWith('.json') || f.endsWith('.zip'))
            .map((f) => {
                const full = path.join(backupsPath, f);
                return { full, mtime: fs.statSync(full).mtimeMs };
            })
            .sort((a, b) => b.mtime - a.mtime);

        let removed = 0;
        for (const old of files.slice(keep)) {
            if (removeSafe(old.full)) removed++;
        }
        return removed;
    } catch {
        return 0;
    }
};

const cleanOldStatistics = (retentionDays) => {
    let count = 0;
    try {
        if (!fs.existsSync(statisticsPath)) return 0;
        for (const file of fs.readdirSync(statisticsPath)) {
            if (!file.endsWith('.json')) continue;
            const full = path.join(statisticsPath, file);
            if (ageInDays(full) > retentionDays) {
                if (removeSafe(full)) count++;
            }
        }
    } catch {}
    return count;
};

const cleanInactiveRpg = (retentionDays) => {
    let count = 0;
    try {
        if (!fs.existsSync(rpgPath)) return 0;
        for (const file of fs.readdirSync(rpgPath)) {
            if (!file.endsWith('.json')) continue;
            const full = path.join(rpgPath, file);
            if (ageInDays(full) > retentionDays) {
                if (removeSafe(full)) count++;
            }
        }
    } catch {}
    return count;
};

const cleanStaleWorkFiles = () => {
    let count = 0;

    const restartInfo = path.join(rootPath, 'restart_info.json');
    if (fs.existsSync(restartInfo) && ageInDays(restartInfo) >= 1) {
        if (removeSafe(restartInfo)) count++;
    }

    const lockFile = path.join(storagePath, '.backup_lock');
    try {
        if (fs.existsSync(lockFile)) {
            const lockTime = parseInt(fs.readFileSync(lockFile, 'utf-8'));
            if (Date.now() - lockTime > 60 * 60 * 1000) {
                if (removeSafe(lockFile)) count++;
            }
        }
    } catch {}
    return count;
};

const getFreeMB = () => {
    try {
        const { checkDiskSpace } = require('check-disk-space');
        return checkDiskSpace(rootPath).then((info) => Math.round(info.free / 1024 / 1024));
    } catch {
        return Promise.resolve(null);
    }
};

const runCleaner = async (reason = 'terjadwal') => {
    const c = cfg();
    if (!c.enabled) return;

    const stats = {
        tmp: 0,
        cache: 0,
        zip: 0,
        backup: 0,
        statistics: 0,
        rpg: 0,
        stale: 0
    };

    try {
        if (c.tmp) stats.tmp = cleanTmp();
        if (c.nodeCache) stats.cache = cleanNodeCaches();
        stats.zip = cleanOldZipBackups();
        stats.backup = pruneDataBackups(c.backupsKeep);
        stats.statistics = cleanOldStatistics(c.statisticsRetentionDays);
        stats.rpg = cleanInactiveRpg(c.rpgRetentionDays);
        stats.stale = cleanStaleWorkFiles();

        const total = Object.values(stats).reduce((a, b) => a + b, 0);
        if (total > 0) {
            logger.success(
                `CLEANER (${reason}): ${total} item dibersihkan — tmp:${stats.tmp} cache:${stats.cache} zipLama:${stats.zip} backupLama:${stats.backup} statistik:${stats.statistics} rpg:${stats.rpg} fileBasi:${stats.stale}`
            );
        }

        const freeMB = await getFreeMB();
        if (freeMB !== null && c.minFreeMB > 0 && freeMB < c.minFreeMB) {
            logger.warning(
                `CLEANER: Sisa disk kritis ${freeMB}MB (< ${c.minFreeMB}MB). Menjalankan pembersihan darurat...`
            );
            cleanTmp();
            cleanNodeCaches();
            pruneDataBackups(Math.max(1, Math.floor(c.backupsKeep / 2)));
            logger.warning('CLEANER: Pembersihan darurat selesai. Pertimbangkan hapus file besar / upgrade disk.');
        }
    } catch (err) {
        logger.error(`CLEANER ERROR: ${err.message}`);
    }
};

if (cfg().enabled) {
    const minutes = Math.max(5, Number(config.autoCleaner?.intervalMinutes) || 30);
    runCleaner('boot');
    setInterval(() => runCleaner('terjadwal'), minutes * 60 * 1000).unref?.();
}

module.exports = { runCleaner };

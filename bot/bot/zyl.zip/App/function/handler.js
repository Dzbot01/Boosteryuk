'use strict';

/**
 * App/function/handler.js — Backward-compatibility shim.
 *
 * Seluruh helper handler sudah dipindah ke folder `./handlers/` (sudah ada
 * sebelumnya). File ini HANYA re-export agar plugin lama yang masih
 * `require('@App/function/handler')` tetap berjalan tanpa perlu diubah.
 *
 * ──────────────────────────────────────────────────────────────────────────
 * @deprecated gunakan import spesifik dari `@App/function/handlers/*`:
 *
 *   const { fetchJson } = require('@App/function/handlers/network');
 *   const { getBuffer }  = require('@App/function/handlers/network');
 *   const { smsg }       = require('@App/function/handlers/serialize');
 *   const { loading }    = require('@App/function/handlers/message');
 *   const { sleep }      = require('@App/function/handlers/time');
 *   const { getProfileUrl, getProfileBuffer } = require('@App/function/handlers/profile');
 *   const { getTimeBasedGreeting } = require('@App/function/handlers/time');
 *   const { formatSize, formatp, checkBandwidth, runtime } = require('@App/function/handlers/formatter');
 *   const { randomAssets } = require('@App/function/handlers/assets');
 *   const { pickRandom, getGroupAdmins, success } = require('@App/function/handlers/index');
 *   const { sendRegisterPrompt, extractMessageBody } = require('@App/function/handlers/message');
 *
 * Target penghapusan: v3.0.0.
 * ──────────────────────────────────────────────────────────────────────────
 */

/** @deprecated use `@App/function/handlers/<spec>` */
module.exports = require('./handlers');

const fs = require('fs');
let file = require.resolve(__filename);
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    delete require.cache[file];
    require(file);
});

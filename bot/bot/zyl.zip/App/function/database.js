module.exports = require('../../database/wrappers/storage');

const fs = require('fs');
const path = require('path');
const moment = require('moment-timezone');

const { loadDB: loadDBLayer, saveDB: saveDBLayer } = require('../../database/wrappers/storage');

moment.tz.setDefault('Asia/Jakarta');

const DB_DIR = path.join(__dirname, '../../Storage');
const DB_PATH = path.join(DB_DIR, 'absen.json');

function today() {
    return moment().format('YYYY-MM-DD');
}

function nowTime() {
    return moment().format('HH:mm:ss');
}

function ensureDB() {
    if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });
}

function loadDB() {
    ensureDB();
    const data = loadDBLayer(DB_PATH, {});
    return data && typeof data === 'object' ? data : {};
}

function saveDB(db) {
    ensureDB();
    saveDBLayer(DB_PATH, db);
}

function initGroup(db, groupId) {
    if (!db[groupId] || db[groupId].date !== today()) {
        db[groupId] = {
            date: today(),
            users: {}
        };
    }
}

function add(groupId, sender) {
    const db = loadDB();
    initGroup(db, groupId);

    if (db[groupId].users[sender]) {
        return { error: 'Sudah absen hari ini' };
    }

    db[groupId].users[sender] = {
        time: nowTime()
    };

    saveDB(db);
    return { success: true, time: db[groupId].users[sender].time };
}

function isAbsen(groupId, sender) {
    const db = loadDB();
    initGroup(db, groupId);
    return !!db[groupId].users[sender];
}

function get(groupId) {
    const db = loadDB();
    initGroup(db, groupId);
    return db[groupId];
}

function remove(groupId, sender) {
    const db = loadDB();
    initGroup(db, groupId);

    if (!db[groupId].users[sender]) return false;

    delete db[groupId].users[sender];
    saveDB(db);
    return true;
}

module.exports = {
    add,
    isAbsen,
    get,
    remove
};

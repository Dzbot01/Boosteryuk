const fs = require('fs');
const path = require('path');
const moment = require('moment-timezone');

const { loadDB: loadDBFile, saveDB: saveDBFile } = require('../../database/wrappers/storage');

const { addSewa } = require('./sewa');
const { addLimit, addMoney } = require('./user');

const { addPremiumUser, checkPremiumUser } = require('./premium');

const DB_PATH = path.join(__dirname, '../../Storage/redeem.json');
const TZ = 'Asia/Jakarta';

const loadDB = () => {
    const data = loadDBFile(DB_PATH, {});
    return data && typeof data === 'object' && !Array.isArray(data) ? data : {};
};

const saveDB = (data) => {
    saveDBFile(DB_PATH, data);
};

const parseExpired = (text = '') => {
    const match = text.match(/^(\d+)([hd])$/i);

    if (!match) return null;

    const value = Number(match[1]);
    const unit = match[2].toLowerCase();

    if (unit === 'h') return { hours: value };
    if (unit === 'd') return { days: value };

    return null;
};

const createRedeem = (code, expiredInput, reward = {}) => {
    if (!code) {
        return {
            status: false,
            msg: 'Kode wajib diisi'
        };
    }

    const db = loadDB();
    const key = code.toUpperCase();

    if (db[key]) {
        return {
            status: false,
            msg: 'Kode sudah ada'
        };
    }

    const expiredDur = parseExpired(expiredInput);

    if (!expiredDur) {
        return {
            status: false,
            msg: 'Format expired salah (12h / 7d)'
        };
    }

    const now = moment().tz(TZ);

    db[key] = {
        expired: now.clone().add(expiredDur).valueOf(),
        reward,
        usedUsers: [],
        usedGroups: [],
        created_at: now.format('YYYY-MM-DD HH:mm:ss')
    };

    saveDB(db);

    return {
        status: true,
        msg: 'Redeem berhasil dibuat'
    };
};

const claimRedeem = async (code, userId, groupId, groupName, Yudzxml) => {
    const db = loadDB();
    const key = code.toUpperCase();
    const data = db[key];

    if (!data) {
        return {
            status: false,
            msg: 'Kode tidak valid'
        };
    }

    const now = moment().tz(TZ).valueOf();

    if (now > data.expired) {
        return {
            status: false,
            msg: 'Kode sudah expired'
        };
    }

    const reward = data.reward || {};

    const hasUserReward = reward.premium || reward.money || reward.limit;

    if (hasUserReward && data.usedUsers.includes(userId)) {
        return {
            status: false,
            msg: 'Kamu sudah menggunakan kode ini'
        };
    }

    if (reward.sewa && data.usedGroups.includes(groupId)) {
        return {
            status: false,
            msg: 'Grup ini sudah menggunakan reward sewa'
        };
    }

    const rewardText = [];

    if (reward.premium) {
        if (!checkPremiumUser(userId)) {
            await addPremiumUser(userId, reward.premium, Yudzxml);

            rewardText.push(`👑 Premium ${reward.premium}`);
        }
    }

    if (reward.money) {
        addMoney(userId, Number(reward.money));

        rewardText.push(`💰 ${Number(reward.money).toLocaleString()} Money`);
    }

    if (reward.limit) {
        addLimit(userId, Number(reward.limit));

        rewardText.push(`🎫 ${reward.limit} Limit`);
    }

    if (reward.sewa && groupId && groupName && !data.usedGroups.includes(groupId)) {
        addSewa(groupId, groupName, Number(reward.sewa));

        rewardText.push(`🤖 Sewa Bot ${reward.sewa} Hari`);

        data.usedGroups.push(groupId);
    }

    if (hasUserReward) {
        data.usedUsers.push(userId);
    }

    saveDB(db);

    return {
        status: true,
        msg: rewardText.join('\n'),
        expired_at: moment(data.expired).tz(TZ).format('DD/MM/YYYY HH:mm:ss')
    };
};

const getRedeem = (code) => {
    const db = loadDB();
    return db[code.toUpperCase()] || null;
};

const deleteRedeem = (code) => {
    const db = loadDB();
    const key = code.toUpperCase();

    if (!db[key]) return false;

    delete db[key];

    saveDB(db);

    return true;
};

const listRedeem = () => {
    return loadDB();
};

module.exports = {
    createRedeem,
    claimRedeem,
    getRedeem,
    deleteRedeem,
    listRedeem
};

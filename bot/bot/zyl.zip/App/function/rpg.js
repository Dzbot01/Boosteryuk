/**
 * rpg.js — Entry lama engine RPG (kompatibilitas).
 * Logic dipisah ke folder ./rpgEngine/ (data / core / actions / shop).
 */
module.exports = require('./rpgEngine');

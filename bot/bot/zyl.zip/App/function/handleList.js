const config = require('../../config');

module.exports = async ({ m, budy, getList, Yudzxml }) => {
    const chatTarget = m.isGroup ? m.chat : config?.superowner + '@s.whatsapp.net';
    const text = budy.toLowerCase();
    const data = await getList(chatTarget, text);
    if (!data) return;

    switch (data.type) {
        case 'text':
            return m.reply(data.text || '');

        case 'image':
            if (!data.url) return;
            return Yudzxml.sendMessage(m.chat, { image: { url: data.url }, caption: data.text || '' }, { quoted: m });

        case 'video':
            if (!data.url) return;
            return Yudzxml.sendMessage(m.chat, { video: { url: data.url }, caption: data.text || '' }, { quoted: m });

        case 'audio':
            if (!data.url) return;
            return Yudzxml.sendMessage(
                m.chat,
                {
                    audio: { url: data.url },
                    mimetype: data.mimetype || 'audio/mp4',
                    ptt: false
                },
                { quoted: m }
            );

        case 'document':
            if (!data.url) return;
            return Yudzxml.sendMessage(
                m.chat,
                {
                    document: { url: data.url },
                    mimetype: data.mimetype || 'application/octet-stream',
                    fileName: data.filename || data.id || 'file',
                    caption: data.text || ''
                },
                { quoted: m }
            );

        default:
            return;
    }
};

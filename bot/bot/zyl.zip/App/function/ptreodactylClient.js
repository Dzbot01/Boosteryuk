const axios = require('axios');
const path = require('path');
const config = require('@Config');
const { loadDB: loadDBFile, saveDB: saveDBFile } = require('../../database/wrappers/storage');
const { cpanel } = config;

function buildConfig(cpanelCfg = cpanel) {
    const nodejs = cpanelCfg.NODEJS || { NESTID: 5, EGGID: 15 };
    const python = cpanelCfg.PYTHON || { NESTID: 6, EGGID: 16 };
    return {
        BASE_URL: cpanelCfg.BASE,
        API_KEY: cpanelCfg.PLTA,
        EGGS: {
            NODEJS: {
                NEST_ID: nodejs.NESTID,
                EGG_ID: nodejs.EGGID,
                IMAGES: {
                    nodejs_24: 'ghcr.io/parkervcp/yolks:nodejs_24',
                    nodejs_23: 'ghcr.io/parkervcp/yolks:nodejs_23',
                    nodejs_22: 'ghcr.io/parkervcp/yolks:nodejs_22',
                    nodejs_21: 'ghcr.io/parkervcp/yolks:nodejs_21',
                    nodejs_20: 'ghcr.io/parkervcp/yolks:nodejs_20',
                    nodejs_19: 'ghcr.io/parkervcp/yolks:nodejs_19',
                    nodejs_18: 'ghcr.io/parkervcp/yolks:nodejs_18',
                    nodejs_17: 'ghcr.io/parkervcp/yolks:nodejs_17',
                    nodejs_16: 'ghcr.io/parkervcp/yolks:nodejs_16',
                    nodejs_15: 'ghcr.io/parkervcp/yolks:nodejs_15'
                }
            },
            PYTHON: {
                NEST_ID: python.NESTID,
                EGG_ID: python.EGGID,
                IMAGES: {
                    'python_3.7': 'ghcr.io/pterodactyl/yolks:python_3.7',
                    'python_3.8': 'ghcr.io/pterodactyl/yolks:python_3.8',
                    'python_3.9': 'ghcr.io/pterodactyl/yolks:python_3.9',
                    'python_3.10': 'ghcr.io/pterodactyl/yolks:python_3.10',
                    'python_3.11': 'ghcr.io/pterodactyl/yolks:python_3.11'
                }
            }
        }
    };
}

const PW_PREFIX = 'enc:';
function encodePw(pw) {
    return PW_PREFIX + Buffer.from(pw).toString('base64');
}
function decodePw(stored) {
    if (!stored) return null;
    if (stored.startsWith(PW_PREFIX)) {
        return Buffer.from(stored.slice(PW_PREFIX.length), 'base64').toString('utf8');
    }
    return stored;
}

const _serviceCache = new Map();

class PteroService {
    constructor(cpanelCfg = cpanel, scope = 'main') {
        this.CONFIG = buildConfig(cpanelCfg);
        this.cpanelCfg = cpanelCfg;
        this.scope = scope;
        this.baseUrl = String(this.CONFIG.BASE_URL || '').replace(/\/$/, '');
        this.apiKey = this.CONFIG.API_KEY;
        this.client = axios.create({
            baseURL: this.baseUrl,
            headers: {
                Authorization: `Bearer ${this.apiKey}`,
                Accept: 'application/json',
                'Content-Type': 'application/json'
            },
            timeout: 15000
        });

        this.scopeDir =
            scope === 'main'
                ? path.join(__dirname, '../../Storage')
                : path.join(__dirname, '../../Storage/jadibot_sessions', scope);
        this.dbPath =
            scope === 'main'
                ? path.join(__dirname, '../../Storage/ptreodactyl.json')
                : path.join(this.scopeDir, 'ptreodactyl.json');

        if (scope === 'main') {
            this.autoDeleteInterval = setInterval(
                () => {
                    this._checkExpiredServers().catch((err) => console.error('[AutoDelete] Error:', err.message));
                },
                60 * 60 * 1000
            );
            this._checkExpiredServers();
        }
    }

    _readDb() {
        const data = loadDBFile(this.dbPath, { users: {}, servers: {} });
        if (!data || typeof data !== 'object' || Array.isArray(data)) return { users: {}, servers: {} };
        if (!data.users) data.users = {};
        if (!data.servers) data.servers = {};
        return data;
    }

    _writeDb(data) {
        saveDBFile(this.dbPath, data);
    }

    _getLocalUser(email) {
        try {
            const data = this._readDb();
            const stored = data.users && data.users[email];
            if (!stored) return null;
            return { password: decodePw(stored) };
        } catch (error) {
            console.error('[DB] Error reading local database:', error);
            return null;
        }
    }

    _saveLocalUser(email, password) {
        try {
            const data = this._readDb();
            if (!data.users) data.users = {};
            data.users[email] = encodePw(password);
            this._writeDb(data);
        } catch (error) {
            console.error('[DB] Error saving to local database:', error);
        }
    }

    _saveServerRecord(serverId, userId, expiredAt) {
        try {
            const data = this._readDb();
            if (!data.servers) data.servers = {};
            data.servers[serverId] = {
                userId: userId,
                expiredAt: expiredAt
            };
            this._writeDb(data);
        } catch (error) {
            console.error('[DB] Error saving server record:', error);
        }
    }

    async _checkExpiredServers() {
        try {
            const data = this._readDb();
            if (!data.servers) return;

            const now = new Date();
            const serverIds = Object.keys(data.servers);
            let deletedCount = 0;

            for (const serverId of serverIds) {
                const serverInfo = data.servers[serverId];
                if (!serverInfo.expiredAt) continue;

                const expiredDate = new Date(serverInfo.expiredAt);

                if (now > expiredDate) {
                    const deleteResult = await this.deleteServer(serverId);

                    if (deleteResult.success) {
                        delete data.servers[serverId];
                        deletedCount++;
                    } else {
                        console.error(
                            `[AutoDelete] Failed to delete server ${serverId} from panel: ${deleteResult.message}`
                        );
                    }
                }
            }

            if (deletedCount > 0) {
                this._writeDb(data);
            }
        } catch (error) {
            console.error('[AutoDelete] System error:', error.message);
        }
    }

    _handleError(error) {
        const message = error.response?.data?.errors?.[0]?.detail || error.message;
        const status = error.response?.status || 500;
        console.error(`[PteroService Error] ${status}: ${message}`);
        return { success: false, message, status };
    }

    _generateExpiration(days = 30) {
        const now = new Date();
        const expired = new Date();
        expired.setDate(now.getDate() + days);
        return {
            createdAt: now.toISOString(),
            expiredAt: expired.toISOString()
        };
    }

    getRamPackage(name) {
        const ramList = this.cpanelCfg?.LISTPANEL || config.cpanel.LISTPANEL;
        const pkg = ramList.find((v) => v.name === name);
        if (!pkg) throw new Error(`Package ${name} tidak ditemukan`);
        return pkg;
    }

    async checkUserByEmail(email) {
        try {
            const response = await this.client.get('/api/application/users', {
                params: { 'filter[email]': email }
            });

            const userData = response.data.data;

            if (userData && userData.length > 0) {
                return { success: true, exists: true, userId: userData[0].attributes.id };
            }

            return { success: true, exists: false, userId: null };
        } catch (error) {
            return this._handleError(error);
        }
    }

    async createUser(email, username, password) {
        try {
            const response = await this.client.post('/api/application/users', {
                email,
                username,
                first_name: username,
                last_name: username,
                language: 'en',
                password
            });

            return { success: true, userId: response.data.attributes.id };
        } catch (error) {
            return this._handleError(error);
        }
    }

    async getStartupCommand(nestId, eggId) {
        try {
            const url = `/api/application/nests/${nestId}/eggs/${eggId}`;
            const response = await this.client.get(url);
            return { success: true, startup: response.data.attributes.startup };
        } catch (error) {
            return this._handleError(error);
        }
    }

    _generateNodeJsPayload(username, description, dockerImage, userId, eggId, startup, ram, disk, cpu) {
        return {
            name: username,
            description: description,
            user: userId,
            egg: eggId,
            docker_image: dockerImage,
            startup: startup,
            environment: {
                INST: 'npm',
                USER_UPLOAD: '0',
                AUTO_UPDATE: '0',
                CMD_RUN: 'npm start'
            },
            limits: {
                memory: ram,
                swap: 0,
                disk: disk,
                io: 500,
                cpu: cpu
            },
            feature_limits: {
                databases: 0,
                backups: 0,
                allocations: 0
            },
            deploy: {
                locations: [1],
                dedicated_ip: false,
                port_range: []
            }
        };
    }

    _generatePythonPayload(username, description, dockerImage, userId, eggId, startup, ram, disk, cpu) {
        return {
            name: username,
            description: description,
            user: userId,
            egg: eggId,
            docker_image: dockerImage,
            startup: startup,
            environment: {
                START_FILE: 'main.py',
                AUTO_UPDATE: '0',
                USER_UPLOAD: '1',
                GIT_ADDRESS: '',
                BRANCH: '',
                USERNAME: '',
                ACCESS_TOKEN: ''
            },
            limits: {
                memory: ram,
                swap: 0,
                disk: disk,
                io: 500,
                cpu: cpu
            },
            feature_limits: {
                databases: 0,
                backups: 0,
                allocations: 0
            },
            deploy: {
                locations: [1],
                dedicated_ip: false,
                port_range: []
            }
        };
    }

    async createServer(payload) {
        try {
            const response = await this.client.post('/api/application/servers', payload);
            const dates = this._generateExpiration();

            return {
                success: true,
                data: {
                    domain: this.baseUrl,
                    userId: payload.user,
                    serverId: response.data.attributes.id,
                    username: payload.name,
                    ram: payload.limits.memory,
                    disk: payload.limits.disk,
                    cpu: payload.limits.cpu,
                    createdAt: dates.createdAt,
                    expiredAt: dates.expiredAt
                }
            };
        } catch (error) {
            return this._handleError(error);
        }
    }

    async deleteUserAndServer(serverId, userId) {
        try {
            await this.client.delete(`/api/application/servers/${serverId}`);
            return { success: true, message: 'Server and user deleted successfully' };
        } catch (error) {
            return this._handleError(error);
        }
    }

    async getUsers(page = 1) {
        try {
            const response = await this.client.get('/api/application/users', { params: { page } });
            return {
                success: true,
                data: response.data.data.map((user) => ({
                    id: user.attributes.id,
                    uuid: user.attributes.uuid,
                    username: user.attributes.username,
                    email: user.attributes.email,
                    first_name: user.attributes.first_name,
                    last_name: user.attributes.last_name,
                    created_at: user.attributes.created_at
                })),
                meta: response.data.meta
            };
        } catch (error) {
            return this._handleError(error);
        }
    }

    async getUser(userId) {
        try {
            const response = await this.client.get(`/api/application/users/${userId}`);
            return { success: true, data: response.data.attributes };
        } catch (error) {
            return this._handleError(error);
        }
    }

    async deleteUser(userId) {
        try {
            await this.client.delete(`/api/application/users/${userId}`);
            return { success: true, message: 'User deleted' };
        } catch (error) {
            return this._handleError(error);
        }
    }

    async getServers(page = 1) {
        try {
            const response = await this.client.get('/api/application/servers', { params: { page } });
            return {
                success: true,
                data: response.data.data.map((server) => ({
                    id: server.attributes.id,
                    uuid: server.attributes.uuid,
                    identifier: server.attributes.identifier,
                    name: server.attributes.name,
                    user: server.attributes.user,
                    suspended: server.attributes.suspended,
                    memory: server.attributes.limits.memory,
                    disk: server.attributes.limits.disk,
                    cpu: server.attributes.limits.cpu
                })),
                meta: response.data.meta
            };
        } catch (error) {
            return this._handleError(error);
        }
    }

    async getServer(serverId) {
        try {
            const response = await this.client.get(`/api/application/servers/${serverId}`);
            return { success: true, data: response.data.attributes };
        } catch (error) {
            return this._handleError(error);
        }
    }

    async deleteServer(serverId) {
        try {
            await this.client.delete(`/api/application/servers/${serverId}`);
            return { success: true, message: 'Server deleted' };
        } catch (error) {
            return this._handleError(error);
        }
    }

    async suspendServer(serverId) {
        try {
            await this.client.post(`/api/application/servers/${serverId}/suspend`);
            return { success: true, message: 'Server suspended' };
        } catch (error) {
            return this._handleError(error);
        }
    }

    async unsuspendServer(serverId) {
        try {
            await this.client.post(`/api/application/servers/${serverId}/unsuspend`);
            return { success: true, message: 'Server unsuspended' };
        } catch (error) {
            return this._handleError(error);
        }
    }

    async getUserServers(userId) {
        try {
            const response = await this.client.get('/api/application/servers');
            const servers = response.data.data
                .filter((server) => server.attributes.user === userId)
                .map((server) => ({
                    id: server.attributes.id,
                    uuid: server.attributes.uuid,
                    name: server.attributes.name,
                    suspended: server.attributes.suspended,
                    memory: server.attributes.limits.memory,
                    disk: server.attributes.limits.disk,
                    cpu: server.attributes.limits.cpu
                }));
            return { success: true, data: servers };
        } catch (error) {
            return this._handleError(error);
        }
    }

    async getStats() {
        try {
            const [users, servers] = await Promise.all([
                this.client.get('/api/application/users'),
                this.client.get('/api/application/servers')
            ]);
            return {
                success: true,
                data: {
                    totalUsers: users.data.meta.pagination.total,
                    totalServers: servers.data.meta.pagination.total
                }
            };
        } catch (error) {
            return this._handleError(error);
        }
    }

    async run(options) {
        try {
            const {
                orderType = 'normal',
                email,
                username,
                password,
                type = 'nodejs',
                dockerImageKey,
                resources = {}
            } = options;

            const typeKey = type.toUpperCase();
            if (!this.CONFIG.EGGS[typeKey]) {
                throw new Error(`Type "${type}" is not supported. Use 'nodejs' or 'python'.`);
            }

            const { NEST_ID, EGG_ID, IMAGES } = this.CONFIG.EGGS[typeKey];

            if (!dockerImageKey || !IMAGES[dockerImageKey]) {
                const availableImages = Object.keys(IMAGES).join(', ');
                throw new Error(`Invalid Docker Image. Available: ${availableImages}`);
            }
            const selectedImage = IMAGES[dockerImageKey];

            let userId;
            let userPassword = password;

            if (orderType === 'self') {
                if (!email) {
                    throw new Error('Email user panel wajib diisi');
                }

                const localUser = this._getLocalUser(email);

                if (localUser) {
                    userPassword = localUser.password;
                } else {
                    if (!password) {
                        throw new Error('Password wajib diisi karena email belum terdaftar di database lokal.');
                    }
                }

                const userCheck = await this.checkUserByEmail(email);
                if (!userCheck.success) throw new Error(userCheck.message);

                if (userCheck.exists) {
                    userId = userCheck.userId;

                    if (!localUser && password) {
                        this._saveLocalUser(email, password);
                    }
                } else {
                    if (!username) throw new Error('Username wajib diisi untuk membuat user baru.');

                    const createResult = await this.createUser(email, username, userPassword);
                    if (!createResult.success) throw new Error(createResult.message);

                    userId = createResult.userId;
                    this._saveLocalUser(email, userPassword);
                }
            } else {
                if (!email || !username || !password) {
                    throw new Error('Email, Username, dan Password wajib diisi untuk order normal.');
                }

                const userCheck = await this.checkUserByEmail(email);
                if (!userCheck.success) throw new Error(userCheck.message);

                if (userCheck.exists) {
                    userId = userCheck.userId;
                } else {
                    const createResult = await this.createUser(email, username, password);
                    if (!createResult.success) throw new Error(createResult.message);
                    userId = createResult.userId;
                }
            }

            const startupRes = await this.getStartupCommand(NEST_ID, EGG_ID);
            if (!startupRes.success) throw new Error(startupRes.message);

            let payload;
            const { ram = 512, disk = 1024, cpu = 100 } = resources;

            if (typeKey === 'NODEJS') {
                payload = this._generateNodeJsPayload(
                    username,
                    `Created by YudzDev - ${type}`,
                    selectedImage,
                    userId,
                    EGG_ID,
                    startupRes.startup,
                    ram,
                    disk,
                    cpu
                );
            } else if (typeKey === 'PYTHON') {
                payload = this._generatePythonPayload(
                    username,
                    `Created by YudzDev - ${type}`,
                    selectedImage,
                    userId,
                    EGG_ID,
                    startupRes.startup,
                    ram,
                    disk,
                    cpu
                );
            }

            const serverRes = await this.createServer(payload);

            if (serverRes.success && serverRes.data.serverId) {
                this._saveServerRecord(serverRes.data.serverId, serverRes.data.userId, serverRes.data.expiredAt);
            }

            return serverRes;
        } catch (error) {
            return this._handleError(error);
        }
    }
}

const mainService = new PteroService(cpanel, 'main');

function createPteroService(cpanelCfg, scope = 'main') {
    const cfg = cpanelCfg || cpanel;
    const key = `${scope}|${cfg.BASE || ''}|${cfg.PLTA || ''}`;
    if (!_serviceCache.has(key)) {
        _serviceCache.set(key, new PteroService(cfg, scope));
    }
    return _serviceCache.get(key);
}

function getPteroForContext(ctx = {}) {
    const { isJadibot, jadibotEntry, jadibotJid } = ctx;
    if (isJadibot && jadibotEntry) {
        const cred = jadibotEntry.credentials?.cpanel;
        if (!cred || !cred.BASE || !cred.PLTA) return null;
        const scope = jadibotEntry.number || (jadibotJid || '').split('@')[0] || 'jadibot';
        return createPteroService(cred, scope);
    }
    return mainService;
}

module.exports = mainService;
module.exports.createPteroService = createPteroService;
module.exports.getPteroForContext = getPteroForContext;
module.exports.PteroService = PteroService;

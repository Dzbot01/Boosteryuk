class SessionManager {
    constructor() {
        this.sessions = new Map();

        this._cleanupInterval = setInterval(() => this.cleanup(), 5 * 60 * 1000);
    }

    create(userId, data = {}, ttl = 300000) {
        this.destroyByUserId(userId);

        const sessionId = this._generateId();

        const sessionData = {
            sessionId,
            userId,
            data,
            createdAt: Date.now(),
            expiresAt: Date.now() + ttl
        };

        this.sessions.set(sessionId, sessionData);
        return sessionId;
    }

    get(sessionId) {
        const session = this.sessions.get(sessionId);
        if (!session) return null;

        if (Date.now() > session.expiresAt) {
            this.sessions.delete(sessionId);
            return null;
        }

        return session;
    }

    getByUserId(userId) {
        for (const [id, session] of this.sessions.entries()) {
            if (session.userId === userId) {
                if (Date.now() > session.expiresAt) {
                    this.sessions.delete(id);

                    return null;
                }
                return session;
            }
        }
        return null;
    }

    update(sessionId, newData = {}) {
        const session = this.get(sessionId);
        if (!session) return false;

        session.data = {
            ...session.data,
            ...newData
        };

        if (newData.status && newData.status !== session.data.status) {
        }

        this.sessions.set(sessionId, session);
        return true;
    }

    updateByUserId(userId, newData = {}) {
        const session = this.getByUserId(userId);
        if (!session) return false;
        return this.update(session.sessionId, newData);
    }

    destroy(sessionId) {
        const deleted = this.sessions.delete(sessionId);
        return deleted;
    }

    destroyByUserId(userId) {
        for (const [id, session] of this.sessions.entries()) {
            if (session.userId === userId) {
                this.sessions.delete(id);
                return true;
            }
        }
        return false;
    }

    isValid(sessionId) {
        return this.get(sessionId) !== null;
    }

    hasActiveSession(userId) {
        return this.getByUserId(userId) !== null;
    }

    getAll() {
        this.cleanup();
        return Array.from(this.sessions.values()).map((s) => ({
            sessionId: s.sessionId,
            userId: s.userId,
            status: s.data.status,
            createdAt: new Date(s.createdAt).toISOString(),
            expiresAt: new Date(s.expiresAt).toISOString()
        }));
    }

    cleanup() {
        const now = Date.now();
        let count = 0;

        for (const [id, session] of this.sessions.entries()) {
            if (now > session.expiresAt) {
                this.sessions.delete(id);
                count++;
            }
        }

        if (count > 0) {
        }
        return count;
    }

    _generateId() {
        return 'cpl_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
    }

    destroyAll() {
        const count = this.sessions.size;
        this.sessions.clear();
        if (this._cleanupInterval) clearInterval(this._cleanupInterval);
        return count;
    }
}

module.exports = new SessionManager();

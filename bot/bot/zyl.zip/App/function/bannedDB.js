module.exports = require('../../database/wrappers/bannedDB');

/**
 * games/tebakBom.js — Handler game Tebak Bom.
 * Diekstrak dari actionGameHandler.js (1 game = 1 file) agar mudah dirawat.
 *
 * Kontrak:
 *   return false      -> pesan dikonsumsi game ini (hentikan seluruh handler)
 *   return true       -> hentikan handler, lanjutkan proses normal pesan
 *   (tanpa return)    -> bukan game ini, lanjut ke handler game berikutnya
 */
const {
    getActiveGameInChat,
    deleteGame,
    clearGameTimeout,
    getGameByPlayer,
    updateGame,
    setGameTimeout
} = require('../gameHandler');

const { addMoney, addLevelCache } = require('../user');

module.exports = async (ctx) => {
    const { Yudzxml, m, text, config, ppuser, prefix, gameSession, suitSession, game_over } = ctx;

    if (gameSession.typegame === 'tebak_bom') {
        const data = gameSession.data;
        const pilihan = Number(text);
        const angkaEmoji = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣'];
        const buatPapan = (grid, terbuka = []) => {
            const buka = new Set(terbuka);
            let out = '';

            for (let i = 0; i < 3; i++) {
                for (let j = 0; j < 3; j++) {
                    const idx = i * 3 + j + 1;
                    out += buka.has(idx) ? `[${grid[i][j]}] ` : `[${angkaEmoji[idx - 1]}] `;
                }
                out += '\n';
            }
            return out;
        };

        if (text === 'nyerah' || text === 'menyerah') {
            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: game_over },
                    caption: `Yahh menyerah 😔
💣 *Posisi Bom:* ${data.bom}

 ${buatPapan(data.grid, [...data.terbuka, data.bom])}

Masih berani coba lagi?
Ketik *.tebakbom*`
                },
                { quoted: m }
            );

            clearGameTimeout(m.chat);
            deleteGame(gameSession.typegame, m.chat);
            return false;
        }

        if (!pilihan) return false;

        if (pilihan === data.bom) {
            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: game_over },
                    caption: `💥 *BOOM!* 💥
Kamu membuka kotak terlarang!

 ${buatPapan(data.grid, [...data.terbuka, data.bom])}

_Game Over_
Ingin balas dendam?
Ketik *.tebakbom*`
                },
                { quoted: m }
            );

            clearGameTimeout(m.chat);
            deleteGame(gameSession.typegame, m.chat);
            return false;
        }

        data.terbuka.push(pilihan);

        if (data.terbuka.length >= 8) {
            addMoney(m.sender, data.price);
            addLevelCache(m.sender, data.price);

            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: ppuser },
                    caption: `
🎉 *BOM BERHASIL DIJINAKKAN!* 🎉

❏ *Game:* Tebak Bom
❏ *Pemenang:* @${m.sender.split('@')[0]}
───────────────────
🎁 *Hadiah*
💵 Money : +${data.price}
⭐ Exp   : +${data.price}
───────────────────

 ${buatPapan(data.grid, [...data.terbuka, data.bom])}

_Misi selesai dengan selamat._
Ketik *.tebakbom* untuk bermain lagi
`
                },
                {
                    quoted: m,
                    mentions: [m.sender]
                }
            );

            clearGameTimeout(m.chat);
            deleteGame(gameSession.typegame, m.chat);
            return false;
        }

        await Yudzxml.sendMessage(
            m.chat,
            {
                text: `✅ *Aman!*

 ${buatPapan(data.grid, data.terbuka)}

⏳ Satu kotak salah, tamat riwayat.`
            },
            { quoted: m }
        );

        return true;
    }
};

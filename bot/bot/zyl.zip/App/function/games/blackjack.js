/**
 * games/blackjack.js — Handler game Blackjack.
 * Diekstrak dari actionGameHandler.js (1 game = 1 file) agar mudah dirawat.
 *
 * Kontrak:
 *   return false      -> pesan dikonsumsi game ini (hentikan seluruh handler)
 *   return true       -> hentikan handler, lanjutkan proses normal pesan
 *   (tanpa return)    -> bukan game ini, lanjut ke handler game berikutnya
 */
const {
    getActiveGameInChat,
    deleteGame,
    clearGameTimeout,
    getGameByPlayer,
    updateGame,
    setGameTimeout
} = require('../gameHandler');

const { addMoney, addLevelCache } = require('../user');

module.exports = async (ctx) => {
    const { Yudzxml, m, text, config, ppuser, prefix, gameSession, suitSession, game_over } = ctx;

    if (gameSession.typegame === 'blackjack') {
        const data = gameSession.data;

        const calculate = (hand) => {
            let total = 0;
            let ace = 0;

            for (const card of hand) {
                if (card === 'A') {
                    total += 11;
                    ace++;
                } else if (card === 'J' || card === 'Q' || card === 'K') {
                    total += 10;
                } else {
                    total += Number(card);
                }
            }

            while (total > 21 && ace > 0) {
                total -= 10;
                ace--;
            }

            return total;
        };

        const cards = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];

        const drawCard = () => cards[Math.floor(Math.random() * cards.length)];

        const cmd = text.toLowerCase();

        if (cmd === 'nyerah' || cmd === 'menyerah') {
            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: game_over },
                    caption: `
🏳️ *MENYERAH!*

🤖 Dealer
${data.dealer.join(' ')}
Total: ${calculate(data.dealer)}

🎮 Kamu
${data.player.join(' ')}
Total: ${calculate(data.player)}

Ketik *.blackjack* untuk bermain lagi
`
                },
                { quoted: m }
            );

            clearGameTimeout(m.chat);
            deleteGame(gameSession.typegame, m.chat);
            return false;
        }

        if (cmd === 'hit') {
            data.player.push(drawCard());

            const totalPlayer = calculate(data.player);

            if (totalPlayer > 21) {
                await Yudzxml.sendMessage(
                    m.chat,
                    {
                        image: { url: game_over },
                        caption: `
💥 *BUST!*

🎮 Kamu
${data.player.join(' ')}
Total: ${totalPlayer}

Kamu melewati 21.

Ketik *.blackjack* untuk bermain lagi
`
                    },
                    { quoted: m }
                );

                clearGameTimeout(m.chat);
                deleteGame(gameSession.typegame, m.chat);
                return false;
            }

            await Yudzxml.sendMessage(
                m.chat,
                {
                    text: `
🃏 *BLACKJACK*

🤖 Dealer
[ ${data.dealer[0]} ] [ ? ]

🎮 Kamu
${data.player.join(' ')}

Total: *${totalPlayer}*

🟢 ketik *hit*
🔴 ketik *stand*
`
                },
                { quoted: m }
            );

            return true;
        }

        if (cmd === 'stand') {
            while (calculate(data.dealer) < 17) {
                data.dealer.push(drawCard());
            }

            const dealerScore = calculate(data.dealer);
            const playerScore = calculate(data.player);

            let result = '';
            let winner = false;

            if (dealerScore > 21) {
                result = '🎉 Dealer Bust!';
                winner = true;
            } else if (playerScore > dealerScore) {
                result = '🎉 Kamu Menang!';
                winner = true;
            } else if (playerScore < dealerScore) {
                result = '🤖 Dealer Menang!';
            } else {
                result = '🤝 Seri!';
            }

            if (winner) {
                addMoney(m.sender, data.price);
                addLevelCache(m.sender, data.price);
            }

            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: {
                        url: winner ? ppuser : game_over
                    },
                    caption: `
${result}

🤖 Dealer
${data.dealer.join(' ')}
Total: ${dealerScore}

🎮 Kamu
${data.player.join(' ')}
Total: ${playerScore}

${
    winner
        ? `🎁 Hadiah
💵 Money : +${data.price}
⭐ Exp   : +${data.price}`
        : ''
}

Ketik *.blackjack* untuk bermain lagi
`
                },
                {
                    quoted: m,
                    mentions: winner ? [m.sender] : []
                }
            );

            clearGameTimeout(m.chat);
            deleteGame(gameSession.typegame, m.chat);
            return false;
        }

        return false;
    }
};

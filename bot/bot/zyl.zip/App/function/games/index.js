/**
 * games/index.js — Dispatcher semua handler game tebak/suit/pvp.
 *
 * Sebelumnya seluruh logic 24 game ada di satu file actionGameHandler.js (±2000 baris).
 * Sekarang 1 game = 1 file di folder ini. Urutan pengecekan SAMA PERSIS dengan file asli:
 *   1. Suit PvP (berbasis pemain, bukan chat)
 *   2. Guard: tidak ada game aktif di chat -> lanjut proses normal
 *   3. Game per-chat sesuai urutan asli
 *
 * Cara menambah game baru:
 *   1. Buat file baru, mis. games/tebakJenaka.js (copy pola dari asahOtak.js)
 *   2. Daftarkan di GAMES di bawah sesuai urutan pengecekan yang diinginkan
 */
const { getGameByPlayer, getActiveGameInChat } = require('../gameHandler');

const suitPvp = require('./suitPvp');
const asahOtak = require('./asahOtak');
const tebakAnime = require('./tebakAnime');
const cakLontong = require('./cakLontong');
const family100 = require('./family100');
const math = require('./math');
const siapakahAku = require('./siapakahAku');
const susunKata = require('./susunKata');
const tebakBendera = require('./tebakBendera');
const tebakEmoji = require('./tebakEmoji');
const tebakEpep = require('./tebakEpep');
const tebakGambar = require('./tebakGambar');
const tebakHeroMl = require('./tebakHeroMl');
const tebakHewan = require('./tebakHewan');
const tebakKalimat = require('./tebakKalimat');
const tebakKode = require('./tebakKode');
const tebakLirik = require('./tebakLirik');
const tebakMakanan = require('./tebakMakanan');
const tebakTebakan = require('./tebakTebakan');
const tebakTempat = require('./tebakTempat');
const tekaTeki = require('./tekaTeki');
const tebakBom = require('./tebakBom');
const tictactoe = require('./tictactoe');
const blackjack = require('./blackjack');

const GAMES = [suitPvp, asahOtak, tebakAnime, cakLontong, family100, math, siapakahAku, susunKata, tebakBendera, tebakEmoji, tebakEpep, tebakGambar, tebakHeroMl, tebakHewan, tebakKalimat, tebakKode, tebakLirik, tebakMakanan, tebakTebakan, tebakTempat, tekaTeki, tebakBom, tictactoe, blackjack];

module.exports = async (Yudzxml, m, budy, config, ppuser, prefix) => {
    const text = budy.toLowerCase().trim();
    const { game_over } = config.thumbnail;
    const suitSession = getGameByPlayer(m.sender);
    const gameSession = getActiveGameInChat(m.chat);

    const ctx = { Yudzxml, m, budy, config, ppuser, prefix, text, gameSession, suitSession, game_over };

    const run = async (game) => {
        const r = await game(ctx);
        if (r === false) return 'consumed';
        if (r === true) return 'stop';
        return 'skip';
    };

    // 1) Suit PvP — berbasis pemain, dicek duluan (sama seperti file asli).
    const suitResult = await run(suitPvp);
    if (suitResult === 'consumed') return false;
    if (suitResult === 'stop') return true;

    // 2) Tidak ada game aktif di chat ini -> lanjut proses normal.
    if (!gameSession) return true;

    // 3) Game per-chat, urutan identik dengan file asli.
    for (const game of GAMES.slice(1)) {
        const result = await run(game);
        if (result === 'consumed') return false;
        if (result === 'stop') return true;
    }

    return true;
};

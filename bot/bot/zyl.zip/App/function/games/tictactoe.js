/**
 * games/tictactoe.js — Handler game TicTacToe.
 * Diekstrak dari actionGameHandler.js (1 game = 1 file) agar mudah dirawat.
 *
 * Kontrak:
 *   return false      -> pesan dikonsumsi game ini (hentikan seluruh handler)
 *   return true       -> hentikan handler, lanjutkan proses normal pesan
 *   (tanpa return)    -> bukan game ini, lanjut ke handler game berikutnya
 */
const {
    getActiveGameInChat,
    deleteGame,
    clearGameTimeout,
    getGameByPlayer,
    updateGame,
    setGameTimeout
} = require('../gameHandler');

const { addMoney, addLevelCache } = require('../user');

module.exports = async (ctx) => {
    const { Yudzxml, m, text, config, ppuser, prefix, gameSession, suitSession, game_over } = ctx;

    if (gameSession.typegame === 'tictactoe') {
        const data = gameSession.data;

        const renderBoard = (board) => {
            return `
[${board[0]}] [${board[1]}] [${board[2]}]
[${board[3]}] [${board[4]}] [${board[5]}]
[${board[6]}] [${board[7]}] [${board[8]}]
`.trim();
        };

        const cekMenang = (board, symbol) => {
            const win = [
                [0, 1, 2],
                [3, 4, 5],
                [6, 7, 8],
                [0, 3, 6],
                [1, 4, 7],
                [2, 5, 8],
                [0, 4, 8],
                [2, 4, 6]
            ];

            return win.some((line) => line.every((i) => board[i] === symbol));
        };

        const isParticipant = m.sender === data.players['❌'] || m.sender === data.players['⭕'];

        if (!isParticipant) return false;

        const mySymbol = data.symbols[m.sender];
        const lawanSymbol = mySymbol === '❌' ? '⭕' : '❌';
        const lawanId = data.players[lawanSymbol];

        if (text === 'nyerah' || text === 'menyerah') {
            if (data.isPvp) {
                addMoney(lawanId, data.price);
                addLevelCache(lawanId, data.price);

                await Yudzxml.sendMessage(
                    m.chat,
                    {
                        image: { url: ppuser },
                        caption: `🏳️ *MENYERAH!*

@${m.sender.split('@')[0]} menyerah dari pertandingan.
Kemenangan untuk @${lawanId.split('@')[0]} 🎉

${renderBoard(data.board)}

Ketik *.tictactoe* untuk bermain lagi`
                    },
                    { quoted: m, mentions: [m.sender, lawanId] }
                );
            } else {
                await Yudzxml.sendMessage(
                    m.chat,
                    {
                        image: { url: game_over },
                        caption: `🏳️ *MENYERAH!*

${renderBoard(data.board)}

Yahh kamu menyerah dari pertandingan.

Ketik *.tictactoe* untuk bermain lagi`
                    },
                    { quoted: m }
                );
            }

            clearGameTimeout(m.chat);
            deleteGame(gameSession.typegame, m.chat);
            return false;
        }

        const posisi = Number(text);

        if (!posisi || posisi < 1 || posisi > 9) return false;

        if (m.sender !== data.turn) {
            return m.reply('⏳ Belum giliranmu, tunggu lawan jalan dulu.');
        }

        if (data.board[posisi - 1] === '❌' || data.board[posisi - 1] === '⭕') {
            return m.reply('⚠️ Posisi sudah terisi.');
        }

        data.board[posisi - 1] = mySymbol;

        if (cekMenang(data.board, mySymbol)) {
            addMoney(m.sender, data.price);
            addLevelCache(m.sender, data.price);

            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: ppuser },
                    caption: `
🎉 *KAMU MENANG!* 🎉

❏ *Game:* TicTacToe
❏ *Pemenang:* @${m.sender.split('@')[0]}
───────────────────
🎁 *Hadiah*
💵 Money : +${data.price}
⭐ Exp   : +${data.price}
───────────────────

${renderBoard(data.board)}

Ketik *.tictactoe* untuk bermain lagi`
                },
                {
                    quoted: m,
                    mentions: [m.sender]
                }
            );

            clearGameTimeout(m.chat);
            deleteGame(gameSession.typegame, m.chat);
            return false;
        }

        const masihAdaKosong = data.board.some((v) => v !== '❌' && v !== '⭕');

        if (data.isPvp) {
            if (!masihAdaKosong) {
                await Yudzxml.sendMessage(
                    m.chat,
                    {
                        text: `
🤝 *PERTANDINGAN SERI!*

${renderBoard(data.board)}

Tidak ada pemenang kali ini.
`
                    },
                    { quoted: m }
                );

                clearGameTimeout(m.chat);
                deleteGame(gameSession.typegame, m.chat);
                return false;
            }

            data.turn = lawanId;

            await Yudzxml.sendMessage(
                m.chat,
                {
                    text: `
🎮 *Giliran @${lawanId.split('@')[0]}*

${renderBoard(data.board)}

❌ @${data.players['❌'].split('@')[0]}
⭕ @${data.players['⭕'].split('@')[0]}

Pilih angka yang masih tersedia.
`
                },
                {
                    quoted: m,
                    mentions: [data.players['❌'], data.players['⭕']]
                }
            );

            return true;
        }

        const kosong = data.board.map((v, i) => ({ v, i })).filter((v) => v.v !== '❌' && v.v !== '⭕');

        if (kosong.length > 0) {
            const botMove = kosong[Math.floor(Math.random() * kosong.length)];

            data.board[botMove.i] = '⭕';
        }

        if (cekMenang(data.board, '⭕')) {
            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: game_over },
                    caption: `
🤖 *BOT MENANG!*

${renderBoard(data.board)}

Coba lagi dan kalahkan bot!

Ketik *.tictactoe*`
                },
                { quoted: m }
            );

            clearGameTimeout(m.chat);
            deleteGame(gameSession.typegame, m.chat);
            return false;
        }

        const masihAdaKosongSetelahBot = data.board.some((v) => v !== '❌' && v !== '⭕');

        if (!masihAdaKosongSetelahBot) {
            await Yudzxml.sendMessage(
                m.chat,
                {
                    text: `
🤝 *PERTANDINGAN SERI!*

${renderBoard(data.board)}

Tidak ada pemenang kali ini.
`
                },
                { quoted: m }
            );

            clearGameTimeout(m.chat);
            deleteGame(gameSession.typegame, m.chat);
            return false;
        }

        await Yudzxml.sendMessage(
            m.chat,
            {
                text: `
🎮 *Giliran Kamu*

${renderBoard(data.board)}

❌ Kamu
⭕ Bot

Pilih angka yang masih tersedia.
`
            },
            { quoted: m }
        );

        return true;
    }
};

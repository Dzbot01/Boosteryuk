/**
 * games/family100.js — Handler game Family 100.
 * Diekstrak dari actionGameHandler.js (1 game = 1 file) agar mudah dirawat.
 *
 * Kontrak:
 *   return false      -> pesan dikonsumsi game ini (hentikan seluruh handler)
 *   return true       -> hentikan handler, lanjutkan proses normal pesan
 *   (tanpa return)    -> bukan game ini, lanjut ke handler game berikutnya
 */
const {
    getActiveGameInChat,
    deleteGame,
    clearGameTimeout,
    getGameByPlayer,
    updateGame,
    setGameTimeout
} = require('../gameHandler');

const { addMoney, addLevelCache } = require('../user');

module.exports = async (ctx) => {
    const { Yudzxml, m, text, config, ppuser, prefix, gameSession, suitSession, game_over } = ctx;

    if (gameSession.typegame === 'family100') {
        const data = gameSession.data;
        const answers = data.answers;
        const answered = data.answered;
        const total = answers.length;

        const renderBoard = () => {
            return answers
                .map((v, i) => {
                    return answered.includes(v) ? `${i + 1}. ${v}` : `${i + 1}. ❔`;
                })
                .join('\n');
        };

        if (text === 'nyerah' || text === 'menyerah') {
            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: game_over },
                    caption: [
                        'Yahh Menyerah 😔',
                        '',
                        '✅ Jawaban yang benar:',
                        answers.map((v, i) => `${i + 1}. ${v}`).join('\n'),
                        '',
                        'Ingin bermain lagi?',
                        `Ketik *.family100*`
                    ].join('\n')
                },
                { quoted: m }
            );

            clearGameTimeout(m.chat);
            deleteGame(gameSession.typegame, m.chat);
            return false;
        }

        if (answers.includes(text) && !answered.includes(text)) {
            const index = answers.indexOf(text);
            const nomor = index + 1;

            answered.push(text);

            const progress = `${answered.length}/${total}`;

            if (answered.length === total) {
                addMoney(m.sender, data.price);
                addLevelCache(m.sender, data.price);

                await Yudzxml.sendMessage(
                    m.chat,
                    {
                        image: { url: ppuser },
                        caption: [
                            '🎉 *SEMUA JAWABAN TERTEBAK!* 🎉',
                            '',
                            `❏ *Game:* Family 100`,
                            `❏ *Soal:* ${data.soal}`,
                            '',
                            renderBoard(),
                            '───────────────────',
                            '🎁 *Hadiah*',
                            `💵 Money : +${data.price}`,
                            `⭐ Exp   : +${data.price}`,
                            '───────────────────',
                            '_Ingin bermain lagi?_',
                            `Ketik *.family100*`
                        ].join('\n')
                    },
                    {
                        quoted: m,
                        mentions: [m.sender]
                    }
                );

                clearGameTimeout(m.chat);
                deleteGame(gameSession.typegame, m.chat);
                return false;
            }

            await m.reply(
                ['✅ *BENAR!*', `📌 Jawaban nomor *${nomor}*`, '', renderBoard(), '', `📊 Progres: *${progress}*`].join(
                    '\n'
                )
            );

            return false;
        }

        if (answered.includes(text)) {
            await m.reply('⚠️ Jawaban itu sudah disebutkan.');
            return false;
        }

        return true;
    }
};

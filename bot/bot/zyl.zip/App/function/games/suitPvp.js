/**
 * games/suitPvp.js — Handler game Suit PvP.
 * Diekstrak dari actionGameHandler.js (1 game = 1 file) agar mudah dirawat.
 *
 * Kontrak:
 *   return false      -> pesan dikonsumsi game ini (hentikan seluruh handler)
 *   return true       -> hentikan handler, lanjutkan proses normal pesan
 *   (tanpa return)    -> bukan game ini, lanjut ke handler game berikutnya
 */
const {
    getActiveGameInChat,
    deleteGame,
    clearGameTimeout,
    getGameByPlayer,
    updateGame,
    setGameTimeout
} = require('../gameHandler');

const { addMoney, addLevelCache } = require('../user');

module.exports = async (ctx) => {
    const { Yudzxml, m, text, config, ppuser, prefix, gameSession, suitSession, game_over } = ctx;

    if (suitSession && suitSession.typegame === 'suit_pvp') {
        const { typegame, chatId, data } = suitSession;

        if (m.chat === chatId && data.status === 'WAIT_ACCEPT') {
            if (m.sender !== data.p2) return true;

            if (['terima', 'gas', 'oke', 'accept'].includes(text)) {
                updateGame(typegame, chatId, { status: 'PLAYING', move: {} });

                setGameTimeout(chatId, 20000, async () => {
                    const session = getActiveGameInChat(chatId);
                    if (!session || session.data.status !== 'PLAYING') return;

                    m.reply(
                        `⏰ *TIMEOUT!*

❌ Salah satu pemain tidak mengirim pilihan tepat waktu.

👤 @${session.data.p1.split('@')[0]} vs @${session.data.p2.split('@')[0]}

🎮 Game dibatalkan.`,
                        chatId,
                        { mentionedJid: [session.data.p1, session.data.p2] }
                    );

                    clearGameTimeout(chatId);
                    deleteGame(session.typegame || 'suit_pvp', chatId);
                });

                m.reply(
                    `🎮 SUIT DIMULAI

👤 @${data.p1.split('@')[0]} vs @${data.p2.split('@')[0]}

⚔️ Pilih salah satu:
🗿 Batu
✂️ Gunting
📄 Kertas

👉 Kirim pilihan ke wa.me/${Yudzxml.user.id.split('@')[0].split(':')[0]}`,
                    chatId,
                    { mentionedJid: [data.p1, data.p2] }
                );

                return false;
            }
        }

        if (data.status === 'PLAYING') {
            if (![data.p1, data.p2].includes(m.sender)) return true;

            if (!['batu', 'gunting', 'kertas'].includes(text)) return true;

            const currentMoves = data.move || {};
            currentMoves[m.sender] = text;

            updateGame(typegame, chatId, { move: currentMoves });

            setGameTimeout(chatId, 20000, async () => {
                const session = getActiveGameInChat(chatId);
                if (!session || session.data.status !== 'PLAYING') return;

                const freshMoves = session.data.move || {};

                if (!freshMoves[session.data.p1] || !freshMoves[session.data.p2]) {
                    m.reply(
                        `⏰ *TIMEOUT!*

❌ Salah satu pemain tidak merespon.

👤 @${session.data.p1.split('@')[0]} vs @${session.data.p2.split('@')[0]}

🎮 Game dibatalkan.`,
                        chatId,
                        { mentionedJid: [session.data.p1, session.data.p2] }
                    );

                    clearGameTimeout(chatId);
                    deleteGame(session.typegame || 'suit_pvp', chatId);
                }
            });

            if (currentMoves[data.p1] && currentMoves[data.p2]) {
                const p1 = currentMoves[data.p1];
                const p2 = currentMoves[data.p2];

                let result = '';

                if (p1 === p2) {
                    result = 'DRAW 🤝';
                } else if (
                    (p1 === 'batu' && p2 === 'gunting') ||
                    (p1 === 'gunting' && p2 === 'kertas') ||
                    (p1 === 'kertas' && p2 === 'batu')
                ) {
                    result = `🏆 P1 MENANG: @${data.p1.split('@')[0]}`;
                } else {
                    result = `🏆 P2 MENANG: @${data.p2.split('@')[0]}`;
                }

                m.reply(
                    `🎮 *SUIT RESULT*

👤 @${data.p1.split('@')[0]} vs @${data.p2.split('@')[0]}

━━━━━━━━━━
P1: ${p1}
P2: ${p2}
━━━━━━━━━━

${result}`,
                    chatId,
                    { mentionedJid: [data.p1, data.p2] }
                );

                clearGameTimeout(chatId);
                deleteGame(typegame, chatId);

                return false;
            }

            return false;
        }
    }
};

/**
 * games/tebakHewan.js — Handler game Tebak Hewan.
 * Diekstrak dari actionGameHandler.js (1 game = 1 file) agar mudah dirawat.
 *
 * Kontrak:
 *   return false      -> pesan dikonsumsi game ini (hentikan seluruh handler)
 *   return true       -> hentikan handler, lanjutkan proses normal pesan
 *   (tanpa return)    -> bukan game ini, lanjut ke handler game berikutnya
 */
const {
    getActiveGameInChat,
    deleteGame,
    clearGameTimeout,
    getGameByPlayer,
    updateGame,
    setGameTimeout
} = require('../gameHandler');

const { addMoney, addLevelCache } = require('../user');

module.exports = async (ctx) => {
    const { Yudzxml, m, text, config, ppuser, prefix, gameSession, suitSession, game_over } = ctx;

    if (gameSession.typegame === 'tebak_hewan') {
        const data = gameSession.data;
        const jawaban = data.jawaban;
        const fullimg = data.fullimg;

        if (text === 'nyerah' || text === 'menyerah') {
            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: fullimg },
                    caption: `Yahh Menyerah 😔
💡 Jawaban: *${jawaban}*

Ingin bermain lagi?
Ketik *.tebakhewan*`
                },
                { quoted: m }
            );

            clearGameTimeout(m.chat);
            deleteGame(gameSession.typegame, m.chat);
            return false;
        }

        if (text === jawaban.toLowerCase()) {
            addMoney(m.sender, data.price);
            addLevelCache(m.sender, data.price);

            await Yudzxml.sendMessage(
                m.chat,
                {
                    image: { url: fullimg },
                    caption: `
🎉 *Selamat Kamu Menang!* 🎉

❏ *Game:* Tebak Hewan
❏ *Jawaban:* ${jawaban}
❏ *Pemenang:* @${m.sender.split('@')[0]}
───────────────────
🎁 *Hadiah*
💵 Money : +${data.price}
⭐ Exp   : +${data.price}
───────────────────
_Ingin bermain lagi?_
Ketik *.tebakhewan*`
                },
                {
                    quoted: m,
                    mentions: [m.sender]
                }
            );

            clearGameTimeout(m.chat);
            deleteGame(gameSession.typegame, m.chat);
            return false;
        }

        return true;
    }
};

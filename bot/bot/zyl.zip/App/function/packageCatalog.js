const config = require('@Config');

const TYPES = ['jadibot', 'sewabot', 'premium'];

const slugify = (value) =>
    String(value || '')
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-+|-+$/g, '');

const typeEnabled = (type) => {
    const section = config[type];
    return section ? section.enabled !== false : false;
};

const packagesOfType = (type) => {
    const section = config[type];
    const list = section && Array.isArray(section.packages) ? section.packages : [];
    return list
        .filter((pkg) => pkg && pkg.name !== undefined && pkg.price !== undefined)
        .map((pkg) => ({
            id: String(pkg.id || `${type}-${slugify(pkg.name)}`),
            type,
            name: String(pkg.name),
            price: Number(pkg.price) || 0,
            days: Number(pkg.days) || 0,
            description: pkg.description ? String(pkg.description) : null,
            enabled: typeEnabled(type)
        }));
};

const listPackages = () => TYPES.flatMap((type) => packagesOfType(type));

const resolvePackage = (idOrName) => {
    const needle = String(idOrName || '').trim();
    if (!needle) return null;

    const all = listPackages();
    const byId = all.filter((pkg) => pkg.id.toLowerCase() === needle.toLowerCase());
    if (byId.length === 1) return byId[0];

    const byName = all.filter((pkg) => pkg.name.toLowerCase() === needle.toLowerCase());
    if (byName.length === 1) return byName[0];
    if (byName.length > 1) {
        return { ambiguous: true, options: byName.map((pkg) => pkg.id) };
    }

    if (TYPES.includes(needle.toLowerCase())) {
        const type = needle.toLowerCase();
        const ofType = all.filter((pkg) => pkg.type === type && pkg.enabled);
        if (ofType.length === 1) return ofType[0];
        return { type, ambiguous: true, options: ofType.map((pkg) => pkg.id) };
    }

    return null;
};

const getPackageById = (packageId) => {
    const all = listPackages();
    return all.find((pkg) => pkg.id === String(packageId || '').trim()) || null;
};

module.exports = {
    TYPES,
    slugify,
    listPackages,
    packagesOfType,
    resolvePackage,
    getPackageById
};

const fs = require('fs');
const path = require('path');
const logger = require('./logger');
const { loadDB: loadDBFile, saveDB: saveDBFile } = require('../../database/wrappers/storage');
const blacklistPath = path.join(__dirname, '../../Storage/blacklistplugins.json');
const pluginsPath = path.join(__dirname, '..', 'plugins');

const loadBlacklist = () => {
    const data = loadDBFile(blacklistPath, []);
    return Array.isArray(data) ? data : [];
};

const saveBlacklist = (data) => {
    saveDBFile(blacklistPath, data);
};

const disablePlugin = (pluginName) => {
    const data = loadBlacklist();
    const name = pluginName.toLowerCase();

    if (!data.includes(name)) {
        data.push(name);
        saveBlacklist(data);
    }

    refreshPlugins();
    return `Plugin ${pluginName} berhasil dinonaktifkan`;
};

const enablePlugin = (pluginName) => {
    const data = loadBlacklist();
    const name = pluginName.toLowerCase();

    const filtered = data.filter((p) => p !== name);
    saveBlacklist(filtered);

    refreshPlugins();
    return `Plugin ${pluginName} berhasil diaktifkan kembali`;
};

const isPluginDisabled = (pluginName) => {
    const data = loadBlacklist();
    return data.includes(pluginName.toLowerCase());
};

const loadPlugins = () => {
    const plugins = [];

    if (!fs.existsSync(pluginsPath)) {
        console.error(`Direktori plugin tidak ditemukan: ${pluginsPath}`);
        return plugins;
    }

    try {
        const pluginDirs = fs
            .readdirSync(pluginsPath, { withFileTypes: true })
            .filter((d) => d.isDirectory())
            .map((d) => d.name);

        for (const category of pluginDirs) {
            const categoryPath = path.join(pluginsPath, category);
            const files = fs.readdirSync(categoryPath).filter((file) => file.endsWith('.js'));

            for (const file of files) {
                const pluginPath = path.join(categoryPath, file);

                try {
                    delete require.cache[require.resolve(pluginPath)];
                    const plugin = require(pluginPath);

                    plugins.push({
                        name: file.replace('.js', ''),
                        category,
                        ...plugin
                    });
                } catch (err) {
                    console.error(`Error loading plugin ${file}:`, err);
                }
            }
        }
    } catch (err) {
        console.error('Error membaca direktori plugin:', err);
    }

    return plugins;
};

const pluginState = {
    pluginsList: [],
    commandMap: new Map(),
    eventPlugins: []
};

const refreshPlugins = () => {
    try {
        const loaded = loadPlugins();
        const blacklist = new Set(loadBlacklist().map((p) => p.toLowerCase()));

        pluginState.pluginsList = [];
        pluginState.commandMap.clear();
        pluginState.eventPlugins.length = 0;
        pluginState.collisions = [];

        const commandOwners = new Map();
        const usedKeys = new Set();
        const usedAliases = new Set();

        for (const plugin of loaded) {
            if (blacklist.has(plugin.name.toLowerCase())) continue;

            pluginState.pluginsList.push(plugin);

            if (Array.isArray(plugin.commands) && plugin.commands.length) {
                const effectiveCommands = [];

                for (const cmd of plugin.commands) {
                    const key = String(cmd).toLowerCase();

                    if (!commandOwners.has(key)) {
                        commandOwners.set(key, `${plugin.category}/${plugin.name}`);
                        effectiveCommands.push(cmd);
                        pluginState.commandMap.set(key, plugin);
                        usedKeys.add(key);
                        continue;
                    }

                    let alias = `${key}_${plugin.category.toLowerCase()}`;
                    let n = 2;
                    while (usedKeys.has(alias) || usedAliases.has(alias))
                        alias = `${key}_${plugin.category.toLowerCase()}${n++}`;

                    effectiveCommands.push(alias);
                    usedAliases.add(alias);
                    pluginState.commandMap.set(alias, plugin);

                    const collision = {
                        command: key,
                        winner: commandOwners.get(key),
                        loser: `${plugin.category}/${plugin.name}`,
                        alias
                    };
                    pluginState.collisions.push(collision);
                    logger.warning(
                        `COMMAND BENTROK: .${key} dipakai ${collision.winner} & ${collision.loser}. ` +
                            `Plugin pertama menang, plugin kedua bisa dipanggil dengan .${alias}`
                    );
                }

                plugin.commands = effectiveCommands;
            } else {
                pluginState.eventPlugins.push(plugin);
            }
        }

        if (pluginState.collisions.length) {
            const detail = pluginState.collisions
                .map((c) => `  .${c.command} → ${c.winner} (asli), ${c.loser} → .${c.alias}`)
                .join('\n');
            logger.warning(`Total ${pluginState.collisions.length} command bentrok otomatis diberi alias:\n${detail}`);
        }
    } catch (err) {
        logger.error(`Error refresh plugin: ${err}`);
    }
};

const addPlugins = (category, pluginName, code) => {
    if (!category || !pluginName || !code) {
        throw new Error('Parameter addPlugin tidak lengkap');
    }

    const categoryPath = path.join(pluginsPath, category);
    const pluginFile = path.join(categoryPath, `${pluginName}.js`);

    if (!fs.existsSync(categoryPath)) {
        fs.mkdirSync(categoryPath, { recursive: true });
    }

    if (fs.existsSync(pluginFile)) {
        throw new Error(`Plugin ${pluginName}.js sudah ada`);
    }

    fs.writeFileSync(pluginFile, code.trim(), 'utf-8');
    return `✅ Plugin ${pluginName}.js berhasil ditambahkan ke kategori ${category}`;
};

const removePlugins = (category, pluginName) => {
    if (!category || !pluginName) {
        throw new Error('Parameter removePlugin tidak lengkap');
    }

    const pluginFile = path.join(pluginsPath, category, `${pluginName}.js`);

    if (!fs.existsSync(pluginFile)) {
        throw new Error(`Plugin ${pluginName}.js tidak ditemukan`);
    }

    const resolved = require.resolve(pluginFile);
    if (require.cache[resolved]) delete require.cache[resolved];

    fs.unlinkSync(pluginFile);
    return `🗑️ Plugin ${pluginName}.js berhasil dihapus`;
};

const listPlugins = () => {
    const result = {};

    if (!fs.existsSync(pluginsPath)) {
        console.error(`Direktori plugin tidak ditemukan: ${pluginsPath}`);
        return result;
    }

    try {
        const categories = fs
            .readdirSync(pluginsPath, { withFileTypes: true })
            .filter((d) => d.isDirectory())
            .map((d) => d.name);

        for (const category of categories) {
            const categoryPath = path.join(pluginsPath, category);
            const files = fs
                .readdirSync(categoryPath, { withFileTypes: true })
                .filter((f) => f.isFile() && f.name.endsWith('.js'))
                .map((f) => ({
                    file: f.name,
                    name: f.name.replace('.js', '')
                }));

            if (files.length) result[category] = files;
        }
    } catch (err) {
        console.error('Gagal membaca daftar plugin:', err);
    }

    return result;
};

const getPlugins = (category, pluginName) => {
    if (!category || !pluginName) {
        throw new Error('Parameter getPlugin tidak lengkap');
    }

    const pluginFile = path.join(pluginsPath, category, `${pluginName}.js`);

    if (!fs.existsSync(pluginFile)) {
        throw new Error(`Plugin ${pluginName}.js tidak ditemukan`);
    }

    return {
        category,
        name: pluginName,
        file: `${pluginName}.js`,
        code: fs.readFileSync(pluginFile, 'utf-8')
    };
};

const findPlugins = (inputCommand, plugins, options = {}) => {
    if (!inputCommand || !Array.isArray(plugins)) return null;

    const { maxDistanceRatio = 0.35, minSimilarity = 0.7 } = options;

    inputCommand = String(inputCommand).toLowerCase().trim();

    let bestMatch = null;
    let bestSimilarity = 0;

    for (const plugin of plugins) {
        if (!Array.isArray(plugin.commands)) continue;

        for (const cmd of plugin.commands) {
            const command = String(cmd).toLowerCase().trim();

            if (command === inputCommand) {
                return { plugin, command: cmd, similarity: 1, type: 'exact' };
            }

            if (
                (command.includes(inputCommand) || inputCommand.includes(command)) &&
                Math.abs(command.length - inputCommand.length) <= 2
            ) {
                return { plugin, command: cmd, similarity: 0.9, type: 'substring' };
            }

            const distance = levenshteinDistance(inputCommand, command);
            const maxLen = Math.max(inputCommand.length, command.length);
            const similarity = 1 - distance / maxLen;

            if (similarity < minSimilarity) continue;

            if (similarity > bestSimilarity) {
                bestSimilarity = similarity;
                bestMatch = { plugin, command: cmd, similarity, type: 'fuzzy' };
            }
        }
    }

    return bestMatch;
};

const levenshteinDistance = (a, b) => {
    const dp = Array.from({ length: b.length + 1 }, () => []);

    for (let i = 0; i <= b.length; i++) dp[i][0] = i;
    for (let j = 0; j <= a.length; j++) dp[0][j] = j;

    for (let i = 1; i <= b.length; i++) {
        for (let j = 1; j <= a.length; j++) {
            dp[i][j] =
                b[i - 1] === a[j - 1]
                    ? dp[i - 1][j - 1]
                    : Math.min(dp[i - 1][j - 1] + 1, dp[i][j - 1] + 1, dp[i - 1][j] + 1);
        }
    }

    return dp[b.length][a.length];
};

module.exports = {
    loadPlugins,
    refreshPlugins,
    addPlugins,
    removePlugins,
    listPlugins,
    getPlugins,
    findPlugins,
    pluginState,
    disablePlugin,
    enablePlugin,
    isPluginDisabled
};

const config = require('@Config');

const getWebsiteUrl = () => String(config.store?.website || '').trim();

const buildWebsiteNotice = (featureLine) => {
    const url = getWebsiteUrl();

    const lines = [
        '🛒 *ORDER & KELOLA JADIBOT VIA WEBSITE*',
        '',
        '_Fitur jadibot lewat command WhatsApp sudah dinonaktifkan._',
        '_Order, pembayaran, dan pengelolaan bot jadibot_',
        '_sekarang dilakukan lewat website kami:_',
        '',
        url ? `🌐 *${url}*` : '🌐 _Website belum dikonfigurasi (config.store.website)._'
    ];

    if (featureLine) lines.push('', `📌 ${featureLine}`);

    lines.push(
        '',
        'Di website kamu bisa:',
        '• Order jadibot baru & pilih paket',
        '• Perpanjang masa aktif & aktivasi ulang',
        '• Pairing bot & minta kode pairing baru',
        '• Cek status bot (online, masa aktif, pesan)',
        '• Ganti nama, bio, foto, channel, dll',
        '• Stop / hapus bot',
        '',
        'ℹ️ _Login website: masukkan nomor bot kamu,_',
        '_kode login dikirim otomatis ke WhatsApp._'
    );

    return lines.join('\n');
};

module.exports = { getWebsiteUrl, buildWebsiteNotice };

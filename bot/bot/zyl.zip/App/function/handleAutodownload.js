/**
 * handleAutodownload.js — Entry lama auto-download (kompatibilitas).
 * Logic dipisah ke folder ./autodl/ (net / sender / platforms / dispatcher).
 */
module.exports = require('./autodl');

const path = require('path');
const { loadDB, saveDB } = require('../../database/wrappers/storage');

const DB_PATH = {
    welcome: path.resolve(__dirname, '../../Storage/welcome.json'),
    left: path.resolve(__dirname, '../../Storage/left.json')
};

const readDoc = (filePath) => {
    const data = loadDB(filePath, {});
    return data && typeof data === 'object' && !Array.isArray(data) ? data : {};
};

const writeDoc = (filePath, data) => {
    saveDB(filePath, data);
    return true;
};

const welcomeDB = {
    set(groupJid, config = {}) {
        if (!groupJid) throw new Error('groupJid wajib diisi');

        const db = readDoc(DB_PATH.welcome);

        db[groupJid] = {
            status: config.status ?? 'on',
            typeWelcome: config.typeWelcome ?? 3,
            text: config.text ?? '',
            imageUrl: config.imageUrl ?? null,
            updatedAt: Date.now()
        };

        writeDoc(DB_PATH.welcome, db);
        return true;
    },

    get(groupJid) {
        const db = readDoc(DB_PATH.welcome);
        return db[groupJid] || null;
    },

    delete(groupJid) {
        const db = readDoc(DB_PATH.welcome);
        if (!db[groupJid]) return false;

        delete db[groupJid];
        writeDoc(DB_PATH.welcome, db);
        return true;
    }
};

const leftDB = {
    set(groupJid, config = {}) {
        if (!groupJid) throw new Error('groupJid wajib diisi');

        const db = readDoc(DB_PATH.left);

        db[groupJid] = {
            status: config.status ?? 'on',
            typeWelcome: config.typeWelcome ?? 3,
            text: config.text ?? '',
            imageUrl: config.imageUrl ?? null,
            updatedAt: Date.now()
        };

        writeDoc(DB_PATH.left, db);
        return true;
    },

    get(groupJid) {
        const db = readDoc(DB_PATH.left);
        return db[groupJid] || null;
    },

    delete(groupJid) {
        const db = readDoc(DB_PATH.left);
        if (!db[groupJid]) return false;

        delete db[groupJid];
        writeDoc(DB_PATH.left, db);
        return true;
    }
};

module.exports = {
    welcomeDB,
    leftDB
};

/**
 * orderManager.js — Entry lama sistem order (kompatibilitas).
 * Logic dipisah per-modul di folder ./order/ agar mudah dirawat.
 */
module.exports = require('./order');

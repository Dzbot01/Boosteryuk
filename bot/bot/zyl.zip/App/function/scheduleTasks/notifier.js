/**
 * scheduleTasks/notifier.js — Format & kirim notifikasi terjadwal ke owner.
 */
const config = require('@Config');
const moment = require('moment-timezone');
const { Logger } = require('./logger');
const { TIMEZONE, OWNER_NUMBER, PATHS } = require('./constants');
const { Database } = require('./database');

const Notifier = {
    prayer: async (botInstance, city, chatId, prayerKey, settings) => {
        const now = moment().tz(TIMEZONE);
        const todayStr = now.format('YYYY-MM-DD');
        const timeNow = now.format('HH:mm');

        const kota = city;
        const waktu = prayerKey;

        const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

        const COMMON_BODY = [
            `🕌 _Waktu ${waktu} telah tiba di wilayah ${kota} dan sekitarnya._\n\n_Mari bersiap mengambil 💧 air wudu dan melaksanakan ibadah sholat. 🤲 Semoga Allah menerima amal ibadah kita._`,
            `🕋 Waktu ${waktu} sudah masuk di ${kota} dan sekitarnya.\n💧 Yuk, ambil air wudu dan laksanakan sholat.\n✨ Jangan lupa, sholat tepat waktu itu berkah! 😊`,
            `🌅 _Saatnya menunaikan sholat ${waktu} untuk wilayah ${kota} dan sekitarnya._\n\n💧 Ambil wudu dan laksanakan dengan khusyuk. Semoga hari kita diberkahi! 🤲`,
            `📢 _Pengingat waktu sholat:_\n\n🕌 _Waktu ${waktu} telah tiba di ${kota} dan sekitarnya._\n💧 Ayo ambil air wudu dan tunaikan kewajiban kita!`,
            `✨ _Waktunya untuk mendekatkan diri kepada Allah._\n\n🕌 _Sholat ${waktu} telah tiba di ${kota} dan sekitarnya._\n💧 Mari bersiap dengan mengambil wudu. Semoga keberkahan menyertai kita semua.`
        ];

        const notifMap = {
            Subuh: {
                title: '🌄 Waktu Subuh',
                audio: 'https://cdn.dyxzy.my.id/files/dc71c2ac.opus',
                body: () => pick(COMMON_BODY)
            },
            Dhuhr: {
                title: '🌤️ Waktu Dzuhur',
                audio: 'https://cdn.dyxzy.my.id/files/e3b4aa80.opus',
                body: () => pick(COMMON_BODY)
            },
            Asr: {
                title: '🌇 Waktu Ashar',
                audio: 'https://cdn.dyxzy.my.id/files/e3b4aa80.opus',
                body: () => pick(COMMON_BODY)
            },
            Maghrib: {
                title: '🌆 Waktu Maghrib',
                audio: 'https://cdn.dyxzy.my.id/files/e3b4aa80.opus',
                body: () => pick(COMMON_BODY)
            },
            Isha: {
                title: '🌙 Waktu Isya',
                audio: 'https://cdn.dyxzy.my.id/files/e3b4aa80.opus',
                body: () => pick(COMMON_BODY)
            },
            Buka: {
                title: '🍽️ Waktu Berbuka',
                audio: 'https://cdn.dyxzy.my.id/files/7dfb7da8.ogg',
                body: () =>
                    pick([
                        '🍽️🌙 Adzan Maghrib berkumandang, menandakan waktu berbuka telah tiba. Setelah seharian menahan lapar dan dahaga, saatnya membatalkan puasa dengan doa, penuh syukur, dan harapan agar setiap amal hari ini diterima. 🤲✨',
                        '🌆🥤 Waktu berbuka akhirnya datang. Lepaskan dahaga dengan penuh rasa syukur, awali dengan doa, dan nikmati rezeki yang ada dengan hati tenang serta penuh keberkahan. Semoga lelah hari ini berubah menjadi pahala. 🌙🤍',
                        '🕌🌙 Adzan Maghrib telah terdengar, puasa hari ini pun selesai. Saatnya berbuka dengan yang manis, memperbanyak doa, dan mensyukuri nikmat yang diberikan. Semoga keberkahan menyertai setiap suapan dan tegukan. ✨🍯',
                        '🌙🍽️ Hari penuh kesabaran telah terlewati. Waktu berbuka kini tiba, awali dengan doa, nikmati hidangan dengan penuh syukur, dan semoga setiap rasa lapar yang ditahan menjadi ladang pahala serta keberkahan. 🤲💫',
                        '✨🌆 Maghrib menyapa, membawa kelegaan setelah seharian berpuasa. Saatnya berbuka, menenangkan hati, mengucap syukur, dan memohon agar ibadah hari ini diterima serta esok diberi kekuatan kembali. 🌙🤍'
                    ])
            },
            Sahur: {
                title: '🥣 Waktu Sahur',
                audio: 'https://cdn.dyxzy.my.id/files/b8b70d3d.opus',
                body: () =>
                    pick([
                        `🕰️ _Saatnya sahur!_\n\n🍚 Yuk, makan sahur agar tetap berenergi sepanjang hari. Jangan lupa minum air yang cukup! 💧`,
                        `📢 _Pengingat Sahur:_\n\n🌅 Waktu sahur sudah masuk di tiba. Ayo persiapkan makanan sehat dan jangan lupa berdoa sebelum makan. 🤲`,
                        `✨ _Berkah sahur telah datang!_\n\n🥣 Makan sahur itu sunnah dan penuh berkah. Yuk, jangan sampai terlewat! Semoga puasamu lancar hari ini. 😊`,
                        `🍽️ _Waktunya sahur!_\n\nJangan lupa bangun dan makan sahur, karena Rasulullah menganjurkannya sebagai sumber keberkahan. 🌟`
                    ])
            },
            Imsak: {
                title: '🛑 Imsak',
                audio: 'https://cdn.dyxzy.my.id/files/7dfb7da8.ogg',
                body: () =>
                    pick([
                        '🛑🌙 Imsak telah tiba. Waktu sahur kini berakhir, mari hentikan makan dan minum. Tenangkan hati, luruskan niat, dan sambut ibadah puasa hari ini dengan penuh keikhlasan serta harapan akan keberkahan. 🤍✨',
                        '⏰🥀 Waktu sahur selesai, Imsak menyapa. Saatnya menahan diri dari segala yang membatalkan, menjaga hati tetap tenang, dan memulai hari dengan niat puasa yang tulus karena-Nya. Semoga diberi kekuatan hingga waktu berbuka nanti. 🌅🙏',
                        '🌅🕌 Imsak datang membawa ketenangan. Makan dan minum telah usai, kini saatnya memperkuat niat, menjaga lisan, serta melangkah menjalani puasa dengan sabar, ikhlas, dan penuh keberkahan sepanjang hari. 🤲✨',
                        '🌙🤍 Imsak telah masuk. Sahur tinggal kenangan, perjuangan puasa dimulai. Semoga hati tetap kuat, tubuh diberi kesabaran, dan setiap detik hari ini bernilai ibadah serta dipenuhi rahmat dan keberkahan. ✨🕊️',
                        '🛑🌄 Imsak menandakan waktu menahan diri telah dimulai. Hentikan santapan, sempurnakan niat, dan sambut hari puasa dengan hati yang bersih, pikiran yang tenang, serta doa agar diberi kemudahan hingga maghrib tiba. 🤲🌙'
                    ])
            }
        };

        const notif = notifMap[prayerKey];
        if (!notif) return;

        if (!settings[chatId]?.notifSholat) return;

        if (!settings[chatId].notifSholat.sentLog) {
            settings[chatId].notifSholat.sentLog = [];
        }

        settings[chatId].notifSholat.sentLog = settings[chatId].notifSholat.sentLog.filter((x) => x.date === todayStr);

        const alreadySent = settings[chatId].notifSholat.sentLog.some(
            (x) => x.date === todayStr && x.prayer === prayerKey
        );
        if (alreadySent) return;

        try {
            await botInstance.sendMessage(chatId, {
                text: `*${notif.title}*\n\n${notif.body()}`,
                contextInfo: {
                    forwardingScore: 9999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.idch,
                        serverMessageId: 20,
                        newsletterName: config.ownername
                    },
                    externalAdReply: {
                        title: config.botname,
                        body: `🕒 ${timeNow}`,
                        thumbnailUrl: 'https://cdn.yupra.my.id/yp/663ajd25.jpg',
                        sourceUrl: config.apikey?.endpoint || 'https://wa.me/6283872031397',
                        mediaType: 1,
                        renderLargerThumbnail: false
                    }
                }
            });

            await botInstance.sendMessage(chatId, {
                audio: { url: notif.audio },
                mimetype: 'audio/ogg; codecs=opus',
                ptt: true
            });

            settings[chatId].notifSholat.sentLog.push({
                date: todayStr,
                prayer: prayerKey,
                time: timeNow
            });

            Database.write(PATHS.groupSettings, settings);
            Logger.success(`Notif Sholat [${prayerKey}] -> ${chatId}`);
        } catch (err) {
            Logger.error(`Notif Sholat gagal: ${err.message}`);
        }
    },

    sewaExpired: async (botInstance, groupId, sewaDb) => {
        try {
            await botInstance.sendMessage(groupId, {
                text: `⏰ *MASA SEWA TELAH HABIS*\n\nTerima kasih telah menggunakan layanan *SewaBot YUDZXML STORE* 🙏\n\nSilakan hubungi Owner untuk perpanjangan.`
            });
            await new Promise((resolve) => setTimeout(resolve, 2000));
            await botInstance.groupLeave(groupId);
            delete sewaDb[groupId];
            Database.write(PATHS.sewa, sewaDb);
            Logger.success(`Group ${groupId} keluar (Sewa Expired)`);
        } catch (error) {
            Logger.error(`Gagal proses expired sewa: ${error.message}`);
        }
    }
};

module.exports = { Notifier };

/**
 * scheduleTasks/prayer.js — Ambil & cache jadwal shalat dari API.
 */
const axios = require('axios');
const config = require('@Config');
const { TIMEZONE, minusMinutes, PATHS } = require('./constants');
const { Database } = require('./database');

async function fetchPrayerTimesFromApi(city) {
    try {
        const res = await axios.get(
            `${config.apikey.endpoint}/api/islami/jadwalshalat?kota=${city}&apikey=${config.apikey.key}`
        );
        const json = res.data;
        const t = json.data.jadwal;

        const result = {
            maghrib: t.Maghrib,
            isha: t.Isya,
            imsak: t.Imsyak,
            dhuhur: t.Dzuhur,
            ashar: t.Ashr,
            subuh: t.Shubuh,
            buka: minusMinutes(t.Maghrib, 5),
            sahur: minusMinutes(t.Imsyak, 60)
        };

        return result;
    } catch (error) {
        console.error(`Error fetching prayer times for ${city}:`, error.message);
        return null;
    }
}

async function getPrayerTimes(city, dateStr) {
    const cache = Database.read(PATHS.prayerCache, {});

    if (cache[city] && cache[city][dateStr]) {
        return cache[city][dateStr];
    }

    const freshData = await fetchPrayerTimesFromApi(city);

    if (freshData) {
        if (!cache[city]) cache[city] = {};
        cache[city][dateStr] = freshData;

        Object.keys(cache[city]).forEach((d) => {
            if (d < dateStr) delete cache[city][d];
        });

        Database.write(PATHS.prayerCache, cache);
    }

    return freshData;
}

module.exports = { fetchPrayerTimesFromApi, getPrayerTimes };

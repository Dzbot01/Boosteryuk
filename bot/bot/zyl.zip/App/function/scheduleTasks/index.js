/**
 * scheduleTasks/index.js — Entry scheduler: jadwal shalat, backup harian & jadwal grup.
 * Dipisah dari schedule.js; modul: constants/prayer/logger/database/backup/notifier.
 */
const fs = require('fs');
const moment = require('moment-timezone');
const config = require('@Config');
const { checkGroupSchedule } = require('../autoCloseHandler');
const { Logger } = require('./logger');
const { Database } = require('./database');
const { BackupSystem } = require('./backup');
const { Notifier } = require('./notifier');
const { getPrayerTimes, fetchPrayerTimesFromApi } = require('./prayer');
const { TIMEZONE, OWNER_NUMBER, PATHS, STORAGE_PATH } = require('./constants');

let schedulerBooted = null;
let schedulerInterval = null;

const startPrayerScheduler = (botInstance, options = {}) => {
    const LOG = options.log === true;

    const log = {
        info: (...a) => LOG && console.log('[INFO]', ...a),
        debug: (...a) => LOG && console.log('[DEBUG]', ...a),
        warn: (...a) => LOG && console.warn('[WARN]', ...a),
        error: (...a) => console.error('[ERROR]', ...a)
    };

    if (!fs.existsSync(STORAGE_PATH)) fs.mkdirSync(STORAGE_PATH, { recursive: true });

    schedulerBooted = botInstance;
    if (schedulerInterval) {
        log.debug('Scheduler sudah berjalan, instance bot diperbarui saja.');
        return;
    }

    schedulerInterval = setInterval(async () => {
        const now = moment().tz(TIMEZONE);
        const currentTime = now.format('HH:mm');
        const currentDateStr = now.format('DD-MM-YYYY');

        log.debug('Tick scheduler', currentTime);

        if (config.autoBackup?.enabled !== false && config.autoBackup?.zipDaily !== false) {
            try {
                const backupDb = Database.read(PATHS.backup, { last_backup: 'Never' });
                const lastBackupStr = backupDb.last_backup;
                const todayDate = now.format('YYYY-MM-DD');

                let lastBackupDate = 'Unknown';
                if (lastBackupStr && lastBackupStr !== 'Never' && lastBackupStr !== 'Error') {
                    lastBackupDate = moment(lastBackupStr, 'YYYY-MM-DD HH:mm:ss').format('YYYY-MM-DD');
                }

                if (lastBackupDate !== todayDate) {
                    log.info('[SmartBackup] Memulai backup...');
                    await BackupSystem.perform(schedulerBooted);
                } else {
                    log.debug('Backup sudah dilakukan hari ini');
                }
            } catch (error) {
                log.error('Gagal cek status backup:', error.message);
            }
        }

        const groupSettings = Database.read(PATHS.groupSettings);

        for (const chatId in groupSettings) {
            const grp = groupSettings[chatId];
            if (!grp?.notifSholat?.isActive) continue;

            const city = grp.notifSholat.city;
            if (!city) continue;

            try {
                const prayerData = await getPrayerTimes(city, currentDateStr);
                if (!prayerData) continue;

                let checkList = {
                    Subuh: prayerData.subuh,
                    Dhuhr: prayerData.dhuhur,
                    Asr: prayerData.ashar,
                    Maghrib: prayerData.maghrib,
                    Isha: prayerData.isha
                };

                if (config.isRamadhan === true) {
                    checkList.Buka = prayerData.buka;
                    checkList.Sahur = prayerData.sahur;
                    checkList.Imsak = prayerData.imsak;
                }

                for (const [prayerName, prayerTime] of Object.entries(checkList)) {
                    if (!prayerTime) continue;
                    const formattedPrayerTime = prayerTime.slice(0, 5);

                    if (currentTime === formattedPrayerTime) {
                        log.info(`Trigger notif ${prayerName} - ${city} - ${chatId}`);
                        await Notifier.prayer(schedulerBooted, city, chatId, prayerName, groupSettings);
                    }
                }
            } catch (error) {
                if (error.code !== 'ECONNRESET') {
                    log.debug(`Gagal jadwal ${city}: ${error.message}`);
                }
            }
        }

        try {
            const scheduleDb = Database.read(PATHS.schedule, {});
            const groupIds = Object.keys(scheduleDb || {});
            if (groupIds.length) {
                for (const gid of groupIds) {
                    log.debug('Check schedule group', gid);
                    await checkGroupSchedule(schedulerBooted, gid);
                }
            }
        } catch (error) {
            log.error('Error Schedule Loop:', error.message);
        }

        const sewaDb = Database.read(PATHS.sewa);
        const nowMs = Date.now();

        for (const groupId in sewaDb) {
            const data = sewaDb[groupId];
            if (data?.expired && nowMs >= data.expired) {
                if (!data.leaving) {
                    log.info('Sewa expired:', groupId);
                    sewaDb[groupId].leaving = true;
                    await Notifier.sewaExpired(schedulerBooted, groupId, sewaDb);
                }
            }
        }
    }, 60 * 1000);
    schedulerInterval.unref?.();
};

module.exports = {
    startPrayerScheduler,
    performBackup: BackupSystem.perform
};

const config = require('@Config');
const path = require('path');

/**
 * scheduleTasks/constants.js — Konstanta scheduler (zona waktu, path, target backup).
 */

const TIMEZONE = 'Asia/Jakarta';

const ROOT_PATH = path.join(__dirname, '../../..');

const STORAGE_PATH = path.join(ROOT_PATH, 'Storage');

const PATHS = {
    groupSettings: path.join(STORAGE_PATH, 'groupSettings.json'),
    sewa: path.join(STORAGE_PATH, 'sewa.json'),
    schedule: path.join(STORAGE_PATH, 'groupSchedule.json'),
    backup: path.join(STORAGE_PATH, 'backup_db.json'),
    prayerCache: path.join(STORAGE_PATH, 'prayerCache.json')
};

const BACKUP_TARGETS = [
    'config.js',
    'App',
    'database',
    'docs',
    'src',
    'Storage',
    'bun.lock',
    'docker-compose.yml',
    'Dockerfile',
    'package.json',
    'package-lock.json',
    'index.js',
    'migrate-database.js',
    'migrate-json-to-mysql.js',
    'migrate-json-to-postgresql.js',
    'migrate-json-to-sqlite.js',
    'README.md',
    'Yudzxml.js'
];

const OWNER_NUMBER = config.superowner + '@s.whatsapp.net';

function minusMinutes(time, mins) {
    let [h, m] = time.split(':').map(Number);
    let total = h * 60 + m - mins;

    if (total < 0) total += 24 * 60;

    const hh = String(Math.floor(total / 60)).padStart(2, '0');
    const mm = String(total % 60).padStart(2, '0');
    return `${hh}:${mm}`;
}

module.exports = { TIMEZONE, OWNER_NUMBER, ROOT_PATH, STORAGE_PATH, PATHS, BACKUP_TARGETS, minusMinutes };

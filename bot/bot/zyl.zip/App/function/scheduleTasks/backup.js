/**
 * scheduleTasks/backup.js — Backup otomatis (zip Storage + session) & pembersihan backup lama.
 */
const fs = require('fs');
const path = require('path');
const archiver = require('archiver');
const moment = require('moment-timezone');
const config = require('@Config');
const { Logger } = require('./logger');
const { Database } = require('./database');
const { Notifier } = require('./notifier');
const { TIMEZONE, OWNER_NUMBER, ROOT_PATH, STORAGE_PATH, BACKUP_TARGETS, PATHS } = require('./constants');

const BackupSystem = {
    cleanOldBackups: () => {
        try {
            if (!fs.existsSync(STORAGE_PATH)) return;
            const files = fs.readdirSync(STORAGE_PATH);

            files.forEach((file) => {
                if (file.startsWith('Backup_X7_') && file.endsWith('.zip')) {
                    const filePath = path.join(STORAGE_PATH, file);
                    fs.unlinkSync(filePath);
                    Logger.warn(`Menghapus backup lama (Auto-Clean): ${file}`);
                }
            });
        } catch (error) {
            Logger.error(`Gagal membersihkan backup lama: ${error.message}`);
        }
    },

    perform: async (botInstance) => {
        const LOCK_FILE = path.join(STORAGE_PATH, '.backup_lock');
        const timestamp = moment().tz(TIMEZONE).format('DD-MM-YYYY_HH-mm');
        const fileName = `Backup_X7_${timestamp}.zip`;
        const backupPath = path.join(STORAGE_PATH, fileName);

        const releaseLock = () => {
            try {
                if (fs.existsSync(LOCK_FILE)) fs.unlinkSync(LOCK_FILE);
            } catch {}
        };

        const checkLock = () => {
            if (fs.existsSync(LOCK_FILE)) {
                try {
                    const lockTime = parseInt(fs.readFileSync(LOCK_FILE));
                    if (Date.now() - lockTime > 3600 * 1000) {
                        Logger.warn('Lock file kadaluarsa. Menghapus lock...');
                        fs.unlinkSync(LOCK_FILE);
                        return true;
                    } else {
                        Logger.warn('Backup sedang berjalan (Lock aktif). Skip...');
                        return false;
                    }
                } catch (error) {
                    Logger.error(`Gagal baca lock file: ${error.message}`);
                    return false;
                }
            }
            return true;
        };

        if (!checkLock()) return;

        try {
            fs.writeFileSync(LOCK_FILE, Date.now().toString());
        } catch (error) {
            Logger.error(`Gagal bikin lock file: ${error.message}`);
            return;
        }

        BackupSystem.cleanOldBackups();
        Logger.info('Memulai Backup Harian...');

        const output = fs.createWriteStream(backupPath);
        const archive = archiver('zip', { zlib: { level: 9 } });

        output.on('close', async () => {
            const sizeInMB = (archive.pointer() / 1024 / 1024).toFixed(2);
            Logger.success(`Backup Selesai: ${fileName} (${sizeInMB} MB)`);

            const sendToWa = config.autoBackup?.sendToWa !== false;

            try {
                if (sendToWa && archive.pointer() > 0) {
                    const limit = 50;
                    if (parseFloat(sizeInMB) <= limit) {
                        await botInstance.sendMessage(OWNER_NUMBER, {
                            document: { url: backupPath },
                            mimetype: 'application/zip',
                            fileName: fileName,
                            caption: `🤖 *SYSTEM BACKUP (DAILY)*\n\n📅 Tanggal: ${moment().tz(TIMEZONE).format('DD/MM/YYYY HH:mm:ss')}\n📦 Ukuran: ${sizeInMB} MB\n🗑️ *File ini akan dihapus otomatis dari server setelah dikirim.*`
                        });
                    } else {
                        await botInstance.sendMessage(OWNER_NUMBER, {
                            text: `⚠️ *Backup Terlalu Besar*\n\nFile (${sizeInMB} MB) melebihi batas WA.\nFile tetap disimpan di server: Storage/${fileName}`
                        });
                    }
                }

                if (fs.existsSync(backupPath) && sendToWa && parseFloat(sizeInMB) <= 50) {
                    fs.unlinkSync(backupPath);
                    Logger.success('File backup dihapus dari server untuk hemat memori.');
                }

                Database.write(PATHS.backup, {
                    last_backup: moment().tz(TIMEZONE).format('YYYY-MM-DD HH:mm:ss'),
                    file_name: sendToWa && parseFloat(sizeInMB) <= 50 ? fileName : `${fileName} (tersimpan di server)`
                });
                releaseLock();
            } catch (error) {
                Logger.error(`Gagal kirim WA: ${error.message}`);
                if (!sendToWa && fs.existsSync(backupPath)) {
                    Logger.info(`ZIP tetap disimpan di server: Storage/${fileName}`);
                } else if (fs.existsSync(backupPath)) {
                    fs.unlinkSync(backupPath);
                }
                releaseLock();
            }
        });

        archive.on('error', (err) => {
            Logger.error(`Zip Error: ${err.message}`);
            releaseLock();
        });

        try {
            archive.pipe(output);
            Logger.info('Mengompresi data...');

            BACKUP_TARGETS.forEach((target) => {
                const targetPath = path.join(ROOT_PATH, target);
                if (fs.existsSync(targetPath)) {
                    const stats = fs.statSync(targetPath);
                    if (stats.isDirectory()) {
                        archive.directory(targetPath, target);
                    } else {
                        archive.file(targetPath, { name: target });
                    }
                }
            });

            await archive.finalize();
        } catch (error) {
            Logger.error(`Proses Zip Gagal: ${error.message}`);
            releaseLock();
        }
    }
};

module.exports = { BackupSystem };

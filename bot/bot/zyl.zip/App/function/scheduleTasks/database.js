/**
 * scheduleTasks/database.js — State database scheduler (flag harian, dst).
 */
const path = require('path');
const { loadDB, saveDB } = require('../../../database/wrappers/storage');
const { PATHS } = require('./constants');
const { Logger } = require('./logger');

const Database = {
    read: (filePath, defaultData = {}) => {
        try {
            const data = loadDB(filePath, defaultData);
            if (data === null || data === undefined) return defaultData;
            return data;
        } catch (error) {
            Logger.error(`Gagal memuat ${path.basename(filePath)}: ${error.message}`);
            return defaultData;
        }
    },
    write: (filePath, data) => {
        try {
            saveDB(filePath, data === undefined ? null : data);
            return true;
        } catch (error) {
            Logger.error(`Gagal menyimpan ${path.basename(filePath)}: ${error.message}`);
            return false;
        }
    }
};

module.exports = { Database };

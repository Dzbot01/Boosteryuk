/**
 * scheduleTasks/logger.js — Logger khusus scheduler.
 */
const chalk = require('chalk');

const Logger = {
    info: (msg) => console.log(chalk.cyan.bold('[INFO]'), msg),
    success: (msg) => console.log(chalk.green.bold('[SUCCESS]'), msg),
    warn: (msg) => console.log(chalk.yellow.bold('[WARN]'), msg),
    error: (msg) => console.log(chalk.red.bold('[ERROR]'), msg),
    debug: (msg) => console.log(chalk.gray('[DEBUG]'), msg)
};

module.exports = { Logger };

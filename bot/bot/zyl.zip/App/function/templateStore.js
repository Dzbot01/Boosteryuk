const path = require('path');

const { loadDB: loadDBFile, saveDB: saveDBFile } = require('../../database/wrappers/storage');

const DB_PATH = path.join(__dirname, '../../Storage/store_template.json');

function loadDB() {
    const data = loadDBFile(DB_PATH, {});
    return data && typeof data === 'object' && !Array.isArray(data) ? data : {};
}

function saveDB(db) {
    saveDBFile(DB_PATH, db);
}

function ensureGroup(db, gid) {
    if (!db[gid]) {
        db[gid] = {
            done: '',
            pending: '',
            batal: '',
            groupLink: '',
            saluranLink: '',
            stickers: {}
        };
    }

    if (!db[gid].stickers) {
        db[gid].stickers = {};
    }
}

function setTemplate(gid, type, text) {
    const db = loadDB();
    ensureGroup(db, gid);
    db[gid][type] = text;
    saveDB(db);
}

function getTemplate(gid, type) {
    const db = loadDB();
    return db[gid]?.[type] || '';
}

function setSticker(gid, key, value) {
    const db = loadDB();
    ensureGroup(db, gid);
    db[gid].stickers[key] = value;
    saveDB(db);
}

function getSticker(gid, key) {
    const db = loadDB();
    return db[gid]?.stickers?.[key] || null;
}

function setGroupLink(gid, link) {
    const db = loadDB();
    ensureGroup(db, gid);
    db[gid].groupLink = link;
    saveDB(db);
}

function setSaluranLink(gid, link) {
    const db = loadDB();
    ensureGroup(db, gid);
    db[gid].saluranLink = link;
    saveDB(db);
}

function getLinks(gid) {
    const db = loadDB();
    return {
        group: db[gid]?.groupLink || '',
        saluran: db[gid]?.saluranLink || ''
    };
}

function formatTime() {
    return new Date().toLocaleTimeString('id-ID', {
        hour: '2-digit',
        minute: '2-digit'
    });
}

function formatDate() {
    return new Date().toLocaleDateString('id-ID', {
        day: '2-digit',
        month: 'long',
        year: 'numeric'
    });
}

function renderTemplate(template, ctx = {}) {
    if (!template) return '';

    let text = template;

    text = text.replace(/@time/g, formatTime());
    text = text.replace(/@tanggal/g, formatDate());
    text = text.replace(/@catatan/g, ctx.catatan || '');
    text = text.replace(/@user/g, ctx.userTag || '');
    text = text.replace(/@group/g, ctx.group || '');
    text = text.replace(/@saluran/g, ctx.saluran || '');

    text = text.replace(/@\w+/g, '');

    return text.trim();
}

module.exports = {
    setTemplate,
    getTemplate,
    setSticker,
    getSticker,
    setGroupLink,
    setSaluranLink,
    getLinks,
    renderTemplate
};

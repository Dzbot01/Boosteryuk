/**
 * groupBlacklist.js — Sumber TUNGGAL data blacklist grup (Storage/blacklistgc.json).
 *
 * Sebelumnya helper readBlacklist/isBlacklisted diduplikat di banyak file
 * (blacklistgc.js, jpm.js, jpmswgc.js, delblacklistgc.js, listblacklistgc.js,
 * accesHandler.js, jpmHandler.js). Semua sekarang lewat modul ini.
 */
const path = require('path');
const { loadDB, saveDB } = require('../../database/wrappers/storage');

const BLACKLIST_PATH = path.join(__dirname, '../../Storage/blacklistgc.json');

const readBlacklist = () => {
    try {
        const data = loadDB(BLACKLIST_PATH, []);
        return Array.isArray(data) ? data : [];
    } catch {
        return [];
    }
};

const writeBlacklist = (data) => {
    saveDB(BLACKLIST_PATH, Array.isArray(data) ? data : []);
    return true;
};

const isBlacklisted = (groupId) => {
    return readBlacklist().some((g) => g && g.id === groupId && g.blacklisted === true);
};

const setBlacklistStatus = (groupData, status) => {
    const data = readBlacklist();
    const index = data.findIndex((g) => g.id === groupData.id);

    const payload = {
        id: groupData.id,
        name: groupData.name,
        blacklisted: status === true,
        updatedAt: Date.now()
    };

    if (index !== -1) {
        data[index] = { ...data[index], ...payload };
    } else {
        data.push({ ...payload, createdAt: Date.now() });
    }

    writeBlacklist(data);
    return payload.blacklisted;
};

const removeBlacklistEntry = (match) => {
    const data = readBlacklist();
    const index = typeof match === 'function' ? data.findIndex(match) : data.findIndex((g) => g.id === match);

    if (index === -1) return null;
    const [removed] = data.splice(index, 1);
    writeBlacklist(data);
    return removed;
};

module.exports = { BLACKLIST_PATH, readBlacklist, writeBlacklist, isBlacklisted, setBlacklistStatus, removeBlacklistEntry };

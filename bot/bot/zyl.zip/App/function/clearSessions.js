const fs = require('fs');
const path = require('path');

const rootPath = path.resolve(__dirname, '../..');
const tmpPath = path.join(rootPath, 'Storage/session');

function clearSessions() {
    try {
        if (!fs.existsSync(tmpPath)) {
            console.warn('[SESSION] Folder session tidak ditemukan');
            return;
        }

        const files = fs.readdirSync(tmpPath);

        const KEEP_FILES = ['creds.json', 'creed.json'];

        let deleted = 0;

        for (const file of files) {
            if (KEEP_FILES.includes(file)) continue;

            const fullPath = path.join(tmpPath, file);

            fs.rmSync(fullPath, {
                recursive: true,
                force: true
            });

            deleted++;
        }

        console.log(`[SESSION] ${deleted} item session berhasil dihapus (creds.json dipertahankan)`);
    } catch (err) {
        console.error('[SESSION] Gagal menghapus session:', err.message);
    }
}

module.exports = clearSessions;

const { loadPlugins } = require('./loadPlugins');

async function applyStyle(text, styleNumber = 1) {
    const styles = ['ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘqʀꜱᴛᴜᴠᴡxʏᴢ1234567890'];

    const map = styles[styleNumber - 1] || '';
    if (!map) return { done: text };

    const result = text
        .toString()
        .split('')
        .map((char) => {
            if (char === ' ') return ' ';
            if (/[a-z]/i.test(char)) {
                const index = char.toLowerCase().charCodeAt(0) - 97;
                return map[index] || char;
            }
            if (/[0-9]/.test(char)) {
                const digitIndex = '1234567890'.indexOf(char);
                const index = 26 + digitIndex;
                return map[index] || char;
            }
            return char;
        })
        .join('');

    return { done: result };
}

function groupByCategory(plugins = []) {
    const temp = {};

    for (const plugin of plugins) {
        const category = plugin.category || 'other';
        if (!temp[category]) temp[category] = [];

        for (const cmd of plugin.commands || []) {
            temp[category].push(cmd);
        }
    }

    return Object.entries(temp).map(([kategori, commands]) => ({
        kategori,
        commands: [...new Set(commands)].sort((a, b) => a.localeCompare(b, 'id', { sensitivity: 'base' }))
    }));
}

function groupCategoryOnly(plugins = []) {
    const categories = new Set();

    for (const plugin of plugins) {
        categories.add(plugin.category || 'other');
    }

    return [...categories]
        .sort((a, b) => a.localeCompare(b, 'id', { sensitivity: 'base' }))
        .map((kategori) => ({ kategori }));
}

async function buildMenuJSON(styleNumber = 1) {
    const plugins = loadPlugins() || [];

    const categorized = groupByCategory(plugins).sort((a, b) =>
        a.kategori.localeCompare(b.kategori, 'id', { sensitivity: 'base' })
    );

    const menuJSON = [];
    let totalCommands = 0;

    for (const item of categorized) {
        const commandCount = item.commands.length;
        totalCommands += commandCount;

        const styledCategory = await applyStyle(item.kategori, styleNumber);
        const styledCommands = await applyStyle(item.commands.join(', '), styleNumber);

        menuJSON.push({
            kategori: styledCategory.done,
            commands: styledCommands.done,
            kategori_nostyle: item.kategori,
            total_commands: commandCount
        });
    }

    return {
        total_kategori: categorized.length,
        total_commands: totalCommands,
        menu: menuJSON,
        kategori_only: groupCategoryOnly(plugins)
    };
}

module.exports = {
    applyStyle,
    groupByCategory,
    groupCategoryOnly,
    buildMenuJSON
};

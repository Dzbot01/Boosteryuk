'use strict';

/**
 * pollStore.js — Persistent poll store (F12).
 *
 * Disimpan di namespace `polls` via DatabaseManager. Survive restart.
 * Auto-close setelah 24 jam (default) — hasil dikirim ke grup.
 */

const logger = require('./logger');

const NAMESPACE = 'polls';
const DEFAULT_AUTO_CLOSE_HOURS = 24;

function getDb() {
    try {
        const { DatabaseManager } = require('@Database');
        return DatabaseManager.getInstance();
    } catch (_) {
        return null;
    }
}

function getAll() {
    const dbm = getDb();
    if (!dbm) return [];
    const doc = dbm.getDoc(NAMESPACE);
    if (!doc || !Array.isArray(doc.items)) return [];
    return doc.items;
}

function saveAll(items) {
    const dbm = getDb();
    if (!dbm) return false;
    dbm.setDoc(NAMESPACE, { items: items || [], updatedAt: Date.now() });
    return true;
}

function create({ chatId, creatorJid, question, options }) {
    const items = getAll();
    const id = `p_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
    const poll = {
        id,
        chatId: String(chatId),
        creatorJid: String(creatorJid),
        question: String(question || 'Poll'),
        options: (options || []).map((text, i) => ({ id: i + 1, text: String(text), votes: 0, voters: [] })),
        createdAt: Date.now(),
        autoCloseAt: Date.now() + DEFAULT_AUTO_CLOSE_HOURS * 3600 * 1000,
        closed: false,
        closedAt: null
    };
    items.push(poll);
    saveAll(items);
    return poll;
}

function getActive(chatId) {
    return getAll().find((p) => p.chatId === String(chatId) && !p.closed);
}

function getById(id) {
    return getAll().find((p) => p.id === id);
}

function vote(id, voterJid, optionId) {
    const items = getAll();
    const p = items.find((x) => x.id === id);
    if (!p) return { error: 'not_found' };
    if (p.closed) return { error: 'closed' };

    // Hapus vote lama user ini kalau sudah pernah vote.
    for (const opt of p.options) {
        const idx = opt.voters.indexOf(voterJid);
        if (idx !== -1) {
            opt.voters.splice(idx, 1);
            opt.votes = Math.max(0, opt.votes - 1);
        }
    }

    const opt = p.options.find((o) => o.id === Number(optionId));
    if (!opt) return { error: 'invalid_option' };
    opt.voters.push(voterJid);
    opt.votes += 1;
    saveAll(items);
    return { ok: true, poll: p };
}

function close(id) {
    const items = getAll();
    const p = items.find((x) => x.id === id);
    if (!p) return { error: 'not_found' };
    if (p.closed) return { error: 'already_closed' };
    p.closed = true;
    p.closedAt = Date.now();
    saveAll(items);
    return { ok: true, poll: p };
}

function formatResults(p) {
    if (!p) return '';
    const lines = p.options
        .map((opt) => {
            const pct = opt.voters.length > 0 ? Math.round((opt.votes / Math.max(1, totalVotes(p))) * 100) : 0;
            const bar = '█'.repeat(Math.floor(pct / 5)).padEnd(20, '░');
            return `${opt.id}. ${opt.text}\n   ${bar} ${pct}% (${opt.votes})`;
        })
        .join('\n');
    return `📊 *${p.question}*\n\n${lines}\n\nTotal votes: ${totalVotes(p)}`;
}

function totalVotes(p) {
    return p.options.reduce((sum, o) => sum + o.votes, 0);
}

function listPendingClose() {
    const now = Date.now();
    return getAll().filter((p) => !p.closed && p.autoCloseAt && p.autoCloseAt <= now);
}

let schedulerStarted = false;
let schedulerTimer = null;

function startAutoCloseScheduler(notifyFn) {
    if (schedulerStarted) return;
    schedulerStarted = true;
    const tick = async () => {
        try {
            const pending = listPendingClose();
            for (const p of pending) {
                try {
                    close(p.id);
                    if (notifyFn) {
                        await notifyFn(p.chatId, `🔒 *Polling ditutup* (24 jam)\n\n${formatResults(p)}`);
                    }
                } catch (err) {
                    logger.error('[poll] auto-close error: ' + err.message);
                }
            }
        } catch (err) {
            logger.error('[poll] scheduler tick error: ' + err.message);
        }
    };
    tick();
    schedulerTimer = setInterval(tick, 60_000);
    if (typeof schedulerTimer.unref === 'function') schedulerTimer.unref();
    logger.info('[poll] auto-close scheduler aktif (cek tiap 1 menit)');
}

function stopAutoCloseScheduler() {
    if (schedulerTimer) clearInterval(schedulerTimer);
    schedulerTimer = null;
    schedulerStarted = false;
}

module.exports = {
    NAMESPACE,
    DEFAULT_AUTO_CLOSE_HOURS,
    create,
    getActive,
    getById,
    vote,
    close,
    formatResults,
    totalVotes,
    listPendingClose,
    startAutoCloseScheduler,
    stopAutoCloseScheduler
};

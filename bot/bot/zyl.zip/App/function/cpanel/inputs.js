/**
 * cpanel/inputs.js — Input teks saat sesi aktif: email, password, cek status, batal. Digabung dari cpanelHandler.js (903 baris) agar per-file kecil & mudah dirawat.
 *
 */
const db = require('@App/function/cpanelDB');
const services = require('./services');
const { STATUS } = require('./constants');
const { isValidEmail, isValidPassword, sendText } = require('./utils');
const { getSession, cancelFlow } = require('./session');
const { sendTypeSelection } = require('./menus');
const { manualCheckPayment } = require('./payment');

async function handleTextInput(Yudzxml, m, text) {
    const session = getSession(m);

    if (!session) return null;

    const { status } = session.data;

    if (text.toLowerCase() === 'batal') {
        return cancelFlow(Yudzxml, m, 'Dibatalkan oleh user.');
    }

    switch (status) {
        case STATUS.WAIT_EMAIL:
            return await handleEmailInput(Yudzxml, m, text, session);

        case STATUS.WAIT_PASSWORD:
            return await handlePasswordInput(Yudzxml, m, text, session);

        case STATUS.WAIT_PAYMENT:
            return await handlePaymentInput(Yudzxml, m, text, session);

        default:
            return null;
    }
}

async function handleEmailInput(Yudzxml, m, text, session) {
    const email = text.trim().toLowerCase();

    if (!isValidEmail(email)) {
        return sendText(
            Yudzxml,
            m,
            `❌ *Format email tidak valid*\n\n` +
                `Pastikan email yang dikirim benar:\n` +
                `> contoh: user@gmail.com\n\n` +
                `Ketik *batal* untuk membatalkan.`
        );
    }

    const { orderType } = session.data;

    if (orderType === 'self') {
        const localUser = services.ptero._getLocalUser(email);

        if (localUser && localUser.password) {
            db.updateByUserId(m.sender, {
                status: STATUS.WAIT_TYPE,
                email: email,
                password: localUser.password,
                passwordFromDB: true
            });

            return sendTypeSelection(Yudzxml, m, session.data.ramPackage);
        } else {
            db.updateByUserId(m.sender, {
                status: STATUS.WAIT_PASSWORD,
                email: email
            });

            return sendText(
                Yudzxml,
                m,
                `✉️  *EMAIL DITERIMA*: ${email}\n\n` +
                    `Email ini belum terdaftar di sistem.\n` +
                    `Silakan kirim *password* untuk akun panel yang akan dibuat:\n\n` +
                    `> Minimal 6 karakter\n\n` +
                    `Ketik *batal* untuk membatalkan.`
            );
        }
    } else {
        db.updateByUserId(m.sender, {
            status: STATUS.WAIT_PASSWORD,
            email: email
        });

        return sendText(
            Yudzxml,
            m,
            `✉️  *EMAIL DITERIMA*: ${email}\n\n` +
                `Silakan kirim *password* untuk akun panel customer:\n\n` +
                `> Minimal 6 karakter\n\n` +
                `Ketik *batal* untuk membatalkan.`
        );
    }
}

async function handlePasswordInput(Yudzxml, m, text, session) {
    const password = text.trim();

    if (!isValidPassword(password)) {
        return sendText(
            Yudzxml,
            m,
            `❌ *Password tidak valid*\n\n` +
                `Password harus minimal 6 karakter.\n` +
                `Silakan kirim ulang password:\n\n` +
                `Ketik *batal* untuk membatalkan.`
        );
    }

    db.updateByUserId(m.sender, {
        status: STATUS.WAIT_TYPE,
        password: password
    });

    return sendTypeSelection(Yudzxml, m, session.data.ramPackage);
}

async function handlePaymentInput(Yudzxml, m, text, session) {
    if (text.toLowerCase() === 'cekstatus') {
        return await manualCheckPayment(Yudzxml, m, session);
    }

    return sendText(
        Yudzxml,
        m,
        `⏳ *Menunggu Pembayaran*\n\n` +
            `Ketik *cekstatus* untuk mengecek status pembayaran.\n` +
            `Ketik *batal* untuk membatalkan.`
    );
}

module.exports = { handleTextInput, handleEmailInput, handlePasswordInput, handlePaymentInput };

/**
 * cpanel/index.js — Entry handler fitur cpanel (command .createserver, jualan panel).
 *
 * Struktur folder:
 *   constants.js — STATUS, DOCKER_IMAGES, TTL
 *   services.js  — registry client ptero/pakasir per-instance
 *   utils.js     — validasi, format, kirim pesan
 *   session.js   — sesi order per user + polling
 *   menus.js     — native flow list (runtime & docker image)
 *   buttons.js   — respon tombol
 *   inputs.js    — input teks sesi (email, password, cekstatus, batal)
 *   payment.js   — QRIS pakasir (buat/polling/cek manual)
 *   provision.js — create server Pterodactyl
 */
const db = require('@App/function/cpanelDB');
const pteroFactory = require('@App/function/ptreodactylClient');
const pakasirFactory = require('@App/function/pakasirClient');
const services = require('./services');
const { STATUS } = require('./constants');
const { buildContextInfo } = require('./utils');
const { activePolling } = require('./session');
const { handleButtonResponse } = require('./buttons');
const { handleTextInput } = require('./inputs');

module.exports = async (Yudzxml, m, budy, config, ppuser, prefix, jadibotCtx = {}) => {
    try {
        if (m.fromMe) return null;

        services.ctx = {
            isJadibot: Boolean(jadibotCtx.isJadibot),
            jadibotEntry: jadibotCtx.jadibotEntry || null,
            jadibotJid: jadibotCtx.jadibotJid || null
        };
        services.ptero = pteroFactory.getPteroForContext ? pteroFactory.getPteroForContext(services.ctx) : pteroFactory;
        services.pakasir = pakasirFactory.getPakasirForContext
            ? pakasirFactory.getPakasirForContext(services.ctx)
            : pakasirFactory;

        if (services.ctx.isJadibot && (!services.ptero || !services.pakasir)) {
            const text = (budy || '').trim();
            const isCpanelRelated =
                (m.mtype === 'interactiveResponseMessage' &&
                    typeof m.text === 'string' &&
                    m.text.startsWith('cpanel_')) ||
                (text.length > 0 && db.hasActiveSession(m.sender));

            if (isCpanelRelated) {
                const missing = [];
                if (!services.ptero) missing.push('• Panel Pterodactyl → pasang lewat website (menu kredensial bot jadibot)');
                if (!services.pakasir) missing.push('• Payment Pakasir → pasang lewat website (menu kredensial bot jadibot)');
                await Yudzxml.sendMessage(
                    m.chat,
                    {
                        text:
                            `🔒 *Lengkapi Kredensial Dulu*\n\n` +
                            `Bot jadibot kamu belum punya kredensial sendiri:\n\n` +
                            missing.join('\n') +
                            `\n\n` +
                            `Setelah lengkap, kamu bisa mulai jualan panel.`,
                        contextInfo: buildContextInfo(m)
                    },
                    { quoted: m }
                );
                return true;
            }
        }

        if (m.mtype === 'interactiveResponseMessage') {
            const id = m.text;
            if (!id || typeof id !== 'string') return null;

            if (id.startsWith('cpanel_')) {
                const handled = await handleButtonResponse(Yudzxml, m, id);
                return handled !== null ? true : null;
            }

            return null;
        }

        if (budy && typeof budy === 'string' && budy.trim().length > 0) {
            const text = budy.trim();

            if (db.hasActiveSession(m.sender)) {
                const handled = await handleTextInput(Yudzxml, m, text);
                return handled !== null ? true : null;
            }
        }

        return null;
    } catch (error) {
        console.error('[CpanelHandler] Unhandled error:', error);

        try {
            await Yudzxml.sendMessage(
                m.chat,
                {
                    text: `❌ Terjadi kesalahan sistem: ${error.message}\n\nSilakan coba lagi atau hubungi admin.`,
                    contextInfo: buildContextInfo(m)
                },
                { quoted: m }
            );
        } catch (sendError) {
            console.error('[CpanelHandler] Failed to send error message:', sendError);
        }

        return true;
    }
};

module.exports.STATUS = STATUS;

module.exports.stopAllPolling = () => {
    for (const [id, interval] of activePolling.entries()) {
        clearInterval(interval);
    }
    activePolling.clear();
};

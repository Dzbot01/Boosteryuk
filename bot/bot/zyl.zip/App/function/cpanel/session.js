/**
 * cpanel/session.js — Sesi alur order (per user) & polling aktif. Digabung dari cpanelHandler.js (903 baris) agar per-file kecil & mudah dirawat.
 *
 */
const db = require('@App/function/cpanelDB');
const services = require('./services');
const { STATUS } = require('./constants');
const { sendText } = require('./utils');

const activePolling = new Map();

function getSession(m) {
    return db.getByUserId(m.sender);
}

function getChatId(m) {
    return m.chat;
}

function cancelFlow(Yudzxml, m, reason) {
    const session = getSession(m);
    if (session) {
        if (session.data.status === STATUS.WAIT_PAYMENT && session.data.orderId) {
            services.pakasir.cancelTransaction(session.data.orderId, session.data.amount).catch(() => {});
        }
        stopPolling(session.sessionId);
        db.destroy(session.sessionId);
    }
    return sendText(
        Yudzxml,
        m,
        `❌ *Proses Dibatalkan*\n\n${reason || 'Tidak ada alasan'}\n\nKetik \`.createserver\` untuk memulai kembali.`
    );
}

function stopPolling(sessionId) {
    if (activePolling.has(sessionId)) {
        clearInterval(activePolling.get(sessionId));
        activePolling.delete(sessionId);
    }
}

function stopAllPolling() {
    for (const [id, interval] of activePolling.entries()) {
        clearInterval(interval);
    }
    activePolling.clear();
}

module.exports = { activePolling, getSession, getChatId, cancelFlow, stopPolling, stopAllPolling };

/**
 * cpanel/services.js — Registry layanan Pterodactyl & Pakasir yang bisa ditukar per-instance.
 *
 * Bot utama memakai kredensial default (factory). Bot jadibot mendapat client sendiri
 * berdasarkan kredensial yang dipasang via menu kredensial (di-set ulang index.js
 * setiap kali handler dipanggil, jadi tidak bocor antar instance).
 */
const pteroFactory = require('@App/function/ptreodactylClient');
const pakasirFactory = require('@App/function/pakasirClient');

const services = {
    ptero: pteroFactory,
    pakasir: pakasirFactory,
    ctx: { isJadibot: false }
};

module.exports = services;

/**
 * cpanel/constants.js — Status state machine order panel, daftar docker image & TTL sesi. Digabung dari cpanelHandler.js (903 baris) agar per-file kecil & mudah dirawat.
 *
 * Ganti/ tambah status order cukup di sini.
 */

const STATUS = Object.freeze({
    CEKUSER: 'CEKUSER',
    WAIT_EMAIL: 'WAIT_EMAIL',
    WAIT_PASSWORD: 'WAIT_PASSWORD',
    WAIT_TYPE: 'WAIT_TYPE',
    WAIT_DOCKER_IMAGE: 'WAIT_DOCKER_IMAGE',
    WAIT_PAYMENT: 'WAIT_PAYMENT',
    PROCESSING: 'PROCESSING',
    COMPLETED: 'COMPLETED',
    FAILED: 'FAILED'
});

const DOCKER_IMAGES = Object.freeze({
    nodejs: [
        'nodejs_24',
        'nodejs_23',
        'nodejs_22',
        'nodejs_21',
        'nodejs_20',
        'nodejs_19',
        'nodejs_18',
        'nodejs_17',
        'nodejs_16',
        'nodejs_15'
    ],
    python: ['python_3.7', 'python_3.8', 'python_3.9', 'python_3.10', 'python_3.11']
});

const TTL = Object.freeze({
    DEFAULT: 5 * 60 * 1000,
    PAYMENT: 30 * 60 * 1000,
    PROCESSING: 10 * 60 * 1000
});

module.exports = { STATUS, DOCKER_IMAGES, TTL };

/**
 * cpanel/menus.js — Native flow list: pilih runtime & docker image. Digabung dari cpanelHandler.js (903 baris) agar per-file kecil & mudah dirawat.
 *
 */
const { DOCKER_IMAGES } = require('./constants');
const { fotomenunya, sendNativeFlowList, formatBytes, formatCurrency } = require('./utils');

function sendTypeSelection(Yudzxml, m, ramPackage) {
    const menuText = `┌─────────────────────────────┐
│  ✦  *PILIH RUNTIME*  ✦       │
├─────────────────────────────┤
│  📦 Package : ${ramPackage.name}
│  🧠 RAM     : ${formatBytes(ramPackage.ram)}
│  💰 Harga   : ${formatCurrency(ramPackage.price)}
└─────────────────────────────┘

Pilih runtime yang diinginkan:`;

    return sendNativeFlowList(Yudzxml, m, {
        image: fotomenunya,
        caption: menuText,
        title: '˖ ࣪ ݂ ✤ PILIH RUNTIME',
        sections: [
            {
                title: 'RUNTIME',
                rows: [
                    {
                        title: '˖ ࣪ ݂ ❥  Node.js',
                        description: `Runtime Node.js`,
                        id: 'cpanel_type_nodejs'
                    },
                    {
                        title: '˖ ࣪ ݂ ❥  Python',
                        description: `Runtime Python`,
                        id: 'cpanel_type_python'
                    }
                ]
            }
        ]
    });
}

function sendDockerImageSelection(Yudzxml, m, type, ramPackage) {
    const images = DOCKER_IMAGES[type] || [];
    const typeLabel = type === 'nodejs' ? 'Node.js' : 'Python';

    const menuText = `┌─────────────────────────────┐
│  ✦  *PILIH DOCKER IMAGE*  ✦  │
├─────────────────────────────┤
│  📦 Package : ${ramPackage.name}
│  🧠 RAM     : ${formatBytes(ramPackage.ram)}
│  💰 Harga   : ${formatCurrency(ramPackage.price)}
│  🔧 Runtime : ${typeLabel}
└─────────────────────────────┘

Pilih Docker Image ${typeLabel} yang diinginkan:`;

    const rows = images.map((img) => ({
        title: `˖ ࣪ ݂ ❥  ${img}`,
        description: `Docker Image ${typeLabel}`,
        id: `cpanel_docker_${img}`
    }));

    return sendNativeFlowList(Yudzxml, m, {
        image: fotomenunya,
        caption: menuText,
        title: `˖ ࣪ ݂ ✤ PILIH DOCKER IMAGE`,
        sections: [
            {
                title: `${typeLabel.toUpperCase()} IMAGES`,
                rows: rows
            }
        ]
    });
}

module.exports = { sendTypeSelection, sendDockerImageSelection };

/**
 * cpanel/payment.js — QRIS Pakasir: buat pembayaran, polling status & cek manual. Digabung dari cpanelHandler.js (903 baris) agar per-file kecil & mudah dirawat.
 *
 */
const db = require('@App/function/cpanelDB');
const config = require('@Config');
const logger = require('@App/function/logger');
const createTemplateQris = require('@App/function/createTemplateQris');
const services = require('./services');
const { STATUS, TTL } = require('./constants');
const {
    formatCurrency,
    formatBytes,
    getTimeRemaining,
    generateOrderId,
    sendText,
    sendImage,
    buildContextInfo
} = require('./utils');
const { stopPolling, activePolling } = require('./session');
const { processServerCreation } = require('./provision');

async function processPayment(Yudzxml, m, sessionId) {
    const session = db.get(sessionId);
    if (!session) {
        return sendText(Yudzxml, m, '❌ Sesi tidak ditemukan.');
    }

    const { ramPackage, type, dockerImageKey, orderType, email } = session.data;
    const amount = ramPackage.price;
    const orderId = generateOrderId();

    try {

        const payment = await services.pakasir.createTransaction(services.pakasir.PAYMENT_METHODS.QRIS, orderId, amount);

        // API v2: QRIS string ada di `qr_string`; VA number di `va_number`.
        const qrisString = payment.qr_string || payment.va_number || payment.payment_number;
        if (!qrisString) {
            throw new Error('QRIS string tidak ditemukan dalam response. Cek konfigurasi Pakasir (API v2).');
        }

        const frameUrl = config.pakasir?.frameQr || null;
        let qrBuffer;

        try {
            qrBuffer = await createTemplateQris(qrisString, frameUrl, config);
        } catch (qrError) {
            qrBuffer = await createTemplateQris(qrisString, null, config);
        }

        db.update(sessionId, {
            status: STATUS.WAIT_PAYMENT,
            orderId: orderId,
            amount: amount,
            qrisString: qrisString,
            paymentExpiredAt: payment.expired_at
        });

        const currentData = { ...session.data };
        currentData.status = STATUS.WAIT_PAYMENT;
        currentData.orderId = orderId;
        currentData.amount = amount;
        currentData.qrisString = qrisString;
        currentData.paymentExpiredAt = payment.expired_at;

        db.destroy(sessionId);
        const newSessionId = db.create(m.sender, currentData, TTL.PAYMENT);

        const paymentCaption =
            `╭━━━━━━━━━━━━━━━━━━━━━━━╮\n` +
            `│    ✦  *PEMBAYARAN QRIS*  ✦    │\n` +
            `╰━━━━━━━━━━━━━━━━━━━━━━━╯\n\n` +
            `📋 *Detail Order*\n` +
            `├ Order ID    : ${orderId}\n` +
            `├ Package     : ${ramPackage.name}\n` +
            `├ RAM         : ${formatBytes(ramPackage.ram)}\n` +
            `├ Disk        : ${formatBytes(ramPackage.disk)}\n` +
            `├ CPU         : ${ramPackage.cpu}%\n` +
            `├ Runtime     : ${type.toUpperCase()}\n` +
            `├ Docker      : ${dockerImageKey}\n` +
            `├ Tipe        : ${orderType === 'self' ? 'Pribadi' : 'Customer'}\n` +
            `├ Email       : ${email}\n` +
            `├ Harga       : ${formatCurrency(amount)}\n` +
            `└ Expired     : ${payment.expired_at ? new Date(payment.expired_at).toLocaleString('id-ID') : '-'}\n\n` +
            `📷 *Scan QRIS di atas untuk membayar*\n\n` +
            `⏱️  Ketik *cekstatus* untuk cek pembayaran\n` +
            `❌  Ketik *batal* untuk membatalkan`;

        await sendImage(Yudzxml, m, qrBuffer, paymentCaption);

        startPaymentPolling(newSessionId, orderId, amount, Yudzxml, m);

        return true;
    } catch (error) {
        db.update(sessionId, { status: STATUS.FAILED });

        return sendText(
            Yudzxml,
            m,
            `❌ *Gagal Membuat Pembayaran*\n\n` +
                `${error.message}\n\n` +
                `Silakan coba lagi dengan ketik \`.createserver\``
        );
    }
}

function startPaymentPolling(sessionId, orderId, amount, Yudzxml, m) {
    stopPolling(sessionId);

    const interval = setInterval(async () => {
        try {
            const session = db.get(sessionId);
            if (!session) {
                stopPolling(sessionId);
                return;
            }

            const paid = await services.pakasir.isPaid(orderId, amount);

            if (paid) {
                stopPolling(sessionId);

                await processServerCreation(sessionId, Yudzxml, m);
                return;
            }

            const expired = await services.pakasir.isExpired(orderId, amount);
            if (expired) {
                stopPolling(sessionId);

                const chatId = session.data.chatId || m.chat;
                await Yudzxml.sendMessage(chatId, {
                    text:
                        `⏰ *Pembayaran Expired*\n\n` +
                        `Order ID: ${orderId}\n` +
                        `QRIS telah expired.\n\n` +
                        `Ketik \`.createserver\` untuk memulai ulang.`,
                    contextInfo: buildContextInfo(m)
                });

                db.destroy(sessionId);
                return;
            }
        } catch (error) {
            logger.error(`[CPANEL] Polling ${orderId}: ${error.message}`);
        }
    }, 5000); // API v2: status dibatasi 1x per 4 detik per transaksi.

    activePolling.set(sessionId, interval);

    setTimeout(
        () => {
            if (activePolling.has(sessionId)) {
                stopPolling(sessionId);
            }
        },
        35 * 60 * 1000
    );
}

async function manualCheckPayment(Yudzxml, m, session) {
    const { orderId, amount, paymentExpiredAt } = session.data;

    try {
        const detail = await services.pakasir.getTransactionDetail(orderId, amount);
        const trx = detail?.transaction;

        if (!trx) {
            return sendText(Yudzxml, m, '❌ Transaksi tidak ditemukan.');
        }

        const statusMap = {
            pending: '⏳ Menunggu Pembayaran',
            completed: '✅ Pembayaran Berhasil',
            expired: '⏰ Pembayaran Expired',
            cancelled: '❌ Pembayaran Dibatalkan',
            canceled: '❌ Pembayaran Dibatalkan' // ejaan status API v2
        };

        const statusText = statusMap[trx.status] || `❓ ${trx.status}`;
        const timeRemaining = paymentExpiredAt ? getTimeRemaining(paymentExpiredAt) : '-';

        return sendText(
            Yudzxml,
            m,
            `📋 *Status Pembayaran*\n\n` +
                `├ Order ID  : ${orderId}\n` +
                `├ Jumlah    : ${formatCurrency(amount)}\n` +
                `├ Status    : ${statusText}\n` +
                `├ Sisa Waktu: ${timeRemaining}\n` +
                `└ Metode    : QRIS\n\n` +
                (trx.status === 'pending'
                    ? `⏱️  Tunggu beberapa saat lalu ketik *cekstatus* lagi.\n❌  Ketik *batal* untuk membatalkan.`
                    : '')
        );
    } catch (error) {
        logger.error(`[CPANEL] Cek manual ${orderId}: ${error.message}`);
        return sendText(Yudzxml, m, `❌ Gagal mengecek status: ${error.message}`);
    }
}

module.exports = { processPayment, startPaymentPolling, manualCheckPayment };

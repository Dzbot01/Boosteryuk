/**
 * cpanel/buttons.js — Respon tombol native flow (cpanel_ram_*, cpanel_ordertype_*, dst). Digabung dari cpanelHandler.js (903 baris) agar per-file kecil & mudah dirawat.
 *
 */
const db = require('@App/function/cpanelDB');
const config = require('@Config');
const { STATUS, TTL } = require('./constants');
const { formatBytes, formatCurrency, sendNativeFlowList, sendText, fotomenunya } = require('./utils');
const { getSession, getChatId } = require('./session');
const { sendDockerImageSelection } = require('./menus');
const { processPayment } = require('./payment');

async function handleButtonResponse(Yudzxml, m, id) {
    const chatId = getChatId(m);

    if (id.startsWith('cpanel_ram_')) {
        const pkgName = id.replace('cpanel_ram_', '');
        const ramList = config.cpanel?.LISTPANEL;
        if (!ramList) {
            return sendText(Yudzxml, m, '❌ Konfigurasi LISTPANEL tidak ditemukan.');
        }

        const pkg = ramList.find((v) => v.name === pkgName);
        if (!pkg) {
            return sendText(Yudzxml, m, `❌ Package "${pkgName}" tidak ditemukan.`);
        }

        db.create(
            m.sender,
            {
                status: STATUS.CEKUSER,
                ramPackage: pkg,
                chatId: chatId
            },
            TTL.DEFAULT
        );

        const menuText = `┌─────────────────────────┐
│  ✦  *DETAIL PACKAGE*  ✦   │
├─────────────────────────┤
│  📦 Nama  : ${pkg.name}
│  🧠 RAM   : ${formatBytes(pkg.ram)}
│  💾 Disk  : ${formatBytes(pkg.disk)}
│  ⚡ CPU   : ${pkg.cpu}%
│  💰 Harga : ${formatCurrency(pkg.price)}
└─────────────────────────┘

Silakan pilih tipe order:`;

        return sendNativeFlowList(Yudzxml, m, {
            image: fotomenunya,
            caption: menuText,
            title: '˖ ࣪ ݂ ✤ PILIH TIPE ORDER',
            sections: [
                {
                    title: 'TIPE ORDER',
                    rows: [
                        {
                            title: '˖ ࣪ ݂ ❥  Pribadi',
                            description: `Gunakan akun panel sendiri`,
                            id: 'cpanel_ordertype_self'
                        },
                        {
                            title: '˖ ࣪ ݂ ❥  Customer',
                            description: `Buat akun panel baru untuk customer`,
                            id: 'cpanel_ordertype_normal'
                        }
                    ]
                }
            ]
        });
    }

    if (id === 'cpanel_ordertype_self' || id === 'cpanel_ordertype_normal') {
        const session = getSession(m);
        if (!session || session.data.status !== STATUS.CEKUSER) {
            return sendText(
                Yudzxml,
                m,
                '❌ Sesi tidak ditemukan atau sudah expired. Ketik \`.createserver\` untuk memulai.'
            );
        }

        const orderType = id === 'cpanel_ordertype_self' ? 'self' : 'normal';

        db.updateByUserId(m.sender, {
            status: STATUS.WAIT_EMAIL,
            orderType: orderType
        });

        if (orderType === 'self') {
            return sendText(
                Yudzxml,
                m,
                `✉️  *MASUKKAN EMAIL*\n\n` +
                    `Mode: *Pribadi (Self)*\n` +
                    `Jika email sudah terdaftar di sistem, password tidak akan diminta lagi.\n\n` +
                    `Kirim email kamu sekarang:\n` +
                    `> contoh: user@gmail.com\n\n` +
                    `Ketik *batal* untuk membatalkan.`
            );
        } else {
            return sendText(
                Yudzxml,
                m,
                `✉️  *MASUKKAN EMAIL CUSTOMER*\n\n` +
                    `Mode: *Customer (Normal)*\n` +
                    `Akun panel baru akan dibuat untuk customer ini.\n\n` +
                    `Kirim email customer sekarang:\n` +
                    `> contoh: customer@gmail.com\n\n` +
                    `Ketik *batal* untuk membatalkan.`
            );
        }
    }

    if (id === 'cpanel_type_nodejs' || id === 'cpanel_type_python') {
        const session = getSession(m);
        if (!session || session.data.status !== STATUS.WAIT_TYPE) {
            return sendText(
                Yudzxml,
                m,
                '❌ Sesi tidak ditemukan atau sudah expired. Ketik \`.createserver\` untuk memulai.'
            );
        }

        const type = id === 'cpanel_type_nodejs' ? 'nodejs' : 'python';

        db.updateByUserId(m.sender, {
            status: STATUS.WAIT_DOCKER_IMAGE,
            type: type
        });

        return sendDockerImageSelection(Yudzxml, m, type, session.data.ramPackage);
    }

    if (id.startsWith('cpanel_docker_')) {
        const session = getSession(m);
        if (!session || session.data.status !== STATUS.WAIT_DOCKER_IMAGE) {
            return sendText(
                Yudzxml,
                m,
                '❌ Sesi tidak ditemukan atau sudah expired. Ketik \`.createserver\` untuk memulai.'
            );
        }

        const dockerImageKey = id.replace('cpanel_docker_', '');

        db.updateByUserId(m.sender, {
            status: STATUS.WAIT_PAYMENT,
            dockerImageKey: dockerImageKey
        });

        return await processPayment(Yudzxml, m, session.sessionId);
    }

    return null;
}

module.exports = { handleButtonResponse };

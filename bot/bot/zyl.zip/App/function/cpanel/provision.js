/**
 * cpanel/provision.js — Pembuatan server Pterodactyl setelah pembayaran terkonfirmasi. Digabung dari cpanelHandler.js (903 baris) agar per-file kecil & mudah dirawat.
 *
 */
const db = require('@App/function/cpanelDB');
const config = require('@Config');
const services = require('./services');
const { STATUS } = require('./constants');
const { formatCurrency, formatBytes, buildContextInfo } = require('./utils');

async function processServerCreation(sessionId, Yudzxml, m) {
    const session = db.get(sessionId);
    if (!session) {
        return;
    }

    const { ramPackage, orderType, email, password, type, dockerImageKey, orderId, amount, chatId } = session.data;
    const targetChatId = chatId || m.chat;

    db.update(sessionId, { status: STATUS.PROCESSING });

    await Yudzxml.sendMessage(targetChatId, {
        text:
            `✅ *Pembayaran Berhasil!*\n\n` +
            `Order ID: ${orderId}\n` +
            `Jumlah: ${formatCurrency(amount)}\n\n` +
            `⏳ Sedang membuat server... Mohon tunggu sebentar.`,
        contextInfo: buildContextInfo(m)
    });

    try {
        await services.pakasir.validatePayment(orderId, amount);

        const username = email
            .split('@')[0]
            .replace(/[^a-zA-Z0-9]/g, '')
            .slice(0, 20);
        const uniqueSuffix = Math.random().toString(36).slice(2, 6);
        const serverName = `${username}_${uniqueSuffix}`;

        const result = await services.ptero.run({
            orderType: orderType,
            email: email,
            username: serverName,
            password: password,
            type: type,
            dockerImageKey: dockerImageKey,
            resources: {
                ram: ramPackage.ram,
                disk: ramPackage.disk,
                cpu: ramPackage.cpu
            }
        });

        if (!result.success) {
            throw new Error(result.message || 'Gagal membuat server');
        }

        db.update(sessionId, {
            status: STATUS.COMPLETED,
            serverData: result.data
        });

        const domain = result.data.domain || config.cpanel?.BASE || '-';
        const serverDetails =
            `╭━━━━━━━━━━━━━━━━━━━━━━━━━━╮\n` +
            `│   ✦  *SERVER BERHASIL*  ✦    │\n` +
            `╰━━━━━━━━━━━━━━━━━━━━━━━━━━╯\n\n` +
            `🌐 *Detail Server*\n` +
            `├ Panel      : ${domain}\n` +
            `├ Server ID  : ${result.data.serverId}\n` +
            `├ Nama       : ${result.data.username}\n` +
            `├ RAM        : ${formatBytes(result.data.ram)}\n` +
            `├ Disk       : ${formatBytes(result.data.disk)}\n` +
            `├ CPU        : ${result.data.cpu}%\n` +
            `├ Runtime    : ${type.toUpperCase()}\n` +
            `├ Docker     : ${dockerImageKey}\n` +
            `├ Dibuat     : ${new Date(result.data.createdAt).toLocaleString('id-ID')}\n` +
            `└ Expired   : ${new Date(result.data.expiredAt).toLocaleString('id-ID')}\n\n` +
            `👤 *Akun Panel*\n` +
            `├ Email    : ${email}\n` +
            `└ Password : ${password}\n\n` +
            `💰 *Pembayaran*\n` +
            `├ Order ID : ${orderId}\n` +
            `├ Jumlah   : ${formatCurrency(amount)}\n` +
            `└ Status   : ✅ Lunas\n\n` +
            `⚠️  *Simpan data ini dengan baik!*\n` +
            `Server akan otomatis dihapus pada tanggal expired.`;

        await Yudzxml.sendMessage(m.sender, {
            text: serverDetails,
            contextInfo: buildContextInfo(m)
        });

        setTimeout(() => {
            db.destroy(sessionId);
        }, 30000);
    } catch (error) {
        console.error(`[CpanelHandler] Server creation failed for ${orderId}:`, error);

        db.update(sessionId, { status: STATUS.FAILED });

        await Yudzxml.sendMessage(targetChatId, {
            text:
                `❌ *Gagal Membuat Server*\n\n` +
                `Order ID: ${orderId}\n` +
                `Pembayaran: ✅ Sudah dibayar (${formatCurrency(amount)})\n\n` +
                `Error: ${error.message}\n\n` +
                `⚠️  Pembayaran sudah berhasil tetapi server gagal dibuat.\n` +
                `Silakan hubungi admin dengan menyertakan Order ID di atas.\n` +
                `Admin akan membuatkan server secara manual.`,
            contextInfo: buildContextInfo(m)
        });
    }
}

module.exports = { processServerCreation };

/**
 * cpanel/utils.js — Validasi, format & helper kirim pesan untuk alur cpanel. Digabung dari cpanelHandler.js (903 baris) agar per-file kecil & mudah dirawat.
 *
 */
const config = require('@Config');
const { randomAssets } = require('@App/function/handler');

const fotomenunya = randomAssets.fotomenunya;

function isValidEmail(email) {
    if (!email || typeof email !== 'string') return false;
    const regex = /^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$/;
    return regex.test(email.trim());
}

function isValidPassword(password) {
    if (!password || typeof password !== 'string') return false;
    return password.trim().length >= 6;
}

function generateOrderId() {
    const timestamp = Date.now().toString(36).toUpperCase();
    const random = Math.random().toString(36).slice(2, 6).toUpperCase();
    return `CPL-${timestamp}-${random}`;
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(amount);
}

function formatBytes(mb) {
    if (mb >= 1024) return `${(mb / 1024).toFixed(1)} GB`;
    return `${mb} MB`;
}

function getTimeRemaining(expiresAt) {
    const now = new Date();
    const expiry = new Date(expiresAt);
    const diff = expiry - now;

    if (diff <= 0) return 'Sudah expired';

    const minutes = Math.floor(diff / 60000);
    const seconds = Math.floor((diff % 60000) / 1000);
    return `${minutes} menit ${seconds} detik`;
}

function buildContextInfo(m) {
    return {
        mentionedJid: [m.sender],
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: config.idch || '',
            newsletterName: config.ownername || 'Bot'
        }
    };
}

async function sendNativeFlowList(Yudzxml, m, { image, caption, title, sections, fileName }) {
    const msgPayload = {
        caption: caption,
        headerType: 4,
        viewOnce: true,
        buttons: [
            {
                buttonId: 'action',
                buttonText: { displayText: `📂 ${title}` },
                type: 4,
                nativeFlowInfo: {
                    name: 'single_select',
                    paramsJson: JSON.stringify({
                        title: title,
                        sections: sections
                    })
                }
            }
        ],
        contextInfo: buildContextInfo(m)
    };

    if (image) {
        msgPayload.image = { url: image };
        msgPayload.fileName = fileName || config.ownername || 'image';
        msgPayload.mimetype = 'image/png';
    }

    return await Yudzxml.sendMessage(m.chat, msgPayload, { quoted: m });
}

async function sendText(Yudzxml, m, text) {
    return await Yudzxml.sendMessage(
        m.chat,
        {
            text: text,
            contextInfo: buildContextInfo(m)
        },
        { quoted: m }
    );
}

async function sendImage(Yudzxml, m, buffer, caption) {
    return await Yudzxml.sendMessage(
        m.chat,
        {
            image: buffer,
            caption: caption,
            mimetype: 'image/png',
            contextInfo: buildContextInfo(m)
        },
        { quoted: m }
    );
}

module.exports = {
    fotomenunya,
    isValidEmail,
    isValidPassword,
    generateOrderId,
    formatCurrency,
    formatBytes,
    getTimeRemaining,
    buildContextInfo,
    sendNativeFlowList,
    sendText,
    sendImage
};

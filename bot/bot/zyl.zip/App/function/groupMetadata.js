const _groupMetaCache = new Map();

async function getGroupMetadata(sock, jid, options = {}) {
    const { ttl = 5 * 60 * 1000, maxSize = 500, force = false } = options;

    const now = Date.now();
    const cached = _groupMetaCache.get(jid);

    if (force) _groupMetaCache.delete(jid);

    if (cached?.data && now - cached.timestamp < ttl) {
        return cached.data;
    }

    if (cached?.promise) {
        return cached.promise;
    }

    const promise = sock
        .groupMetadata(jid)
        .then(async (metadata) => {
            if (Array.isArray(metadata.participants)) {
                await Promise.all(
                    metadata.participants.map(async (participant) => {
                        if (participant.phoneNumber) {
                            participant.lid = participant.id;
                            participant.id = participant.phoneNumber;
                            return;
                        }

                        if (participant.id?.endsWith('@lid') && sock.signalRepository?.lidMapping?.getPNForLID) {
                            try {
                                const pn = await sock.signalRepository.lidMapping.getPNForLID(participant.id);

                                if (pn) {
                                    participant.lid = participant.id;
                                    participant.phoneNumber = pn;
                                    participant.id = pn;
                                }
                            } catch {}
                        }
                    })
                );
            }

            _groupMetaCache.set(jid, {
                data: metadata,
                timestamp: Date.now()
            });

            if (_groupMetaCache.size > maxSize) {
                const oldestKey = _groupMetaCache.keys().next().value;
                _groupMetaCache.delete(oldestKey);
            }

            return metadata;
        })
        .catch((err) => {
            _groupMetaCache.delete(jid);
            throw err;
        });

    _groupMetaCache.set(jid, {
        promise,
        timestamp: now
    });

    return promise;
}

module.exports = getGroupMetadata;

const fs = require('fs');
const path = require('path');

const { loadDB: loadDBLayer, saveDB: saveDBLayer } = require('../../database/wrappers/storage');

class ListManagerError extends Error {
    constructor(message) {
        super(message);
        this.name = 'ListManagerError';
    }
}

class ListManager {
    constructor() {
        this.STORAGE_DIR = path.join(__dirname, '../../Storage');
        this.DB_PATH_GRUP = path.join(this.STORAGE_DIR, 'listDB.json');
        this.DB_PATH_OWNER = path.join(this.STORAGE_DIR, 'listOwnDB.json');

        this._ensureStorageDir();
    }

    _ensureStorageDir() {
        if (!fs.existsSync(this.STORAGE_DIR)) {
            fs.mkdirSync(this.STORAGE_DIR, { recursive: true });
        }
    }

    _getPathByChat(chatId) {
        return chatId.endsWith('@g.us') ? this.DB_PATH_GRUP : this.DB_PATH_OWNER;
    }

    _loadDB(filePath) {
        try {
            const data = loadDBLayer(filePath, {});
            return data && typeof data === 'object' && !Array.isArray(data) ? data : {};
        } catch (err) {
            console.error('[ListManager] Load DB error:', err);
            return {};
        }
    }

    _saveDB(filePath, data) {
        try {
            saveDBLayer(filePath, data);
            return true;
        } catch (err) {
            throw new ListManagerError('Gagal menyimpan database.');
        }
    }

    _normalizeId(id) {
        if (id === undefined || id === null) return null;
        return String(id).trim();
    }

    _getNextId(list) {
        if (!Array.isArray(list) || list.length === 0) return '1';

        const numericIds = list.map((v) => Number(v.id)).filter((v) => !isNaN(v));

        if (numericIds.length === 0) return '1';
        return String(Math.max(...numericIds) + 1);
    }

    addList(chatId, { id, type, text = '', url = null }) {
        const allowedTypes = ['text', 'audio', 'image', 'video', 'document'];

        if (!allowedTypes.includes(type)) {
            throw new ListManagerError(`Tipe "${type}" tidak valid.`);
        }

        if (type === 'text' && !text.trim()) {
            throw new ListManagerError('Teks tidak boleh kosong.');
        }

        if (type !== 'text' && !url) {
            throw new ListManagerError('URL wajib untuk media.');
        }

        const dbPath = this._getPathByChat(chatId);
        const db = this._loadDB(dbPath);

        if (!db[chatId]) db[chatId] = [];

        const finalId = this._normalizeId(id) || this._getNextId(db[chatId]);

        const duplicate = db[chatId].some((v) => String(v.id) === finalId);

        if (duplicate) {
            throw new ListManagerError(`ID "${finalId}" sudah digunakan.`);
        }

        const newItem = {
            id: finalId,
            type,
            text: text.trim(),
            url: url ? url.trim() : null,
            createdAt: new Date().toISOString(),
            timestamp: Date.now()
        };

        db[chatId].push(newItem);
        this._saveDB(dbPath, db);

        return newItem;
    }

    getList(chatId, id = null) {
        const dbPath = this._getPathByChat(chatId);
        const db = this._loadDB(dbPath);

        const list = db[chatId] || [];

        if (id === null || id === undefined) {
            return list;
        }

        const targetId = this._normalizeId(id);
        return list.find((v) => String(v.id) === targetId) || null;
    }

    deleteList(chatId, id) {
        const dbPath = this._getPathByChat(chatId);
        const db = this._loadDB(dbPath);

        if (!db[chatId]) return false;

        const targetId = this._normalizeId(id);
        const index = db[chatId].findIndex((v) => String(v.id) === targetId);

        if (index === -1) return false;

        db[chatId].splice(index, 1);
        this._saveDB(dbPath, db);
        return true;
    }

    clearList(chatId) {
        const dbPath = this._getPathByChat(chatId);
        const db = this._loadDB(dbPath);

        if (!db[chatId]) return false;

        db[chatId] = [];
        this._saveDB(dbPath, db);
        return true;
    }

    updateList(chatId, { id, type, text, url }) {
        const allowedTypes = ['text', 'audio', 'image', 'video', 'document'];
        const dbPath = this._getPathByChat(chatId);
        const db = this._loadDB(dbPath);

        if (!db[chatId]) {
            throw new ListManagerError('List tidak ditemukan.');
        }

        const targetId = this._normalizeId(id);
        const item = db[chatId].find((v) => String(v.id) === targetId);

        if (!item) {
            throw new ListManagerError(`ID "${targetId}" tidak ditemukan.`);
        }

        if (type) {
            type = type.toLowerCase();
            if (!allowedTypes.includes(type)) {
                throw new ListManagerError('Tipe tidak valid.');
            }
            item.type = type;
        }

        if (text !== undefined) {
            if (item.type === 'text' && !text.trim()) {
                throw new ListManagerError('Teks tidak boleh kosong.');
            }
            item.text = text.trim();
        }

        if (url !== undefined) {
            if (item.type !== 'text' && !url) {
                throw new ListManagerError('URL wajib untuk media.');
            }
            item.url = url ? url.trim() : null;
        }

        item.updatedAt = new Date().toISOString();
        this._saveDB(dbPath, db);

        return item;
    }
}

const listManager = new ListManager();

module.exports = {
    addList: listManager.addList.bind(listManager),
    getList: listManager.getList.bind(listManager),
    updateList: listManager.updateList.bind(listManager),
    deleteList: listManager.deleteList.bind(listManager),
    clearList: listManager.clearList.bind(listManager)
};

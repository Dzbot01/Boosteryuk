exports.loading = async (conn, m) => {
    try {
        await conn.sendMessage(m.chat, {
            react: {
                text: '⏰',
                key: m.key
            }
        });
    } catch {}
};

exports.success = async (conn, m) => {
    try {
        await conn.sendMessage(m.chat, {
            react: {
                text: '✅',
                key: m.key
            }
        });
    } catch {}
};

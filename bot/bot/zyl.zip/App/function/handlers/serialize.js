const { proto, getContentType } = require('baileys');
const config = require('../../../config');

exports.smsg = async (conn, m, store) => {
    try {
        if (!m) return m;
        const M = proto.WebMessageInfo;

        const cleanJid = (jid = '') => {
            if (!jid) return jid;
            return jid.replace(/:\d+@s\.whatsapp\.net$/, '@s.whatsapp.net');
        };

        const resolveLid = async (jid) => {
            try {
                if (!jid?.endsWith('@lid')) {
                    return cleanJid(jid);
                }
                const pn = await conn.signalRepository?.lidMapping?.getPNForLID(jid);
                return cleanJid(conn.decodeJid(pn || jid));
            } catch {
                return cleanJid(jid);
            }
        };

        const resolveMentionedJid = async (mentioned = []) => {
            try {
                if (!Array.isArray(mentioned)) return [];
                return await Promise.all(
                    mentioned.map(async (jid) => {
                        try {
                            return await resolveLid(jid);
                        } catch {
                            return cleanJid(jid);
                        }
                    })
                );
            } catch {
                return mentioned;
            }
        };

        if (m.key) {
            m.id = m.key.id;
            m.isBaileys = m.id?.startsWith('BAE5') && m.id.length === 16;

            m.chat = cleanJid(m.key.remoteJidAlt || m.key.remoteJid);

            m.fromMe = m.key.fromMe;
            m.isGroup = m.chat?.endsWith('@g.us');

            let rawSender = m.fromMe ? conn.user.id : m.key.participantAlt || m.key.participant || m.chat;

            rawSender = await resolveLid(rawSender);

            m.sender = conn.decodeJid(rawSender);

            if (m.isGroup) {
                let rawParticipant = m.key.participantAlt || m.key.participant || '';
                rawParticipant = await resolveLid(rawParticipant);
                m.participant = conn.decodeJid(rawParticipant);
            }
        }

        if (m.message) {
            m.mtype = getContentType(m.message);

            m.msg =
                m.mtype === 'viewOnceMessage'
                    ? m.message[m.mtype].message[getContentType(m.message[m.mtype].message)]
                    : m.message[m.mtype];

            m.body =
                m.message.conversation ||
                m.msg?.caption ||
                m.msg?.text ||
                m.msg?.singleSelectReply?.selectedRowId ||
                m.msg?.selectedButtonId ||
                '';

            const quoted = m.msg?.contextInfo?.quotedMessage;

            m.mentionedJid = await resolveMentionedJid(m.msg?.contextInfo?.mentionedJid || []);

            if (quoted) {
                let type = getContentType(quoted);
                let q = quoted[type];

                if (typeof q === 'string') {
                    q = { text: q };
                }

                m.quoted = q;
                m.quoted.mtype = type;
                m.quoted.id = m.msg.contextInfo.stanzaId;
                m.quoted.chat = m.chat;
                m.quoted.isBaileys = m.quoted.id?.startsWith('BAE5') && m.quoted.id.length === 16;

                let rawQuotedSender = m.msg.contextInfo.participant;
                rawQuotedSender = await resolveLid(rawQuotedSender);

                m.quoted.sender = conn.decodeJid(rawQuotedSender);
                m.quoted.fromMe = m.quoted.sender === conn.user?.id;

                m.quoted.text =
                    q.text || q.caption || q.conversation || q.contentText || q.selectedDisplayText || q.title || '';

                m.quoted.mentionedJid = await resolveMentionedJid(m.msg.contextInfo.mentionedJid || []);

                m.getQuotedObj = m.getQuotedMessage = async () => {
                    if (!m.quoted.id) return null;
                    const qmsg = await store.loadMessage(m.chat, m.quoted.id, conn);
                    return exports.smsg(conn, qmsg, store);
                };

                const vM = (m.quoted.fakeObj = M.fromObject({
                    key: {
                        remoteJid: m.quoted.chat,
                        fromMe: m.quoted.fromMe,
                        id: m.quoted.id
                    },
                    message: quoted,
                    ...(m.isGroup ? { participant: m.quoted.sender } : {})
                }));

                m.quoted.delete = () => conn.sendMessage(m.quoted.chat, { delete: vM.key });
                m.quoted.copyNForward = (jid, force = false, opt = {}) => conn.copyNForward(jid, vM, force, opt);
                m.quoted.download = () => conn.downloadMediaMessage(m.quoted);
            }
        }

        if (m.msg?.url) {
            m.download = () => conn.downloadMediaMessage(m.msg);
        }

        let params = {};
        const raw = m.message?.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson;
        params = typeof raw === 'string' ? JSON.parse(raw) : raw || {};
        m.text =
            params?.id ||
            m.msg?.text ||
            m.msg?.caption ||
            m.message?.conversation ||
            m.msg?.contentText ||
            m.msg?.selectedDisplayText ||
            m.msg?.title ||
            '';

        m.reply = async (text, jid = m.chat, options = {}) => {
            return conn.sendMessage(
                jid,
                {
                    text,
                    contextInfo: {
                        mentionedJid: [m.sender, ...(options.mentionedJid || [])],
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: conn.identity?.idch || config.idch,
                            newsletterName: conn.identity?.ownername || config.ownername
                        },
                        ...options.contextInfo
                    }
                },
                { quoted: m }
            );
        };

        m.copy = () => exports.smsg(conn, M.fromObject(M.toObject(m)), store);
        m.copyNForward = (jid = m.chat, force = false, opt = {}) => conn.copyNForward(jid, m, force, opt);

        return m;
    } catch (err) {
        console.log('❌ SMSG ERROR:');
        console.log(err);
        console.log(err?.stack);
        return m;
    }
};

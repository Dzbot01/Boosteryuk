const Jimp = require('jimp');
const axios = require('axios');
const { bytesToSize } = require('./formatter');

exports.generateProfilePicture = async (buffer) => {
    const jimp = await Jimp.read(buffer);
    const min = jimp.getWidth();
    const max = jimp.getHeight();
    const cropped = jimp.crop(0, 0, min, max);
    return {
        img: await cropped.scaleToFit(720, 720).getBufferAsync(Jimp.MIME_JPEG),
        preview: await cropped.scaleToFit(720, 720).getBufferAsync(Jimp.MIME_JPEG)
    };
};

exports.reSize = (buffer, ukur1, ukur2) => {
    return new Promise(async (resolve, reject) => {
        try {
            var baper = await Jimp.read(buffer);
            var ab = await baper.resize(ukur1, ukur2).getBufferAsync(Jimp.MIME_JPEG);
            resolve(ab);
        } catch (error) {
            reject(error);
        }
    });
};

exports.getSizeMedia = (path) => {
    return new Promise((resolve, reject) => {
        if (/http/.test(path)) {
            axios
                .head(path)
                .then((res) => {
                    let length = parseInt(res.headers['content-length']);
                    let size = bytesToSize(length, 3);
                    if (!isNaN(length)) resolve(size);
                    else reject('Unknown content length');
                })
                .catch((e) => reject(e));
        } else if (Buffer.isBuffer(path)) {
            let length = Buffer.byteLength(path);
            let size = bytesToSize(length, 3);
            if (!isNaN(length)) resolve(size);
        } else {
            reject('error invalid path');
        }
    });
};

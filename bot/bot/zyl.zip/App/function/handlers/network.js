const axios = require('axios');
const fs = require('fs');
const https = require('https');
const http = require('http');

/**
 * PF4: Global HTTP keep-alive pool untuk axios.
 *
 * Sebelumnya setiap `axios.get` create koneksi baru → boros CPU & latency.
 * Sekarang pakai single `https.Agent` & `http.Agent` dengan keepAlive true,
 * maxSockets 50, yang di-share ke semua request axios global.
 */
const keepAliveHttpsAgent = new https.Agent({
    keepAlive: true,
    maxSockets: 50,
    maxFreeSockets: 10,
    timeout: 30000,
    freeSocketTimeout: 15000
});

const keepAliveHttpAgent = new http.Agent({
    keepAlive: true,
    maxSockets: 50,
    maxFreeSockets: 10,
    timeout: 30000,
    freeSocketTimeout: 15000
});

// Apply globally — semua axios.get/post default pakai agent ini.
axios.defaults.httpsAgent = keepAliveHttpsAgent;
axios.defaults.httpAgent = keepAliveHttpAgent;
// Default timeout global (boleh di-override per-request).
axios.defaults.timeout = 30000;

/**
 * fetchJson — SATU-SATUNYA fetch JSON untuk seluruh project.
 * Support opsional retry: fetchJson(url, { retries: 4, retryDelay: 2000, timeout: 25000 })
 * Perilaku lama dipertahankan: gagal => balikin object error (tidak throw).
 */
exports.fetchJson = async (url, options) => {
    options = options || {};
    const { retries = 0, retryDelay = 2000, timeout = 30000, ...axiosOptions } = options;

    let lastError;
    for (let attempt = 1; attempt <= retries + 1; attempt++) {
        try {
            const res = await axios({
                method: 'GET',
                url,
                timeout,
                headers: {
                    'User-Agent':
                        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36',
                    Accept: 'application/json,text/plain,*/*'
                },
                ...axiosOptions
            });
            return res.data;
        } catch (err) {
            lastError = err;
            if (attempt <= retries) {
                await new Promise((r) => setTimeout(r, retryDelay));
            }
        }
    }
    return lastError;
};

exports.getBuffer = async (url, options) => {
    try {
        options = options || {};
        const res = await axios({
            method: 'get',
            url,
            headers: {
                DNT: 1,
                'Upgrade-Insecure-Request': 1
            },
            ...options,
            responseType: 'arraybuffer'
        });
        return res.data;
    } catch (err) {
        return err;
    }
};

exports.getImg = async (url, options) => {
    return exports.getBuffer(url, options);
};

exports.shorturl = async function (longUrl) {
    try {
        const data = { url: longUrl };
        const response = await axios.post('https://shrtrl.vercel.app/', data);
        return response.data.data.shortUrl;
    } catch (error) {
        return error;
    }
};

exports.checkBandwidth = async () => {
    try {
        let last = {
            rx: 0,
            tx: 0,
            time: Date.now()
        };
        const netDir = '/sys/class/net';
        const iface = fs.readdirSync(netDir).find((i) => i !== 'lo') || 'eth0';

        const rxPath = `${netDir}/${iface}/statistics/rx_bytes`;
        const txPath = `${netDir}/${iface}/statistics/tx_bytes`;

        const rx = Number(fs.readFileSync(rxPath, 'utf8').trim());
        const tx = Number(fs.readFileSync(txPath, 'utf8').trim());

        const now = Date.now();
        const timeDiff = (now - last.time) / 1000;

        const rxDiff = rx - last.rx;
        const txDiff = tx - last.tx;

        last = { rx, tx, time: now };

        const { bytesToSize } = require('./formatter');
        return {
            interface: iface,
            download: bytesToSize(rx),
            upload: bytesToSize(tx),
            downloadSpeed: bytesToSize(rxDiff / timeDiff) + '/s',
            uploadSpeed: bytesToSize(txDiff / timeDiff) + '/s'
        };
    } catch (e) {
        console.log('Error checking bandwidth:', e);
        return null;
    }
};

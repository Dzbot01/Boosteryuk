const { extractMessageBody, sendRegisterPrompt, getTimeBasedGreeting } = require('./message');

const { getProfileUrl, getProfileBuffer, fkontak } = require('./profile');

const { getBuffer, getImg, fetchJson, shorturl, checkBandwidth } = require('./network');

const {
    bytesToSize,
    formatSize,
    formatp,
    isUrl,
    jsonformat,
    json,
    logic,
    parseMention,
    getRandom,
    pickRandom,
    color
} = require('./formatter');

const {
    getTime,
    formatDate,
    tanggal,
    jam,
    runtime,
    clockString,
    processTime,
    unixTimestampSeconds,
    generateMessageTag,
    sleep
} = require('./time');

const { generateProfilePicture, reSize, getSizeMedia } = require('./image');

const { loading, success } = require('./react');

const { smsg } = require('./serialize');

const { randomAssets } = require('./assets');

const { getGroupAdmins } = require('./profile');

module.exports = {
    extractMessageBody,
    sendRegisterPrompt,
    getTimeBasedGreeting,

    getProfileUrl,
    getProfileBuffer,
    fkontak,
    getGroupAdmins,

    getBuffer,
    getImg,
    fetchJson,
    shorturl,
    checkBandwidth,

    bytesToSize,
    formatSize,
    formatp,
    isUrl,
    jsonformat,
    json,
    logic,
    parseMention,
    getRandom,
    pickRandom,
    color,

    getTime,
    formatDate,
    tanggal,
    jam,
    runtime,
    clockString,
    processTime,
    unixTimestampSeconds,
    generateMessageTag,
    sleep,

    generateProfilePicture,
    reSize,
    getSizeMedia,

    loading,
    success,

    smsg,

    randomAssets
};

const { proto, prepareWAMessageMedia } = require('baileys');
const moment = require('moment-timezone');
const logger = require('../logger');
const config = require('../../../config');

exports.extractMessageBody = (msg) => {
    const type = msg?.mtype;
    const content = msg?.message;
    if (!content) return '';

    const getInteractiveId = () => {
        try {
            const paramsJson =
                content?.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson ||
                content?.nativeFlowResponseMessage?.paramsJson;
            const params = JSON.parse(paramsJson);
            return params?.id || '';
        } catch (e) {
            return '';
        }
    };

    const messageMap = {
        conversation: content.conversation,
        imageMessage: content.imageMessage?.caption,
        videoMessage: content.videoMessage?.caption,
        extendedTextMessage: content.extendedTextMessage?.text,
        buttonsResponseMessage: content.buttonsResponseMessage?.selectedButtonId,
        templateButtonReplyMessage: content.templateButtonReplyMessage?.selectedId,
        listResponseMessage: content.listResponseMessage?.singleSelectReply?.selectedRowId,
        interactiveResponseMessage: getInteractiveId()
    };

    return messageMap[type] || msg?.text || '';
};

exports.sendRegisterPrompt = async (sock, m, prefix, cfg) => {
    try {
        const media = await prepareWAMessageMedia(
            {
                image: {
                    url: cfg.thumbnail.register || 'https://i.imgur.com/Example.jpg'
                }
            },
            { upload: sock.waUploadToServer }
        );

        const interactiveMsg = proto.Message.InteractiveMessage.fromObject({
            body: proto.Message.InteractiveMessage.Body.fromObject({ text: cfg.mess.register }),
            footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: `` }),
            header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: true,
                ...media
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                    {
                        name: 'quick_reply',
                        buttonParamsJson: JSON.stringify({
                            display_text: 'ᴅᴀꜰᴛᴀʀ ꜱᴇᴋᴀʀᴀɴɢ',
                            id: `${prefix}daftar`
                        })
                    }
                ]
            }),
            contextInfo: {
                mentionedJid: [m.sender],
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: cfg.idch || '120363291726836483@newsletter',
                    serverMessageId: 100,
                    newsletterName: cfg.ownername
                }
            }
        });

        await sock.relayMessage(
            m.chat,
            { viewOnceMessageV2Extension: { message: { interactiveMessage: interactiveMsg } } },
            { quoted: m }
        );
    } catch (err) {
        logger.error('Error sending register prompt: ' + err);
        await sock.sendMessage(m.chat, { text: cfg.mess.register }, { quoted: m });
    }
};

exports.getTimeBasedGreeting = () => {
    const time = moment().tz('Asia/Jakarta').format('HH:mm:ss');
    let greeting, emoji;
    if (time < '03:00:00') {
        greeting = 'ꜱᴇʟᴀᴍᴀᴛ ᴛᴇɴɢᴀʜ ᴍᴀʟᴀᴍ';
        emoji = '🌙';
    } else if (time < '05:00:00') {
        greeting = 'ꜱᴇʟᴀᴍᴀᴛ ꜱᴜʙᴜʜ';
        emoji = '🌙';
    } else if (time < '10:00:00') {
        greeting = 'ꜱᴇʟᴀᴍᴀᴛ ᴘᴀɢɪ';
        emoji = '🌄';
    } else if (time < '11:00:00') {
        greeting = 'ꜱᴇʟᴀᴍᴀᴛ ᴘᴀɢɪ';
        emoji = '🌄';
    } else if (time < '15:00:00') {
        greeting = 'ꜱᴇʟᴀᴍᴀᴛ ꜱɪᴀɴɢ';
        emoji = '☀️';
    } else if (time < '17:00:00') {
        greeting = 'ꜱᴇʟᴀᴍᴀᴛ ꜱɪᴀɴɢ';
        emoji = '☀️';
    } else if (time < '18:00:00') {
        greeting = 'ꜱᴇʟᴀᴍᴀᴛ ꜱᴏʀᴇ';
        emoji = '🌅';
    } else if (time < '19:00:00') {
        greeting = 'ꜱᴇʟᴀᴍᴀᴛ ꜱᴏʀᴇ';
        emoji = '🌅';
    } else if (time < '23:59:00') {
        greeting = 'ꜱᴇʟᴀᴍᴀᴛ ᴘᴇᴛᴀɴɢ';
        emoji = '🌙';
    } else {
        greeting = 'ꜱᴇʟᴀᴍᴀᴛ ᴍᴀʟᴀᴍ️';
        emoji = '🌌';
    }
    return { greeting, emoji };
};

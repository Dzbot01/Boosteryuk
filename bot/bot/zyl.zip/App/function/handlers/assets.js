const config = require('../../../config');
const { pickRandom } = require('./formatter');

exports.randomAssets = {
    replyimage: pickRandom(config.thumbnail.imagereply || []),
    fotomenunya: pickRandom(config.thumbnail.imagemenu || []),
    audiomenu: pickRandom(config.thumbnail.audio || [])
};

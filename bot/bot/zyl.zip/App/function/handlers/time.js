const moment = require('moment-timezone');

exports.getTime = (format, date) => {
    if (date) {
        return moment(date).locale('id').format(format);
    } else {
        return moment.tz('Asia/Jakarta').locale('id').format(format);
    }
};

exports.formatDate = (n, locale = 'id') => {
    let d = new Date(n);
    return d.toLocaleDateString(locale, {
        weekday: 'long',
        day: 'numeric',
        month: 'long',
        year: 'numeric',
        hour: 'numeric',
        minute: 'numeric',
        second: 'numeric'
    });
};

exports.tanggal = (numer) => {
    const myMonths = [
        'Januari',
        'Februari',
        'Maret',
        'April',
        'Mei',
        'Juni',
        'Juli',
        'Agustus',
        'September',
        'Oktober',
        'November',
        'Desember'
    ];
    const myDays = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jum\u2019at', 'Sabtu'];
    var tgl = new Date(numer);
    var day = tgl.getDate();
    var bulan = tgl.getMonth();
    var thisDay = tgl.getDay();
    thisDay = myDays[thisDay];
    var yy = tgl.getYear();
    var year = yy < 1000 ? yy + 1900 : yy;

    return `${thisDay}, ${day} - ${myMonths[bulan]} - ${year}`;
};

exports.jam = (numer, options = {}) => {
    let format = options.format ? options.format : 'HH:mm';
    let timeZone = options.timeZone || 'Asia/Jakarta';
    let jam = moment(numer).tz(timeZone).format(format);
    return `${jam}`;
};

exports.runtime = function (seconds) {
    seconds = Number(seconds);
    var d = Math.floor(seconds / (3600 * 24));
    var h = Math.floor((seconds % (3600 * 24)) / 3600);
    var m = Math.floor((seconds % 3600) / 60);
    var s = Math.floor(seconds % 60);
    var dDisplay = d > 0 ? d + (d == 1 ? ' Hari, ' : ' Hari, ') : '';
    var hDisplay = h > 0 ? h + (h == 1 ? ' Jam, ' : ' Jam, ') : '';
    var mDisplay = m > 0 ? m + (m == 1 ? ' Menit, ' : ' Menit, ') : '';
    var sDisplay = s > 0 ? s + (s == 1 ? ' Detik' : ' Detik') : '';
    return dDisplay + hDisplay + mDisplay + sDisplay;
};

exports.clockString = (ms) => {
    let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000);
    let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60;
    let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60;
    return [h, m, s].map((v) => v.toString().padStart(2, 0)).join(':');
};

exports.processTime = (timestamp, now) => {
    return moment.duration(now - moment(timestamp * 1000)).asSeconds();
};

exports.unixTimestampSeconds = (date = new Date()) => Math.floor(date.getTime() / 1000);

exports.generateMessageTag = (epoch) => {
    let tag = (0, exports.unixTimestampSeconds)().toString();
    if (epoch) tag += '.--' + epoch;
    return tag;
};

exports.sleep = async (ms) => {
    return new Promise((resolve) => setTimeout(resolve, ms));
};

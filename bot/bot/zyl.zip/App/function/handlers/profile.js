const config = require('../../../config');

exports.getProfileUrl = async (Yudzxml, sender) => {
    try {
        const pp = await Yudzxml.profilePictureUrl(sender, 'image');
        return pp;
    } catch (e) {
        return 'https://raw.githubusercontent.com/Yudzxml/UploaderV2/refs/heads/main/tmp/IMG-20260116-WA0029.jpg';
    }
};

exports.getProfileBuffer = async (Yudzxml, sender) => {
    const getProfileUrl = await exports.getProfileUrl(Yudzxml, sender);
    const { getBuffer } = require('./network');
    return await getBuffer(getProfileUrl);
};

exports.fkontak = () => {
    return {
        key: {
            fromMe: false,
            participant: `0@s.whatsapp.net`,
            remoteJid: 'status@broadcast'
        },
        message: {
            contactMessage: {
                displayName: config.store.nameStore,
                vcard: `BEGIN:VCARD
VERSION:3.0
N:Owner;;
FN:Owner
TEL;waid=${config.superowner}:${config.superowner}
END:VCARD`
            },
            businessOwnerJid: `0@s.whatsapp.net`
        }
    };
};

exports.getGroupAdmins = (participants) => {
    let admins = [];
    for (let i of participants) {
        i.admin === 'superadmin' ? admins.push(i.jid) : i.admin === 'admin' ? admins.push(i.jid) : '';
    }
    return admins || [];
};

/**
 * schedule.js — Entry lama scheduler (kompatibilitas).
 * Logic dipisah ke folder ./scheduleTasks/ agar mudah dirawat.
 */
module.exports = require('./scheduleTasks');

const config = require('@Config');
const { loadDB: loadDBFile, saveDB: saveDBFile } = require('../../database/wrappers/storage');
const path = require('path');

const DB_FILE = path.join(__dirname, '../../Storage/payment.json');

/**
 * PAKASIR API V2 (https://pakasir.com/p/create-transaction) — MODE QRIS SAJA
 * ---------------------------------------------------------------------------
 * - Endpoint   : /api/v2/create-transaction/{slug}/{order_id}  (POST)
 * - Auth       : header `X-Api-Key` (api_key TIDAK dikirim di body lagi)
 * - Sifat API  : find-or-create → memanggil ulang dengan body yang sama
 *                mengembalikan transaksi yang sama (idempotent, aman retry).
 * - Kunci      : setiap transaksi punya `txn_id`; status/cancel memakai
 *                txn_id (BUKAN order_id), jadi txn_id wajib disimpan lokal.
 * - Rate limit : create/cancel 2 req/detik, status 1x per 4 detik per txn
 *                (client ini menambahkan throttle cache 4.2s per txn_id).
 * - Status v2  : pending | completed | canceled
 *                Client memetakan "canceled" → STATUS.CANCELLED, dan
 *                mendeteksi kadaluarsa lokal dari `expired_at` transaksi.
 *
 * PEMBAYARAN = QRIS SAJA (kebijakan bot):
 * - TANPA payment link, TANPA virtual account — semua transaksi dipaksa `qris`.
 * - TANPA webhook — status dicek MANUAL oleh polling order/cpanel
 *   (order/index.js startPolling + command cekstatus), mematuhi rate limit
 *   status 1x per 4 detik via cache internal.
 */

// Hanya QRIS — metode lain (payment_link / VA) sengaja tidak disediakan.
const PAYMENT_METHODS = Object.freeze({
    QRIS: 'qris'
});

// Metode v2 yang TIDAK dipakai bot ini (ditolak dengan pesan jelas).
const DISABLED_METHODS = Object.freeze([
    'payment_link',
    'bni_va',
    'bri_va',
    'cimb_niaga_va',
    'permata_va',
    'maybank_va',
    'sampoerna_va',
    'bnc_va',
    'artha_graha_va'
]);

// Status LOKAL (normalisasi). "expired" dideteksi dari expired_at lokal
// karena API v2 hanya mengenal pending/completed/canceled.
const STATUS = Object.freeze({
    PENDING: 'pending',
    COMPLETED: 'completed',
    EXPIRED: 'expired',
    CANCELLED: 'cancelled'
});

// Status mentah yang dikembalikan API v2.
const V2_STATUS = Object.freeze({
    PENDING: 'pending',
    COMPLETED: 'completed',
    CANCELED: 'canceled'
});

const DEFAULT_EXPIRY_MS = 24 * 60 * 60 * 1000; // v2: auto-cancel setelah 1x24 jam
const STATUS_CACHE_TTL_MS = 4200; // > rate limit 4 detik per txn

const isPlaceholder = (v) => !v || /^your[_-]?/i.test(String(v).trim());

class PakasirClient {
    constructor(overrideCfg = null, scope = 'main') {
        this.STATUS = STATUS;
        this.PAYMENT_METHODS = PAYMENT_METHODS;
        this.overrideCfg = overrideCfg;
        this.scope = scope;

        this.dbFile =
            scope === 'main' ? DB_FILE : path.join(__dirname, '../../Storage/jadibot_sessions', scope, 'payment.json');

        // Cache status per txn_id (hemat kuota rate-limit status 1x/4 detik).
        this._statusCache = new Map();

        this.cleanupInterval = setInterval(() => {
            try {
                this.cleanupExpiredTransactions();
            } catch (_) {}
        }, 60 * 1000);
        this.cleanupInterval.unref?.();
    }

    _cfg() {
        if (this.overrideCfg) return this.overrideCfg;
        return config.pakasir || {};
    }

    get slug() {
        return String(this._cfg().slug || '').trim();
    }
    get apiKey() {
        return String(this._cfg().key || '').trim();
    }
    get baseUrl() {
        return String(this._cfg().baseUrl || 'https://app.pakasir.com').replace(/\/+$/, '');
    }
    get defaultMethod() {
        const m = String(this._cfg().defaultMethod || PAYMENT_METHODS.QRIS).toLowerCase();
        return Object.values(PAYMENT_METHODS).includes(m) ? m : PAYMENT_METHODS.QRIS;
    }

    get isConfigured() {
        const cfg = this._cfg();
        return cfg.enabled !== false && !isPlaceholder(this.slug) && !isPlaceholder(this.apiKey);
    }

    assertConfigured() {
        if (this._cfg().enabled === false) {
            throw new Error('Pembayaran otomatis MATI. Nyalakan config.pakasir.enabled = true di config.js.');
        }
        if (isPlaceholder(this.slug) || isPlaceholder(this.apiKey)) {
            throw new Error(
                'Pakasir belum dikonfigurasi. Isi config.pakasir.key dan config.pakasir.slug ' +
                    'di config.js (dapat dari https://pakasir.com → detail proyek kamu).'
            );
        }
    }

    assertMethod(method) {
        const m = String(method || '').toLowerCase();
        if (DISABLED_METHODS.includes(m)) {
            throw new Error(
                `Metode pembayaran "${method}" tidak dipakai bot ini. Pembayaran HANYA via QRIS.`
            );
        }
        if (!Object.values(PAYMENT_METHODS).includes(m)) {
            throw new Error(
                `Metode pembayaran "${method}" tidak dikenal. Satu-satunya metode: qris.`
            );
        }
        return m;
    }

    /* ── Penyimpanan lokal ─────────────────────────────────────────────────── */

    _readDB() {
        try {
            const data = loadDBFile(this.dbFile, { transactions: [] });
            return data && Array.isArray(data.transactions) ? data : { transactions: [] };
        } catch (_) {
            return { transactions: [] };
        }
    }

    _writeDB(data) {
        saveDBFile(this.dbFile, data);
    }

    saveTransaction(data) {
        const db = this._readDB();
        const index = db.transactions.findIndex((trx) => trx.order_id === data.order_id);

        if (index !== -1) {
            db.transactions[index] = { ...db.transactions[index], ...data, updated_at: new Date().toISOString() };
        } else {
            db.transactions.push({
                ...data,
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString()
            });
        }

        if (db.transactions.length > 300) {
            db.transactions = db.transactions.slice(-300);
        }

        this._writeDB(db);
        return data;
    }

    getTransaction(orderId) {
        return this._readDB().transactions.find((trx) => trx.order_id === orderId);
    }

    deleteTransaction(orderId) {
        const db = this._readDB();
        db.transactions = db.transactions.filter((trx) => trx.order_id !== orderId);
        this._writeDB(db);
        return true;
    }

    cleanupExpiredTransactions() {
        const db = this._readDB();
        const now = Date.now();
        const filtered = db.transactions.filter((trx) => !trx.expired_at || new Date(trx.expired_at).getTime() > now);
        if (filtered.length !== db.transactions.length) {
            db.transactions = filtered;
            this._writeDB(db);
        }
    }

    /* ── HTTP dasar ────────────────────────────────────────────────────────── */

    async _request(path, { method = 'GET', body } = {}, errorMessage = 'Request gagal') {
        let url = `${this.baseUrl}${path}`;

        let response;
        try {
            response = await fetch(url, {
                method,
                headers: {
                    'Content-Type': 'application/json',
                    'X-Api-Key': this.apiKey
                },
                body: body ? JSON.stringify(body) : undefined
            });
        } catch (err) {
            throw new Error(`${errorMessage}: tidak bisa menghubungi pakasir (${err.message})`);
        }

        if (!response.ok) {
            // 404 = transaksi tidak ada di pakasir (mis. dihapus/dibatalkan dari
            // dashboard) — sinyal normal, bukan error jaringan.
            if (response.status === 404) return null;
            let message = 'Unknown error';
            try {
                const error = await response.json();
                message = error?.message || error?.error || message;
            } catch {}
            throw new Error(`${errorMessage}: ${response.status} ${response.statusText} - ${message}`);
        }

        try {
            return await response.json();
        } catch {
            return null;
        }
    }

    /* ── Normalisasi response v2 → bentuk yang dipakai seluruh bot ────────── */

    _normalize(raw) {
        if (!raw) return null;

        return {
            txn_id: raw.txn_id || null,
            project: raw.project || this.slug,
            order_id: raw.order_id || null,
            amount: raw.amount !== undefined ? Number(raw.amount) : undefined,
            fee: raw.fee !== undefined ? Number(raw.fee) : undefined,
            total_payment: raw.total_payment !== undefined ? Number(raw.total_payment) : undefined,
            payment_method: raw.payment_method || PAYMENT_METHODS.QRIS,
            // Kompatibilitas lama: payment_number = string QRIS/VA yang dirender.
            va_number: raw.va_number || '',
            payment_number: raw.qr_string || raw.va_number || '',
            qr_string: raw.qr_string || null,
            // Tidak ada payment link di bot ini — selalu null (QRIS saja).
            payment_link: null,
            expired_at: raw.expired_at || null,
            is_sandbox: Boolean(raw.is_sandbox),
            status: raw.status || null,
            completed_at: raw.completed_at || null
        };
    }

    /* ── API v2 ────────────────────────────────────────────────────────────── */

    async createTransaction(method, orderId, amount, { requireQris = true } = {}) {
        this.assertConfigured();
        // Kebijakan bot: PAKSA QRIS. Parameter `method` dari caller lama tetap
        // diterima demi kompatibilitas, tapi divalidasi lalu diabaikan.
        const m = this.assertMethod(method || this.defaultMethod);
        const cleanOrderId = encodeURIComponent(String(orderId || '').trim());

        const raw = await this._request(
            `/api/v2/create-transaction/${encodeURIComponent(this.slug)}/${cleanOrderId}`,
            { method: 'POST', body: { method: m, amount: Number(amount) } },
            'Gagal membuat transaksi'
        );

        const payment = this._normalize(raw);
        if (!payment?.txn_id) {
            throw new Error('Gagal membuat transaksi: respons tidak valid dari pakasir (txn_id kosong).');
        }
        if (requireQris && m === PAYMENT_METHODS.QRIS && !payment.qr_string) {
            throw new Error(
                'Gagal membuat transaksi: QRIS string tidak tersedia dari gateway. ' +
                    'Cek metode proyek di dashboard Pakasir (harus mendukung QRIS).'
            );
        }

        this.saveTransaction({
            order_id: payment.order_id || orderId,
            txn_id: payment.txn_id,
            amount: payment.amount,
            fee: payment.fee,
            total_payment: payment.total_payment,
            payment_method: PAYMENT_METHODS.QRIS,
            payment_number: payment.qr_string || payment.va_number,
            qr_string: payment.qr_string,
            expired_at: payment.expired_at,
            status: STATUS.PENDING
        });

        return payment;
    }

    /**
     * Ambil txn_id untuk sebuah order:
     *   1. dari DB lokal,
     *   2. dari order.gatewayRef / order.txnId (order baru hasil migrasi v2),
     *   3. fallback find-or-create (idempotent) — membuat order lama sisa v1
     *      tetap bisa dicek setelah migrasi.
     */
    async _resolveTxn(orderId, amount, order = null) {
        const local = this.getTransaction(orderId);
        if (local?.txn_id) return local;

        const ref = order?.txnId || order?.gatewayRef;
        if (ref && ref !== orderId) {
            // gatewayRef versi v2 adalah txn_id.
            return { order_id: orderId, txn_id: ref, ...local };
        }

        // Fallback idempotent: body sama → transaksi sama (dok. find-or-create).
        // Selalu QRIS — metode lain tidak dipakai bot ini.
        // requireQris: false → order lama sisa migrasi tetap bisa dicek walau
        // respons gateway tidak menyertakan qr_string.
        const payment = await this.createTransaction(PAYMENT_METHODS.QRIS, orderId, amount, { requireQris: false });
        return this.getTransaction(orderId) || { order_id: orderId, txn_id: payment.txn_id };
    }

    async getTransactionStatus(txnId, { useCache = true } = {}) {
        this.assertConfigured();

        if (useCache) {
            const hit = this._statusCache.get(txnId);
            if (hit && Date.now() - hit.at < STATUS_CACHE_TTL_MS) return hit.data;
        }

        const raw = await this._request(
            `/api/v2/transaction-status/${encodeURIComponent(this.slug)}/${encodeURIComponent(txnId)}`,
            {},
            'Gagal mendapatkan detail transaksi'
        );

        if (raw === null) {
            // Transaksi hilang di pakasir — jangan cache, biar caller bersih-bersih.
            return null;
        }
        this._statusCache.set(txnId, { at: Date.now(), data: raw });
        return raw;
    }

    /** Bentuk lama { transaction: {...} } agar pemanggil lama tetap jalan. */
    async getTransactionDetail(orderId, amount, order = null) {
        const entry = await this._resolveTxn(orderId, amount, order);
        const raw = await this.getTransactionStatus(entry.txn_id);
        if (!raw) return null;

        const detail = this._normalize({ ...raw, order_id: raw.order_id || orderId });
        return { transaction: detail, raw };
    }

    async cancelTransaction(orderId, amount, order = null) {
        this.assertConfigured();
        const entry = await this._resolveTxn(orderId, amount, order);

        await this._request(
            `/api/v2/cancel-transaction/${encodeURIComponent(this.slug)}/${encodeURIComponent(entry.txn_id)}`,
            { method: 'POST' },
            'Gagal membatalkan transaksi'
        );

        this.deleteTransaction(orderId);
        return true;
    }

    /**
     * Sinkron status transaksi (dipakai polling order).
     * Return: object v2 ternormalisasi dengan `status` sudah dipetakan ke
     * STATUS lokal (pending/completed/expired/cancelled).
     */
    async syncTransaction(orderId, amount, order = null) {
        const detail = await this.getTransactionDetail(orderId, amount, order);
        if (!detail?.transaction) {
            this.deleteTransaction(orderId);
            return null;
        }

        const trx = detail.transaction;
        let status = trx.status;

        if (status === V2_STATUS.COMPLETED) status = STATUS.COMPLETED;
        else if (status === V2_STATUS.CANCELED) status = STATUS.CANCELLED;
        else status = STATUS.PENDING;

        // Deteksi expired lokal (v2 tidak punya status "expired").
        const expiredAt = trx.expired_at || this.getTransaction(orderId)?.expired_at;
        if (status === STATUS.PENDING && expiredAt && new Date(expiredAt).getTime() <= Date.now()) {
            status = STATUS.EXPIRED;
        }

        trx.status = status;
        trx.expired_at = expiredAt || null;

        if ([STATUS.COMPLETED, STATUS.CANCELLED, STATUS.EXPIRED].includes(status)) {
            this.deleteTransaction(orderId);
            this._statusCache.delete(trx.txn_id);
        }

        return trx;
    }

    async validatePayment(orderId, amount, order = null) {
        const trx = await this.syncTransaction(orderId, amount, order);
        if (!trx) throw new Error('Transaksi tidak ditemukan');
        if (trx.status !== STATUS.COMPLETED) throw new Error('Pembayaran belum selesai');
        if (amount !== undefined && trx.amount !== undefined && Number(trx.amount) !== Number(amount)) {
            throw new Error('Nominal tidak sesuai');
        }
        return trx;
    }

    async isPaid(orderId, amount, order = null) {
        const trx = await this.syncTransaction(orderId, amount, order);
        return trx?.status === STATUS.COMPLETED;
    }

    async isExpired(orderId, amount, order = null) {
        const trx = await this.syncTransaction(orderId, amount, order);
        const expired = trx?.status === STATUS.EXPIRED;
        if (expired) this.deleteTransaction(orderId);
        return expired;
    }

    /* Catatan: buildPaymentPageUrl & verifyWebhookSecret DIHAPUS.
     * Bot ini TIDAK memakai payment link dan TIDAK memakai webhook —
     * status pembayaran selalu dicek manual via polling (syncTransaction). */

    /* ── Tidak tersedia di v2 ──────────────────────────────────────────────── */

    async simulatePayment() {
        throw new Error(
            'Fitur simulasi tidak ada di API v2. Proyek yang belum KYC otomatis ber-mode sandbox ' +
                '(transaksi ber-flag is_sandbox) — cukup bayar lewat halaman payment link sandbox.'
        );
    }
}

const _clientCache = new Map();

function createPakasirClient(overrideCfg, scope = 'main') {
    const cfg = overrideCfg || config.pakasir;
    const key = `${scope}|${cfg?.key || ''}|${cfg?.slug || ''}`;
    if (!_clientCache.has(key)) {
        _clientCache.set(key, new PakasirClient(overrideCfg, scope));
    }
    return _clientCache.get(key);
}

function getPakasirForContext(ctx = {}) {
    const { isJadibot, jadibotEntry, jadibotJid } = ctx;
    if (isJadibot && jadibotEntry) {
        const cred = jadibotEntry.credentials?.pakasir;
        if (!cred || !cred.key || !cred.slug) return null;
        const scope = jadibotEntry.number || (jadibotJid || '').split('@')[0] || 'jadibot';
        return createPakasirClient(cred, scope);
    }
    return mainClient;
}

const mainClient = new PakasirClient(null, 'main');

module.exports = mainClient;
module.exports.STATUS = STATUS;
module.exports.V2_STATUS = V2_STATUS;
module.exports.PAYMENT_METHODS = PAYMENT_METHODS;
module.exports.DISABLED_METHODS = DISABLED_METHODS;
module.exports.createPakasirClient = createPakasirClient;
module.exports.getPakasirForContext = getPakasirForContext;
module.exports.PakasirClient = PakasirClient;

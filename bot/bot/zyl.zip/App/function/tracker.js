const fs = require('fs');
const path = require('path');

const { loadDB: loadDBLayer, saveDB: saveDBLayer } = require('../../database/wrappers/storage');

const statisticsDir = path.join(__dirname, '../../Storage/statistics');
const SAVE_INTERVAL = 10000;
const MAX_ERROR_TYPES = 100;

if (!fs.existsSync(statisticsDir)) {
    fs.mkdirSync(statisticsDir, { recursive: true });
}

let currentMonth = getMonthKey();
let stats = loadStats(currentMonth);
let saveTimer = null;
let dirty = false;
let saving = false;

function getMonthKey() {
    const now = new Date();

    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
}

function getDateKey() {
    const now = new Date();

    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(
        2,
        '0'
    )}`;
}

function getFilePath(month) {
    return path.join(statisticsDir, `${month}.json`);
}

function createStats(month) {
    return {
        month,
        total: 0,
        success: 0,
        error: 0,
        totalResponseTime: 0,
        commands: {},
        errors: {}
    };
}

function loadStats(month) {
    const filePath = getFilePath(month);

    try {
        const data = loadDBLayer(filePath, null);

        if (!data) {
            return createStats(month);
        }

        return {
            ...createStats(month),
            ...data,
            commands: data.commands || {},
            errors: data.errors || {}
        };
    } catch (error) {
        console.error('[TRACKER] Gagal membaca statistik:', error.message);

        return createStats(month);
    }
}

function normalizeCommand(command) {
    if (!command) {
        return 'unknown';
    }

    return String(command).trim().toLowerCase().replace(/^\./, '').slice(0, 100) || 'unknown';
}

function normalizeError(error) {
    if (!error) {
        return 'Unknown error';
    }

    if (error instanceof Error) {
        return error.message || error.name || 'Unknown error';
    }

    if (typeof error === 'string') {
        return error.slice(0, 300);
    }

    try {
        return JSON.stringify(error).slice(0, 300);
    } catch {
        return String(error).slice(0, 300);
    }
}

function checkMonth() {
    const month = getMonthKey();

    if (month === currentMonth) {
        return;
    }

    flushStats();

    currentMonth = month;
    stats = loadStats(month);
    dirty = false;
}

function trackRequest({ command, success = true, responseTime = 0, error = null } = {}) {
    checkMonth();

    const commandName = normalizeCommand(command);
    const time = Math.max(Number(responseTime) || 0, 0);

    stats.total++;
    stats.totalResponseTime += time;

    if (success) {
        stats.success++;
    } else {
        stats.error++;

        const errorMessage = normalizeError(error);

        const errorKey = `${commandName}|${errorMessage}`;

        if (!stats.errors[errorKey]) {
            stats.errors[errorKey] = {
                command: commandName,
                error: errorMessage,
                count: 0
            };
        }

        stats.errors[errorKey].count++;

        cleanupErrors();
    }

    if (!stats.commands[commandName]) {
        stats.commands[commandName] = {
            total: 0,
            success: 0,
            error: 0,
            totalResponseTime: 0
        };
    }

    const commandStats = stats.commands[commandName];

    commandStats.total++;
    commandStats.totalResponseTime += time;

    if (success) {
        commandStats.success++;
    } else {
        commandStats.error++;
    }

    dirty = true;

    return true;
}

function cleanupErrors() {
    const keys = Object.keys(stats.errors);

    if (keys.length <= MAX_ERROR_TYPES) {
        return;
    }

    keys.sort((a, b) => stats.errors[b].count - stats.errors[a].count);

    const keep = keys.slice(0, MAX_ERROR_TYPES);

    const result = {};

    for (const key of keep) {
        result[key] = stats.errors[key];
    }

    stats.errors = result;
}

function saveStats() {
    if (!dirty || saving) {
        return;
    }

    saving = true;

    try {
        const filePath = getFilePath(currentMonth);
        saveDBLayer(filePath, stats);
        dirty = false;
    } catch (error) {
        console.error('[TRACKER] Gagal menyimpan:', error.message);
    } finally {
        saving = false;
    }
}

function flushStats() {
    if (!dirty) {
        return;
    }

    saveStats();
}

function startTracker() {
    if (saveTimer) {
        return;
    }

    saveTimer = setInterval(() => {
        checkMonth();
        saveStats();
    }, SAVE_INTERVAL);

    if (saveTimer.unref) {
        saveTimer.unref();
    }
}

function stopTracker() {
    if (!saveTimer) {
        return;
    }

    clearInterval(saveTimer);
    saveTimer = null;

    flushStats();
}

function getMonthlyStats() {
    checkMonth();

    const total = stats.total || 0;
    const success = stats.success || 0;
    const error = stats.error || 0;

    const averageResponseTime = total > 0 ? Math.round(stats.totalResponseTime / total) : 0;

    return {
        month: stats.month,
        total,
        success,
        error,
        successRate: total > 0 ? Number(((success / total) * 100).toFixed(2)) : 0,
        errorRate: total > 0 ? Number(((error / total) * 100).toFixed(2)) : 0,
        averageResponseTime
    };
}

function getCommandStats(command) {
    checkMonth();

    if (command) {
        const name = normalizeCommand(command);

        const data = stats.commands[name];

        if (!data) {
            return null;
        }

        return formatCommandStats(name, data);
    }

    return Object.entries(stats.commands)
        .map(([name, data]) => formatCommandStats(name, data))
        .sort((a, b) => b.total - a.total);
}

function formatCommandStats(command, data) {
    const total = data.total || 0;
    const success = data.success || 0;
    const error = data.error || 0;

    return {
        command,
        total,
        success,
        error,
        successRate: total > 0 ? Number(((success / total) * 100).toFixed(2)) : 0,
        errorRate: total > 0 ? Number(((error / total) * 100).toFixed(2)) : 0,
        averageResponseTime: total > 0 ? Math.round(data.totalResponseTime / total) : 0
    };
}

function getTopErrors(limit = 10) {
    checkMonth();

    return Object.values(stats.errors)
        .sort((a, b) => b.count - a.count)
        .slice(0, limit);
}

function getSlowestCommands(limit = 10) {
    checkMonth();

    return Object.entries(stats.commands)
        .map(([name, data]) => formatCommandStats(name, data))
        .sort((a, b) => b.averageResponseTime - a.averageResponseTime)
        .slice(0, limit);
}

function getFastestCommands(limit = 10) {
    checkMonth();

    return Object.entries(stats.commands)
        .map(([name, data]) => formatCommandStats(name, data))
        .sort((a, b) => a.averageResponseTime - b.averageResponseTime)
        .slice(0, limit);
}

function getStatistics() {
    return {
        monthly: getMonthlyStats(),
        commands: getCommandStats(),
        topErrors: getTopErrors(10),
        slowest: getSlowestCommands(10),
        fastest: getFastestCommands(10)
    };
}

function getStatisticsFiles() {
    try {
        return fs
            .readdirSync(statisticsDir)
            .filter((file) => /^\d{4}-\d{2}\.json$/.test(file))
            .sort()
            .reverse();
    } catch {
        return [];
    }
}

function resetCurrentMonth() {
    checkMonth();

    stats = createStats(currentMonth);

    dirty = true;

    flushStats();

    return true;
}

startTracker();

module.exports = {
    trackRequest,
    getMonthlyStats,
    getCommandStats,
    getTopErrors,
    getSlowestCommands,
    getFastestCommands,
    getStatistics,
    getStatisticsFiles,
    resetCurrentMonth,
    flushStats,
    startTracker,
    stopTracker
};

/**
 * docs.js — Dokumentasi API otomatis (endpoint publik, tanpa key).
 */
const config = require('@Config');
const { BOT_VERSION } = require('./helpers');

const buildApiDocs = (baseUrl) => ({
    success: true,
    name: `${config.botname} API`,
    version: BOT_VERSION,
    authentication: {
        header: 'X-API-Key: <isi config.api.keys>',
        alternative: 'Authorization: Bearer <key>'
    },
    documentation: {
        public: {
            'GET /': 'Dokumentasi API ini (tanpa key)',
            'GET /api/docs': 'Dokumentasi API ini (tanpa key)'
        },
        status: {
            'GET /api/status':
                'Status server: uptime, bot utama, maintenance, statistik jadibot (total/aktif/pending/expired/online), TOTAL sewabot & premium (aktif/expired), database, memory, system',
            'GET /api/ping': 'Cek cepat: server hidup + API key valid (uptime, timestamp).',
            'GET /api/stats':
                'Statistik dashboard website: jadibot (total/aktif/pending/expired/stopped/banned/online), sewabot (aktif/expired), premium (aktif/expired), breakdown paket, total pesan jadibot.'
        },
        jadibot: {
            'POST /api/jadibot':
                'CREATE jadibot. Body: { number, days? } — balas pairingCode + masa aktif. days default 30 (max 3650 ≈ permanen). Website pakai harga sendiri, API tidak peduli nominal.',
            'GET /api/jadibot/status':
                'CEK STATUS. Query ?number=628xxx → detail 1 bot (status: active/pending_pairing/pairing_failed/stopped/expired/banned, online, sisa masa aktif, pairingCode bila pending). Tanpa ?number= → statistik semua jadibot.',
            'GET /api/jadibot/list': 'Daftar SEMUA jadibot (nomor utuh, status, paket, expired).',
            'GET /api/jadibot/check':
                'CEK NOMOR (validasi form website). Query ?number=628xxx → { valid, registered, canCreate, reason, slot }. Panggil ini SEBELUM POST /api/jadibot supaya tahu nomor bisa didaftarkan atau tidak.',
            'GET /api/jadibot/profile':
                'PROFIL & KONFIGURASI LENGKAP 1 BOT (dashboard pembeli): identitas, settings, mode, kredensial (di-mask), runtime, pairing, statistik. Query ?number=628xxx.',
            'GET /api/jadibot/settings':
                'BACA SEMUA PENGATURAN BOT (settings per-instance: autoRead, anticall, thumbnail, mess, payment, dll). Query ?number=628xxx.',
            'POST /api/jadibot/settings':
                'PENGATURAN BOT. Body: { number, settings: { autoRead, autoswview, anticall, botDestination, prefix, prefix_custom, idch, sewabot, premium, payment, thumbnail, mess, singlemess } }. Hanya key whitelisted yang diterima.',
            'GET /api/jadibot/messages':
                'BACA TEKS BOT PER-INSTANCE (mess & singlemess: pesan payment, wait, error, owner, open/close grub, dll). Query ?number=628xxx.',
            'POST /api/jadibot/messages':
                'GANTI TEKS BOT PER-INSTANCE. Body: { number, messages: { mess: { payment, wait, error, owner, ... }, singlemess: { open_grub, close_grub, ... } } }. String bebas, key bebas; kirim null pada key untuk reset.',
            'DELETE /api/jadibot/messages':
                'RESET TEKS BOT ke default. Query ?number=628xxx (&key=mess|singlemess untuk reset sebagian).',
            'GET /api/jadibot/media':
                'BACA MEDIA BOT PER-INSTANCE (thumbnail: welcome, register, imagereply[], imagemenu[], audio[], game_over, dst). Query ?number=628xxx.',
            'POST /api/jadibot/media':
                'GANTI MEDIA/THUMBNAIL/AUDIO BOT. Body: { number, media: { welcome: url|base64|dataURI, audio: [url|base64, ...], imagemenu: [...], ... } }. Base64/data-URI otomatis diupload ke server & diubah jadi URL /api/assets/... (gambar maks ~5MB, audio/video maks 10MB, array maks 20 item). Nilai "" menghapus key.',
            'DELETE /api/jadibot/media': 'RESET SEMUA MEDIA BOT ke default. Query ?number=628xxx.',
            'GET /api/jadibot/payment':
                'BACA INFO PEMBAYARAN MANUAL BOT (settings.payment: QRIS, DANA, GOPAY, dll milik bot itu). Query ?number=628xxx.',
            'POST /api/jadibot/payment':
                'GANTI INFO PEMBAYARAN MANUAL BOT. Body: { number, payment: { QRIS: "url_gambar", DANA: "0812xxx", GOPAY: "0813xxx", ... } } — nama metode bebas. Nilai "" menghapus metode.',
            'DELETE /api/jadibot/payment': 'RESET INFO PEMBAYARAN BOT. Query ?number=628xxx.',
            'GET /api/jadibot/packages':
                'BACA PAKET sewabot & premium MILIK INSTANCE (yang dijual bot itu sendiri). Query ?number=628xxx.',
            'POST /api/jadibot/packages':
                'SET PAKET sewabot/premium MILIK INSTANCE. Body: { number, type: "sewabot"|"premium", packages: [{ name, price, days }], enabled?, bonusPremiumMinDays? (sewabot). }',
            'GET /api/jadibot/owners': 'BACA daftar owner bot. Query ?number=628xxx.',
            'POST /api/jadibot/owners':
                'TAMBAH/HAPUS owner bot. Body: { number, action: "add"|"remove", owner: "628xxx" }.',
            'GET /api/jadibot/credentials':
                'BACA kredensial bot (cpanel & pakasir) dalam kondisi TER-MASK. Query ?number=628xxx.',
            'POST /api/jadibot/credentials':
                'KREDENSIAL COMMAND BOT (cpanel / pakasir milik bot itu). Body: { number, credentials: { cpanel: {...}|null, pakasir: { enabled, key, slug, baseUrl, defaultMethod, frameQr }|null } }. Disimpan untuk command WA bot, dibalas dalam kondisi di-mask.',
            'POST /api/jadibot/restart':
                'RESTART instance bot (stop + start ulang). Body: { number } — balas pairingCode bila perlu pairing ulang.',
            'POST /api/jadibot/identity':
                'IDENTITAS BOT. Body: { number, identity: { botname, ownername, packname, storename, bio, author, links } }. Nama/bio langsung diterapkan bila bot online.',
            'POST /api/jadibot/mode': 'MODE BOT. Body: { number, mode: "public" | "self" }.',
            'POST /api/jadibot/profile-picture':
                'FOTO PROFIL BOT. Body: { number, imageUrl } atau { number, imageBase64 } (maks 5MB). Bot harus online.',
            'POST /api/jadibot/extend': 'PERPANJANG. Body: { number, days } — masa aktif ditambah di atas sisa hari.',
            'POST /api/jadibot/pairing':
                'PAIRING ULANG. Body: { number } — reset session & terbitkan pairing code baru.',
            'POST /api/jadibot/start': 'START. Body: { number } — nyalakan bot yang stop/pairing_failed.',
            'POST /api/jadibot/stop': 'STOP. Body: { number } — matikan sementara (masa aktif tetap berjalan).',
            'DELETE /api/jadibot': 'HAPUS permanen. Body: { number }.'
        },
        sewabot: {
            'POST /api/sewabot':
                'CREATE sewa. Body: { groupLink, days } atau { groupJid, days } + opsional "instance": "628xxx" → sewa tercatat di data milik bot jadibot itu.',
            'GET /api/sewabot/status': 'CEK STATUS sewa. Query ?group=<jid|id|link>&instance=628xxx (opsional).',
            'GET /api/sewabot/list': 'Daftar semua sewa aktif (jid grup, nama, expired). Query ?instance=628xxx (opsional).',
            'GET /api/sewabot/packages':
                'PAKET sewabot dari config (bot utama) atau milik instance. Query ?instance=628xxx (opsional).',
            'POST /api/sewabot/extend': 'PERPANJANG sewa. Body: { groupJid|groupLink, days, instance? }.',
            'DELETE /api/sewabot':
                'HAPUS sewa. Body: { group, leave?, instance? } — leave:true = bot keluar grup juga (default false).'
        },
        premium: {
            'POST /api/premium': 'CREATE premium. Body: { number, days, instance? } — instance = nomor bot jadibot (opsional).',
            'GET /api/premium/status': 'CEK STATUS premium. Query ?number=628xxx&instance= (opsional).',
            'GET /api/premium/list': 'Daftar semua user premium. Query ?instance= (opsional).',
            'GET /api/premium/packages':
                'PAKET premium dari config (bot utama) atau milik instance. Query ?instance=628xxx (opsional).',
            'POST /api/premium/bulk':
                'TAMBAH BANYAK premium sekaligus. Body: { numbers: ["628xx", ...], days, instance? } — maks 100 nomor.',
            'POST /api/premium/extend': 'PERPANJANG premium. Body: { number, days, instance? }.',
            'DELETE /api/premium': 'HAPUS premium. Body: { number, instance? }.'
        },
        expired: {
            'GET /api/expired':
                'DAFTAR EXPIRED & SEGERA EXPIRED (bahan pengingat perpanjangan website). Query opsional: ?type=jadibot|sewabot|premium & ?days=7 (window hari ke depan, 0 = yang sudah expired saja).'
        }
    },
    baseUrl
});

/* ── Helper umum ──────────────────────────────────────────────────────────── */


function registerDocsRoutes(app) {
/* ── Docs (publik, tanpa key) ─────────────────────────────────────────── */

app.get('/', (req, res) => res.json(buildApiDocs(`${req.protocol}://${req.get('host')}`)));
app.get('/api/docs', (req, res) => res.json(buildApiDocs(`${req.protocol}://${req.get('host')}`)));

}

module.exports = { buildApiDocs, registerDocsRoutes };

/**
 * routes/jadibot.js — Semua endpoint /api/jadibot/* (CRUD, pairing, settings, identitas).
 */
const express = require('express');
const config = require('@Config');
const jadibotManager = require('../../core/jadibot');
const { saveAsset } = require('../assets');
const {
    normalizeNumber,
    validWaNumber,
    numberToJid,
    clampDays,
    humanDate,
    resolveImageBuffer
} = require('../helpers');
const { wrap } = require('../middleware');

const router = express.Router();

    // Mode JADIBOT ONLY (bootMode 'jadibot'): bot utama sengaja tidak dijalankan.
    // Order/instance jadibot tetap boleh diproses karena pairing memakai socket
    // instance itu sendiri, bukan socket bot utama.
    const isJadibotOnlyMode = () => {
        const cfgMode = String(config.bootMode || '').toLowerCase();
        if (cfgMode === 'jadibot') return true;
        try {
            const { readSavedMode } = require('../../core/bootMenu');
            return readSavedMode() === 'jadibot';
        } catch (_) {
            return false;
        }
    };

    const mainBotReady = () => Boolean(jadibotManager.mainSocket?.user) || isJadibotOnlyMode();

    /* ══════════════════════════════ JADIBOT ═══════════════════════════════ */

    const jadibotDetail = (entry) => {
        const runtime = jadibotManager.getRuntimeStatus(entry.jid) || {};
        const now = Date.now();
        return {
            number: entry.number,
            botname: entry.identity?.botname || null,
            package: entry.package,
            status: entry.status,
            online: Boolean(jadibotManager.sockets.get(entry.jid)?.user),
            activation: entry.activatedVia || null,
            start: entry.start,
            expired: entry.expired,
            expiredHuman: humanDate(entry.expired),
            expiredInDays: entry.expired > now ? Math.max(0, Math.ceil((entry.expired - now) / 86400000)) : 0,
            expiredInSeconds: entry.expired > now ? Math.floor((entry.expired - now) / 1000) : 0,
            messages: entry.stats?.messages || 0,
            pairingAttempts: entry.pairingAttempts || 0,
            pairingCode: entry.status === 'pending_pairing' ? entry.pairingCode || null : null,
            pairingFailureReason: entry.pairingFailureReason || null,
            stopReason: entry.stopReason || null
        };
    };

    const findJadibotOrFail = (number) => {
        const clean = normalizeNumber(number);
        const entry = jadibotManager.getByNumber(clean);
        if (!entry) {
            const err = new Error(`Jadibot +${clean} tidak ditemukan.`);
            err.status = 404;
            err.code = 'NOT_FOUND';
            throw err;
        }
        return entry;
    };

    router.get('/api/jadibot/list', (req, res) => {
        const all = jadibotManager.listAll().map(jadibotDetail);
        res.json({ success: true, data: { total: all.length, jadibots: all } });
    });

    router.get(
        '/api/jadibot/check',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.query.number);
            const slotUsed = jadibotManager.listAll().filter((e) => e.status !== 'stopped' && e.status !== 'expired')
                .length;
            const slotMax = Number(config.jadibot?.maxInstances) || 20;
            const slot = { used: slotUsed, max: slotMax };

            const data = { number, valid: validWaNumber(number), registered: false, canCreate: false, reason: null, slot };

            if (!data.valid) {
                data.reason = 'Format nomor tidak valid. Gunakan format 628xxxxxxxxxx (minimal 628 + 7-15 digit).';
                return res.json({ success: true, data });
            }

            const existing = jadibotManager.getByNumber(number);
            if (existing) {
                data.registered = true;
                data.reason = `Nomor sudah terdaftar sebagai jadibot (status: ${existing.status}). Untuk pairing ulang pakai POST /api/jadibot/pairing, untuk perpanjang pakai POST /api/jadibot/extend.`;
                data.current = {
                    status: existing.status,
                    expired: existing.expired,
                    expiredHuman: humanDate(existing.expired)
                };
                return res.json({ success: true, data });
            }

            if (slotUsed >= slotMax) {
                data.reason = `Slot jadibot penuh (${slotUsed}/${slotMax}). Hapus jadibot tidak aktif atau tambah maxInstances di config.`;
                return res.json({ success: true, data });
            }

            if (!mainBotReady()) {
                data.reason = 'Server bot sedang tidak terhubung — create sementara tidak bisa diproses.';
                return res.json({ success: true, data });
            }

            data.canCreate = true;
            res.json({ success: true, data });
        })
    );

    router.get(
        '/api/jadibot/status',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.query.number);

            if (!number) {
                return res.json({
                    success: true,
                    data: {
                        summary: jadibotManager.stats(),
                        mainBotConnected: Boolean(jadibotManager.mainSocket?.user),
                        maxInstances: Number(config.jadibot?.maxInstances) || 20
                    }
                });
            }

            const entry = findJadibotOrFail(number);
            const detail = jadibotDetail(entry);
            const pairing = jadibotManager.getPairingStatus(entry.jid);

            res.json({
                success: true,
                data: {
                    ...detail,
                    pairing: pairing
                        ? {
                              status: detail.status,
                              pairingCode: detail.pairingCode,
                              codeExpiresAt: pairing.codeExpiresAt,
                              codeExpired: pairing.codeExpired,
                              attempts: pairing.pairingAttempts,
                              maxAttempts: pairing.maxPairingAttempts,
                              failureReason: pairing.pairingFailureReason || null
                          }
                        : null,
                    serverOnline: Boolean(jadibotManager.mainSocket?.user)
                }
            });
        })
    );

    router.post(
        '/api/jadibot',
        wrap(async (req, res) => {
            if (config.jadibot?.enabled === false) {
                return res
                    .status(503)
                    .json({ success: false, message: 'Fitur jadibot sedang nonaktif.', code: 'FEATURE_DISABLED' });
            }

            const number = normalizeNumber(req.body?.number);
            if (!validWaNumber(number)) {
                return res.status(400).json({
                    success: false,
                    message: 'Field "number" wajib (nomor WA yang mau jadi bot, format 628xxxxxxxxxx).',
                    code: 'VALIDATION'
                });
            }
            if (jadibotManager.isFull()) {
                return res.status(409).json({
                    success: false,
                    message: `Slot jadibot penuh (maksimal ${config.jadibot?.maxInstances || 20}).`,
                    code: 'SLOT_FULL'
                });
            }
            if (!mainBotReady()) {
                return res.status(503).json({
                    success: false,
                    message: 'Server bot sedang tidak terhubung. Coba lagi nanti.',
                    code: 'MAIN_BOT_OFFLINE'
                });
            }

            const days = clampDays(req.body?.days, 30);

            const { entry, pairingCode } = await jadibotManager.createJadibot(number, {
                days,
                packageName: req.body?.package || 'WEBSITE',
                ownerJid: numberToJid(number),
                activation: 'website',
                source: 'web'
            });

            res.status(201).json({
                success: true,
                message: `Jadibot +${entry.number} dibuat (${days} hari). Masukkan kode pairing di WhatsApp (berlaku ±60 detik).`,
                data: {
                    number: entry.number,
                    package: entry.package,
                    days,
                    status: entry.status,
                    expired: entry.expired,
                    expiredHuman: humanDate(entry.expired),
                    pairingCode,
                    pairingSteps: [
                        'Buka WhatsApp di nomor bot',
                        'Menu > Perangkat Tertaut > Tautkan dengan Nomor Telepon',
                        'Masukkan kode pairing'
                    ]
                }
            });
        })
    );

    router.post(
        '/api/jadibot/extend',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.body?.number);
            const entry = findJadibotOrFail(number);
            const days = clampDays(req.body?.days, 30);

            const updated = jadibotManager.extendJadibot(entry.jid, days);

            res.json({
                success: true,
                message: `Masa aktif +${number} diperpanjang ${days} hari.`,
                data: {
                    number: updated.number,
                    package: updated.package,
                    status: updated.status,
                    expired: updated.expired,
                    expiredHuman: humanDate(updated.expired),
                    expiredInDays: Math.max(0, Math.ceil((updated.expired - Date.now()) / 86400000))
                }
            });
        })
    );

    router.post(
        '/api/jadibot/pairing',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.body?.number);
            const entry = findJadibotOrFail(number);

            const { entry: updated, pairingCode } = await jadibotManager.repairPairing(entry.jid);

            res.json({
                success: true,
                message: 'Pairing di-reset. Masukkan kode pairing baru di WhatsApp (berlaku ±60 detik).',
                data: {
                    number: updated.number,
                    status: updated.status,
                    pairingCode,
                    expiresAt: Date.now() + (Number(config.jadibot?.pairingCodeTtlMs) || 90000),
                    pairingSteps: [
                        'Buka WhatsApp di nomor bot',
                        'Menu > Perangkat Tertaut > Tautkan dengan Nomor Telepon',
                        'Masukkan kode pairing'
                    ]
                }
            });
        })
    );

    router.post(
        '/api/jadibot/start',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.body?.number);
            const entry = findJadibotOrFail(number);

            const forceRestart = ['stopped', 'pairing_failed'].includes(entry.status);
            const pairingCode = await jadibotManager.startInstance(entry.jid, { force: forceRestart });

            res.json({
                success: true,
                message: pairingCode
                    ? 'Bot dijalankan. Masukkan kode pairing baru di WhatsApp.'
                    : 'Bot dijalankan. Session lama masih valid, menyambung ulang.',
                data: { number: entry.number, status: 'pending_pairing', pairingCode: pairingCode || null }
            });
        })
    );

    router.post(
        '/api/jadibot/stop',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.body?.number);
            const entry = findJadibotOrFail(number);

            await jadibotManager.stopInstance(entry.jid, 'website');

            res.json({
                success: true,
                message: `Bot +${entry.number} dihentikan. Masa aktif tetap berjalan.`,
                data: { number: entry.number, status: 'stopped', expired: entry.expired }
            });
        })
    );

    router.delete(
        '/api/jadibot',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.body?.number);
            const entry = findJadibotOrFail(number);

            await jadibotManager.deleteJadibot(entry.jid);

            res.json({
                success: true,
                message: `Jadibot +${number} dihapus permanen (data bisnis diarsipkan sesuai retention).`,
                data: { number: entry.number, deleted: true }
            });
        })
    );

    /* ── KONFIGURASI JADIBOT (dipakai dashboard website pembeli bot) ──────── */

    router.get(
        '/api/jadibot/profile',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.query.number);
            const entry = findJadibotOrFail(number);
            res.json({ success: true, data: jadibotManager.getFullProfile(entry.jid) });
        })
    );

    router.post(
        '/api/jadibot/settings',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.body?.number);
            const entry = findJadibotOrFail(number);
            const patch = req.body?.settings;

            if (!patch || typeof patch !== 'object' || Array.isArray(patch)) {
                return res.status(400).json({
                    success: false,
                    message:
                        'Body butuh "settings" (object). Key yang boleh: ' +
                        'autoRead, autoswview, anticall, markOnlineOnConnect, isRamadhan (true/false), ' +
                        'botDestination (group/private/both), prefix (true/false), prefix_custom (array karakter), ' +
                        'idch (ID/link saluran, "" untuk matikan), ' +
                        'sewabot ({enabled, packages:[{name,price,days}], bonusPremiumMinDays}), ' +
                        'premium ({enabled, packages:[{name,price,days}]}), ' +
                        'payment ({QRIS, DANA, GOPAY, MANDIRI, ...} metode bebas), ' +
                        'thumbnail ({welcome, register, imagereply[], imagemenu[], audio[], ...}), ' +
                        'mess ({payment, wait, error, owner, ...}), singlemess ({open_grub, close_grub, ...}). ' +
                        'Kirim null untuk reset ke config global.',
                    code: 'VALIDATION'
                });
            }

            const settings = await jadibotManager.updateSettings(entry.jid, patch);

            res.json({
                success: true,
                message: `Pengaturan bot +${entry.number} diperbarui.`,
                data: { number: entry.number, settings }
            });
        })
    );

    router.post(
        '/api/jadibot/identity',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.body?.number);
            const entry = findJadibotOrFail(number);
            const patch = req.body?.identity;

            if (!patch || typeof patch !== 'object' || Array.isArray(patch)) {
                return res.status(400).json({
                    success: false,
                    message:
                        'Body butuh "identity" (object). Key yang boleh: botname, ownername, packname, storename, bio, author, links { group, website } (null = reset ke default).',
                    code: 'VALIDATION'
                });
            }

            const identity = jadibotManager.updateIdentityFull(entry.jid, patch);

            res.json({
                success: true,
                message: `Identitas bot +${entry.number} diperbarui (nama/bio langsung diterapkan bila bot online).`,
                data: { number: entry.number, identity }
            });
        })
    );

    router.post(
        '/api/jadibot/mode',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.body?.number);
            const entry = findJadibotOrFail(number);
            const mode = String(req.body?.mode || '').toLowerCase();

            if (!['public', 'self'].includes(mode)) {
                return res.status(400).json({
                    success: false,
                    message: 'Field "mode" wajib "public" atau "self".',
                    code: 'VALIDATION'
                });
            }

            const isPublic = jadibotManager.setPublicMode(entry.jid, mode === 'public');

            res.json({
                success: true,
                message: `Mode bot +${entry.number} sekarang ${isPublic ? 'PUBLIC' : 'SELF'}.`,
                data: { number: entry.number, mode: isPublic ? 'public' : 'self' }
            });
        })
    );

    router.post(
        '/api/jadibot/profile-picture',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.body?.number);
            const entry = findJadibotOrFail(number);

            let buffer;
            try {
                buffer = await resolveImageBuffer({ imageUrl: req.body?.imageUrl, imageBase64: req.body?.imageBase64 });
            } catch (err) {
                return res.status(400).json({ success: false, message: err.message, code: 'VALIDATION' });
            }

            await jadibotManager.setBotProfilePicture(entry.jid, buffer);

            res.json({
                success: true,
                message: `Foto profil bot +${entry.number} diperbarui.`,
                data: { number: entry.number, sizeKB: Math.round(buffer.length / 1024) }
            });
        })
    );

    router.post(
        '/api/jadibot/credentials',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.body?.number);
            const entry = findJadibotOrFail(number);
            const patch = req.body?.credentials;

            if (!patch || typeof patch !== 'object' || Array.isArray(patch)) {
                return res.status(400).json({
                    success: false,
                    message:
                        'Body butuh "credentials" (object). Kategori: cpanel (BASE, PLTA, NODEJS {NESTID,EGGID}, PYTHON {NESTID,EGGID}, LISTPANEL[]) dan pakasir (enabled, key, slug, baseUrl, defaultMethod, methods[], frameQr). Kirim null untuk menghapus kategori. Kredensial HANYA dipakai command WA bot itu sendiri — tidak ada fitur pembayaran di API ini, dan API tidak pernah menampilkan nilainya utuh (selalu di-mask).',
                    code: 'VALIDATION'
                });
            }

            jadibotManager.updateCredentials(entry.jid, patch);

            res.json({
                success: true,
                message: `Kredensial bot +${entry.number} disimpan (disamarkan untuk keamanan).`,
                data: { number: entry.number, credentials: jadibotManager.getCredentialsMasked(entry.jid) }
            });
        })
    );

    /* ══════════════════════ JADIBOT — PENGATURAN LANJUTAN ═════════════════ */

    router.get(
        '/api/jadibot/settings',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.query.number);
            const entry = findJadibotOrFail(number);
            res.json({
                success: true,
                data: { number: entry.number, settings: jadibotManager.getSettings(entry.jid) }
            });
        })
    );

    /* ── MESSAGES (teks bot per-instance: mess & singlemess) ─────────────── */

    router.get(
        '/api/jadibot/messages',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.query.number);
            const entry = findJadibotOrFail(number);
            const s = jadibotManager.getSettings(entry.jid);
            res.json({ success: true, data: { number: entry.number, mess: s.mess || null, singlemess: s.singlemess || null } });
        })
    );

    router.post(
        '/api/jadibot/messages',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.body?.number);
            const entry = findJadibotOrFail(number);
            const patch = req.body?.messages || {};

            if (!patch || typeof patch !== 'object' || Array.isArray(patch)) {
                return res.status(400).json({
                    success: false,
                    message:
                        'Body butuh "messages" (object). Contoh: { messages: { mess: { payment: "teks", wait: "teks" }, singlemess: { open_grub: "teks" } } }. ' +
                        'Key mess/singlemess bebas (welcome, payment, wait, error, owner, open_grub, close_grub, dll). Kirim null pada key untuk reset.',
                    code: 'VALIDATION'
                });
            }

            const allowed = {};
            if (patch.mess !== undefined) allowed.mess = patch.mess;
            if (patch.singlemess !== undefined) allowed.singlemess = patch.singlemess;
            if (!Object.keys(allowed).length) {
                return res
                    .status(400)
                    .json({ success: false, message: 'Tidak ada key valid (mess / singlemess) pada body.messages.', code: 'VALIDATION' });
            }

            const settings = await jadibotManager.updateSettings(entry.jid, allowed);
            res.json({
                success: true,
                message: `Teks bot +${entry.number} diperbarui.`,
                data: { number: entry.number, mess: settings.mess || null, singlemess: settings.singlemess || null }
            });
        })
    );

    router.delete(
        '/api/jadibot/messages',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.query.number || req.body?.number);
            const entry = findJadibotOrFail(number);
            const key = req.query.key || req.body?.key || null; // 'mess' | 'singlemess' | null = semua
            const patch = {};
            if (key === 'mess' || key === 'singlemess') patch[key] = null;
            else {
                patch.mess = null;
                patch.singlemess = null;
            }
            await jadibotManager.updateSettings(entry.jid, patch);
            res.json({ success: true, message: `Teks bot +${entry.number} direset ke default.`, data: { number: entry.number, reset: key || 'all' } });
        })
    );

    /* ── MEDIA (thumbnail/welcome/register/audio per-instance) ───────────── */

    const MEDIA_SCALAR_KEYS = ['welcome', 'register', 'game_over', 'start_game', 'timeout_game'];
    const MEDIA_ARRAY_KEYS = ['imagereply', 'imagemenu', 'audio'];

    const resolveMediaBuffer = async ({ url, base64 }) => {
        if (base64) {
            const raw = String(base64).replace(/^data:[a-zA-Z0-9/+.-]+;base64,/, '');
            const buf = Buffer.from(raw, 'base64');
            if (!buf.length) throw new Error('base64 kosong / tidak valid.');
            if (buf.length > 10 * 1024 * 1024) throw new Error('Media melebihi 10MB.');
            return buf;
        }
        if (url) {
            let parsed;
            try {
                parsed = new URL(String(url));
            } catch (_) {
                throw new Error('url tidak valid (harus http/https lengkap).');
            }
            if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error('url hanya boleh http/https.');
            let res2;
            try {
                res2 = await fetch(parsed, { signal: AbortSignal.timeout(20000) });
            } catch (err) {
                throw new Error(`Gagal mengunduh media: ${err.message}`);
            }
            if (!res2.ok) throw new Error(`Gagal mengunduh media (HTTP ${res2.status}).`);
            const buf = Buffer.from(await res2.arrayBuffer());
            if (!buf.length) throw new Error('Media yang diunduh kosong.');
            if (buf.length > 10 * 1024 * 1024) throw new Error('Media melebihi 10MB.');
            return buf;
        }
        throw new Error('Setiap media butuh "url" atau "base64".');
    };

    const storeMediaValue = async (key, val, number) => {
        if (val === null || val === undefined || val === '') return null; // hapus key
        if (MEDIA_ARRAY_KEYS.includes(key)) {
            const list = Array.isArray(val) ? val : [val];
            const out = [];
            for (const item of list) {
                if (typeof item === 'string' && /^https?:\/\//i.test(item)) {
                    out.push(item); // URL langsung — tidak perlu diunduh
                    continue;
                }
                const buf = await resolveMediaBuffer(
                    typeof item === 'object' ? item : { base64: item }
                );
                out.push(saveAsset(number, buf));
            }
            return out.slice(0, 20);
        }
        // scalar
        if (typeof val === 'string' && /^https?:\/\//i.test(val)) return val;
        const buf = await resolveMediaBuffer(typeof val === 'object' ? val : { base64: val });
        return saveAsset(number, buf);
    };

    router.get(
        '/api/jadibot/media',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.query.number);
            const entry = findJadibotOrFail(number);
            const s = jadibotManager.getSettings(entry.jid);
            res.json({ success: true, data: { number: entry.number, media: s.thumbnail || null } });
        })
    );

    router.post(
        '/api/jadibot/media',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.body?.number);
            const entry = findJadibotOrFail(number);
            const media = req.body?.media;

            if (!media || typeof media !== 'object' || Array.isArray(media)) {
                return res.status(400).json({
                    success: false,
                    message:
                        'Body butuh "media" (object). Key scalar: welcome, register, game_over, start_game, timeout_game. ' +
                        'Key array (maks 20): imagereply, imagemenu, audio. ' +
                        'Nilai: URL http(s), base64, data-URI, atau { url } / { base64 }. Nilai "" menghapus key.',
                    code: 'VALIDATION'
                });
            }

            const stored = {};
            for (const [key, val] of Object.entries(media)) {
                if (!MEDIA_SCALAR_KEYS.includes(key) && !MEDIA_ARRAY_KEYS.includes(key)) {
                    return res.status(400).json({
                        success: false,
                        message: `Key media "${key}" tidak dikenal. Gunakan: ${[...MEDIA_SCALAR_KEYS, ...MEDIA_ARRAY_KEYS].join(', ')}`,
                        code: 'VALIDATION'
                    });
                }
                stored[key] = await storeMediaValue(key, val, entry.number);
            }

            const settings = await jadibotManager.updateSettings(entry.jid, { thumbnail: stored });
            res.json({
                success: true,
                message: `Media bot +${entry.number} diperbarui.`,
                data: { number: entry.number, media: settings.thumbnail || null }
            });
        })
    );

    router.delete(
        '/api/jadibot/media',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.query.number || req.body?.number);
            const entry = findJadibotOrFail(number);
            await jadibotManager.updateSettings(entry.jid, { thumbnail: null });
            res.json({ success: true, message: `Media bot +${entry.number} direset ke default.`, data: { number: entry.number } });
        })
    );

    /* ── PAYMENT INFO (metode bayar manual per-instance: QRIS/DANA/GOPAY..) ─ */

    router.get(
        '/api/jadibot/payment',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.query.number);
            const entry = findJadibotOrFail(number);
            const s = jadibotManager.getSettings(entry.jid);
            res.json({ success: true, data: { number: entry.number, payment: s.payment || null } });
        })
    );

    router.post(
        '/api/jadibot/payment',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.body?.number);
            const entry = findJadibotOrFail(number);
            const payment = req.body?.payment;

            if (!payment || typeof payment !== 'object' || Array.isArray(payment)) {
                return res.status(400).json({
                    success: false,
                    message:
                        'Body butuh "payment" (object) — metode bebas. Contoh: { payment: { QRIS: "https://.../qris.png", DANA: "0812xxxx", GOPAY: "0813xxxx" } }. Nilai "" menghapus metode itu.',
                    code: 'VALIDATION'
                });
            }

            const settings = await jadibotManager.updateSettings(entry.jid, { payment });
            res.json({
                success: true,
                message: `Info pembayaran bot +${entry.number} diperbarui (dipakai command addpay/listpay & tampilan store bot itu).`,
                data: { number: entry.number, payment: settings.payment || null }
            });
        })
    );

    router.delete(
        '/api/jadibot/payment',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.query.number || req.body?.number);
            const entry = findJadibotOrFail(number);
            await jadibotManager.updateSettings(entry.jid, { payment: null });
            res.json({ success: true, message: `Info pembayaran bot +${entry.number} direset.`, data: { number: entry.number } });
        })
    );

    /* ── PACKAGES (paket sewabot / premium milik instance) ───────────────── */

    const sanitizePackages = (packages) => {
        if (!Array.isArray(packages)) throw new Error('packages harus berupa array [{ name, price, days }]');
        return packages.map((p) => ({
            name: String(p?.name || '').trim().slice(0, 50),
            price: Number(p?.price) || 0,
            days: Number(p?.days) || 0
        }));
    };

    router.get(
        '/api/jadibot/packages',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.query.number);
            const entry = findJadibotOrFail(number);
            const s = jadibotManager.getSettings(entry.jid);
            res.json({
                success: true,
                data: {
                    number: entry.number,
                    sewabot: s.sewabot || { enabled: undefined, packages: null },
                    premium: s.premium || { enabled: undefined, packages: null }
                }
            });
        })
    );

    router.post(
        '/api/jadibot/packages',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.body?.number);
            const entry = findJadibotOrFail(number);
            const type = String(req.body?.type || '').toLowerCase();

            if (!['sewabot', 'premium'].includes(type)) {
                return res
                    .status(400)
                    .json({ success: false, message: 'Field "type" wajib "sewabot" atau "premium".', code: 'VALIDATION' });
            }
            if (req.body?.packages === undefined) {
                return res.status(400).json({ success: false, message: 'Field "packages" (array) wajib diisi.', code: 'VALIDATION' });
            }

            // Pertahankan field lain (enabled, bonusPremiumMinDays) yang sudah ada.
            const current = jadibotManager.getSettings(entry.jid)[type] || {};
            const patch = { ...current, packages: sanitizePackages(req.body.packages) };
            if (req.body?.enabled !== undefined) patch.enabled = Boolean(req.body.enabled);
            if (type === 'sewabot' && req.body?.bonusPremiumMinDays !== undefined) {
                patch.bonusPremiumMinDays = Number(req.body.bonusPremiumMinDays) || 0;
            }

            const settings = await jadibotManager.updateSettings(entry.jid, { [type]: patch });
            res.json({
                success: true,
                message: `Paket ${type} bot +${entry.number} disimpan (hanya berlaku untuk bot itu).`,
                data: { number: entry.number, [type]: settings[type] || null }
            });
        })
    );

    /* ── OWNERS (daftar owner bot jadibot) ───────────────────────────────── */

    router.get(
        '/api/jadibot/owners',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.query.number);
            const entry = findJadibotOrFail(number);
            res.json({
                success: true,
                data: {
                    number: entry.number,
                    ownerJid: entry.ownerJid || null,
                    owners: jadibotManager.getOwnerList(entry.jid)
                }
            });
        })
    );

    router.post(
        '/api/jadibot/owners',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.body?.number);
            const entry = findJadibotOrFail(number);
            const action = String(req.body?.action || 'add').toLowerCase();
            const owner = normalizeNumber(req.body?.owner);

            if (!/^\d{7,15}$/.test(owner)) {
                return res.status(400).json({ success: false, message: 'Field "owner" wajib (format 628xxx).', code: 'VALIDATION' });
            }

            if (action === 'add') {
                jadibotManager.addOwner(entry.jid, owner);
            } else if (action === 'remove' || action === 'delete') {
                jadibotManager.removeOwner(entry.jid, owner);
            } else {
                return res
                    .status(400)
                    .json({ success: false, message: 'Field "action" harus "add" atau "remove".', code: 'VALIDATION' });
            }

            res.json({
                success: true,
                message: `Owner ${action === 'add' ? 'ditambahkan' : 'dihapus'} untuk bot +${entry.number}.`,
                data: { number: entry.number, owners: jadibotManager.getOwnerList(entry.jid) }
            });
        })
    );

    /* ── CREDENTIALS (GET versi ter-mask) & RESTART ──────────────────────── */

    router.get(
        '/api/jadibot/credentials',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.query.number);
            const entry = findJadibotOrFail(number);
            res.json({
                success: true,
                data: { number: entry.number, credentials: jadibotManager.getCredentialsMasked(entry.jid) }
            });
        })
    );

    router.post(
        '/api/jadibot/restart',
        wrap(async (req, res) => {
            const number = normalizeNumber(req.body?.number);
            const entry = findJadibotOrFail(number);

            const wasOnline = jadibotManager.sockets.has(entry.jid);
            if (wasOnline) await jadibotManager.stopInstance(entry.jid, 'restart');
            entry.status = 'pending_pairing';
            const pairingCode = await jadibotManager.startInstance(entry.jid, { force: true });

            res.json({
                success: true,
                message: wasOnline
                    ? `Bot +${entry.number} direstart.`
                    : `Bot +${entry.number} dijalankan (sebelumnya offline).`,
                data: {
                    number: entry.number,
                    status: 'pending_pairing',
                    pairingCode: pairingCode || null,
                    note: pairingCode ? 'Masukkan kode pairing di WhatsApp (berlaku ±60 detik).' : null
                }
            });
        })
    );

    /* ══════════════════════════════ SEWABOT ═══════════════════════════════ */


module.exports = router;

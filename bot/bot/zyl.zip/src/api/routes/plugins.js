'use strict';

const express = require('express');
const fs = require('fs');
const path = require('path');
const config = require('@Config');
const { listPlugins, getPlugins, addPlugins, removePlugins, refreshPlugins } = require('@App/function/loadPlugins');
const { wrap } = require('../middleware');
const logger = require('@App/function/logger');

const router = express.Router();
const PLUGINS_DIR = path.resolve(__dirname, '../../App/plugins');

const FORBIDDEN_PATTERNS = [
    /require\s*\(\s*['"]child_process['"]\s*\)/i,
    /\bprocess\.exit\s*\(/i,
    /\beval\s*\(\s*[^)]*\bconfig\./i,
    /config\.apikey\.key/i,
    /config\.pakasir\.key/i,
    /config\.cpanel\.PLTA/i
];

function sanitizePluginCode(code) {
    const issues = [];
    for (const pattern of FORBIDDEN_PATTERNS) {
        if (pattern.test(code)) {
            issues.push(`Pattern terlarang terdeteksi: ${pattern.toString()}`);
        }
    }
    return issues;
}

function isSuperOwner(sender) {
    if (!sender) return false;
    const num = String(sender).replace(/[^0-9]/g, '');
    const superNum = String(config.superowner || '').replace(/[^0-9]/g, '');
    return num && superNum && num === superNum;
}

/**
 * Endpoint ini diproteksi via `requireApiKey` di server.js (global middleware).
 * Tapi untuk write/delete, ada tambahan check bahwa caller adalah superowner.
 *
 * Karena API key bersifat shared-secret (bukan per-user), kita TIDAK tahu
 * siapa WA sender dari request HTTP. Jadi operasi POST/DELETE TIDAK diizinkan
 * dari REST API untuk alasan keamanan — kecuali via "owner token" khusus
 * yang di-generate saat main bot start.
 *
 * Untuk versi awal ini, upload plugin tetap dilakukan via WA command `.addplugin`
 * (lihat App/plugins/superowner/plugin.js). REST API hanya menyediakan READ.
 */

router.get('/api/plugins/list', (req, res) => {
    const all = listPlugins().map((p) => ({
        name: p.name,
        category: p.category,
        commands: p.commands || [],
        description: p.description || null,
        isSuperOwner: Boolean(p.isSuperOwner),
        isOwner: Boolean(p.isOwner),
        allowJadibotOwner: Boolean(p.allowJadibotOwner)
    }));
    res.json({ success: true, data: { total: all.length, plugins: all } });
});

router.get(
    '/api/plugins/:name',
    wrap(async (req, res) => {
        const name = String(req.params.name || '').toLowerCase();
        if (!name) return res.status(400).json({ success: false, message: 'name wajib', code: 'VALIDATION' });
        const all = getPlugins();
        const plugin = all.find((p) => p.name === name);
        if (!plugin) return res.status(404).json({ success: false, message: 'Plugin tidak ditemukan', code: 'NOT_FOUND' });
        res.json({
            success: true,
            data: {
                name: plugin.name,
                category: plugin.category,
                commands: plugin.commands || [],
                description: plugin.description || null,
                isSuperOwner: Boolean(plugin.isSuperOwner),
                isOwner: Boolean(plugin.isOwner),
                allowJadibotOwner: Boolean(plugin.allowJadibotOwner),
                isEventPlugin: !Array.isArray(plugin.commands) || plugin.commands.length === 0
            }
        });
    })
);

/**
 * POST /api/plugins — upload plugin baru.
 *
 * Body:
 *   { "category": "main", "name": "mycommand", "code": "module.exports = {...}" }
 *
 * Catatan: untuk keamanan, operasi ini membutuhkan header tambahan
 * `X-Owner-Token` yang harus cocok dengan `config.api.ownerToken` (bila di-set).
 * Bila `config.api.ownerToken` tidak di-set, operasi upload DITOLAK.
 */
router.post(
    '/api/plugins',
    wrap(async (req, res) => {
        const ownerToken = String(req.headers['x-owner-token'] || '');
        const expectedToken = config.api?.ownerToken;
        if (!expectedToken || ownerToken !== expectedToken) {
            return res.status(403).json({
                success: false,
                message:
                    'Upload plugin via API dinonaktifkan. Set config.api.ownerToken & kirim via X-Owner-Token header.',
                code: 'FORBIDDEN'
            });
        }

        const { category, name, code } = req.body || {};
        if (!category || !name || !code) {
            return res.status(400).json({
                success: false,
                message: 'Body butuh { category, name, code }',
                code: 'VALIDATION'
            });
        }

        // Sanitize.
        const issues = sanitizePluginCode(String(code));
        if (issues.length) {
            return res.status(422).json({
                success: false,
                message: `Plugin code rejected: ${issues.join('; ')}`,
                code: 'PLUGIN_REJECTED'
            });
        }

        try {
            const result = addPlugins(category, name, code);
            refreshPlugins();
            logger.info(`[API] Plugin uploaded: ${category}/${name}`);
            res.status(201).json({ success: true, message: result, data: { category, name } });
        } catch (err) {
            res.status(400).json({ success: false, message: err.message, code: 'UPLOAD_FAILED' });
        }
    })
);

router.delete(
    '/api/plugins',
    wrap(async (req, res) => {
        const ownerToken = String(req.headers['x-owner-token'] || '');
        const expectedToken = config.api?.ownerToken;
        if (!expectedToken || ownerToken !== expectedToken) {
            return res.status(403).json({ success: false, message: 'Forbidden', code: 'FORBIDDEN' });
        }

        const { category, name } = req.body || {};
        if (!category || !name) {
            return res.status(400).json({ success: false, message: 'Body butuh { category, name }', code: 'VALIDATION' });
        }

        try {
            const result = removePlugins(category, name);
            res.json({ success: true, message: result, data: { category, name } });
        } catch (err) {
            res.status(400).json({ success: false, message: err.message, code: 'DELETE_FAILED' });
        }
    })
);

module.exports = router;

/**
 * routes/expired.js — Endpoint /api/expired (daftar jadibot/sewabot/premium yang segera habis).
 */
const express = require('express');
const jadibotManager = require('../../core/jadibot');
const { humanDate, normalizeNumber } = require('../helpers');
const { wrap } = require('../middleware');

const router = express.Router();

    router.get(
        '/api/expired',
        wrap(async (req, res) => {
            const type = String(req.query.type || '').toLowerCase();
            if (type && !['jadibot', 'sewabot', 'premium'].includes(type)) {
                return res.status(400).json({
                    success: false,
                    message: 'Query ?type= hanya boleh: jadibot, sewabot, atau premium.',
                    code: 'VALIDATION'
                });
            }

            const rawDays = Number(req.query.days);
            const days = Number.isFinite(rawDays) && String(req.query.days ?? '').trim() !== ''
                ? Math.max(0, Math.min(365, Math.floor(rawDays)))
                : 7;
            const windowMs = days * 24 * 60 * 60 * 1000;
            const deadline = Date.now() + windowMs;
            const now = Date.now();
            const sewa = require('@App/function/sewa');
            const premium = require('@Database/wrappers/premium');

            const pick = (expiredMs) => expiredMs <= deadline;
            const remainDays = (expiredMs) => Math.ceil((expiredMs - now) / 86400000);

            const result = {};
            let total = 0;

            if (!type || type === 'jadibot') {
                result.jadibot = jadibotManager
                    .listAll()
                    .filter((e) => pick(e.expired))
                    .map((e) => ({
                        number: e.number,
                        package: e.package,
                        status: e.status,
                        expired: e.expired,
                        expiredHuman: humanDate(e.expired),
                        remainingDays: remainDays(e.expired)
                    }))
                    .sort((a, b) => a.expired - b.expired);
                total += result.jadibot.length;
            }

            if (!type || type === 'sewabot') {
                result.sewabot = Object.entries(sewa.getSewa() || {})
                    .filter(([, v]) => pick(v.expired))
                    .map(([groupId, v]) => ({
                        groupJid: groupId,
                        groupName: v.namegrup || null,
                        expired: v.expired,
                        expiredHuman: humanDate(v.expired),
                        remainingDays: remainDays(v.expired)
                    }))
                    .sort((a, b) => a.expired - b.expired);
                total += result.sewabot.length;
            }

            if (!type || type === 'premium') {
                result.premium = (premium.getAllPremiumUser() || [])
                    .filter((u) => pick(u.expired))
                    .map((u) => ({
                        number: normalizeNumber(u.id),
                        status: u.status,
                        expired: u.expired,
                        expiredHuman: humanDate(u.expired),
                        remainingDays: remainDays(u.expired)
                    }))
                    .sort((a, b) => a.expired - b.expired);
                total += result.premium.length;
            }

            res.json({
                success: true,
                data: {
                    windowDays: days,
                    meaning: 'remainingDays <= 0 berarti sudah expired; 1-7 berarti segera habis.',
                    total,
                    ...result
                }
            });
        })
    );


module.exports = router;

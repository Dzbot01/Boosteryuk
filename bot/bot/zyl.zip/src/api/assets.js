/**
 * assets.js — Penyimpanan & penyajian aset media milik bot jadibot.
 * ---------------------------------------------------------------------------
 * Thumbnail/welcome/register/audio yang di-upload lewat API disimpan di
 * Storage/jadibot_assets/<nomor>/<nama-acak>.<ext> lalu disajikan via route
 * PUBLIK /api/assets/<nomor>/<file> (terdaftar sebelum middleware API key,
 * sama seperti docs). Nama file diacak (hex) agar tidak mudah ditebak.
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const logger = require('@App/function/logger');

const ASSETS_ROOT = path.resolve(__dirname, '../../Storage/jadibot_assets');

const EXT_BY_MIME = {
    'image/jpeg': '.jpg',
    'image/png': '.png',
    'image/webp': '.webp',
    'image/gif': '.gif',
    'audio/mpeg': '.mp3',
    'audio/mp4': '.m4a',
    'audio/ogg': '.ogg',
    'audio/wav': '.wav',
    'video/mp4': '.mp4'
};

/** Deteksi ekstensi dari data-uri header atau magic bytes buffer. */
function detectExt(buffer, dataUri = '') {
    const m = String(dataUri).match(/^data:([a-zA-Z0-9/+.-]+);/);
    if (m && EXT_BY_MIME[m[1]]) return EXT_BY_MIME[m[1]];

    const b = buffer;
    if (b.length > 8 && b[0] === 0x89 && b[1] === 0x50) return '.png';
    if (b.length > 3 && b[0] === 0xff && b[1] === 0xd8) return '.jpg';
    if (b.length > 12 && b.slice(0, 4).toString() === 'RIFF' && b.slice(8, 12).toString() === 'WEBP') return '.webp';
    if (b.length > 3 && b.slice(0, 3).toString() === 'GIF') return '.gif';
    if (b.length > 12 && b.slice(4, 8).toString() === 'ftyp') return '.mp4';
    if (b.length > 4 && b.slice(0, 2).toString() === 'ID3') return '.mp3';
    if (b.length > 4 && b[0] === 0x4f && b[1] === 0x67 && b[2] === 0x67) return '.ogg';
    return '.bin';
}

/**
 * Simpan buffer sebagai aset milik nomor tertentu.
 * Return URL relatif: /api/assets/<nomor>/<namafile>
 */
function saveAsset(number, buffer, { ext = null, subdir = '' } = {}) {
    const clean = String(number).replace(/[^0-9]/g, '');
    if (!clean) throw new Error('Nomor bot tidak valid untuk menyimpan aset.');
    if (!buffer || !buffer.length) throw new Error('Aset kosong.');

    const dir = path.join(ASSETS_ROOT, clean, subdir);
    fs.mkdirSync(dir, { recursive: true });

    const extFinal = ext || detectExt(buffer);
    const name = `${Date.now().toString(36)}-${crypto.randomBytes(6).toString('hex')}${extFinal}`;
    fs.writeFileSync(path.join(dir, name), buffer);

    return `/api/assets/${clean}/${subdir ? subdir + '/' : ''}${name}`;
}

/** Hapus semua aset milik satu nomor (dipakai saat jadibot dihapus). */
function deleteAssets(number) {
    const clean = String(number).replace(/[^0-9]/g, '');
    if (!clean) return;
    const dir = path.join(ASSETS_ROOT, clean);
    try {
        fs.rmSync(dir, { recursive: true, force: true });
    } catch (err) {
        logger.warning(`[ASSETS] Gagal hapus aset ${clean}: ${err.message}`);
    }
}

/**
 * Route publik untuk menyajikan aset (dipasang SEBELUM middleware API key).
 * Content-type ditebak express.static otomatis dari ekstensi.
 */
function registerAssetsRoute(app) {
    app.use(
        '/api/assets',
        express.static(ASSETS_ROOT, {
            fallthrough: true,
            maxAge: '7d',
            immutable: true
        })
    );
}

module.exports = { ASSETS_ROOT, saveAsset, deleteAssets, registerAssetsRoute, detectExt };

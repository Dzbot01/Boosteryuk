/**
 * middleware.js — Autentikasi API key, rate limiter & error wrapper.
 */
const crypto = require('crypto');
const config = require('@Config');
const logger = require('@App/function/logger');

const isValidApiKey = (key) => {
    const keys = Array.isArray(config.api?.keys) ? config.api.keys : [];
    if (!keys.length) return false;
    try {
        return keys.some((k) => crypto.timingSafeEqual(Buffer.from(String(k)), Buffer.from(String(key || ''))));
    } catch (_) {
        return false;
    }
};

const createRateLimiter = () => {
    const windowMs = config.api?.rateLimit?.windowMs || 60000;
    const max = config.api?.rateLimit?.max || 30;
    const hits = new Map();

    const sweep = setInterval(() => {
        const now = Date.now();
        for (const [ip, entry] of hits) {
            if (now - entry.start > windowMs) hits.delete(ip);
        }
    }, windowMs);
    sweep.unref?.();

    return (req, res, next) => {
        const ip = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket.remoteAddress || 'unknown';
        const now = Date.now();
        let entry = hits.get(ip);

        if (!entry || now - entry.start > windowMs) {
            entry = { start: now, count: 0 };
            hits.set(ip, entry);
        }

        entry.count += 1;
        if (entry.count > max) {
            return res.status(429).json({
                success: false,
                message: 'Terlalu banyak permintaan. Coba lagi nanti.',
                code: 'RATE_LIMITED'
            });
        }

        next();
    };
};


    const requireApiKey = (req, res, next) => {
        let key = req.headers['x-api-key'];
        const auth = req.headers.authorization;
        if (!key && typeof auth === 'string' && auth.startsWith('Bearer ')) {
            key = auth.slice(7).trim();
        }
        if (!isValidApiKey(key)) {
            res.setHeader('WWW-Authenticate', 'Bearer realm="x7botz-api"');
            return res.status(401).json({
                success: false,
                message: 'API key tidak valid (header X-API-Key wajib).',
                code: 'INVALID_API_KEY'
            });
        }
        next();
    };

    const wrap = (fn) => (req, res) => {
        Promise.resolve(fn(req, res)).catch((err) => {
            const status = Number(err.status) || (err.message?.includes('tidak ditemukan') ? 404 : 400);
            logger.error(`[API] ${req.method} ${req.path}: ${err.message}`);
            res.status(status).json({
                success: false,
                message: err.message || 'Terjadi kesalahan internal.',
                code: err.code || 'REQUEST_FAILED'
            });
        });
    };


module.exports = { isValidApiKey, createRateLimiter, requireApiKey, wrap };

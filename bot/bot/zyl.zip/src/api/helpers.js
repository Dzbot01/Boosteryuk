/**
 * helpers.js — Helper bersama untuk REST API X7BOTZ.
 * Diekstrak dari server.js agar mudah diubah per-fungsi.
 */
const fs = require('fs');
const path = require('path');
const config = require('@Config');
const logger = require('@App/function/logger');

const BOT_VERSION = (() => {
    try {
        return JSON.parse(fs.readFileSync(path.resolve(__dirname, '../../package.json'), 'utf-8')).version || '2.5.0';
    } catch (_) {
        return '2.5.0';
    }
})();

const MAX_DAYS = 3650; // ≈ permanen (10 tahun)


const normalizeNumber = (input) => String(input || '').replace(/[^0-9]/g, '');

const validWaNumber = (number) => /^628\d{7,15}$/.test(number);

const numberToJid = (number) => `${normalizeNumber(number)}@s.whatsapp.net`;

const clampDays = (value, fallback = 30) => {
    const n = Math.floor(Number(value));
    if (!Number.isFinite(n)) return fallback;
    return Math.min(Math.max(n, 1), MAX_DAYS);
};

const humanDate = (ms) => (ms ? new Date(ms).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }) : null);

const parseDaysToExpired = (days) => Date.now() + days * 24 * 60 * 60 * 1000;

/* ── Helper gambar: unduh URL / decode base64 → Buffer (untuk foto profil bot) */

const MAX_IMAGE_BYTES = 5 * 1024 * 1024; // 5MB

const resolveImageBuffer = async ({ imageUrl, imageBase64 }) => {
    if (imageBase64) {
        const raw = String(imageBase64).replace(/^data:image\/[a-zA-Z+]+;base64,/, '');
        const buf = Buffer.from(raw, 'base64');
        if (!buf.length) throw new Error('imageBase64 kosong / tidak valid.');
        if (buf.length > MAX_IMAGE_BYTES) throw new Error('Gambar melebihi 5MB.');
        return buf;
    }

    if (imageUrl) {
        let url;
        try {
            url = new URL(String(imageUrl));
        } catch (_) {
            throw new Error('imageUrl tidak valid (harus http/https lengkap).');
        }
        if (!['http:', 'https:'].includes(url.protocol)) {
            throw new Error('imageUrl hanya boleh http/https.');
        }

        let res;
        try {
            res = await fetch(url, { signal: AbortSignal.timeout(15000) });
        } catch (err) {
            throw new Error(`Gagal mengunduh gambar: ${err.message}`);
        }
        if (!res.ok) throw new Error(`Gagal mengunduh gambar (HTTP ${res.status}).`);

        const type = String(res.headers.get('content-type') || '');
        if (!type.startsWith('image/')) throw new Error(`URL bukan gambar (content-type: ${type || 'unknown'}).`);

        const buf = Buffer.from(await res.arrayBuffer());
        if (!buf.length) throw new Error('Gambar yang diunduh kosong.');
        if (buf.length > MAX_IMAGE_BYTES) throw new Error('Gambar melebihi 5MB.');
        return buf;
    }

    throw new Error('Kirim "imageUrl" (link gambar http/https) atau "imageBase64" (data base64).');
};

/* ── Helper sewabot: link invite → jadikan id grup ───────────────────────── */

const extractInviteCode = (input) => {
    const s = String(input || '').trim();
    let m = s.match(/chat\.whatsapp\.com\/(?:invite\/)?([A-Za-z0-9]{15,})/i);
    if (m) return m[1];
    if (/^[A-Za-z0-9]{15,}$/.test(s)) return s; // sudah berupa kode invite
    return null;
};

const extractGroupJid = (input) => {
    const digits = normalizeNumber(input);
    if (digits.length >= 15 && digits.length <= 22) return `${digits}@g.us`;
    return null;
};

const resolveGroupViaSocket = async (socket, { groupLink, groupJid }) => {
    // Prioritas: groupJid langsung → metadata grup; kalau link → join/resolve invite.
    if (groupJid) {
        if (!socket) return { jid: groupJid, name: null, joined: false };
        try {
            const meta = await socket.groupMetadata(groupJid);
            return { jid: groupJid, name: meta?.subject || null, joined: true };
        } catch (_) {
            return { jid: groupJid, name: null, joined: false };
        }
    }

    const inviteCode = extractInviteCode(groupLink);
    if (!inviteCode) throw new Error('Link grup tidak valid. Contoh: https://chat.whatsapp.com/xxxxxxxx');

    if (!socket) throw new Error('Bot utama sedang tidak terhubung. Coba lagi nanti.');

    let jid = null;
    let name = null;
    let joined = false;

    try {
        await socket.groupAcceptInvite(inviteCode);
        joined = true;
    } catch (err) {
        // "already in group" / conflict berarti bot sudah member — bukan masalah.
        const msg = String(err?.message || '');
        if (!/conflict|already|alkes/i.test(msg)) {
            logger.warning(`[API] groupAcceptInvite: ${msg}`);
        }
    }

    try {
        const res = await socket.query({
            tag: 'iq',
            attrs: { type: 'get', xmlns: 'w:g2', to: '@g.us' },
            content: [{ tag: 'invite', attrs: { code: inviteCode } }]
        });
        const attrs = res?.content?.[0]?.attrs;
        if (attrs?.id) {
            jid = attrs.id.endsWith('@g.us') ? attrs.id : `${attrs.id}@g.us`;
            name = attrs.subject || null;
        }
    } catch (err) {
        logger.warning(`[API] Gagal resolve info invite: ${err.message}`);
    }

    return { jid, name, joined };
};


module.exports = {
    BOT_VERSION,
    MAX_DAYS,
    normalizeNumber,
    validWaNumber,
    numberToJid,
    clampDays,
    humanDate,
    parseDaysToExpired,
    MAX_IMAGE_BYTES,
    resolveImageBuffer,
    extractInviteCode,
    extractGroupJid,
    resolveGroupViaSocket
};

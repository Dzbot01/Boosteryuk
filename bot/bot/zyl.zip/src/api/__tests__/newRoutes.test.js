/**
 * newRoutes.test.js — Integration test endpoint API baru (v2.8.0).
 *
 * Menguji lewat HTTP server express sungguhan dengan jadibotManager &
 * store yang di-mock:
 *  - jadibot: GET settings, messages (POST/GET/DELETE), media (POST base64
 *    upload → URL /api/assets), payment, packages, owners, credentials (GET)
 *  - sewabot: packages, list dengan ?instance=
 *  - premium: packages, bulk, list dengan ?instance=
 */
const path = require('path');
const fs = require('fs');
const os = require('os');
const express = require('express');

const PROJECT = path.resolve(__dirname, '../../..');
const TMP = path.join(os.tmpdir(), `x7-api-test-${Date.now()}`);

const API_KEY = 'test-api-key';
const NUM = '628111111111';

let server;
let baseUrl;

const makeFakeManager = () => {
    const entry = {
        jid: `${NUM}@s.whatsapp.net`,
        number: NUM,
        identity: { botname: 'TestBot', packname: 'P', ownername: 'O', storename: 'S', bio: 'b', links: {} },
        settings: {},
        credentials: {},
        owners: ['628222222222'],
        ownerJid: `${NUM}@s.whatsapp.net`,
        public: true,
        package: 'TEST',
        status: 'active',
        start: Date.now(),
        expired: Date.now() + 86400000,
        stats: { messages: 5 }
    };

    const manager = {
        mainSocket: null,
        sockets: new Map(),
        registry: { [entry.jid]: entry },
        get: (jid) => manager.registry[jid] || null,
        getByNumber: (n) => {
            const clean = String(n || '').replace(/[^0-9]/g, '');
            return clean === NUM ? entry : null;
        },
        startInstance: async (jid, opts) => 'CODE123',
        stopInstance: async (jid, reason) => true,
        listAll: () => Object.values(manager.registry),
        getSettings: (jid) => entry.settings,
        updateSettings: async (jid, patch) => {
            for (const [k, v] of Object.entries(patch)) {
                if (v === null) entry.settings[k] = undefined;
                else entry.settings[k] = { ...(entry.settings[k] || {}), ...v };
            }
            return { ...entry.settings };
        },
        getCredentialsMasked: (jid) => entry.credentials,
        updateCredentials: (jid, patch) => {
            entry.credentials = { ...entry.credentials, ...patch };
            return entry.credentials;
        },
        getOwnerList: (jid) => [entry.ownerJid.split('@')[0], ...(entry.owners || [])],
        addOwner: (jid, user) => {
            entry.owners.push(user);
            return user;
        },
        removeOwner: (jid, user) => {
            entry.owners = entry.owners.filter((o) => o !== user);
            return user;
        },
        resolveConfig: (jid) => ({
            sewabot: { enabled: true, packages: [{ name: 'A', price: 1000, days: 3 }] },
            premium: { enabled: true, packages: [{ name: 'B', price: 2000, days: 7 }] }
        }),
        getSewaStore: (jid) => manager._sewaStore,
        getPremiumStore: (jid) => manager._premStore
    };

    manager._sewaStore = {
        _db: {},
        getSewa: (gid) => manager._sewaStore._db[gid] || null,
        addSewa: (gid, name, days) => {
            manager._sewaStore._db[gid] = { namegrup: name, start: new Date().toISOString(), expired: Date.now() + days * 86400000 };
            return true;
        },
        deleteSewa: (gid) => Boolean(delete manager._sewaStore._db[gid]),
        listActiveSewa: () =>
            Object.entries(manager._sewaStore._db)
                .filter(([, v]) => v.expired > Date.now())
                .map(([groupId, v]) => ({ groupId, ...v, remaining: v.expired - Date.now() }))
    };

    manager._premStore = {
        _db: {},
        addPremiumUser: (jid, dur) => {
            manager._premStore._db[jid] = { expired: Date.now() + 86400000 };
            return manager._premStore._db[jid].expired;
        },
        checkPremiumUser: (jid) => Boolean(manager._premStore._db[jid]),
        getPremiumExpired: (jid) => manager._premStore._db[jid]?.expired || null,
        delPremiumUser: (jid) => {
            if (!manager._premStore._db[jid]) throw new Error('not found');
            delete manager._premStore._db[jid];
            return { success: true };
        },
        getAllPremiumUser: () =>
            Object.entries(manager._premStore._db).map(([id, v]) => ({
                id,
                expired: v.expired,
                status: v.expired > Date.now() ? 'active' : 'expired',
                remaining: v.expired - Date.now()
            }))
    };

    return manager;
};

beforeAll(async () => {
    fs.mkdirSync(TMP, { recursive: true });

    jest.resetModules();

    const fakeManager = makeFakeManager();

    jest.doMock(path.join(PROJECT, 'config'), () => ({
        botname: 'test',
        api: { enabled: true, port: 0, keys: [API_KEY] },
        jadibot: { enabled: true, maxInstances: 10, maxPairingAttempts: 5, pairingCodeTtlMs: 90000 },
        sewabot: { enabled: true, packages: [{ name: 'MAIN', price: 500, days: 7 }], bonusPremiumMinDays: 0 },
        premium: { enabled: true, packages: [{ name: 'MAINPREM', price: 900, days: 14 }] },
        messageQueue: { enabled: true },
        reconnect: {}
    }));
    jest.doMock(path.join(PROJECT, 'App/function/logger'), () => ({
        info: jest.fn(),
        warning: jest.fn(),
        error: jest.fn(),
        success: jest.fn()
    }));
    jest.doMock(path.join(PROJECT, 'src/core/jadibot'), () => fakeManager);
    jest.doMock(path.join(PROJECT, 'database/wrappers/sewa'), () => ({
        createSewaStore: () => fakeManager._sewaStore,
        getSewa: (gid) => fakeManager._sewaStore.getSewa(gid),
        addSewa: (gid, name, days) => fakeManager._sewaStore.addSewa(gid, name, days),
        deleteSewa: (gid) => fakeManager._sewaStore.deleteSewa(gid),
        listActiveSewa: () => fakeManager._sewaStore.listActiveSewa()
    }));
    jest.doMock(path.join(PROJECT, 'database/wrappers/premium'), () => ({
        createPremiumStore: () => fakeManager._premStore,
        addPremiumUser: (jid, d) => fakeManager._premStore.addPremiumUser(jid, d),
        checkPremiumUser: (jid) => fakeManager._premStore.checkPremiumUser(jid),
        getPremiumExpired: (jid) => fakeManager._premStore.getPremiumExpired(jid),
        delPremiumUser: (jid) => fakeManager._premStore.delPremiumUser(jid),
        getAllPremiumUser: () => fakeManager._premStore.getAllPremiumUser()
    }));

    const assets = require(path.join(PROJECT, 'src/api/assets'));
    const jadibotRoutes = require(path.join(PROJECT, 'src/api/routes/jadibot'));
    const sewabotRoutes = require(path.join(PROJECT, 'src/api/routes/sewabot'));
    const premiumRoutes = require(path.join(PROJECT, 'src/api/routes/premium'));
    const { requireApiKey } = require(path.join(PROJECT, 'src/api/middleware'));

    const app = express();
    app.use(express.json({ limit: '5mb' }));
    assets.registerAssetsRoute(app);
    app.use('/api', requireApiKey);
    app.use(jadibotRoutes);
    app.use(sewabotRoutes);
    app.use(premiumRoutes);
    app.use((req, res) => res.status(404).json({ success: false, code: 'NOT_FOUND' }));

    await new Promise((resolve) => {
        server = app.listen(0, () => resolve());
    });
    baseUrl = `http://127.0.0.1:${server.address().port}`;
});

afterAll(async () => {
    if (server) await new Promise((r) => server.close(r));
    jest.dontMock(path.join(PROJECT, 'config'));
    jest.dontMock(path.join(PROJECT, 'App/function/logger'));
    try {
        fs.rmSync(TMP, { recursive: true, force: true });
    } catch (_) {}
});

const api = async (pathName, opts = {}) => {
    const res = await fetch(`${baseUrl}${pathName}`, {
        ...opts,
        headers: { 'Content-Type': 'application/json', 'X-API-Key': API_KEY, ...(opts.headers || {}) }
    });
    let body = null;
    try {
        body = await res.json();
    } catch (_) {}
    return { status: res.status, body };
};

describe('API baru — jadibot settings/messages', () => {
    test('GET /api/jadibot/settings mengembalikan settings', async () => {
        const { status, body } = await api(`/api/jadibot/settings?number=${NUM}`);
        expect(status).toBe(200);
        expect(body.success).toBe(true);
        expect(body.data.number).toBe(NUM);
    });

    test('POST /api/jadibot/messages menyimpan teks per-instance', async () => {
        const { status, body } = await api('/api/jadibot/messages', {
            method: 'POST',
            body: JSON.stringify({ number: NUM, messages: { mess: { payment: 'Teks bayar custom' }, singlemess: { open_grub: 'Grup dibuka' } } })
        });
        expect(status).toBe(200);
        expect(body.data.mess.payment).toBe('Teks bayar custom');
        expect(body.data.singlemess.open_grub).toBe('Grup dibuka');
    });

    test('POST /api/jadibot/messages menolak key tak dikenal', async () => {
        const { status } = await api('/api/jadibot/messages', {
            method: 'POST',
            body: JSON.stringify({ number: NUM, messages: { randomkey: { x: 'y' } } })
        });
        expect(status).toBe(400);
    });

    test('DELETE /api/jadibot/messages mereset teks', async () => {
        const { status, body } = await api(`/api/jadibot/messages?number=${NUM}`, { method: 'DELETE' });
        expect(status).toBe(200);
        expect(body.data.reset).toBe('all');
    });
});

describe('API baru — jadibot media (upload base64)', () => {
    const PNG_BASE64 =
        'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';

    test('POST /api/jadibot/media base64 → tersimpan & URL /api/assets dapat diakses publik', async () => {
        const { status, body } = await api('/api/jadibot/media', {
            method: 'POST',
            body: JSON.stringify({ number: NUM, media: { welcome: `data:image/png;base64,${PNG_BASE64}`, audio: [PNG_BASE64] } })
        });
        expect(status).toBe(200);
        expect(body.data.media.welcome).toMatch(/^\/api\/assets\//);
        expect(body.data.media.audio[0]).toMatch(/^\/api\/assets\//);

        // Aset bisa diambil TANPA API key (route publik).
        const res = await fetch(`${baseUrl}${body.data.media.welcome}`);
        expect(res.status).toBe(200);
        const buf = Buffer.from(await res.arrayBuffer());
        expect(buf.length).toBeGreaterThan(0);
        expect(buf[0]).toBe(0x89); // magic bytes PNG
    });

    test('POST /api/jadibot/media menolak key tidak dikenal', async () => {
        const { status } = await api('/api/jadibot/media', {
            method: 'POST',
            body: JSON.stringify({ number: NUM, media: { notakey: 'x' } })
        });
        expect(status).toBe(400);
    });
});

describe('API baru — jadibot payment/packages/owners/credentials', () => {
    test('POST /api/jadibot/payment menyimpan metode bayar bebas', async () => {
        const { status, body } = await api('/api/jadibot/payment', {
            method: 'POST',
            body: JSON.stringify({ number: NUM, payment: { DANA: '0812xxx', GOPAY: '0813xxx' } })
        });
        expect(status).toBe(200);
        expect(body.data.payment.DANA).toBe('0812xxx');

        const got = await api(`/api/jadibot/payment?number=${NUM}`);
        expect(got.body.data.payment.GOPAY).toBe('0813xxx');
    });

    test('POST /api/jadibot/packages menyimpan paket sewabot instance', async () => {
        const { status, body } = await api('/api/jadibot/packages', {
            method: 'POST',
            body: JSON.stringify({
                number: NUM,
                type: 'sewabot',
                packages: [
                    { name: 'Mingguan', price: 5000, days: 7 },
                    { name: 'Bulanan', price: 15000, days: 30 }
                ]
            })
        });
        expect(status).toBe(200);
        expect(body.data.sewabot.packages).toHaveLength(2);
        expect(body.data.sewabot.packages[0].name).toBe('Mingguan');
    });

    test('POST /api/jadibot/packages menolak type aneh', async () => {
        const { status } = await api('/api/jadibot/packages', {
            method: 'POST',
            body: JSON.stringify({ number: NUM, type: 'hacker', packages: [] })
        });
        expect(status).toBe(400);
    });

    test('POST /api/jadibot/owners add lalu remove', async () => {
        const add = await api('/api/jadibot/owners', {
            method: 'POST',
            body: JSON.stringify({ number: NUM, action: 'add', owner: '628333333333' })
        });
        expect(add.status).toBe(200);
        expect(add.body.data.owners).toContain('628333333333');

        const del = await api('/api/jadibot/owners', {
            method: 'POST',
            body: JSON.stringify({ number: NUM, action: 'remove', owner: '628333333333' })
        });
        expect(del.status).toBe(200);
        expect(del.body.data.owners).not.toContain('628333333333');
    });

    test('GET /api/jadibot/credentials ter-mask & POST restart 404 nomor tak ada', async () => {
        const cred = await api(`/api/jadibot/credentials?number=${NUM}`);
        expect(cred.status).toBe(200);

        const missing = await api('/api/jadibot/restart', {
            method: 'POST',
            body: JSON.stringify({ number: '628999999999' })
        });
        expect(missing.status).toBe(404);
    });

    test('Tanpa API key → 401', async () => {
        const res = await fetch(`${baseUrl}/api/jadibot/settings?number=${NUM}`);
        expect(res.status).toBe(401);
    });
});

describe('API baru — sewabot & premium', () => {
    test('GET /api/sewabot/packages bot utama', async () => {
        const { body } = await api('/api/sewabot/packages');
        expect(body.data.instance).toBe('main');
        expect(body.data.packages[0].name).toBe('MAIN');
    });

    test('GET /api/sewabot/packages ?instance= paket milik jadibot', async () => {
        const { body } = await api(`/api/sewabot/packages?instance=${NUM}`);
        expect(body.data.instance).toBe(NUM);
        expect(body.data.packages[0].name).toBe('A');
    });

    test('POST /api/sewabot dengan instance → sewa masuk store jadibot', async () => {
        const { status, body } = await api('/api/sewabot', {
            method: 'POST',
            body: JSON.stringify({ groupJid: '120363012345678901@g.us', days: 10, instance: NUM })
        });
        expect(status).toBe(201);
        expect(body.data.instance).toBe(NUM);
        expect(body.data.active).toBe(true);
    });

    test('GET /api/sewabot/list ?instance= menampilkan sewa jadibot', async () => {
        const { body } = await api(`/api/sewabot/list?instance=${NUM}`);
        expect(body.data.total).toBeGreaterThanOrEqual(1);
        expect(body.data.instance).toBe(NUM);
    });

    test('GET /api/premium/packages & POST /api/premium/bulk', async () => {
        const pkg = await api('/api/premium/packages');
        expect(pkg.body.data.packages[0].name).toBe('MAINPREM');

        const bulk = await api('/api/premium/bulk', {
            method: 'POST',
            body: JSON.stringify({ numbers: ['628444444444', '628555555555', '123bad'], days: 7 })
        });
        expect(bulk.status).toBe(201);
        expect(bulk.body.data.addedCount).toBe(2);
        expect(bulk.body.data.skipped).toHaveLength(1);
    });

    test('GET /api/premium/list ?instance= memakai store jadibot', async () => {
        const prem = await api('/api/premium', {
            method: 'POST',
            body: JSON.stringify({ number: '628666666666', days: 5, instance: NUM })
        });
        expect(prem.body.data.instance).toBe(NUM);

        const list = await api(`/api/premium/list?instance=${NUM}`);
        expect(list.body.data.instance).toBe(NUM);
        expect(list.body.data.total).toBeGreaterThanOrEqual(1);
    });
});

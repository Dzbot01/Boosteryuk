/**
 * middleware.test.js — Unit tests for src/api/middleware.js (Q3).
 */
const path = require('path');
const PROJECT = path.resolve(__dirname, '../../..');

// Pre-mock config via jest.doMock with the aliased module name BEFORE requiring middleware.
jest.doMock('@Config', () => ({
    api: {
        enabled: true,
        port: 3000,
        keys: ['test-secret-key'],
        rateLimit: { windowMs: 1000, max: 2 },
        cors: { origin: '*' }
    }
}), { virtual: false });

// Also stub logger to avoid moment-timezone load.
jest.doMock('@App/function/logger', () => ({
    info: jest.fn(),
    success: jest.fn(),
    error: jest.fn(),
    warning: jest.fn(),
    debug: jest.fn()
}), { virtual: false });

const { isValidApiKey, createRateLimiter, requireApiKey, wrap } = require(path.join(PROJECT, 'src/api/middleware'));

describe('API middleware', () => {
    describe('isValidApiKey', () => {
        test('accept valid key', () => {
            expect(isValidApiKey('test-secret-key')).toBe(true);
        });
        test('reject invalid key', () => {
            expect(isValidApiKey('wrong-key')).toBe(false);
        });
        test('reject empty', () => {
            expect(isValidApiKey('')).toBe(false);
            expect(isValidApiKey(null)).toBe(false);
            expect(isValidApiKey(undefined)).toBe(false);
        });
    });

    describe('requireApiKey', () => {
        const makeRes = () => {
            const headers = {};
            return {
                setHeader(k, v) { headers[k] = v; },
                status(code) { this.statusCode = code; return this; },
                json(payload) { this.body = payload; return this; },
                headers,
                statusCode: 200,
                body: null
            };
        };

        test('accept X-API-Key header', () => {
            const req = { headers: { 'x-api-key': 'test-secret-key' } };
            const res = makeRes();
            const next = jest.fn();
            requireApiKey(req, res, next);
            expect(next).toHaveBeenCalled();
        });

        test('accept Bearer token', () => {
            const req = { headers: { authorization: 'Bearer test-secret-key' } };
            const res = makeRes();
            const next = jest.fn();
            requireApiKey(req, res, next);
            expect(next).toHaveBeenCalled();
        });

        test('reject missing key with 401', () => {
            const req = { headers: {} };
            const res = makeRes();
            const next = jest.fn();
            requireApiKey(req, res, next);
            expect(next).not.toHaveBeenCalled();
            expect(res.statusCode).toBe(401);
            expect(res.body.code).toBe('INVALID_API_KEY');
        });
    });

    describe('createRateLimiter', () => {
        test('allow under limit, block over limit', () => {
            const limiter = createRateLimiter();
            const makeReqRes = (ip) => {
                const res = {
                    statusCode: 200,
                    status(c) { this.statusCode = c; return this; },
                    json(p) { this.body = p; return this; },
                    body: null
                };
                return { req: { headers: { 'x-forwarded-for': ip }, socket: { remoteAddress: ip } }, res };
            };

            // First two pass (max=2)
            let r1 = makeReqRes('5.5.5.5');
            limiter(r1.req, r1.res, () => {});
            expect(r1.res.statusCode).toBe(200);

            let r2 = makeReqRes('5.5.5.5');
            limiter(r2.req, r2.res, () => {});
            expect(r2.res.statusCode).toBe(200);

            // Third blocked
            let r3 = makeReqRes('5.5.5.5');
            limiter(r3.req, r3.res, () => {});
            expect(r3.res.statusCode).toBe(429);
            expect(r3.res.body.code).toBe('RATE_LIMITED');
        });
    });

    describe('wrap', () => {
        test('success result — handler called with req,res', async () => {
            const handler = jest.fn().mockResolvedValue({ ok: true });
            const res = {
                json: jest.fn(),
                status: jest.fn().mockReturnThis()
            };
            await wrap(handler)({ method: 'GET', path: '/x' }, res);
            expect(handler).toHaveBeenCalledWith({ method: 'GET', path: '/x' }, res);
            // wrap does NOT auto-send — handler is responsible for res.json()
            // (handler returned { ok: true } but didn't call res.json)
        });

        test('error → 400 with message', async () => {
            const handler = jest.fn().mockRejectedValue(Object.assign(new Error('Bad req'), { status: 400 }));
            const res = { json: jest.fn(), status: jest.fn().mockReturnThis() };
            await wrap(handler)({ method: 'POST', path: '/x' }, res);
            expect(res.status).toHaveBeenCalledWith(400);
            expect(res.json).toHaveBeenCalledWith(expect.objectContaining({ success: false, message: 'Bad req' }));
        });

        test('tidak ditemukan → 404', async () => {
            const handler = jest.fn().mockRejectedValue(new Error('Jadibot tidak ditemukan.'));
            const res = { json: jest.fn(), status: jest.fn().mockReturnThis() };
            await wrap(handler)({ method: 'GET', path: '/x' }, res);
            expect(res.status).toHaveBeenCalledWith(404);
        });
    });
});

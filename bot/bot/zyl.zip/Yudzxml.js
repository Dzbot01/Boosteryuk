'use strict';

const mainMessageHandler = require('./src/handler/main');

module.exports = mainMessageHandler;

const fs = require('fs');
const logger = require('@App/function/logger');
const file = require.resolve(__filename);
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    logger.info(`UPDATE FILE YUDZXML.JS (shim)`);
    try {
        delete require.cache[file];
        require(file);
    } catch (err) {
        logger.error(`RELOAD YUDZXML GAGAL: ${err.message}`);
    }
});

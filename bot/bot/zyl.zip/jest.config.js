/**
 * Jest config — resolve module aliases (mirrors package.json _moduleAliases).
 */
module.exports = {
    testEnvironment: 'node',
    testMatch: ['**/__tests__/**/*.test.js', '**/?(*.)+(spec|test).js'],
    testPathIgnorePatterns: ['/node_modules/', '/Storage/', '/tmp/'],
    moduleNameMapper: {
        '^@App/(.*)$': '<rootDir>/App/$1',
        '^@App$': '<rootDir>/App',
        '^@Config$': '<rootDir>/config.js',
        '^@Database$': '<rootDir>/database/index.js',
        '^@Database/(.*)$': '<rootDir>/database/$1',
        '^@Storage/(.*)$': '<rootDir>/Storage/$1',
        '^@tmp/(.*)$': '<rootDir>/tmp/$1'
    },
    collectCoverageFrom: [
        'src/**/*.js',
        'database/**/*.js',
        'App/function/**/*.js',
        '!**/__tests__/**',
        '!**/node_modules/**'
    ],
    setupFilesAfterEnv: [],
    verbose: false
};

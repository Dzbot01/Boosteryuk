/*
 * SILAHKAN BACA DOKUMENTASI DI FOLDER
 => /docs/config-readme.md
*/

const fs = require('fs');
const moment = require('moment-timezone');
const logger = require('./App/function/logger');

const TIMEZONE = 'Asia/Jakarta';

const config = {
  superowner: '6285184112705',
  ownername: 'YudzDev ✨',
  email: 'support@yydz.my.id',
  botname: 'X7BOTZ - MD V2.1',
  packname: '❃ ʏᴜᴅᴢ - ᴍᴜʟᴛɪᴅᴇᴠɪᴄᴇ',
  author: `Date: ${moment.tz(TIMEZONE).format('DD/MM/YY')}\nTelegram: @Yudzxzy\nSticker: By Yudzxml`,
  region: 'Indonesia',
  idch: '120363426771378655@newsletter',

  pairingCode: true,
  pairingNumber: '',
  markOnlineOnConnect: false,
  public: true,
  prefix: true,
  autoRead: true,
  autoswview: false,
  anticall: true,
  debug: false,
  allowEval: true,
  isRamadhan: true,
  prefix_custom: ['/', '!', '.', '#', '&'],
  customPairing: 'YUDZDEV7',
  bootMode: 'menu',
  botDestination: 'group',
  resetclaim: 720,
  sleep_game: 60000,
  MoneyMenangGame: 20,
  ratelimiter: 5000,
  icon_on: '🟢',
  icon_off: '🔴',
  
  store: {
    nameStore: 'YUDZXML STORE 77',
    group: 'https://chat.whatsapp.com/EtMl7mHHn93G0YcWIpcXiA',
    saluran: 'https://whatsapp.com/channel/0029VbA78K82f3EGd78yGU28',
    website: 'https://nokohost.eu.cc'
  },

  payment: {
    QRIS: 'https://cdn.dyxzy.my.id/files/d7de5d53.png',
    DANA: '6281275673391'
  },

  apikey: {
    endpoint: 'https://api.yudzapi.my.id',
    key: 'YourKey'
  },


  pakasir: {
    enabled: true,
    key: 'YourKey',
    slug: 'YourSlug',
    baseUrl: 'https://app.pakasir.com',
    defaultMethod: 'qris', 
    frameQr: 'https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/f2bee145.png'
  },

  cpanel: {
    BASE: 'https://your_domain.com',
    PLTA: 'ptla_xxxxxx',
    NODEJS: { NESTID: 5, EGGID: 15 },
    PYTHON: { NESTID: 6, EGGID: 16 },
    LISTPANEL: [
      { name: 'ram1',  ram: 512,   disk: 1024,  cpu: 50,  price: 2000 },
      { name: 'ram2',  ram: 1024,  disk: 2048,  cpu: 80,  price: 4000 },
      { name: 'ram3',  ram: 2048,  disk: 3072,  cpu: 120, price: 7000 },
      { name: 'ram4',  ram: 3072,  disk: 4096,  cpu: 150, price: 10000 },
      { name: 'ram5',  ram: 4096,  disk: 6144,  cpu: 200, price: 14000 },
      { name: 'ram6',  ram: 5120,  disk: 8192,  cpu: 250, price: 18000 },
      { name: 'ram7',  ram: 6144,  disk: 10240, cpu: 300, price: 22000 },
      { name: 'ram8',  ram: 8192,  disk: 12288, cpu: 350, price: 28000 },
      { name: 'ram9',  ram: 10240, disk: 20480, cpu: 400, price: 35000 },
      { name: 'ram10', ram: 12288, disk: 30720, cpu: 500, price: 45000 }
    ]
  },

  jadibot: {
    enabled: true,
    maxInstances: 50,
    freeRegistration: false,
    sessionFolder: 'Storage/jadibot_sessions',
    autoDeleteSession: true,
    maxPairingAttempts: 5,
    pairingCodeTtlMs: 90000,
    dataRetentionDays: 30,
    packages: [
       { name: '3 Hari', price: 5000, days: 3 },
       { name: '7 Hari', price: 10000, days: 7 },
       { name: '1 Bulan', price: 30000, days: 30 },
       { name: '2 Bulan', price: 55000, days: 60 },
       { name: '3 Bulan', price: 75000, days: 90 },
       { name: '1 Tahun', price: 250000, days: 365 }
    ],
  },

  sewabot: {
    enabled: true,
    packages: [
       { name: '3 Hari', price: 3000, days: 3 },
       { name: '7 Hari', price: 5000, days: 7 },
       { name: '1 Bulan', price: 10000, days: 30 },
       { name: '2 Bulan', price: 20000, days: 60 },
       { name: '3 Bulan', price: 30000, days: 90 },
       { name: '1 Tahun', price: 85000, days: 365 }
    ],
    bonusPremiumMinDays: 30,
    autoJoinGroup: true
  },

  premium: {
    enabled: true,
    packages: [
       { name: '3 Hari', price: 1000, days: 3 },
       { name: '7 Hari', price: 2000, days: 7 },
       { name: '1 Bulan', price: 5000, days: 30 },
       { name: '2 Bulan', price: 10000, days: 60 },
       { name: '3 Bulan', price: 15000, days: 90 },
       { name: '1 Tahun', price: 40000, days: 365 }
    ],
  },

  database: {
    type: 'json',
    json: { path: './Storage' },
    sqlite: { path: './bot.db' },
    postgresql: {
      host: 'localhost',
      port: 5432,
      database: 'x7botz_db',
      user: 'postgres',
      password: 'password123'
    },
    mysql: {
      host: 'localhost',
      port: 3306,
      database: 'x7botz_db',
      user: 'root',
      password: 'password123'
    },
    pool: { min: 2, max: 10, acquireTimeoutMillis: 10000, idleTimeoutMillis: 30000 },
    debug: false,
    autoMigrate: true,
    fallbackToJson: true,
    cacheEnabled: true,
    cacheTtl: 30000,
    flushIntervalMs: 300,
    maxRetries: 3,
    legacyLowdbHeartbeat: false,
    backupCompress: true
  },

  api: {
    enabled: true,
    port: 3001,
    keys: ['YourKeys'],
    ownerToken: 'YourKeys',
    rateLimit: { windowMs: 60000, max: 30 },
    cors: { origin: 'https://nokohost.eu.cc' }
  },

  messageQueue: {
    enabled: true,
    minDelayMs: 900,
    maxJitterMs: 600,
    maxQueue: 150,
    sendTimeoutMs: 90000
  },

  autoBackup: {
    enabled: true,
    zipDaily: true,
    dbIntervalHours: 12,
    keep: 10,
    includeSessions: true,
    sendToWa: true
  },

  autoCleaner: {
    enabled: true,
    intervalMinutes: 30,
    tmp: true,
    nodeCache: true,
    statisticsRetentionDays: 90,
    rpgRetentionDays: 80,
    backupsKeep: 10,
    minFreeMB: 512
  },

  autoRestart: {
    enabled: true,
    dailyAtHour: 1,
    memoryLimitMB: 1024
  },

  reconnect: {
    maxAttempts: 10,
    baseDelayMs: 5000,
    maxDelayMs: 600000,
    banCooldownMs: 1800000,
    maxBanRetries: 5,
    jadibotAutoStopOnBan: true
  },

  thumbnail: {
    game_over: 'https://cdn.dyxzy.my.id/files/e3387f74.png',
    start_game: 'https://cdn.dyxzy.my.id/files/daa48734.png',
    timeout_game: 'https://cdn.dyxzy.my.id/files/d9841d54.png',
    welcome: 'https://cdn.dyxzy.my.id/files/ee57f957.jpg',
    register: 'https://cdn.dyxzy.my.id/files/1631d3e4.png',
    imagereply: [
      'https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/2fc1c35e.jpg',
      'https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/59edb6a3.jpg',
      'https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/4803fcd1.jpg',
      'https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/43d2387f.jpg',
      'https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/03581e59.jpg',
      'https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/e61e1a6b.jpg'
    ],
    imagemenu: [
      'https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/7faa96e3.jpg',
      'https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/d65e752e.jpg',
      'https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/f8f8d36a.jpg',
      'https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/82f5752c.jpg',
      'https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/02a3c164.jpg',
      'https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/dc5ab274.jpg',
      'https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/171e8189.jpg'
    ],
    audio: [
      'https://cdn.dyxzy.my.id/files/3b2b07d6.opus',
      'https://cdn.dyxzy.my.id/files/70f20e85.opus',
      'https://cdn.dyxzy.my.id/files/a2709d07.opus',
      'https://cdn.dyxzy.my.id/files/63399c4b.opus',
      'https://cdn.dyxzy.my.id/files/6ec0d861.opus',
      'https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/5d00aa6a.opus'
    ]
  },

  mess: {
    payment: '*⚡ ᴘᴀʏᴍᴇɴᴛ ʏᴜᴅᴢxᴍʟ ꜱᴛᴏʀᴇ ⚡*\n\n*_📝 ᴋᴇᴛᴇɴᴛᴜᴀɴ ᴘᴇᴍʙᴀʏᴀʀᴀɴ_*\n• ᴡᴀᴊɪʙ *ᴍᴇɴɢɪʀɪᴍ ʙᴜᴋᴛɪ ᴛʀᴀɴꜱꜰᴇʀ* ꜱᴇᴛᴇʟᴀʜ ᴍᴇʟᴀᴋᴜᴋᴀɴ ᴘᴇᴍʙᴀʏᴀʀᴀɴ.\n• ᴘᴇᴍʙᴀʏᴀʀᴀɴ ᴍᴇʟᴀʟᴜɪ *qʀɪꜱ* ᴅɪᴋᴇɴᴀᴋᴀɴ ʙɪᴀʏᴀ ᴀᴅᴍɪɴɪꜱᴛʀᴀꜱɪ ꜱᴇʙᴇꜱᴀʀ *ʀᴘ100.*\n• ᴡᴀᴊɪʙ ᴍᴇɴʏᴇʀᴛᴀᴋᴀɴ *ꜱᴄʀᴇᴇɴꜱʜᴏᴛ ʙᴜᴋᴛɪ ᴄʜᴀᴛ* ꜱᴀᴀᴛ ᴘᴇᴍᴇꜱᴀɴᴀɴ ꜱᴇʙᴀɢᴀɪ ꜱʏᴀʀᴀᴛ ᴋʟᴀɪᴍ ɢᴀʀᴀɴꜱɪ.\n• ᴛʀᴀɴꜱᴀᴋꜱɪ *ᴛᴀɴᴘᴀ ᴅʀᴀᴍᴀ* ᴅᴀɴ *ᴛᴀɴᴘᴀ ᴘᴇʀᴅᴇʙᴀᴛᴀɴ*, ᴋᴇꜱᴀʟᴀʜᴀɴ ᴅᴀʀɪ ᴘɪʜᴀᴋ ᴋᴀᴍɪ ᴀᴋᴀɴ ᴅɪʟᴀᴋᴜᴋᴀɴ *ʀᴇꜰᴜɴᴅ ᴘᴇɴᴜʜ.*\n• *ʀᴇꜰᴜɴᴅ ᴛɪᴅᴀᴋ ʙᴇʀʟᴀᴋᴜ* ᴀᴘᴀʙɪʟᴀ ʙᴀʀᴀɴɢ ᴛᴇʟᴀʜ ᴅɪᴛᴇʀɪᴍᴀ ᴅᴀɴ ᴅɪɢᴜɴᴀᴋᴀɴ ᴅᴀʟᴀᴍ ᴊᴀɴɢᴋᴀ ᴡᴀᴋᴛᴜ ᴛᴇʀᴛᴇɴᴛᴜ.',
    blacklistgc: 'ɢʀᴏᴜᴘ ɪɴɪ ᴛᴇʟᴀʜ ᴅɪʙʟᴀᴄᴋʟɪꜱᴛ ᴏʟᴇʜ ᴏᴡɴᴇʀ.\nꜱᴇᴍᴜᴀ ꜰɪᴛᴜʀ ʙᴏᴛ ᴛɪᴅᴀᴋ ᴅᴀᴘᴀᴛ ᴅɪɢᴜɴᴀᴋᴀɴ ᴅɪ ɢʀᴏᴜᴘ ɪɴɪ.\nꜱɪʟᴀᴋᴀɴ ʜᴜʙᴜɴɢɪ ᴏᴡɴᴇʀ ᴜɴᴛᴜᴋ ɪɴꜰᴏ ʟᴇʙɪʜ ʟᴀɴᴊᴜᴛ.',
    success: '*😋 ᴅᴏɴᴇ ᴅᴇꜱᴜᴜ ~*',
    premium: '_*ꜰɪᴛᴜʀ ᴏɴʟʏ ᴜꜱᴇʀ ᴘʀᴇᴍɪᴜᴍ*_\n*_ʙᴜʏ ᴘʀᴇᴍɪᴜᴍ ꜰᴏʀ ᴀᴄᴄᴇꜱꜱ ꜰɪᴛᴜʀ, ʏᴏᴜ ᴄᴀɴ ᴛʏᴘᴇ .ʙᴜʏᴘʀᴇᴍ, ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ʟɪꜱᴛ ʜᴀʀɢᴀ ᴍᴇᴍʙᴇʀ ᴘʀᴇᴍɪᴜᴍ_*',
    admin: '_*ᴏɴʟʏ ᴀᴅᴍɪɴ !!*_',
    botNotAdmin: '*_ᴊᴀᴅɪᴋᴀɴ ʙᴏᴛ ᴀᴅᴍɪɴ ᴜɴᴛᴜᴋ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ꜰɪᴛᴜʀ ɪɴɪ !!_*',
    userNotAdmin: '*_ᴋᴀᴍᴜ ɪᴛᴜ ʙᴜᴋᴀɴ ᴀᴅᴍɪɴ !!_*',
    urlnotvalid: '*_ʟɪɴᴋ ᴛɪᴅᴀᴋ ᴠᴀʟɪᴅ/ꜱᴀʟᴀʜ!!_*',
    limit: '_*ʟɪᴍɪᴛ ʜᴀʀɪ ɪɴɪ ᴛᴇʀʟᴀʜ ᴛᴇʀᴄᴀᴘᴀɪ, ꜱɪʟᴀʜᴋᴀɴ ᴛᴜɴɢɢᴜ ʙᴇꜱᴏᴋ ᴀᴛᴀᴜ ʟᴀᴋᴜᴋᴀɴ ᴘᴇᴍʙᴇʟɪᴀɴ ᴘʀᴇᴍɪᴜᴍ ᴜɴᴛᴜᴋ ᴍᴇɴɢᴀᴋꜱᴇꜱꜱʏᴀ ʙᴏᴛ ᴛᴀɴᴘᴀ ʙᴀᴛᴀꜱ*_',
    superowner: '*_ᴏɴʟʏ ꜱᴜᴘᴇʀᴏᴡɴᴇʀ !!_*',
    owner: '*_ᴏɴʟʏ ᴏᴡɴᴇʀ !!_*',
    group: '*_ᴏɴʟʏ ɢʀᴜᴘ ᴄʜᴀᴛ !!_*',
    private: '*_ᴏɴʟʏ ᴘʀɪᴠᴀᴛᴇ ᴄʜᴀᴛ !!_*',
    wait: '_*ᴡᴀɪᴛɪɴɢ...*_',
    error: '_*ꜰɪᴛᴜʀ ꜱᴇᴅᴀɴɢ ᴇʀʀᴏʀ !!*_',
    register: '*⚠️ ᴍᴀᴀꜰ ᴋᴀᴋ ᴋᴀᴍᴜ ʙᴇʟᴜᴍ ᴛᴇʀᴅᴀꜰᴛᴀʀ ᴘᴀᴅᴀ ʙᴏᴛ ᴋᴀᴍɪ ꜱɪʟᴀʜᴋᴀɴ ᴍᴇɴᴇᴋᴀɴ ᴛᴏᴍʙᴏʟ ᴅᴀꜰᴛᴀʀ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ*'
  },

  singlemess: {
    open_grub: '_*ɢʀᴏᴜᴘ ʙᴇʀʜᴀꜱɪʟ ᴅɪʙᴜᴋᴀ ᴛᴜᴀɴ*_ 「 🔓 」',
    close_grub: '_*ɢʀᴏᴜᴘ ʙᴇʀʜᴀꜱɪʟ ᴅɪᴛᴜᴛᴜᴘ ᴛᴜᴀɴ*_ 「 🔒 」',
    kickmember: '_*ʙᴇʀʜᴀꜱɪʟ ᴍᴇɴɢᴇʟᴜᴀʀᴋᴀɴ ᴅᴀʀɪ ɢʀᴜᴘ*_',
    antidocument: '「 🚫 」 *_ᴅᴏᴄᴜᴍᴇɴᴛ ᴛɪᴅᴀᴋ ᴅɪɪᴢɪɴᴋᴀɴ_*\nᴘᴇɴɢɪʀɪᴍᴀɴ ᴅᴏᴄᴜᴍᴇɴᴛ ᴅɪʟᴀʀᴀɴɢ ᴅɪ ɢʀᴏᴜᴘ ɪɴɪ.\nᴘᴇꜱᴀɴ ᴀᴋᴀɴ ᴅɪʜᴀᴘᴜꜱ.',
    antiimage: '「 🚫 」 *_ɢᴀᴍʙᴀʀ ᴛɪᴅᴀᴋ ᴅɪɪᴢɪɴᴋᴀɴ_*\nᴘᴇɴɢɪʀɪᴍᴀɴ ɢᴀᴍʙᴀʀ ᴅɪʟᴀʀᴀɴɢ ᴅɪ ɢʀᴏᴜᴘ ɪɴɪ.\nᴘᴇꜱᴀɴ ᴀᴋᴀɴ ᴅɪʜᴀᴘᴜꜱ.',
    antivideo: '「 🚫 」 *_ᴠɪᴅᴇᴏ ᴛɪᴅᴀᴋ ᴅɪɪᴢɪɴᴋᴀɴ_*\nᴘᴇɴɢɪʀɪᴍᴀɴ ᴠɪᴅᴇᴏ ᴅɪʟᴀʀᴀɴɢ ᴅɪ ɢʀᴏᴜᴘ ɪɴɪ.\nᴘᴇꜱᴀɴ ᴀᴋᴀɴ ᴅɪʜᴀᴘᴜꜱ.',
    antisticker: '「 🚫 」 *_ꜱᴛɪᴄᴋᴇʀ ᴛɪᴅᴀᴋ ᴅɪɪᴢɪɴᴋᴀɴ_*\nᴘᴇɴɢɪʀɪᴍᴀɴ ꜱᴛɪᴄᴋᴇʀ ᴅɪʟᴀʀᴀɴɢ ᴅɪ ɢʀᴏᴜᴘ ɪɴɪ.\nᴘᴇꜱᴀɴ ᴀᴋᴀɴ ᴅɪʜᴀᴘᴜꜱ.',
    antiaudio: '「 🚫 」 *_ᴀᴜᴅɪᴏ ᴛɪᴅᴀᴋ ᴅɪɪᴢɪɴᴋᴀɴ_*\nᴘᴇɴɢɪʀɪᴍᴀɴ ᴀᴜᴅɪᴏ ᴅɪʟᴀʀᴀɴɢ ᴅɪ ɢʀᴏᴜᴘ ɪɴɪ.\nᴘᴇꜱᴀɴ ᴀᴋᴀɴ ᴅɪʜᴀᴘᴜꜱ.',
    antikontak: '「 🚫 」 *_ᴋᴏɴᴛᴀᴋ ᴛɪᴅᴀᴋ ᴅɪɪᴢɪɴᴋᴀɴ_*\nᴘᴇɴɢɪʀɪᴍᴀɴ ᴋᴏɴᴛᴀᴋ ᴅɪʟᴀʀᴀɴɢ ᴅɪ ɢʀᴏᴜᴘ ɪɴɪ.\nᴘᴇꜱᴀɴ ᴀᴋᴀɴ ᴅɪʜᴀᴘᴜꜱ.',
    antipolling: '「 🚫 」 *_ᴘᴏʟʟɪɴɢ ᴛɪᴅᴀᴋ ᴅɪɪᴢɪɴᴋᴀɴ_*\nᴘᴇᴍʙᴜᴀᴛᴀɴ ᴘᴏʟʟɪɴɢ ᴅɪʟᴀʀᴀɴɢ ᴅɪ ɢʀᴏᴜᴘ ɪɴɪ.\nᴘᴇꜱᴀɴ ᴀᴋᴀɴ ᴅɪʜᴀᴘᴜꜱ.',
    antilinkv1_detek: '_*ᴀɴᴛɪʟɪɴᴋ ᴅᴇᴛᴇᴄᴛᴇᴅ*_ 「 🚫 」',
    antilinkv2_dete: '_*ᴀɴᴛɪʟɪɴᴋ2 ᴅᴇᴛᴇᴄᴛᴇᴅ*_ 「 🚫 」',
    antilinkwa_detek: '_*ᴀɴᴛɪʟɪɴᴋ ᴡᴀ ᴅᴇᴛᴇᴄᴛᴇᴅ*_ 「 🚫 」',
    antilinktiktok_detek: '_*ᴀɴᴛɪʟɪɴᴋ ᴛɪᴋᴛᴏᴋ ᴅᴇᴛᴇᴄᴛᴇᴅ*_ 「 🚫 」',
    antinsfwv1_detek: '_*ɴꜱꜰᴡ ᴅᴇᴛᴇᴄᴛᴇᴅ*_ 「 🚫 」\nᴋᴏɴᴛᴇɴ ᴛɪᴅᴀᴋ ʟᴀʏᴀᴋ ᴅɪᴛᴀᴍᴘɪʟᴋᴀɴ ᴅɪ ɢʀᴏᴜᴘ ɪɴɪ.\nᴘᴇꜱᴀɴ ᴀᴋᴀɴ ᴅɪʜᴀᴘᴜꜱ.',
    antigame: '「 🚫 」 *_ꜰɪᴛᴜʀ ɢᴀᴍᴇ ᴛᴇʟᴀʜ ᴅɪᴍᴀᴛɪᴋᴀɴ ᴜɴᴛᴜᴋ ᴍᴇɴɢʜɪɴᴅᴀʀɪ ꜱᴘᴀᴍ ʙᴇʀʟᴇʙɪʜ, ᴍᴏʜᴏɴ ᴍᴀᴀꜰ ʏᴀ ᴋᴀᴋ..._',
    antispam1: '「 🚫 」 _*ꜱᴘᴀᴍ ᴅᴇᴛᴇᴄᴛᴇᴅ*_',
    antispam2: '「 🚫 」 *_ᴘᴇʀɪɴɢᴀᴛᴀɴ ᴛᴇʀᴀᴋʜɪʀ!!_*\nᴋᴀᴍᴜ ᴀᴋᴀɴ ᴅɪᴋɪᴄᴋ ᴊɪᴋᴀ ᴍᴇɴɢɪʀɪᴍ ꜱᴘᴀᴍ ᴄʜᴀᴛ ʟᴀɢɪ!!!',
    antipromosi_limit: '「 🚫 」 *_ʙᴀᴛᴀꜱ ᴘʀᴏᴍᴏꜱɪ ᴛᴇʀᴄᴀᴘᴀɪ_*\nᴋᴀᴍᴜ ᴛᴇʟᴀʜ ᴍᴇʟᴇʙɪʜɪ ʙᴀᴛᴀꜱ ᴘʀᴏᴍᴏꜱɪ ʜᴀʀɪ ɪɴɪ 3/3.\nꜱɪʟᴀʜᴋᴀɴ ᴄᴏʙᴀ ʟᴀɢɪ ʙᴇꜱᴏᴋ.',
    antipromosiv2_detek: '「 🚫 」 *_ᴘʀᴏᴍᴏꜱɪ ᴛᴇʀᴅᴇᴛᴇᴋꜱɪ_*\nᴍᴏʜᴏɴ ᴍᴀᴀꜰ, ᴘʀᴏᴍᴏꜱɪ ᴛɪᴅᴀᴋ ᴅɪɪᴢɪɴᴋᴀɴ ᴅɪ ɢʀᴏᴜᴘ ɪɴɪ.\nᴘᴇꜱᴀɴ ᴀᴋᴀɴ ᴅɪʜᴀᴘᴜꜱ',
    antipromosiv3_detek: '「 🚫 」 *_ᴘʀᴏᴍᴏꜱɪ ᴅᴇᴛᴇᴄᴛᴇᴅ_*\nᴘᴇꜱᴀɴ ᴘʀᴏᴍᴏꜱɪ ᴛᴇʀᴅᴇᴛᴇᴋꜱɪ.\nᴋᴀᴍᴜ ᴀᴋᴀɴ ʟᴀɴɢꜱᴜɴɢ ᴅɪᴋɪᴄᴋ.',
    antibot_detek: '「 🚫 」 *_ᴀɴᴏᴛʜᴇʀ ʙᴏᴛ ᴅᴇᴛᴇᴄᴛᴇᴅ_*\nᴍᴏʜᴏɴ ᴍᴀᴀꜰ ᴋᴀᴍᴜ ᴀᴋᴀɴ ꜱᴀʏᴀ ᴋɪᴄᴋ',
    antibadword: '「 🚫 」 *_ɪɴɪ ᴀᴅᴀʟᴀʜ ᴘᴇʀɪɴɢᴀᴛᴀɴ ᴛᴇʀᴀᴋʜɪʀ!!_*\nᴋᴀᴍᴜ ᴀᴋᴀɴ ꜱᴀʏᴀ ᴋɪᴄᴋ ᴊɪᴋᴀ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ/ᴍᴇɴɢɪʀɪᴍ ᴋᴀᴛᴀ² ᴛᴇʀʟᴀʀᴀɴɢ !!',
    antivirtex: '「 🚫 」 *_ᴀɴᴛɪ ᴠɪʀᴛᴇx ᴅᴇᴛᴇᴄᴛᴇᴅ_*\nᴍᴏʜᴏɴ ᴍᴀᴀꜰ ᴋᴀᴍᴜ ᴀᴋᴀɴ ᴅɪ ᴋɪᴄᴋ ᴅᴀʀɪ ɢʀᴜᴘ',
    antitagsw: '「 🚫 」 ᴀɴᴛɪ ᴛᴀɢ ꜱᴛᴀᴛᴜꜱ ᴅᴇᴛᴇᴄᴛᴇᴅ\n ᴍᴏʜᴏɴ ᴍᴀᴀꜰ, ᴍᴇɴɢɪʀɪᴍ ᴛᴀɢ ꜱᴛᴀᴛᴜꜱ ᴅɪ ɢʀᴜᴘ ᴅɪʟᴀʀᴀɴɢ.',
    antitagswv2: '「 🚫 」 *_ᴀɴᴛɪ ᴛᴀɢ ꜱᴡ ᴅᴇᴛᴇᴄᴛᴇᴅ_*\n ᴍᴏʜᴏɴ ᴍᴀᴀꜰ ᴋᴀᴍᴜ ᴀᴋᴀɴ ᴅɪ ᴋɪᴄᴋ ᴅᴀʀɪ ɢʀᴜᴘ',
    unmute: '*_ʙᴏᴛ ʙᴇʀʜᴀꜱɪʟ ᴅɪ ᴜɴᴍᴜᴛᴇ ᴅɪ ɢʀᴜᴘ ɪɴɪ_*',
    mute: '*_ʙᴏᴛ ʙᴇʀʜᴀꜱɪʟ ᴅɪᴍᴜᴛᴇ ᴅɪ ɢʀᴜᴘ ɪɴɪ_*'
  }
};

module.exports = config;

let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  logger.info('UPDATE FILE CONFIG');
  delete require.cache[file];
  require(file);
});

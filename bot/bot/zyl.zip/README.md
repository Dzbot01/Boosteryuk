<div align="center">

<!-- LOGO -->
<a href="https://github.com/Yudzxml/X7BOTZ">
  <img src="https://a.top4top.io/p_37574umed0.jpg" alt="X7BOTZ Logo" width="180" style="filter: drop-shadow(0 0 10px rgba(0,255,255,0.5));"/>
</a>

<!-- TYPING EFFECT -->
<a href="https://git.io/typing-svg">
  <img src="https://readme-typing-svg.herokuapp.com?font=Black+Ops+One&size=40&duration=3500&pause=1000&color=00FFFF&center=true&vCenter=true&width=1000&lines=X7BOTZ+-+MD;MODULAR+WHATSAPP+BOT;MULTI-DEVICE+SUPPORT;CLEAN+ARCHITECTURE" alt="Typing SVG" />
</a>

<!-- DYNAMIC BADGES -->
<p>
  <img src="https://img.shields.io/badge/version-2.6.2-green?style=for-the-badge&logo=appveyor" alt="Version">
  <img src="https://img.shields.io/badge/node-v20+-green?style=for-the-badge&logo=node.js" alt="Node">
  <img src="https://img.shields.io/badge/license-MIT-orange?style=for-the-badge" alt="License">
  <img src="https://img.shields.io/badge/platform-Android%20%7C%20Windows%20%7C%20Linux-lightgrey?style=for-the-badge&logo=android" alt="Platform">
</p>

<!-- SOCIAL BUTTONS -->
<p>
  <a href="https://github.com/Yudzxml/X7BOTZ/stargazers">
    <img src="https://img.shields.io/github/stars/Yudzxml/X7BOTZ?style=social" alt="Stars">
  </a>
  <a href="https://github.com/Yudzxml/X7BOTZ/network/members">
    <img src="https://img.shields.io/github/forks/Yudzxml/X7BOTZ?style=social" alt="Forks">
  </a>
  <a href="https://github.com/Yudzxml/X7BOTZ/issues">
    <img src="https://img.shields.io/github/issues/Yudzxml/X7BOTZ" alt="Issues">
  </a>
</p>

</div>

---

## 📋 Daftar Isi

- [📖 Overview](#-overview)
- [✨ Fitur Utama](#-fitur-utama)
- [🏗️ Arsitektur Proyek](#-arsitektur-proyek)
- [🛠️ Tech Stack](#-tech-stack)
- [⚙️ Persyaratan Sistem](#-persyaratan-sistem)
- [🚀 Instalasi](#-instalasi)
- [🔧 Konfigurasi](#-konfigurasi)
- [📁 Struktur Folder](#-struktur-folder)
- [🧩 Cara Menambah Plugin](#-cara-menambah-plugin)
- [📦 Cara Menambah Handler](#-cara-menambah-handler)
- [📝 Changelog](#-changelog)
- [🤝 Kontribusi](#-kontribusi)
- [⚠️ Disclaimer](#-disclaimer)
- [📄 Lisensi](#-lisensi)
- [👑 Author](#-author)

---

## 📖 Overview

<div align="center">

**X7BOTZ - MD** adalah WhatsApp bot multi-device yang dibangun dengan **arsitektur modular yang bersih**. Dirancang agar mudah di-maintain, mudah ditambah fitur baru, dan stabil untuk penggunaan jangka panjang.

> **v1.6.0** — Handler utilities sudah dipecah menjadi modul-modul terpisah agar mudah dianalisis dan dikembangkan.

</div>

---

## ✨ Fitur Utama

| Fitur | Deskripsi | Status |
| :---: | :--- | :---: |
| 🤖 **Multi-Device** | Koneksi multi-sesi tanpa konflik. | ✅ |
| 🧩 **Modular Plugin** | Tambah/hapus fitur tanpa mengganggu core. | ✅ |
| ⚡ **Native Flow** | Dukungan button & list interaktif WhatsApp terbaru. | ✅ |
| 🛡️ **Group Guard** | Anti-link, anti-toxic, anti-spam, auto-moderation. | ✅ |
| 🎮 **Game System** | 20+ game interaktif dengan hadiah economy. | ✅ |
| 🛒 **Store/List** | Sistem toko online dengan pembayaran QRIS. | ✅ |
| 👑 **Premium System** | Akses premium dengan limit & expiry. | ✅ |
| 🖥️ **CPanel** | Integrasi manajemen Pterodactyl panel. | ✅ |
| 🤖 **AI Integration** | Gemini, GPT, image generation, dll. | ✅ |
| 🧹 **Auto Cleaner** | Otomatis membersihkan file tmp. | ✅ |
| 🎨 **Smart Logger** | Console log berwarna untuk debugging. | ✅ |

---

## 🏗️ Arsitektur Proyek

```
X7BOTZ/
├── index.js                    # Entry point
├── config.js                   # Konfigurasi utama bot
├── Yudzxml.js                  # Command handler & routing
├── package.json
├── README.md
│
├── src/                        # Core system
│   ├── core/                   # Bot init, database
│   │   ├── bot.js              # Baileys socket initialization
│   │   └── database.js         # Database setup
│   ├── events/                 # Event listeners
│   │   ├── messages.js         # Pesan masuk
│   │   ├── groups.js           # Event group
│   │   ├── calls.js            # Event panggilan
│   │   ├── contacts.js         # Event kontak
│   │   └── connection.js       # Koneksi & disconnect
│   ├── handler/                # Routing & context
│   │   ├── router.js           # Command router + middleware
│   │   └── context.js          # Plugin context builder
│   ├── middleware/              # Middleware chain
│   │   ├── banCheck.js         # Cek banned user
│   │   ├── registerCheck.js    # Cek registrasi
│   │   ├── permissions.js      # Cek owner/admin/group
│   │   ├── rateLimit.js        # Rate limiter & limit
│   │   ├── levelCache.js       # Level & role system
│   │   └── chain.js            # Middleware executor
│   └── extensions/             # Socket extensions
│       ├── decode.js           # JID decoder
│       ├── sender.js           # Send helpers
│       ├── sticker.js          # Sticker helpers
│       └── media.js            # Media helpers
│
├── App/
│   ├── function/                # Utility functions
│   │   ├── handlers/            # ⭐ HANDLER UTILITIES (v1.6.0)
│   │   │   ├── index.js         # Barrel export (re-export semua)
│   │   │   ├── message.js       # extractMessageBody, sendRegisterPrompt, greeting
│   │   │   ├── profile.js       # getProfileUrl, fkontak, getGroupAdmins
│   │   │   ├── network.js       # getBuffer, fetchJson, checkBandwidth
│   │   │   ├── formatter.js     # bytesToSize, formatSize, isUrl, pickRandom
│   │   │   ├── time.js          # getTime, runtime, clockString, sleep
│   │   │   ├── image.js         # generateProfilePicture, reSize, getSizeMedia
│   │   │   ├── react.js         # loading, success (reaction emoji)
│   │   │   ├── serialize.js     # smsg (message serializer)
│   │   │   └── assets.js        # randomAssets
│   │   ├── handler.js           # Re-export barrel (backward compatible)
│   │   ├── loadPlugins.js       # Plugin loader system
│   │   ├── logger.js            # Logger berwarna
│   │   ├── database.js          # Database helper (loadDB/saveDB)
│   │   ├── converter.js         # FFmpeg converter (toAudio, toVideo, dll)
│   │   ├── exif.js              # Sticker EXIF writer
│   │   ├── uploader.js          # CDN uploader
│   │   ├── user.js              # User DB (level, money, limit)
│   │   ├── premium.js           # Premium system
│   │   ├── groupHandler.js      # Group protection handler
│   │   ├── gameHandler.js       # Game state management
│   │   └── ...                  # Lainnya
│   │
│   └── plugins/                 # ⭐ COMMAND PLUGINS
│       ├── main/                # Command utama (menu, ping, register, dll)
│       ├── owner/               # Command owner (ban, restart, jpm, dll)
│       ├── admin/                # Command admin group (kick, promote, dll)
│       ├── group/                # Command group (sewabot, afk, economy, dll)
│       ├── download/             # Command download (yt, tiktok, ig, dll)
│       ├── search/               # Command search (google, pinterest, dll)
│       ├── ai/                   # Command AI (gemini, gpt, upscale, dll)
│       ├── maker/                # Command maker (sticker, meme, quote, dll)
│       ├── game/                 # Command game (tebak gambar, suit, dll)
│       ├── fun/                  # Command fun (cek ganteng, dll)
│       ├── tools/                # Command tools (translate, ssweb, dll)
│       ├── store/                # Command store management
│       ├── berita/               # Command berita (CNN, detik, dll)
│       ├── stalk/                # Command stalk (ig, tiktok, github, dll)
│       ├── islami/               # Command islami (surah, doa, jadwal shalat)
│       ├── primbon/              # Command primbon (arti nama, ramalan, dll)
│       ├── nsfw/                 # Command nsfw
│       └── cpanel/               # Command cpanel management
│
├── Storage/                    # Database JSON files
│   └── session/                 # WhatsApp auth session
│
└── tmp/                        # File sementara (auto-cleaned)
```

---

## 🛠️ Tech Stack

<div align="center">

![Node.js](https://img.shields.io/badge/Node.js-43853D?style=for-the-badge&logo=node.js&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)
![Baileys](https://img.shields.io/badge/Baileys-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)

</div>

---

## ⚙️ Persyaratan Sistem

| Kebutuhan | Minimum | Rekomendasi |
| :--- | :---: | :---: |
| **OS** | Linux / Windows / Android (Termux) | Ubuntu 22.04+ |
| **Node.js** | v20+ | v20 LTS |
| **RAM** | 1 GB | 2 GB+ |
| **Storage** | 800 MB | 2 GB+ |

---

## 🚀 Instalasi

### 1. Clone Repository
```bash
git clone https://github.com/Yudzxml/X7BOTZ.git
cd X7BOTZ
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Konfigurasi

Edit file `config.js` dan sesuaikan bagian wajib berikut:

```javascript
// Wajib diubah:
superowner: '628xxxxxxxxxx',     // Nomor WhatsApp owner
apikey.key: 'YOUR_API_KEY',      // API key dari https://yydz.biz.id
botname: 'NAMA_BOT_KAMU',        // Nama bot
```

### 4. Jalankan Bot
```bash
npm start
```

> **Pairing Code:** Masukkan nomor WhatsApp aktif (format: 628xx) saat diminta.

---

## 🔧 Konfigurasi

File `config.js` dibagi menjadi section yang jelas:

| Section | Deskripsi |
| :--- | :--- |
| `CORE BOT SETTINGS` | Pairing code, public mode, prefix |
| `AUTOMATION SETTINGS` | Auto-read, anti-call, auto-backup |
| `OWNER & BOT IDENTITY` | Nomor owner, nama bot, email |
| `PREFIX SETTINGS` | Daftar prefix command |
| `GAME & RATE LIMITS` | Timeout game, hadiah, anti-spam |
| `STORE IDENTITY` | Info toko, link group, website |
| `PAYMENT INFO` | QRIS, DANA, dll |
| `API KEY` | Endpoint dan key REST API |
| `CPANEL` | Konfigurasi Pterodactyl panel |
| `THUMBNAIL & ASSETS` | Gambar dan audio untuk menu |
| `SYSTEM MESSAGES` | Pesan notifikasi bot |

---

## 📁 Struktur Folder

- **`src/`** — Core system (bot init, events, middleware, routing). Jangan diubah kecuali Anda paham arsitekturnya.
- **`App/function/`** — Utility functions. Handler utilities sekarang berada di sub-folder **`handlers/`**.
- **`App/plugins/`** — Semua command plugin. Setiap sub-folder mewakili 1 kategori fitur.
- **`Storage/`** — Database JSON (auto-generated).
- **`tmp/`** — File sementara (auto-cleaned).

---

## 🧩 Cara Menambah Plugin

### Langkah 1: Buat File Plugin

Buat file baru di `App/plugins/<kategori>/`:

```javascript
// App/plugins/tools/helloworld.js
module.exports = {
    name: 'hello world',
    category: 'tools',
    command: ['hello', 'hi'],
    description: 'Contoh plugin baru',
    usage: '.hello',
    run: async ({ m, reply }) => {
        await reply('Hello World! 🌍');
    }
};
```

### Langkah 2: Selesai!

Plugin otomatis ter-load saat bot restart. Tidak perlu edit file lain.

---

## 📦 Cara Menambah Handler

### Langkah 1: Buat File Handler

Buat file baru di `App/function/handlers/`:

```javascript
// App/function/handlers/myHandler.js

/**
 * My Custom Handler
 * @module handlers/myHandler
 */

exports.myCustomFunction = (param) => {
    return `Processed: ${param}`;
};
```

### Langkah 2: Export di Index

Tambahkan di `App/function/handlers/index.js`:

```javascript
const { myCustomFunction } = require('./myHandler');

module.exports = {
    // ... existing exports
    myCustomFunction,
};
```

### Langkah 3: Gunakan

```javascript
const { myCustomFunction } = require('./handlers');
// atau
const { myCustomFunction } = require('./handlers/myHandler');
```

---

## 📝 Changelog

### v1.6.0 (Juli 2025)
- 🔥 **Refactoring besar**: `handler.js` (802 baris) dipecah menjadi 9 modul terpisah
- 📁 Handler utilities dipindah ke `App/function/handlers/`
- 📝 `config.js` ditulis ulang dengan dokumentasi section yang jelas
- 📦 `package.json` diperbarui dengan metadata lengkap
- 📖 `README.md` diperbarui dengan dokumentasi arsitektur
- ♻️ `handler.js` menjadi barrel re-export (100% backward compatible)

### v1.5.1
- Optimasi memory dan stabilisasi

### v1.1.0 BETA
- Initial public release

---

## 🤝 Kontribusi

Kontribusi, issues, dan request fitur sangat welcome!

1. Fork repository ini
2. Buat branch baru (`git checkout -b fitur-baru`)
3. Commit perubahan Anda (`git commit -m 'Menambahkan fitur baru'`)
4. Push ke branch (`git push origin fitur-baru`)
5. Buka [Pull Request](https://github.com/Yudzxml/X7BOTZ/pulls)

Untuk laporan bug atau saran fitur, silakan buka [Issues](https://github.com/Yudzxml/X7BOTZ/issues).

---

## ⚠️ Disclaimer

Project ini menggunakan **Baileys**, library tidak resmi untuk WhatsApp Web, dan tidak berafiliasi dengan WhatsApp Inc./Meta. Gunakan dengan bijak dan sesuai [Terms of Service WhatsApp](https://www.whatsapp.com/legal/terms-of-service). Developer tidak bertanggung jawab atas penyalahgunaan bot ini.

---

## 📄 Lisensi

Project ini dilisensikan di bawah **MIT License** — bebas digunakan, dimodifikasi, dan didistribusikan dengan tetap mencantumkan atribusi.

---

## 👑 Author

<div align="center">

### 🧑‍💻 Developer
<a href="https://github.com/Yudzxml">
  <img src="https://github.com/Yudzxml.png" alt="Yudzxml" width="100" style="border-radius: 50%; border: 3px solid #00FFFF;">
</a>

**[Yudzxml](https://github.com/Yudzxml)**
*Owner & Lead Developer*

- 📧 Email: yydzstore@gmail.com
- 🌐 Website: https://yydz.my.id
- 💬 WhatsApp: 6283872031397

### 💖 Dukung Project Ini

Jika project ini membantu, jangan lupa kasih ⭐ Star!

---

**Copyright © 2025 X7BOTZ - MD. | MIT License**

</div>


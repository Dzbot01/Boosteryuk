#!/usr/bin/env node

const path = require('path');
const { DbLogger } = require('./database/utils/logger');
const { MigrationEngine, MigrationError } = require('./database/utils/migration');

const logger = new DbLogger({ tag: 'MIGRATE' });

function parseArgs(argv) {
  const args = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === '--no-backup') args.noBackup = true;
    else if (arg === '--no-validate') args.noValidate = true;
    else if (arg === '--validate-only') args.validateOnly = true;
    else if (arg === '--sqlite-path') args.sqlitePath = argv[++i];
    else args._.push(arg);
  }
  return args;
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const overrides = {};
  if (args.sqlitePath) overrides.sqlitePath = args.sqlitePath;

  const engine = new MigrationEngine({ logger });

  if (args.validateOnly) {
    logger.info('Mode validasi saja: membandingkan Storage/*.json dengan SQLite...');
    const report = await engine.validate('json', 'sqlite', {}, { path: args.sqlitePath });
    printReport(report);
    process.exit(report.failed.length ? 2 : 0);
  }

  const result = await engine.migrate('json', 'sqlite', {
    targetOverrides: { path: args.sqlitePath || './bot.db' },
    strict: !args.noValidate
  });

  logger.success(`Selesai dalam ${result.durationMs}ms. ${result.migrated} namespace dimigrasikan ke SQLite.`);
  logger.info('Langkah selanjutnya: ubah config.js -> database.type: "sqlite" lalu restart bot.');
  if (result.backup) {
    logger.info(`Backup JSON tersimpan di: ${result.backup.path}`);
  }
  if (result.report) printReport(result.report);
}

function printReport(report) {
  console.log('\nRingkasan validasi:');
  for (const detail of report.details) {
    const icon = detail.ok ? 'OK' : 'BEDA';
    console.log(`  [${icon}] ${detail.namespace}: ${detail.sourceRecords} -> ${detail.targetRecords} record`);
  }
  console.log(`Total: ${report.passed}/${report.total} identik\n`);
}

main().catch(err => {
  if (err instanceof MigrationError) {
    logger.error(`Migrasi gagal (${err.step}): ${err.message}`);
    if (err.rollbackAvailable) logger.info('Backup tersedia untuk restore: node database/utils/backup.js restore <file> sqlite');
  } else {
    logger.error(err.message);
  }
  process.exit(1);
});

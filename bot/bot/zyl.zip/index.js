require('module-alias/register');
require('@App/function/cleaner');

const fs = require('fs');
const config = require('@Config');
const logger = require('@App/function/logger');
const DatabaseManager = require('@Database').DatabaseManager;

require('./src/core/database');

let shuttingDown = false;

async function gracefulShutdown(signal, exitCode = 0) {
    if (shuttingDown) return;
    shuttingDown = true;
    logger.warning(`Menerima ${signal}. Mematikan bot dengan aman...`);

    if (global.db?.data && typeof global.db.write === 'function') {
        try {
            await global.db.write();
            logger.success('global.db di-flush.');
        } catch (err) {
            logger.error('Gagal flush global.db: ' + err.message);
        }
    }

    try {
        require('@App/function/orderManager').stopAllPolling();
        logger.success('Semua poller order dihentikan.');
    } catch (err) {
        logger.error('Gagal menghentikan poller order: ' + err.message);
    }

    try {
        const jadibotManager = require('./src/core/jadibot');
        await jadibotManager.stopAll('shutdown');
        logger.success('Semua instance jadibot dihentikan.');
    } catch (err) {
        logger.error('Gagal menghentikan jadibot: ' + err.message);
    }

    try {
        const dbm = DatabaseManager.getInstance();
        await dbm.flushAll();
        await dbm.disconnect();
        logger.success('Database layer ditutup.');
    } catch (err) {
        logger.error('Gagal menutup database layer: ' + err.message);
    }

    logger.info('Shutdown selesai. Sampai jumpa!');
    process.exit(exitCode);
}

process.on('SIGINT', () => gracefulShutdown('SIGINT', 0));
process.on('SIGTERM', () => gracefulShutdown('SIGTERM', 0));
process.on('SIGHUP', () => gracefulShutdown('SIGHUP', 0));

function startAutoDataBackup() {
    const ab = config.autoBackup || {};
    if (ab.enabled === false) return;

    const { startScheduleBackup, pruneBackups, listBackups } = require('@Database/utils/backup');
    const dbm = DatabaseManager.getInstance();
    const keep = Number(ab.keep) || 10;

    setInterval(
        () => {
            try {
                const removed = pruneBackups(keep);
                if (removed.length) logger.info(`[AUTO-BACKUP] ${removed.length} backup lama dihapus (rotasi).`);
            } catch (err) {
                logger.error('[AUTO-BACKUP] Rotasi gagal: ' + err.message);
            }
        },
        60 * 60 * 1000
    ).unref?.();

    setTimeout(async () => {
        try {
            if (listBackups().length === 0) {
                const result = await dbm.exportBackup();
                logger.success(`[AUTO-BACKUP] Backup data awal: ${result.path} (${result.namespaces} namespace)`);
            }
        } catch (err) {
            logger.error('[AUTO-BACKUP] Backup awal gagal: ' + err.message);
        }
    }, 15000).unref?.();

    const hours = Math.max(1, Number(ab.dbIntervalHours) || 12);
    setInterval(
        async () => {
            try {
                const result = await dbm.exportBackup();
                logger.success(`[AUTO-BACKUP] Backup data terjadwal: ${result.path} (${result.namespaces} namespace)`);
            } catch (err) {
                logger.error('[AUTO-BACKUP] Backup terjadwal gagal: ' + err.message);
            }
        },
        hours * 60 * 60 * 1000
    ).unref?.();

    logger.info(`[AUTO-BACKUP] AKTIF SETIAP ${hours} JAM`);
}

function startAutoRestart() {
    const ar = config.autoRestart || {};
    if (ar.enabled === true) {
        const hour = Math.min(23, Math.max(0, Number(ar.dailyAtHour) || 4));
        const check = () => {
            const now = new Date();
            const jakarta = new Date(now.getTime() + (7 * 60 + now.getTimezoneOffset()) * 60000);
            if (jakarta.getHours() === hour && jakarta.getMinutes() === 0) {
                logger.info(`[AUTO-RESTART] Restart terjadwal jam ${hour}:00 WIB.`);
                global.restartBot(null, 'auto-restart-harian');
            }
        };
        setInterval(check, 60 * 1000).unref?.();
        logger.info(`[AUTO-RESTART] HARIAN JAM ${hour}:00 WIB`);
    }

    const limitMB = Number(ar.memoryLimitMB) || 0;
    if (limitMB > 0) {
        let ramWarned = false;
        setInterval(
            () => {
                const rssMB = Math.round(process.memoryUsage().rss / 1024 / 1024);
                if (rssMB > limitMB) {
                    if (!ramWarned) {
                        ramWarned = true;
                        logger.warning(`[AUTO-RESTART] RAM ${rssMB}MB melebihi batas ${limitMB}MB. Me-restart bot...`);
                        global.restartBot(null, 'ram-limit');
                    }
                } else {
                    ramWarned = false;
                }
            },
            5 * 60 * 1000
        ).unref?.();
    }
}

const startAll = async () => {
    const dbm = DatabaseManager.getInstance();
    try {
        await dbm.connect();
    } catch (err) {
        logger.error(`DATABASE CONNECT GAGAL: ${err.message}`);
        if (!config.database?.fallbackToJson) {
            throw err;
        }
    }

    startAutoDataBackup();
    startAutoRestart();

    // Tentukan mode startup DULU. Menu hanya muncul sekali (boot pertama,
    // belum ada session & belum ada mode tersimpan). Setelah bot pernah
    // pairing / mode dipilih, restart otomatis LANGSUNG jalan tanpa menu.
    const { resolveBootMode } = require('./src/core/bootMenu');
    const { mode } = await resolveBootMode();

    const { startApiServer } = require('./src/api/server');
    if (config.api?.enabled) startApiServer();

    // MODE API: hanya REST API server — tidak ada socket WhatsApp sama sekali.
    if (mode === 'api') {
        logger.info('MODE API — hanya REST API server (tanpa socket WhatsApp).');
        return;
    }

    const jadibotManager = require('./src/core/jadibot');

    // MODE JADIBOT ONLY: bot utama TIDAK dijalankan. Instance jadibot tetap
    // restore & API tetap jalan (dipakai website untuk order/kelola jadibot).
    if (mode === 'jadibot') {
        logger.info('MODE JADIBOT ONLY — bot utama tidak dijalankan.');
        jadibotManager.restoreAll().catch((err) => {
            logger.error('[JADIBOT] Gagal restore instance saat boot: ' + err.message);
        });
        return;
    }

    // MODE BOT UTAMA: jadibot manager ikut di-restore (juga di-restore ulang
    // saat bot utama connect), lalu bot utama start. Kalau belum ada session,
    // startBot otomatis lanjut ke prompt nomor + kode pairing.
    jadibotManager.restoreAll().catch((err) => {
        logger.error('[JADIBOT] Gagal restore instance saat boot: ' + err.message);
    });

    const { startBot } = require('./src/core/bot');
    await startBot();
};

startAll().catch((err) => {
    console.error('FATAL: Bot gagal start:', err);
    process.exit(1);
});

let watchTimer = null;
let lastWatchMtime = 0;
fs.watchFile(__filename, { interval: 2000 }, (curr) => {
    if (curr.mtimeMs === lastWatchMtime) return;
    lastWatchMtime = curr.mtimeMs;
    if (watchTimer) clearTimeout(watchTimer);
    watchTimer = setTimeout(() => {
        logger.info('INDEX.JS BERUBAH — RESTART OTOMATIS...');
        global.restartBot(null, 'index-diedit');
    }, 2000);
});

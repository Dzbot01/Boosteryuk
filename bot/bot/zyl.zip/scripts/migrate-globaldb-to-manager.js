#!/usr/bin/env node
'use strict';

/**
 * migrate-globaldb-to-manager.js — Migration helper (D1).
 *
 * Mencari semua file .js di App/ dan src/ yang masih memakai pattern
 * `global.db.data.users` / `global.db.data.chats` / dst., dan melaporkan
 * lokasi-lokasi yang perlu di-migrate ke `DatabaseManager.getInstance().getDoc('users')`.
 *
 * Pada v3.0.0, `global.db` akan dihapus total.
 *
 * Usage:
 *   node scripts/migrate-globaldb-to-manager.js            # dry-run (laporan saja)
 *   node scripts/migrate-globaldb-to-manager.js --apply    # apply replacements
 */

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const SCAN_DIRS = ['App', 'src', 'database'];
const SKIP_DIRS = ['node_modules', 'App/locales'];

const PATTERNS = [
    {
        // global.db.data.users
        regex: /global\.db\.data\.users\b/g,
        replacement: "(await DatabaseManager.getInstance().getDoc('users'))",
        note: 'Gunakan DatabaseManager.getInstance().getDoc(\'users\') — async.'
    },
    {
        // global.db.data.chats
        regex: /global\.db\.data\.chats\b/g,
        replacement: "(await DatabaseManager.getInstance().getDoc('chats'))",
        note: 'Gunakan DatabaseManager.getInstance().getDoc(\'chats\') — async.'
    },
    {
        // global.db.data.database
        regex: /global\.db\.data\.database\b/g,
        replacement: "(await DatabaseManager.getInstance().getDoc('database'))",
        note: 'Gunakan DatabaseManager.getInstance().getDoc(\'database\') — async.'
    },
    {
        // global.db.data.groups
        regex: /global\.db\.data\.groups\b/g,
        replacement: "(await DatabaseManager.getInstance().getDoc('groups'))",
        note: 'Gunakan DatabaseManager.getInstance().getDoc(\'groups\') — async.'
    },
    {
        // global.db.data.game
        regex: /global\.db\.data\.game\b/g,
        replacement: "(await DatabaseManager.getInstance().getDoc('game'))",
        note: 'Gunakan DatabaseManager.getInstance().getDoc(\'game\') — async.'
    },
    {
        // global.db.data.settings
        regex: /global\.db\.data\.settings\b/g,
        replacement: "(await DatabaseManager.getInstance().getDoc('settings'))",
        note: 'Gunakan DatabaseManager.getInstance().getDoc(\'settings\') — async.'
    },
    {
        // global.db.data.sticker
        regex: /global\.db\.data\.sticker\b/g,
        replacement: "(await DatabaseManager.getInstance().getDoc('sticker'))",
        note: 'Gunakan DatabaseManager.getInstance().getDoc(\'sticker\') — async.'
    },
    {
        // global.db.data.others
        regex: /global\.db\.data\.others\b/g,
        replacement: "(await DatabaseManager.getInstance().getDoc('others'))",
        note: 'Gunakan DatabaseManager.getInstance().getDoc(\'others\') — async.'
    }
];

function walk(dir, files = []) {
    let entries = [];
    try {
        entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
        return files;
    }
    for (const entry of entries) {
        const full = path.join(dir, entry.name);
        const rel = path.relative(ROOT, full);
        if (SKIP_DIRS.some((s) => rel.startsWith(s))) continue;
        if (entry.isDirectory()) {
            walk(full, files);
        } else if (entry.isFile() && entry.name.endsWith('.js')) {
            files.push(full);
        }
    }
    return files;
}

function scan(apply = false) {
    let totalMatches = 0;
    let totalFiles = 0;
    const report = [];

    for (const scanDir of SCAN_DIRS) {
        const abs = path.join(ROOT, scanDir);
        if (!fs.existsSync(abs)) continue;
        const files = walk(abs);
        for (const file of files) {
            const src = fs.readFileSync(file, 'utf-8');
            let newSrc = src;
            const matches = [];

            for (const p of PATTERNS) {
                const m = src.match(p.regex);
                if (m) {
                    matches.push({ pattern: p.regex.toString(), count: m.length, note: p.note });
                    if (apply) newSrc = newSrc.replace(p.regex, p.replacement);
                }
            }

            if (matches.length) {
                totalMatches += matches.reduce((s, m) => s + m.count, 0);
                totalFiles += 1;
                report.push({ file: path.relative(ROOT, file), matches });
                if (apply && newSrc !== src) {
                    fs.writeFileSync(file, newSrc, 'utf-8');
                    console.log(`✅ Applied: ${path.relative(ROOT, file)}`);
                }
            }
        }
    }

    console.log('\n' + '='.repeat(60));
    console.log(apply ? 'MIGRATION APPLIED' : 'MIGRATION DRY-RUN (laporan)');
    console.log('='.repeat(60));
    console.log(`Files affected : ${totalFiles}`);
    console.log(`Total matches : ${totalMatches}\n`);

    if (!apply) {
        for (const r of report) {
            console.log(`📄 ${r.file}`);
            for (const m of r.matches) {
                console.log(`   • ${m.count}x ${m.pattern}`);
                console.log(`     ↳ ${m.note}`);
            }
        }
        console.log('\nRun with --apply untuk eksekusi replacements.');
        console.log('⚠️  Periksa hasil secara manual — beberapa call site mungkin perlu di-await.');
    } else {
        console.log('✅ Migration selesai. Jalankan `npm test` untuk verifikasi.');
    }

    return { totalFiles, totalMatches, report };
}

if (require.main === module) {
    const apply = process.argv.includes('--apply');
    scan(apply);
}

module.exports = { scan };

#!/usr/bin/env node

const { DbLogger } = require('./database/utils/logger');
const { MigrationEngine, MigrationError } = require('./database/utils/migration');

const logger = new DbLogger({ tag: 'MIGRATE' });

const VALID_TYPES = ['json', 'sqlite', 'postgresql', 'mysql'];

function parseArgs(argv) {
  const args = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === '--no-backup') args.noBackup = true;
    else if (arg === '--no-validate') args.noValidate = true;
    else if (arg === '--validate-only') args.validateOnly = true;
    else if (arg === '--force') args.force = true;
    else if (arg.startsWith('--')) {
      const body = arg.replace(/^--/, '');
      const eq = body.indexOf('=');
      if (eq !== -1) {
        const key = body.slice(0, eq).replace(/-([a-z])/g, (_, c) => c.toUpperCase());
        args[key] = body.slice(eq + 1);
      } else {
        const next = argv[i + 1];
        if (next !== undefined && !next.startsWith('--') && !/^(json|sqlite|postgresql|mysql)$/.test(next)) {
          args[body] = next;
          i += 1;
        } else {
          args[body] = true;
        }
      }
    } else args._.push(arg);
  }
  return args;
}

function overridesFor(type, args) {
  const overrides = {};
  const prefix = type === 'postgresql' ? 'pg' : type;
  const map = {
    host: `${prefix}Host`,
    port: `${prefix}Port`,
    database: `${prefix}Database`,
    user: `${prefix}User`,
    password: `${prefix}Password`,
    path: `${prefix}Path`
  };
  for (const [key, argKey] of Object.entries(map)) {
    if (args[argKey] !== undefined) {
      overrides[key] = key === 'port' ? Number(args[argKey]) : args[argKey];
    }
  }
  if (type === 'sqlite' && args.sqlitePath) overrides.path = args.sqlitePath;
  if (type === 'json' && args.jsonPath) overrides.path = args.jsonPath;
  return overrides;
}

function usage() {
  console.log(`
Penggunaan: node migrate-database.js <source> <target> [opsi]

Tipe database: ${VALID_TYPES.join(', ')}

Contoh:
  node migrate-database.js json sqlite
  node migrate-database.js sqlite postgresql --pgDatabase=x7botz_db --pgUser=postgres --pgPassword=secret
  node migrate-database.js postgresql mysql --myHost=db.example.com
  node migrate-database.js json sqlite --validate-only
  node migrate-database.js sqlite json --jsonPath=./Storage

Opsi:
  --validate-only        Hanya membandingkan data, tanpa migrasi
  --no-backup            Lewati pembuatan backup sebelum migrasi
  --no-validate          Lewati validasi setelah migrasi
  --force                Lanjut meski validasi menemukan perbedaan
  --sqlitePath=<path>    Path file SQLite
  --jsonPath=<path>      Path folder Storage JSON
  --pgHost/--pgPort/--pgDatabase/--pgUser/--pgPassword   Konfigurasi PostgreSQL
  --myHost/--myPort/--myDatabase/--myUser/--myPassword   Konfigurasi MySQL
`);
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const [source, target] = args._;

  if (!source || !target) {
    usage();
    process.exit(1);
  }
  if (!VALID_TYPES.includes(source) || !VALID_TYPES.includes(target)) {
    logger.error(`Tipe tidak valid. Pilihan: ${VALID_TYPES.join(', ')}`);
    process.exit(1);
  }
  if (source === target) {
    logger.error('Source dan target tidak boleh sama');
    process.exit(1);
  }

  const engine = new MigrationEngine({ logger });
  const sourceOverrides = overridesFor(source, args);
  const targetOverrides = overridesFor(target, args);

  if (args.validateOnly) {
    logger.info(`Mode validasi: ${source} vs ${target}...`);
    const report = await engine.validate(source, target, sourceOverrides, targetOverrides);
    for (const detail of report.details) {
      console.log(`  [${detail.ok ? 'OK' : 'BEDA'}] ${detail.namespace}: ${detail.sourceRecords} -> ${detail.targetRecords} record`);
    }
    console.log(`Total: ${report.passed}/${report.total} identik`);
    process.exit(report.failed.length ? 2 : 0);
  }

  const result = await engine.migrate(source, target, {
    sourceOverrides,
    targetOverrides,
    strict: !args.noValidate && !args.force
  });

  logger.success(`Migrasi ${source} -> ${target} selesai dalam ${result.durationMs}ms (${result.migrated} namespace).`);
  logger.info(`Langkah selanjutnya: ubah config.js -> database.type: "${target}" lalu restart bot.`);
  if (result.backup) logger.info(`Backup tersimpan di: ${result.backup.path}`);
}

main().catch(err => {
  if (err instanceof MigrationError) {
    logger.error(`Migrasi gagal (${err.step}): ${err.message}`);
    if (err.rollbackAvailable) logger.info('Restore backup: node database/utils/backup.js restore <file> <type>');
  } else {
    logger.error(err.message);
  }
  process.exit(1);
});

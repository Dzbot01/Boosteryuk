# Plugin JSDoc Template (Q4)

Plugin baru WAJIB menyertakan JSDoc untuk parameter `execute(ctx)`. Template
berikut bisa di-copy-paste lalu di-edit.

## Template

```javascript
/**
 * Plugin: <name>
 *
 * Description: <one-line description>
 *
 * @module plugins/<category>/<name>
 */

/**
 * @typedef {Object} PluginContext
 * @property {import('baileys').WASocket} Yudzxml  - Bot socket (atau jadibot instance socket)
 * @property {import('baileys').proto.WebMessageInfo & {
 *   sender: string,
 *   chat: string,
 *   reply: (text: string) => Promise<void>,
 *   download: () => Promise<Buffer>,
 *   quoted?: import('baileys').proto.WebMessageInfo
 * }} m                - Serialized message object
 * @property {string} budy        - Raw text body
 * @property {string} command     - Command name (lowercase)
 * @property {string[]} args      - Parsed args
 * @property {string} text        - Full text after command
 * @property {string} prefix     - Active prefix character
 * @property {boolean} isOwner    - Sender is owner
 * @property {boolean} isSuperOwner - Sender is superowner
 * @property {boolean} isPremium  - Sender is premium
 * @property {boolean} isAdmins   - Sender is group admin
 * @property {boolean} isBotAdmins - Bot is group admin
 * @property {boolean} isGroupOwner - Sender is group owner
 * @property {boolean} isJadibot  - Currently executing in jadibot instance
 * @property {string|null} jadibotJid - JID of jadibot instance (null if main bot)
 * @property {Object} config       - instanceConfig (config jadibot or main config)
 * @property {Object} quoted       - Quoted message (or m itself)
 * @property {string} mime         - Quoted message mime type
 * @property {boolean} isImage     - Message is image
 * @property {boolean} isVideo     - Message is video
 * @property {boolean} isAudio     - Message is audio
 * @property {boolean} isSticker  - Message is sticker
 * @property {boolean} isMedia     - Any media type
 */

module.exports = {
    name: '<name>',
    category: '<category>',
    commands: ['<command>'],
    description: '<one-line description>',
    isPrivate: false,
    isGroup: false,
    isOwner: false,
    isSuperOwner: false,
    isPremium: false,

    /**
     * Execute the plugin command.
     *
     * @param {PluginContext} ctx - Plugin context (see typedef above)
     * @returns {Promise<void>}
     */
    async execute(ctx) {
        const { m, args, prefix, command } = ctx;
        // ... implementation
        await m.reply('Hello!');
    }
};
```

## Rules

1. **Always document `execute(ctx)`** — even if minimal.
2. **List `commands`** explicitly — helps auto-generate menu.
3. **Set `isPrivate` / `isGroup`** correctly so middleware blocks appropriately.
4. **Use `ctx.logger`** instead of `console.log` (P7).
5. **Return early** on validation errors via `return m.reply(...)`.
6. **Catch errors** in try/catch and reply user-friendly message.
7. **For per-instance broadcast plugins**, set `allowJadibotOwner: true`.

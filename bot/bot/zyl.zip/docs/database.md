# X7BOTZ-MD Database Abstraction Layer

Lapisan database fleksibel untuk X7BOTZ-MD. Ganti engine database cukup dengan mengubah `config.js`, tanpa menyentuh kode plugin atau logika bot.

## Arsitektur

```
┌─────────────────────────────────────────────────────────┐
│  Plugins / Handler (kode existing, TIDAK berubah)       │
│  user.addUser(), premium.checkPremiumUser(), dst.       │
├─────────────────────────────────────────────────────────┤
│  Wrappers (database/wrappers/)                          │
│  API synchronous 100% kompatibel dengan kode lama       │
├─────────────────────────────────────────────────────────┤
│  DatabaseManager (database/index.js) - SINGLETON        │
│  MemoryStore (hot data) + flush scheduler + hot-reload  │
├─────────────────────────────────────────────────────────┤
│  Drivers                                                │
│  json.js │ sqlite.js │ postgresql.js │ mysql.js         │
└─────────────────────────────────────────────────────────┘
```

Desain inti: **memory-first**. Seluruh dataset dimuat ke memory saat boot. Semua operasi wrapper bersifat synchronous (O(1), tanpa I/O) sehingga ribuan plugin existing tetap berjalan tanpa diubah. Penulisan ke engine database dilakukan oleh flush scheduler (debounced, atomic), dan `flushAll()` dipanggil saat shutdown.

## Driver yang tersedia

| Tipe         | Library        | Kegunaan                                    |
|--------------|----------------|---------------------------------------------|
| `json`       | fs (bawaan)    | Default, 100% backward compatible Storage/  |
| `sqlite`     | better-sqlite3 | Single file, sync, WAL mode                 |
| `postgresql` | pg             | Production, connection pool                 |
| `mysql`      | mysql2         | MariaDB/MySQL, connection pool              |

## Konfigurasi

Semua konfigurasi berada di `config.js` bagian `database`:

```javascript
database: {
  type: 'json',                  // 'json' | 'sqlite' | 'postgresql' | 'mysql'
  json: { path: './Storage' },
  sqlite: { path: './bot.db' },
  postgresql: {
    host: 'localhost',
    port: 5432,
    database: 'x7botz_db',
    user: 'postgres',
    password: 'password123'
  },
  mysql: {
    host: 'localhost',
    port: 3306,
    database: 'x7botz_db',
    user: 'root',
    password: 'password123'
  },
  pool: { min: 2, max: 10, acquireTimeoutMillis: 10000, idleTimeoutMillis: 30000 },
  debug: false,                  // log semua operasi database
  autoMigrate: true,             // seed otomatis dari Storage/*.json saat DB baru
  fallbackToJson: true,          // fallback ke JSON jika driver utama gagal
  cacheEnabled: true,
  cacheTtl: 30000,
  flushIntervalMs: 300,
  maxRetries: 3
}
```

### Mengganti database

1. Jalankan script migrasi (lihat MIGRATION_GUIDE.md).
2. Ubah `database.type` di config.js.
3. Restart bot. Hot-reload config.js juga didukung: saat file config.js berubah, DatabaseManager otomatis memuat ulang dan melakukan switch jika `type` berubah.

## Penggunaan

### Dari plugin (cara lama, tetap jalan)

```javascript
const { addUser, getUser, addMoney } = require('@App/function/user');
const { checkPremiumUser } = require('@App/function/premium');
const { getSewa, addSewa } = require('@App/function/sewa');
```

### Langsung ke DatabaseManager (cara baru)

```javascript
const db = require('@Database');

db.getDoc('user');
db.getSub('user', '628xxx@s.whatsapp.net');
db.setSub('user', '628xxx@s.whatsapp.net', { limit: 30 });
db.deleteSub('user', '628xxx@s.whatsapp.net');

await db.connect();
const driver = db.getDriver();
await driver.get('user:628xxx@s.whatsapp.net');
await driver.set('user:628xxx@s.whatsapp.net', { limit: 30, money: 0 });

await db.flushAll();
console.log(await db.healthCheck());
console.log(db.getStats());
```

### Konsep Key / Namespace

- Key berbentuk `namespace` atau `namespace:subkey`, contoh `user`, `user:628xxx@s.whatsapp.net`.
- Namespace `jadibot:<nomor>:<dataset>` menunjuk data milik instance jadibot tertentu, contoh `jadibot:628123:sewa`.
- Dataset utama dipetakan ke tabel SQL ternormalisasi (users, chat_stats, premium_users, bot_sewa, banned_users, maintenance_mode, payment_transactions, afk_status, pterodactyl_users, pterodactyl_servers, bot_settings). Dataset lain tersimpan di `generic_data` sebagai dokumen JSON.

### DatabaseManager API

| Method                     | Keterangan                                              |
|----------------------------|---------------------------------------------------------|
| `getInstance()`            | Ambil instance singleton                                |
| `connect()`                | Hubungkan driver aktif + muat data ke memory            |
| `disconnect()`             | Flush lalu putuskan koneksi                             |
| `reconnect()`              | Sambungkan ulang driver aktif                           |
| `getDriver()`              | Instance driver aktif                                   |
| `switchType(type)`         | Ganti engine saat runtime dengan sinkronisasi data      |
| `reloadConfig()`           | Muat ulang config.js                                    |
| `healthCheck()`            | Status koneksi, latency, statistik memory & cache       |
| `getStats()`               | Statistik lengkap (driver, store, cache, uptime)        |
| `getDoc/setDoc(ns)`        | Akses dokumen namespace secara sync                     |
| `getSub/setSub/deleteSub`  | Akses subkey secara sync                                |
| `flushAll()`               | Paksa simpan semua perubahan ke engine database         |
| `transaction(fn)`          | Transaksi tingkat manager                               |

### Driver API (BaseDriver)

`connect`, `disconnect`, `reconnect`, `get`, `set`, `delete`, `getAll`, `clear`, `exists`, `getKeys(pattern)`, `transaction(fn)`, `getDocument`, `saveDocument`, `deleteDocument`, `listNamespaces`, `healthCheck`, `getStats`, `exportAll`, `importAll`, `countRecords`.

## Struktur direktori

```
database/
├── index.js              DatabaseManager + export utama (@Database)
├── registry.js           Pemetaan namespace -> file/tabel + normalizer
├── store.js              MemoryStore (hot data, dirty tracking, flush)
├── cache.js              TTL cache dengan LRU eviction
├── errors.js             DatabaseError, ConnectionError, QueryError, dst
├── drivers/
│   ├── base.js           BaseDriver (abstract + retry + metrics)
│   ├── json.js           JSONDriver (Storage/*.json)
│   ├── sqlite.js         SQLiteDriver (better-sqlite3, WAL)
│   ├── postgresql.js     PostgreSQLDriver (pg pool)
│   ├── mysql.js          MySQLDriver (mysql2 pool)
│   ├── sqlcommon.js      Logika SQL bersama (DDL, adapter, transaksi)
│   └── __tests__/        Test suite jest
├── wrappers/             API kompatibel 100% dengan modul lama
│   ├── user.js  userDb.js  premium.js  sewa.js  bannedDB.js
│   ├── maintenance.js  afkDb.js  globalDB.js  storage.js
├── adapters/
│   └── jsonAdapter.js    Adapter per-file untuk pola loadDB/saveDB
└── utils/
    ├── migration.js      MigrationEngine (export/import/validate/rollback)
    ├── backup.js         Backup, restore, schedule, CLI
    ├── validator.js      Validasi & helper data
    ├── logger.js         Logger database (menghormati config.database.debug)
    └── requireProject.js Resolver modul project
```

## CLI

```bash
node migrate-json-to-sqlite.js                       # JSON -> SQLite
node migrate-json-to-postgresql.js                   # JSON -> PostgreSQL
node migrate-json-to-mysql.js                        # JSON -> MySQL
node migrate-database.js <source> <target>           # Semua kombinasi
node migrate-database.js json sqlite --validate-only # Validasi tanpa migrasi
node database/utils/backup.js json                   # Backup ke Storage/backups
node database/utils/backup.js list                   # Daftar backup
node database/utils/backup.js restore <file> sqlite  # Restore backup
```

## Testing

```bash
npm test
```

25 test mencakup: BaseDriver, CRUD JSONDriver, CRUD SQLiteDriver + skema ternormalisasi + scoped jadibot, DatabaseManager (switchType, healthCheck, fallback), migration (roundtrip JSON-SQLite-JSON, backup/restore). Test PostgreSQL/MySQL mencoba koneksi dan melewati diri sendiri jika server tidak tersedia.

## Keamanan & keandalan

- Semua query SQL memakai **prepared statements** (anti SQL injection).
- Tulis JSON memakai **atomic write** (tmp + rename) sehingga file tidak rusak saat crash.
- **Auto-reconnect** dengan exponential backoff saat koneksi PG/MySQL terputus; wrapper tetap berjalan dari memory (graceful degradation).
- **fallbackToJson**: jika driver utama gagal saat boot, bot tetap hidup dengan driver JSON.
- Retry otomatis untuk error sementara (deadlock, connection glitch).
- Namespace/subkey divalidasi (anti path traversal).
- File backup disimpan di `Storage/backups/`.

## Performa

- Baca: O(1) dari memory store, tanpa I/O disk.
- Tulis: debounce 300ms per namespace, batched ke SQL dalam satu transaksi.
- SQLite: WAL mode + synchronous NORMAL + prepared statements + index.
- PostgreSQL/MySQL: connection pool + batch insert 120 baris per statement.
- Cache TTL opsional untuk akses driver-level.

## FAQ

**Apakah plugin lama harus diubah?** Tidak. Semua modul database lama (`App/function/user.js`, `premium.js`, `sewa.js`, dst) menjadi shim yang meneruskan ke lapisan baru.

**Apa yang terjadi jika bot mati saat flush tertunda?** `SIGINT`/`SIGTERM` memicu `flushAll()` sebelum keluar, dan tulis JSON bersifat atomic. Untuk keamanan ekstra gunakan backup terjadwal.

**Bisakah jadibot tetap punya data sendiri?** Ya. Data per-instance tersimpan di namespace `jadibot:<nomor>:*` (file terpisah saat JSON, kolom `scope` saat SQL).

**Bagaimana dengan `global.db` (lowdb)?** Sudah digantikan adapter kompatibel (`database/wrappers/globalDB.js`) dengan API identik: `data`, `read()`, `write()`, `chain`.

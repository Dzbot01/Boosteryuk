# Peta Refactoring — X7BOTZ MD v2.6.2

Dokumen ini menjelaskan pemisahan file monolit menjadi modul-modul kecil agar mudah
dicari dan diperbaiki. **Semua file lama tetap ada sebagai shim (forwarder)** sehingga
`require('@App/function/...')` dari plugin/kode lama tetap jalan tanpa perubahan.

## 1. REST API — sebelumnya `src/api/server.js` (1.338 baris)

| File | Isi |
|------|-----|
| `src/api/server.js` | Bootstrap saja: express app, CORS, mount router, 404/error handler, listen |
| `src/api/helpers.js` | Helper bersama: normalisasi nomor, clampDays, resolve gambar, resolve link grup |
| `src/api/middleware.js` | `isValidApiKey`, rate limiter, `requireApiKey`, `wrap` (error handler) |
| `src/api/docs.js` | `buildApiDocs` + route publik `/` dan `/api/docs` |
| `src/api/routes/status.js` | `/api/ping`, `/api/status`, `/api/stats` |
| `src/api/routes/jadibot.js` | 17 endpoint `/api/jadibot/*` (CRUD, pairing, settings, identitas, foto) |
| `src/api/routes/sewabot.js` | `/api/sewabot/*` (create, extend, hapus, cek) |
| `src/api/routes/premium.js` | `/api/premium/*` (create, extend, hapus, cek) |
| `src/api/routes/expired.js` | `/api/expired` (daftar yang segera habis) |

> Catatan: path di dalam tiap router **sudah termasuk `/api`**; server memakai
> `app.use(require('./routes/x'))` (tanpa prefix) supaya tidak jadi `/api/api/...`.

## 2. Handler Game — sebelumnya `App/function/actionGameHandler.js` (1.939 baris)

Sekarang **1 game = 1 file** di `App/function/games/`:

`suitPvp, asahOtak, tebakAnime, cakLontong, family100, math, siapakahAku, susunKata,
tebakBendera, tebakEmoji, tebakEpep, tebakGambar, tebakHeroMl, tebakHewan, tebakKalimat,
tebakKode, tebakLirik, tebakMakanan, tebakTebakan, tebakTempat, tekaTeki, tebakBom,
tictactoe, blackjack` + `index.js` (dispatcher).

Kontrak tiap modul game: `module.exports = async (ctx) => {}` dengan
`ctx = { Yudzxml, m, budy, config, ppuser, prefix, text, gameSession, suitSession, game_over }`.

- `return false` → pesan dikonsumsi game (hentikan handler)
- `return true`  → hentikan handler, lanjut proses normal pesan
- tanpa return   → bukan game ini, lanjut ke modul berikutnya

**Menambah game baru:** buat file di `games/`, daftarkan di array `GAMES` pada
`games/index.js` (urutan pengecekan sama seperti file lama: suit PvP dulu, lalu game per-chat).

## 3. Cpanel — sebelumnya `App/function/cpanelHandler.js` (903 baris)

Folder `App/function/cpanel/`:

| File | Isi |
|------|-----|
| `index.js` | Entry handler `.createserver`, tukar kredensial per-instance |
| `constants.js` | `STATUS` state machine, `DOCKER_IMAGES`, `TTL` |
| `services.js` | Registry client Pterodactyl & Pakasir (jadibot punya kredensial sendiri) |
| `utils.js` | Validasi email/password, format, `sendText`/`sendImage`/`sendNativeFlowList` |
| `session.js` | Sesi order per user, cancel, polling registry |
| `menus.js` | Native flow list (runtime & docker image) |
| `buttons.js` | Respon tombol `cpanel_*` |
| `inputs.js` | Input teks sesi (email, password, cekstatus, batal) |
| `payment.js` | QRIS Pakasir: buat transaksi, polling, cek manual |
| `provision.js` | Create server Pterodactyl setelah bayar |

## 4. Order (pakasir) — sebelumnya `App/function/orderManager.js` (836 baris)

Folder `App/function/order/`: `constants.js` (STATUS, interval), `store.js`
(Storage/orders.json), `payment.js` (client per-instance), `creators.js`
(create order jadibot/sewa/premium), `fulfillment.js` (eksekusi order lunas),
`pairing.js` (siklus pairing), `index.js` (OrderManager: polling, cancel, delegasi).

## 5. Jadibot — sebelumnya `src/core/jadibot.js` (1.452 baris)

`src/core/jadibot.js` tetap menjadi manager (registry, lifecycle, notifikasi) —
logic sekunder dipindah ke `src/core/jadibot_modules/`:

- `base.js` — konstanta murni & helper (whitelist settings, mask kredensial, path Storage)
- `identity.js` — identitas/settings/kredensial/config token bot jadibot
- `pairing.js` — pairing code: daftar, repair, status, auth owner
- `profile.js` — profil lengkap, runtime status, summary, stats

Method class jadi stub delegasi (`return identity.updateSettings(this, jid, patch)`).

## 6. RPG — sebelumnya `App/function/rpg.js` (1.500 baris)

Folder `App/function/rpgEngine/`: `data.js` (balancing/konten), `core.js`
(db user, exp, uang, cooldown, item), `actions.js` (hunt/boss/dungeon/dst),
`shop.js` (toko/inventaris), `index.js` (ekspor SAMA PERSIS dengan file lama).

## 7. Auto-download — sebelumnya `App/function/handleAutodownload.js` (439 baris)

Folder `App/function/autodl/`: `net.js`, `sender.js`, `platforms/`
(`downloadTikTok.js`, `downloadCapcut.js`, `downloadInstagram.js`, `downloadYouTube.js`),
`index.js` (detectPlatform + handleDownload). **Menambah platform = 1 file baru.**

## 8. Scheduler — sebelumnya `App/function/schedule.js` (555 baris)

Folder `App/function/scheduleTasks/`: `constants.js`, `prayer.js`, `logger.js`,
`database.js`, `backup.js`, `notifier.js`, `index.js`.

## Semua file shim (jangan dihapus)

`actionGameHandler.js`, `cpanelHandler.js`, `orderManager.js`, `rpg.js`,
`handleAutodownload.js`, `schedule.js` — masing-masing hanya berisi
`module.exports = require('./<folder>')` agar kode lama tetap jalan.

## Perbaikan lain

- Menghapus file sampah `App/lowdb/adapters/.js` (menyrequire package yang tidak ada).
- Perilaku tidak diubah: semua body kode dipindah utuh (verbatim), hanya struktur file
  yang dipecah. Diverifikasi `node --check` seluruh project + smoke test require
  (38 modul) + uji fungsional API/jadibot/game/order (7 tes).

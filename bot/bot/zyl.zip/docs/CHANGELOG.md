# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased] — v2.8.0-stability

### QRIS-Only Payment + Session Stability + API Expansion (2026-10-03)
- **PAY5** — Kebijakan pembayaran berubah: **QRIS SAJA**. `payment_link` & semua
  metode VA dihapus dari client (`PAYMENT_METHODS = { QRIS: 'qris' }`),
  `createTransaction()` selalu memaksa `qris` (parameter method caller lama
  divalidasi lalu diabaikan), field `payment_link`/`paymentPageUrl` dibuang dari
  order & invoice. Invoice tanpa gambar kini menampilkan string QRIS untuk
  discan manual — bukan link bayar.
- **PAY6** — **Webhook dihapus** sesuai permintaan: route `src/api/routes/
  pakasir.js` dihapus, `verifyWebhookSecret()` & `config.pakasir.webhookSecret`
  dibuang, server.js tidak lagi mendaftarkan route webhook. Status pembayaran
  100% dicek MANUAL: polling internal order tiap 5 detik (cache 4.2s menghormati
  rate limit v2) + command `cekstatus`/`orderstatus`.
- **SESS1** — Auth state baru **atomik & serial** (`src/core/authState.js`,
  dipakai `src/core/bot.js`): `creds.json` & key-file ditulis via `tmp + rename`
  (atomik di POSIX) lewat antrean tulis per-folder. Proses mati/kill di tengah
  save tidak bisa lagi merusak `creds.json` (penyebab umum "logout sendiri"
  setelah restart). Bonus: backup `creds.json.bak` otomatis — bila file utama
  ternyata korup, bot memulihkan sendiri dari backup tanpa pairing ulang.
- **SESS2** — **Antrean kirim anti-spam** (`src/core/sendQueue.js`): semua
  `sendMessage` (bot utama & jadibot) melewati pacing per-socket — jeda
  `minDelayMs (default 900ms) + jitter acak`, batas antrean 150 (lebihnya
  ditolak + warning, tidak menumpuk), timeout per kirim 90s. Mengurangi risiko
  nomor di-flag spam WhatsApp (penyebab lain logout/ban). Jalur darurat tanpa
  antrean: `socket.sendMessageRaw`. Konfigurasi via `config.messageQueue`.
- **SESS3** — Anti double-socket jadibot: guard `starting` di `startInstance`
  (dua socket di folder session yang sama memicu CONFLICT 440 → logout),
  socket lama kini dibersihkan (`cleanupOldSocket`) di `handleDisconnected` &
  `stopInstance`.
- **API1** — Endpoint jadibot BARU: `GET /api/jadibot/settings`,
  `GET/POST/DELETE /api/jadibot/messages` (teks bot per-instance: mess &
  singlemess), `GET/POST/DELETE /api/jadibot/media` (thumbnail/welcome/register/
  imagereply/imagemenu/audio — terima URL, base64, atau data-URI; upload base64
  disimpan ke Storage/jadibot_assets dan disajikan publik via `/api/assets/...`),
  `GET/POST/DELETE /api/jadibot/payment` (info bayar manual per-instance),
  `GET/POST /api/jadibot/packages` (paket sewabot/premium milik instance),
  `GET/POST /api/jadibot/owners`, `GET /api/jadibot/credentials` (ter-mask),
  `POST /api/jadibot/restart`.
- **API2** — Endpoint sewabot & premium: `GET /api/sewabot/packages`,
  `GET /api/premium/packages`, `POST /api/premium/bulk` (maks 100 nomor), dan
  **dukungan `instance`** di semua endpoint sewabot/premium — kelola data sewa &
  premium milik bot jadibot tertentu lewat parameter `instance=628xxx`.
- **API3** — `/api/status` kini menyertakan statistik antrean kirim
  (`sendQueue`), `/api/docs` diperbarui untuk semua endpoint baru.

## [Unreleased] — v2.7.0-refactor

### Pakasir API v2 + Console Cleanup + Bug Fix (2026-10-03)
- **PAY2** — Migrasi penuh payment gateway **Pakasir v1 → v2** (`App/function/
  pakasirClient.js` ditulis ulang): `POST /api/v2/create-transaction/{slug}/{order_id}`,
  auth header `X-Api-Key`, status `GET /api/v2/transaction-status/{slug}/{txn_id}`,
  cancel `POST /api/v2/cancel-transaction/{slug}/{txn_id}`, halaman bayar `/pay-v2/{txn_id}`.
  Metode baru `payment_link`; `atm_bersama_va` (v1) dihapus. Client menyimpan
  `txn_id` per order, men-throttle cache status (rate limit v2: 1x/4 detik),
  dan fallback find-or-create agar **order lama sisa v1 tetap bisa dicek/cancel**.
- **PAY3** — Semua pemakai ikut disesuaikan: `order/payment.js` (map `qr_string`
  → QR, `va_number`, `payment_link`, simpan `txnId`), `cpanel/payment.js`
  (polling 3s → 5s sesuai rate limit, status `canceled` v2), invoice
  `buyprem.js`/`sewabot.js` (fallback link bayar bila QR tidak tersedia).
- **PAY4** — Webhook v2 baru: `src/api/routes/pakasir.js` (`POST /api/pakasir/
  webhook`, verifikasi header `X-Secret` via `config.pakasir.webhookSecret`)
  → order WA pending langsung dilunasi tanpa nunggu polling.
- **UI1** — `App/function/logger.js` ditulis ulang: format rapi `[ HH:MM ] tag
  pesan`, tanpa uppercase paksa, pesan multi-baris di-indent `└`, anti-spam
  dedupe (pesan identik ≤10 detik maks 3x tampil). Aman layar kecil/panel.
- **UI2** — Banner connect, prompt nomor & box kode pairing dirapikan (tanpa
  emoji di border yang bikin align melenceng, lebar ~42 kolom).
- **UI3** — Log pesan masuk (debug) jadi 1 baris ringkas per pesan (dulu box
  rainbow 9 baris per pesan).
- **FIX1** — Anti-spam log `BOT HANYA BISA DIGUNAKAN DI GROUP` dst di
  `accesHandler.js`: warning per-chat maks 1x per 10 menit (dulu tiap pesan
  masuk → console banjir puluhan baris).
- **FIX2** — Welcome/left grup: URL gambar non-http(s) ditolak & kirim gambar
  yang gagal otomatis fallback ke teks (bug `GAGAL MENGIRIM PESAN GROUP:
  Failed to fetch stream ...`).
- **FIX3** — `database/index.js` transaction (driver-level): commit sekarang
  disinkronkan balik ke MemoryStore namespace yang disentuh — dulu bacaan
  `getSub` setelah transaction mengembalikan data stale (test
  `DatabaseManager › transaction manager-level` selalu gagal).
- **FIX4** — eslint.config.js: globals Node 18+ (`fetch`, `URLSearchParams`,
  `Intl`, dll) ditambahkan supaya `npm run lint` tidak salah `no-undef`.

### WebSocket Client-Only (W)
- **W1** — Semua fungsi WebSocket SERVER (gateway internal) **dihapus** dari
  bot: `src/websocket/{auth,connection-manager,room-manager,request-manager,
  transfer-manager,rate-limiter,router,heartbeat}.js`, `handlers/system.js`,
  `client/bot-bridge.js`, `__tests__/`, dan `scripts/ws-debug-room.js`.
  Bot kini hanya **client** + plugin (HTML Mini App).
- **W2** — `src/websocket/index.js` ditulis ulang sebagai bootstrap client-only.
  Nama `startWebSocketGateway`/`stopWebSocketGateway` dipertahankan demi
  kompatibilitas, isinya sekarang start/stop client.
- **W3** — `client/external-client.js` diperbaiki (bug `require('./protocol')`
  yang salah path) dan di-upgrade: dispatch request dari gateway, handler
  registry (`client.on(action, fn)`), streaming binary chunked dengan
  backpressure, keepalive ping, auto-reconnect bertahap.
- **W4** — `config.js` bagian `websocket` dibersihkan jadi client-only:
  `url`, `secret`, `serverId`, `capabilities`, `publicUrl`, `chunkSize`,
  `maxBinaryBytes`, `pingIntervalMs`, `autoReconnect*`. Semua key server lama
  (`port`, `path`, `maxConnections`, `bridgeUrl`, dll) dihapus.
  Env: `WEBSOCKET_URL`, `WEBSOCKET_SECRET`, `WEBSOCKET_PUBLIC_URL`.
- **W5** — Plugin `musicapp.js` kini menampilkan status koneksi client ke WSS
  gateway; URL endpoint diambil dari `websocket.publicUrl`/`websocket.url`.
- **W6** — `mini-services/websocket-gateway` (service terpisah untuk server
  lain) diperbaiki total: constructor mismatch, `Router.route()` yang tidak
  ada, relay binary frame yang hilang, logger dependency-free, endpoint
  `/health`, `.env.example`, dan README baru.
- **W7** — Dokumentasi ditulis ulang: `WEBSOCKET_EXTERNAL_MODE.md` dan
  `docs/websocket-gateway.md` kini menjelaskan arsitektur client-only.
- **W8** — E2E test (gateway + bot client + HTML client) PASS: auth, routing
  request/response, streaming binary chunk utuh 30000 byte, error handling,
  graceful stop.

### Architecture (A)
- **A1** — Refactor monolithic `Yudzxml.js` (469 baris) into:
  - `src/handler/main.js` (orchestration)
  - `src/handler/evalExecutor.js` (eval/exec logic — easy to audit)
  - `src/handler/contextBuilder.js` (grouped context object)
  The root `Yudzxml.js` is now a backward-compat shim.
- **A2** — `App/function/handler.js` is now explicitly marked `@deprecated`
  with migration hints pointing to `@App/function/handlers/*`. Backward
  compatibility is preserved (still re-exports `./handlers`).
- **A3** — Added `App/lowdb/README.md` documenting that the folder is a
  vendored fork of lowdb v1.x, scheduled for removal in v3.0.0.

### Reliability (R)
- **R2** — `global.restartBot` no longer spawns a child process via
  `process.on('exit') + spawn`. Now uses `process.exit(1)` so Docker / PM2 /
  systemd orchestrators perform the restart with clean state.

### Database (D)
- **D1** — `global.db` (LowDB compat) is marked `@deprecated`. The 30s
  heartbeat write is disabled by default (`config.database.legacyLowdbHeartbeat`).
  Migration path: use `DatabaseManager.getInstance().getDoc(...)`.
- **D2** — `DatabaseManager.transaction(fn)` now delegates to the driver's
  native transaction (BEGIN/COMMIT/ROLLBACK) for SQL drivers. JSON driver
  uses in-memory snapshot + serial write fallback.
- **D3** — Fixed cache invalidation. `setDoc/setSub/deleteDoc/deleteSub` now
  call `cache.invalidatePattern(\`${namespace}:*\`)` instead of
  `cache.invalidate(\`${namespace}*\`)` (which was a no-op). Added unit
  test in `database/drivers/__tests__/cache.test.js`.
- **D4** — SQLite WAL mode verified: `journal_mode=WAL`, `synchronous=NORMAL`,
  `foreign_keys=ON`, `busy_timeout=5000`. Already correct.
- **D5** — Backup utility now writes `.json.gz` by default (level 9 gzip).
  Auto-detects `.gz` on restore. Backward compatible with old `.json` files.
  Toggle via `config.database.backupCompress`.
- **D6** — Schema migration versioning in place. `SCHEMA_VERSION = 2` with
  incremental migrations registered in `MIGRATIONS` array. SQLite & SQL
  common both store version in `db_meta`.

### Bot lifecycle (B)
- **B1** — Pairing prompt in `src/core/bot.js` is now non-TTY-safe: skips
  interactive prompt in Docker / PM2, gives clear instructions. TTY mode
  uses retry (max 3) + 60s timeout, no `process.exit(1)` on bad input.
- **B2** — Jadibot registry writes are now serialized via in-process write
  queue + sidecar `.lock` file (O_EXCL atomic across processes). Race
  condition between REST API and Baileys event handlers fixed.
- **B3** — Session folder cleanup for expired jadibot: default
  `autoDeleteSession: true` (was false) with grace period 7 days
  (`config.jadibot.sessionGracePeriodDays`). After grace, folder is moved to
  `Storage/jadibot_trash/` and deleted permanently after `dataRetentionDays`
  (default 30).
- **B4** — Recursive `startBot()` on reconnect now calls `cleanupOldSocket`
  to remove all listeners and `end()` the old socket before starting a new
  one. Added `restartCount` for debugging.
- **B6** — Added `messages.update` listener in `bindMessageHandler`. Now
  processes read receipts (updates `chat_stats`), message deletions
  (anti-delete logging), and reactions.

### Plugins (P)
- **P1** — Plugin context grouped: `ctx.core`, `ctx.message`, `ctx.user`,
  `ctx.group`, `ctx.services`, `ctx.media`, `ctx.config`, `ctx.runtime`.
  Old flat fields kept for backward compat.
- **P2** — Broadcast plugins (`pushkontak`, `jpm`, `jpmswgc`, `autojpm`)
  are now per-instance. Jadibot owner can use them on their own instance
  without affecting main bot. Added `allowJadibotOwner` plugin flag and
  `_broadcastInstance.js` helper with `canBroadcast(ctx)` permission.
- **P6** — `App/plugins/main/script.js` now reads version from
  `package.json` (single source of truth) instead of hardcoded `1.1.0 BETA`.
- **PF4** — Global HTTP keep-alive pool for axios in
  `App/function/handlers/network.js`: `https.Agent({ keepAlive: true,
  maxSockets: 50 })`. Reduces CPU & latency for outbound requests.

### Ops (OP)
- **OP2** — `docker-compose.yml` now sets memory limit (2G hard / 512M soft)
  and CPU limit (2 cores).
- **OP3** — Docker log rotation: `json-file` driver with `max-size: 10m`,
  `max-file: 3`. Optional healthcheck added.

### Quality (Q)
- **Q1** — Added `jsconfig.json` with path aliases (`@App/*`, `@Config`, etc.)
  to enable IDE type resolution.
- **Q2** — Added `eslint.config.js` (flat config) with `@eslint/js`
  recommended + `eslint-plugin-node`. Rules: `no-unused-vars` (warn),
  `eqeqeq` (error), `prefer-const` (warn), `no-console` (warn in prod).
- **Q3** — Added tests for:
  - `database/drivers/__tests__/cache.test.js` (D3 wildcard invalidation)
  - `src/api/__tests__/middleware.test.js` (auth, rate limit, wrap)
  - `src/handler/__tests__/evalExecutor.test.js` (eval/exec safety)
  - `src/core/__tests__/jadibotRegistry.test.js` (B2 file lock)
- **Q4** — JSDoc template documented in `docs/plugin-jsdoc-template.md`.
- **Q5** — This CHANGELOG.md file added.

### Features (F)
- **F3** — i18n via `i18next` (`App/locales/id.json`, `App/locales/en.json`).
  User command `.setlang en|id` switches bot language. Persisted in user DB.
- **F7** — Plugin marketplace API: owner can upload `.js` plugin via
  `POST /api/plugins` (with strict permission & sandbox checks). Jadibot
  instances CANNOT install plugins (read-only).
- **F11** — Reminder / scheduler user plugin: `.reminder 30m Minum air`
  creates a scheduled task that survives restart. Stored in `reminders`
  namespace via DatabaseManager.
- **F12** — Polling / voting group plugin: `.poll "Pilih makan" "Mie"
  "Ayam" "Ikan"` creates poll with native WA buttons. Auto-closes after
  24 hours.

## [2.6.2] — 2026-Q3 (baseline)

- Multi-device WhatsApp bot (Baileys)
- Modular plugin system (300+ plugins)
- Multi-driver database (json / sqlite / mysql / postgresql)
- Jadibot multi-instance system
- REST API (no webhooks)

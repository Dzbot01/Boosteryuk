# Database Schema Reference

Skema tabel untuk SQLite, PostgreSQL, dan MySQL. Skema dibuat otomatis oleh driver saat `connect()`. Perbedaan dialek: `SERIAL` (PostgreSQL), `AUTO_INCREMENT` (MySQL), `AUTOINCREMENT` (SQLite). Kolom teks pada MySQL memakai `VARCHAR(191)` untuk kolom terindeks (batas utf8mb4 index) dan `LONGTEXT` untuk payload besar.

## Pemetaan namespace ke tabel

| Namespace (JSON lama)             | Tabel SQL                                   | Keterangan                    |
|-----------------------------------|---------------------------------------------|-------------------------------|
| `user` (user.json)                | `users`                                     | Data user per JID             |
| `userDB` (userDB.json)            | `chat_stats`                                | Statistik chat per grup-user  |
| `premium` (premium.json)          | `premium_users`                             | Array premium                 |
| `sewa` (sewa.json)                | `bot_sewa`                                  | Sewa per grup                 |
| `bannedDB` (bannedDB.json)        | `banned_users`                              | User ban                      |
| `maintenance` (maintenance.json)  | `maintenance_mode`                          | Satu baris (id=1)             |
| `payment` (payment.json)          | `payment_transactions`                      | Transaksi pakasir             |
| `afk` (afk.json)                  | `afk_status`                                | Status AFK                    |
| `ptreodactyl` (ptreodactyl.json)  | `pterodactyl_users`, `pterodactyl_servers`  | Panel cpanel                  |
| `welcome`, `left`                 | `bot_settings`                              | Template per grup             |
| Namespace lain (redeem, jpm, orders, database/global.db, dst) | `generic_data` | Dokumen JSON utuh |
| `jadibot:<nomor>:premium`         | `premium_users` (scope = nomor)             | Data premium instance jadibot |
| `jadibot:<nomor>:sewa`            | `bot_sewa` (scope = nomor)                  | Data sewa instance jadibot    |

Kolom `scope` pada `premium_users` dan `bot_sewa` (default `main`) menjaga isolasi data antara bot utama dan instance jadibot.

## users

```sql
CREATE TABLE users (
  jid TEXT PRIMARY KEY,
  "limit" BIGINT DEFAULT 30,
  money BIGINT DEFAULT 0,
  role TEXT DEFAULT '-',
  level_user BIGINT DEFAULT 1,
  level_cache BIGINT DEFAULT 0,
  last_reset BIGINT,
  last_claim_limit BIGINT,
  extra TEXT,             -- JSON: field tambahan apa pun
  created_at BIGINT,
  updated_at BIGINT
);
```

Dokumen JSON `user.json` berbentuk `{ "628x@s.whatsapp.net": { limit, money, role, level_user, level_cache, lastReset, lastClaimLimit, ... } }`. Mapping field: `lastReset` <-> `last_reset`, `lastClaimLimit` <-> `last_claim_limit`. Field di luar mapping tersimpan utuh di kolom `extra` sehingga tidak ada data yang hilang.

## chat_stats

```sql
CREATE TABLE chat_stats (
  id SERIAL PRIMARY KEY,
  group_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  total_chat BIGINT DEFAULT 0,
  last_chat BIGINT,
  created_at BIGINT,
  updated_at BIGINT,
  UNIQUE(group_id, user_id)
);
```

Representasi dari `userDB.json`: `{ groups: { "<gid>": { users: { "<uid>": { totalChat, lastChat } } } } }`.

## premium_users

```sql
CREATE TABLE premium_users (
  id SERIAL PRIMARY KEY,
  scope TEXT NOT NULL DEFAULT 'main',
  user_id TEXT NOT NULL,
  expired BIGINT NOT NULL,
  created_at BIGINT,
  updated_at BIGINT,
  UNIQUE(scope, user_id)
);
```

Dokumen JSON: array `[{ id, expired }]`. `scope='main'` untuk bot utama.

## bot_sewa

```sql
CREATE TABLE bot_sewa (
  id SERIAL PRIMARY KEY,
  scope TEXT NOT NULL DEFAULT 'main',
  group_id TEXT NOT NULL,
  group_name TEXT,
  start TEXT,
  expired BIGINT,
  created_at BIGINT,
  updated_at BIGINT,
  UNIQUE(scope, group_id)
);
```

Dokumen JSON: `{ "<gid>": { namegrup, start (ISO string), expired (timestamp) } }`.

## banned_users

```sql
CREATE TABLE banned_users (
  user_id TEXT PRIMARY KEY,
  reason TEXT,
  banned_at TEXT,
  expired_at TEXT,
  permanent SMALLINT DEFAULT 0,
  created_at BIGINT
);
```

`banned_at`/`expired_at` mempertahankan format moment (ISO dengan offset) seperti JSON asli.

## maintenance_mode

```sql
CREATE TABLE maintenance_mode (
  id INT PRIMARY KEY,          -- selalu 1
  enabled SMALLINT DEFAULT 0,
  reason TEXT,
  start_at BIGINT,
  end_at BIGINT,
  duration BIGINT DEFAULT 0,
  updated_at BIGINT
);
```

## payment_transactions

```sql
CREATE TABLE payment_transactions (
  id SERIAL PRIMARY KEY,
  order_id TEXT NOT NULL UNIQUE,
  user_id TEXT,
  amount BIGINT DEFAULT 0,
  status TEXT DEFAULT 'pending',
  data TEXT,               -- JSON: payload transaksi lengkap
  created_at BIGINT,
  updated_at BIGINT
);
```

Dokumen JSON `{ transactions: [...] }` direkonstruksi dari kolom `data` sehingga field apa pun dari pakasir tetap tersimpan.

## afk_status

```sql
CREATE TABLE afk_status (
  id SERIAL PRIMARY KEY,
  group_id TEXT,
  user_id TEXT,
  reason TEXT,
  started_at BIGINT,
  mentioned BIGINT DEFAULT 0,
  created_at BIGINT,
  updated_at BIGINT,
  UNIQUE(group_id, user_id)
);
```

## pterodactyl_users / pterodactyl_servers

```sql
CREATE TABLE pterodactyl_users (
  user_id TEXT PRIMARY KEY,   -- email user panel
  api_key TEXT,               -- password terenkripsi (enc:...)
  data TEXT,                  -- JSON: nilai asli apa pun
  created_at BIGINT
);

CREATE TABLE pterodactyl_servers (
  server_id TEXT PRIMARY KEY,
  user_id TEXT,
  server_name TEXT,
  data TEXT,                  -- JSON: { userId, expiredAt }
  created_at BIGINT
);
```

## bot_settings

```sql
CREATE TABLE bot_settings (
  namespace TEXT NOT NULL,    -- 'welcome' | 'left' | lainnya
  key TEXT NOT NULL,          -- group id
  value TEXT,                 -- string atau JSON
  created_at BIGINT,
  updated_at BIGINT,
  PRIMARY KEY (namespace, key)
);
```

## game_sessions (siap pakai)

```sql
CREATE TABLE game_sessions (
  id SERIAL PRIMARY KEY,
  game_type TEXT,
  group_id TEXT,
  user_id TEXT,
  state TEXT,                 -- JSON
  created_at BIGINT,
  updated_at BIGINT
);
```

Tabel ini tersedia untuk integrasi website/API. Saat ini data game (`global.db.data.game`) tetap tersimpan utuh di `generic_data` agar 100% kompatibel dengan plugin game existing.

## generic_data

```sql
CREATE TABLE generic_data (
  id SERIAL PRIMARY KEY,
  namespace TEXT NOT NULL,
  key TEXT NOT NULL DEFAULT '__doc__',
  value TEXT,                 -- JSON dokumen utuh
  created_at BIGINT,
  updated_at BIGINT,
  UNIQUE(namespace, key)
);
```

Menyimpan namespace tanpa mapping khusus, termasuk `database` (global.db: users, chats, groups, game, settings, others, sticker) dalam satu baris `__doc__` per namespace.

## db_meta

```sql
CREATE TABLE db_meta (
  key TEXT PRIMARY KEY,
  value TEXT
);
-- berisi: schema_version = 1
```

## Index

```sql
CREATE INDEX idx_chat_stats_group  ON chat_stats(group_id);
CREATE INDEX idx_chat_stats_user   ON chat_stats(user_id);
CREATE INDEX idx_premium_user      ON premium_users(user_id);
CREATE INDEX idx_premium_scope     ON premium_users(scope);
CREATE INDEX idx_sewa_scope        ON bot_sewa(scope);
CREATE INDEX idx_settings_namespace ON bot_settings(namespace);
CREATE INDEX idx_generic_namespace ON generic_data(namespace);
CREATE INDEX idx_payment_status    ON payment_transactions(status);
```

## Konvensi waktu

Semua kolom `*_at`, `expired`, `started_at`, `last_*` memakai **epoch milliseconds** (BIGINT), konsisten dengan `Date.now()` di kode bot. Pengecualian: `bot_sewa.start` berupa string ISO (mengikuti format JSON asli dari `addSewa`).

## Membaca langsung dari website

Contoh query umum untuk backend website (PostgreSQL):

```sql
-- daftar user teratas
SELECT jid, "limit", money, role, level_user FROM users ORDER BY money DESC LIMIT 20;

-- premium aktif
SELECT user_id, expired FROM premium_users WHERE scope = 'main' AND expired > <now_ms>;

-- sewa aktif
SELECT group_id, group_name, expired FROM bot_sewa WHERE scope = 'main' AND expired > <now_ms>;

-- transaksi terbaru
SELECT order_id, amount, status, created_at FROM payment_transactions ORDER BY created_at DESC LIMIT 50;
```

Gunakan prepared statements / parameter binding di sisi website juga. Berikan user database khusus read-only bila backend hanya membaca.

# Dokumentasi Konfigurasi X7BOTZ - MD (config.js)

File ini memuat semua panduan dan penjelasan untuk variabel yang ada pada `config.js`. Karena file `config.js` sudah dibersihkan dari komentar, silakan merujuk ke file ini untuk memahami setiap pengaturan.

## 1. IDENTITAS BOT
*   **`superowner`**: Nomor WhatsApp owner tertinggi (superowner). Format internasional TANPA tanda "+" dan TANPA spasi. Contoh Indonesia: `62812xxxxxxx`. Hanya nomor ini yang bisa pakai perintah khusus superowner (seperti `.blacklistgc`, `.setautojpm`, `.addowner`, eksekusi `$` dan `>`, dll).
*   **`ownername`**: Nama pemilik bot (tampil di menu, watermark, dan notifikasi).
*   **`email`**: Email kontak yang ditampilkan pada info bot & dokumentasi API. Isi dengan email kamu sendiri, contoh: `nama@gmail.com`.
*   **`botname`**: Nama bot yang tampil di chat/menu.
*   **`packname` & `author`**: Untuk informasi pembuat pada sticker yang dibuat bot.
*   **`region`**: Negara/region bot (hanya informasi).
*   **`idch`**: JID saluran WhatsApp (newsletter) bot untuk fitur share/reaction. Format: `<id-saluran>@newsletter`. Ambil lewat `.cekidch` di saluranmu.

## 2. PERILAKU BOT
*   **`pairingCode`**: `true` = login pakai KODE PAIRING (masukkan nomor di terminal); `false` = login pakai scan QR code di terminal.
*   **`pairingNumber`**: NOMOR BOT UTAMA untuk pairing OTOMATIS tanpa input terminal (headless / Docker). Format: `628xx` TANPA + atau spasi. Kosongkan `''` untuk input manual. PENTING: isi agar recovery bot setelah banned/logout bisa via API.
*   **`markOnlineOnConnect`**: `true` = bot tampil online; `false` = bot tampil offline (disarankan agar tidak dicurigai spam).
*   **`public`**: `true` = mode PUBLIC (semua user bisa pakai bot); `false` = mode SELF (hanya owner & superowner).
*   **`prefix`**: `true` = wajib pakai prefix di private chat; `false` = tanpa prefix juga bisa merespons.
*   **`autoRead`**: `true` = bot otomatis membaca (centang biru) chat biasa.
*   **`autoswview`**: `true` = bot otomatis membaca/melihat status (sw) yang masuk.
*   **`anticall`**: `true` = bot menolak/mengakhiri panggilan telepon masuk (anti-call).
*   **`debug`**: `true` = tampilkan log rutin (info/success) di terminal + log pesan masuk Baileys via lolcatjs. `false` (default) = console bersih, HANYA warning & error yang tampil.
*   **`isRamadhan`**: `true` = aktifkan notifikasi jadwal imsak/sahur/berbuka.
*   **`prefix_custom`**: Daftar prefix tambahan (contoh: `['/', '!', '#']`).
*   **`customPairing`**: 8 karakter kode pairing custom saat login (opsional).
*   **`bootMode`**: Mode startup bot:
    *   `'menu'` (default) → tanya SEKALI di boot pertama (hanya bila belum ada session tersimpan & belum ada pilihan): **Mode Bot Utama / Mode API / Mode Jadibot**. Pilihan tersimpan di `Storage/bootmode.json` sehingga restart otomatis (Pterodactyl/Docker/PM2) TIDAK menampilkan menu lagi.
    *   `'bot'` → bot utama langsung jalan (+ API). Pairing otomatis bila `config.pairingNumber` diisi, atau prompt nomor bila TTY & belum ada session.
    *   `'api'` → hanya REST API server, tanpa socket WhatsApp apa pun.
    *   `'jadibot'` → TANPA bot utama; hanya mengelola instance jadibot (+ API website untuk order/kelola jadibot).
    *   Bot sudah pernah pairing (session tersimpan) → menu otomatis dilewati, langsung MODE BOT UTAMA.
*   **`allowEval`**: `true` (default) = superowner boleh pakai `>` (eval), `=>` (expression), `$` (shell) dari chat. `false` = fitur dimatikan total. Setiap eksekusi tercatat di `Storage/eval_audit.log`. Hanya `config.superowner` yang bisa — owner jadibot TIDAK bisa.

## 3. DESTINASI PENGGUNAAN BOT (`botDestination`)
Menentukan di mana bot BOLEH merespon perintah (Owner/Premium SELALU lolos aturan ini):
*   `'group'`: Bot HANYA aktif di grup (cocok untuk disewakan ke grup).
*   `'private'`: Bot HANYA aktif di private chat.
*   `'both'`: Bot aktif di grup DAN private chat.

## 4. GAME, LIMIT & EKONOMI
*   **`resetclaim`**: Interval (menit) reset klaim limit harian user.
*   **`sleep_game`**: Jeda (ms) antar soal game (anti-spam).
*   **`MoneyMenangGame`**: Hadiah money setiap menang game.
*   **`ratelimiter`**: Jeda minimal (ms) antar perintah per user (anti-spam rate limit).
*   **`icon_on` & `icon_off`**: Ikon status aktif/nonaktif.

## 5. STORE / TOKO (`store`)
Menampung properti seperti `nameStore`, link `group`, `saluran`, dan `website` jualan/toko.

## 6. PEMBAYARAN (`payment`)
Metode pembayaran BEBAS — tinggal tambah/hapus variabel baru dan nilainya, otomatis tampil di `.listpay`:
*   **`QRIS`**: URL gambar QRIS (upload ke CDN lalu tempel di sini).
*   **`DANA`**, **`GOPAY`**, **`OVO`**: Nomor e-wallet penerima (format 62xxx).
*   **`MANDIRI`**, **`BCA`**, **`BRI`**, **`SEABANK`**: Nomor rekening bank.

> Owner bot jadibot TIDAK perlu edit config.js: mereka mengatur payment milik instance-nya sendiri lewat chat private bot-nya (`.addpay dana=0812 gopay=0898 mandiri=1300012345678`, `.delpay dana`, `.listpay`) atau lewat website. Payment instance tersimpan di registry jadibot (settings.payment) — terpisah dari bot utama.

## 7. API KEY EKSTERNAL (`apikey`)
*   **`endpoint`**: Domain REST API penyedia fitur (download, search, AI).
*   **`key`**: API key kamu dari penyedia tersebut.

## 8. PAKASIR (PAYMENT GATEWAY OTOMATIS — API v2, QRIS SAJA)
Gateway pembayaran OTOMATIS dari https://pakasir.com untuk `.buyprem`, `.sewabot`, `.jadibot`.
**Bot ini memakai Pakasir API v2** (`/api/v2/create-transaction`, `X-Api-Key`, `txn_id`)
dengan **kebijakan QRIS SAJA**: tanpa payment link, tanpa virtual account, tanpa webhook.
*   **`enabled`**: `true` = order otomatis aktif.
*   **`key`** & **`slug`**: API Key dan nama proyek dari dashboard Pakasir (WAJIB diganti).
    Kunci dikirim lewat header `X-Api-Key` (bukan lagi di body seperti v1).
*   **`defaultMethod`**: selalu `qris` — satu-satunya metode yang dipakai bot.
    Metode lain (payment_link / VA) ditolak otomatis oleh client.
*   **`frameQr`**: URL gambar frame/template tempat QRIS digambar (opsional).
*   **Cek status = MANUAL**: TIDAK ada webhook. Status transaksi dipolling
    internal bot tiap 5 detik (menghormati rate limit v2 1x/4 detik via cache)
    dan bisa dicek manual lewat command `cekstatus` / `orderstatus`.

## 9. CPANEL / PTERODACTYL
Untuk fitur jualan panel (jika digunakan). Meliputi `BASE` URL, API key (`PLTA`), ID Nest/Egg, serta tabel harga (`LISTPANEL`).

## 10. JADIBOT
Fitur nomor user berubah menjadi bot.
*   **`enabled`**: Master switch jadibot.
*   **`maxInstances`**: Maksimal instance bot yang bisa jalan.
*   **`sessionFolder` & `autoDeleteSession`**: Mengatur penyimpanan session.
*   **`packages`**: Pricelist langganan Jadibot (durasi dalam hari).

## 11. SEWABOT
Bot utama yang dimasukkan/diundang ke grup klien.
*   **`packages`**: Pricelist sewabot (Format: `{ name, price, days }`).
*   **`bonusPremiumMinDays`**: Minimal sewa hari untuk dapat bonus user premium.
*   **`autoJoinGroup`**: `true` = otomatis masuk grup setelah lunas via gateway.

> **PER-INSTANCE**: Bot jadibot bisa punya pricelist & pengaturan sendiri tanpa mengubah config.js. Semua item berikut bisa di-set per-instance via website (`POST /api/jadibot/settings`) atau command WA:
> *   `sewabot` (`{enabled, packages[], bonusPremiumMinDays}`) & `premium` (`{enabled, packages[]}`) — pricelist milik bot jadibot sendiri.
> *   `payment` — metode pembayaran milik instance (QRIS/DANA/GOPAY/MANDIRI/dll).
> *   `thumbnail` (`welcome`, `imagereply[]`, `imagemenu[]`, `audio[]`, dll) — gambar menu/stiker audio instance.
> *   `mess` & `singlemess` — teks balasan instance.
> *   `markOnlineOnConnect`, `isRamadhan`, `autoRead`, `autoswview`, `anticall`, `botDestination`, `prefix`, `prefix_custom`, `idch` — setting perilaku instance.
> *   Kredensial `pakasir` (lengkap: `enabled`, `key`, `slug`, `baseUrl`, `defaultMethod`, `methods[]`, `frameQr`) & `cpanel` (`BASE`, `PLTA`, `NODEJS{NESTID,EGGID}`, `PYTHON{NESTID,EGGID}`, `LISTPANEL[]`) via `POST /api/jadibot/credentials`.
>
> Order sewabot/premium yang dibuat dari bot jadibot otomatis memakai pricelist & gateway instance tersebut. Command WA terkait: `.setidch <link/ID>`, `.delidch`, `.addpay`, `.delpay`, `.listpay`, `.upch <link/ID saluran>` (upload ke channel, support link saluran langsung).

## 12. PREMIUM USER
Pengaturan harga untuk menjadi Premium User (bebas limit & akses fitur premium bot utama).

## 13. DATABASE
*   **`type`**: Pilih salah satu antara `'json'`, `'sqlite'`, `'mysql'`, atau `'postgresql'`.
*   Bot memiliki auto-migrate (dari JSON ke SQL) dan fallback sistem.
*   Ganti detail host/password jika memakai MySQL/PostgreSQL.

## 14. REST API
API pemanggilan manajemen (tanpa webhook/callback).
*   **`keys`**: API key keamanan wajib di header (X-API-Key). WAJIB GANTI!
*   **`port` & `cors`**: Pengaturan jaringan dan akses port API.
*   Dokumentasi endpoint lengkap: `GET http://IP:PORT/api/docs` — mencakup
    manajemen jadibot (settings, messages, media/thumbnail/audio, payment,
    packages, owners, credentials, restart), sewabot & premium (semua
    mendukung parameter `instance=628xxx` untuk mengelola data milik bot
    jadibot tertentu).

## 15. ANTREAN KIRIM ANTI-SPAM (`messageQueue`)
Jeda otomatis antar pesan keluar (bot utama & semua jadibot) agar pola kirim
terlihat manusiawi dan nomor tidak mudah di-flag spam WhatsApp — salah satu
penyebab utama "session logout sendiri".
*   **`enabled`**: `true` = pacing aktif (disarankan).
*   **`minDelayMs` + `maxJitterMs`**: jeda minimum + variasi acak antar pesan
    (default 900ms + 0-600ms).
*   **`maxQueue`**: batas antrean (default 150). Pesan lebih dari itu ditolak
    dengan error & warning di console — bukan menumpuk diam-diam.
*   **`sendTimeoutMs`**: timeout per kirim (default 90s) agar satu kirim yang
    menggantung tidak membekukan antrean.
*   Jalur darurat tanpa antrean (dipakai kode internal saja):
    `socket.sendMessageRaw(...)`.

## 16. AUTO BACKUP
*   **`zipDaily`**: Kirim backup ZIP harian ke WA.
*   **`dbIntervalHours`**: Jeda waktu export JSON backup.
*   **`keep`**: Jumlah file yang disimpan sebelum ditimpa (rotasi).

## 17. AUTO CLEANER
*   Menghapus file sementara (folder `tmp/`, `nodeCache`) dan menyeleksi data statistik usang (`statisticsRetentionDays`, `rpgRetentionDays`).

## 18. AUTO RESTART
*   **`dailyAtHour`**: Jam restart harian (0-23) untuk menyegarkan memori.
*   **`memoryLimitMB`**: Restart saat RAM menyentuh batas tertentu.

## 19. RECONNECT & PENANGANAN BAN
*   Mencegah bot terblokir dengan mengatur jeda reconnect (`banCooldownMs`, `baseDelayMs`) saat terdeteksi indikasi ban dari WhatsApp.

## 20. THUMBNAIL & ASET
*   Berisi URL gambar / audio yang dikirim saat bot memunculkan menu, game, maupun reply suara.

## 21. TEMPLATE PESAN (`mess` & `singlemess`)
*   Kumpulan teks balasan (respons sukses, anti-link, dll). Silakan diedit sesuka hati (menggunakan format WA bold `*`, italic `_`, dll).

# Panduan Migrasi Database X7BOTZ-MD

Panduan lengkap memindahkan data antar engine database: JSON (Storage/*.json), SQLite, PostgreSQL, dan MySQL.

## Prinsip penting

1. **Selalu backup sebelum migrasi.** Semua script migrasi membuat backup otomatis kecuali `--no-backup`.
2. Jalankan migrasi saat bot **belum berjalan** (atau setelah stop) agar data tidak berubah di tengah proses.
3. Setelah migrasi selesai dan tervalidasi, ubah `database.type` di config.js, lalu start bot.
4. Rollback tersedia: restore file backup yang dibuat otomatis.

## Persiapan

### SQLite
Tidak ada persiapan server. File `bot.db` dibuat otomatis.

### PostgreSQL
```bash
createdb x7botz_db
# atau
psql -U postgres -c "CREATE DATABASE x7botz_db;"
```
Sesuaikan `database.postgresql` di config.js (host, port, database, user, password).

### MySQL / MariaDB
```sql
CREATE DATABASE x7botz_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```
Sesuaikan `database.mysql` di config.js.

## Migrasi dari JSON (setup pertama kali)

```bash
npm run db:migrate:sqlite        # atau: node migrate-json-to-sqlite.js
npm run db:migrate:postgresql    # atau: node migrate-json-to-postgresql.js
npm run db:migrate:mysql         # atau: node migrate-json-to-mysql.js
```

Opsi yang tersedia:

| Opsi               | Keterangan                                  |
|--------------------|---------------------------------------------|
| `--validate-only`  | Bandingkan data saja, tanpa menulis         |
| `--no-backup`      | Lewati backup otomatis                      |
| `--no-validate`    | Lewati validasi setelah migrasi             |
| `--sqlite-path X`  | Path file SQLite tujuan                     |
| `--host/--port/--database/--user/--password` | Konfigurasi koneksi PG/MySQL |

Contoh PostgreSQL dengan koneksi kustom:

```bash
node migrate-json-to-postgresql.js \
  --host db.example.com \
  --port 5432 \
  --database x7botz_db \
  --user botuser \
  --password rahasia
```

Output yang diharapkan:

```
[ OK ] [DB][MIGRATE] Backup tersimpan: Storage/backups/backup-json-....json
Import ke sqlite [████████████████████] 100% (22/22)
[ OK ] [DB][MIGRATE] Validasi: 22/22 namespace identik
[ OK ] [DB][MIGRATE] Migrasi json -> sqlite selesai dalam 120ms (22 namespace).
```

Terakhir, ubah config.js:

```javascript
database: {
  type: 'sqlite',        // sebelumnya 'json'
  ...
}
```

lalu start bot seperti biasa.

## Migrasi antar engine (semua kombinasi)

```bash
node migrate-database.js <source> <target>
```

Kombinasi yang didukung:

```bash
node migrate-database.js sqlite postgresql
node migrate-database.js sqlite mysql
node migrate-database.js postgresql sqlite
node migrate-database.js postgresql mysql
node migrate-database.js mysql sqlite
node migrate-database.js mysql postgresql
node migrate-database.js json sqlite
```

Opsi koneksi per-engine:

| Opsi                                       | Keterangan        |
|--------------------------------------------|-------------------|
| `--sqlitePath ./bot.db`                    | Path SQLite       |
| `--jsonPath ./Storage`                     | Folder JSON       |
| `--pgHost --pgPort --pgDatabase --pgUser --pgPassword` | PostgreSQL |
| `--myHost --myPort --myDatabase --myUser --myPassword` | MySQL      |

Contoh lengkap:

```bash
node migrate-database.js postgresql mysql \
  --pgHost localhost --pgDatabase x7botz_db --pgUser postgres --pgPassword secret \
  --myHost db2.example.com --myDatabase x7botz_db --myUser botuser --myPassword rahasia
```

Mode validasi tanpa menulis (exit code 2 jika ada perbedaan):

```bash
node migrate-database.js json sqlite --validate-only
```

## Validasi

Validasi membandingkan isi namespace sumber dan tujuan (jumlah record + isi dokumen). Hasil per namespace:

```
  [OK] user: 2 -> 2 record
  [OK] premium: 3 -> 3 record
  [BEDA] sewa: 5 -> 4 record
Total: 2/3 identik
```

Jika validasi menemukan perbedaan dan `--force` tidak dipakai, proses dianggap gagal (rollback backup ditawarkan).

## Backup & Restore

```bash
node database/utils/backup.js                 # backup engine aktif di config (default json)
node database/utils/backup.js sqlite          # backup SQLite
node database/utils/backup.js list            # daftar backup di Storage/backups
node database/utils/backup.js prune 10        # sisakan 10 backup terbaru
node database/utils/backup.js restore Storage/backups/backup-sqlite-xxx.json json
```

Backup berbentuk satu file JSON berisi seluruh namespace. Restore menulis ulang ke engine tujuan tanpa menghapus data yang tidak ada di backup (gabungan). Untuk penggantian total, jalankan migrasi `json -> target` setelah restore ke JSON.

### Backup terjadwal

Panggil dari kode custom (mis. di index.js tambahan):

```javascript
const { startScheduleBackup } = require('./database/utils/backup');
startScheduleBackup(['json'], 24);
```

## Switch saat runtime (tanpa script)

DatabaseManager dapat berpindah engine saat bot hidup; data memory disinkronkan otomatis:

```javascript
const db = require('@Database');
await db.switchType('sqlite');
```

Atau lewat hot-reload: ubah `database.type` di config.js, DatabaseManager mendeteksi perubahan dan melakukan switch sendiri. Perubahan ini tidak tersimpan permanen ke config (hot-reload hanya memengaruhi proses berjalan); untuk permanen, tetap ubah file config.js sebelum restart.

## Rollback lengkap

1. Kembalikan `database.type` ke nilai sebelumnya di config.js.
2. Restore backup:
   ```bash
   node database/utils/backup.js restore Storage/backups/backup-json-xxx.json json
   ```
3. Start bot.

## Troubleshooting

| Masalah | Penyebab | Solusi |
|---------|----------|--------|
| `ECONNREFUSED` saat migrasi ke PG/MySQL | Server mati / host-port salah | Cek kredensial dan jaringan |
| `better-sqlite3 belum terinstall` | Dependensi belum terpasang | `bun add better-sqlite3` atau `npm i better-sqlite3` |
| `password authentication failed` | Kredensial salah di config.js | Perbaiki config, ulangi migrasi |
| `database "x7botz_db" does not exist` | Database belum dibuat | `CREATE DATABASE x7botz_db;` |
| Validasi `BEDA` beberapa namespace | Ada proses lain menulis saat migrasi | Stop bot, ulangi migrasi |
| File SQLite korup | Disk penuh / crash ekstrem | Restore dari backup, atau hapus `bot.db` lalu migrasi ulang dari JSON |

## Pertanyaan umum

**Apakah migrasi menghapus data sumber?** Tidak. Data sumber tidak pernah diubah; backup tetap dibuat.

**Berapa lama migrasi?** Bergantung jumlah user. Ribuan record umumnya di bawah beberapa detik karena batch insert.

**Apakah session WhatsApp (folder auth) ikut dimigrasi?** Tidak. Session Baileys tetap berupa folder file (`Storage/session`, `Storage/jadibot_sessions/*`) dan bukan bagian lapisan database.

**Apakah bisa menjalankan dua bot dengan engine berbeda?** Bisa. Setiap proses membaca config.js sendiri.

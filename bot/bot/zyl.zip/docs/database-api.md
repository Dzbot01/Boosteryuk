# Database API Reference

Referensi lengkap API lapisan database X7BOTZ-MD. Semua contoh memakai CommonJS.

## Mengakses DatabaseManager

```javascript
const db = require('@Database');
const { DatabaseManager, getInstance } = require('@Database');

getInstance() === db;               // true, singleton
DatabaseManager.getInstance() === db; // true
```

## Lifecycle

### connect()
```javascript
await db.connect();
```
Menghubungkan driver aktif dari `config.database.type`, memuat seluruh namespace ke memory store, dan menjalankan seed otomatis dari Storage/*.json bila `autoMigrate: true` dan database masih kosong. Idempoten: pemanggilan berulang mengembalikan promise yang sama.

### disconnect()
```javascript
await db.disconnect();
```
Flush seluruh perubahan tertunda, menghentikan config watcher, menutup koneksi.

### reconnect()
```javascript
await db.reconnect();
```
Menyambung ulang driver aktif. Dipanggil otomatis (dengan backoff) saat kehilangan koneksi terdeteksi.

### switchType(newType, options?)
```javascript
const result = await db.switchType('sqlite');
// { from: 'json', to: 'sqlite', migrated: true }
```
Mengganti engine saat runtime. Urutan kerja: flush memory ke driver lama, connect driver baru, migrasi data bila target kosong atau sinkronisasi snapshot memory bila target sudah berisi, lalu tukar driver. Melempar `DriverNotFoundError` untuk tipe tak dikenal.

### reloadConfig()
```javascript
const status = await db.reloadConfig();
// { changed: true, type: 'sqlite' }
```
Memuat ulang `config.js`. Bila `database.type` berubah, otomatis `switchType`.

## Akses data synchronous (untuk plugin)

Method ini tidak melakukan I/O; data diambil dari memory store dan ditulis dengan flush debounced.

```javascript
db.getDoc('user');
db.setDoc('user', { '628x@s.whatsapp.net': { limit: 30 } });
db.deleteDoc('user');

db.getSub('user', '628x@s.whatsapp.net');
db.setSub('user', '628x@s.whatsapp.net', { limit: 10, money: 5 });
db.deleteSub('user', '628x@s.whatsapp.net');

db.store.getDirtyNamespaces();
db.store.getSnapshot();
```

Untuk dokumen berbentuk array (mis. `premium`), `setSub` mencocokkan item lewat `id` atau `user_id`:

```javascript
db.setSub('premium', '628x@s.whatsapp.net', { expired: 999 });
// menambah/memperbarui item { id: '628x@s.whatsapp.net', expired: 999 }
```

## Akses data asynchronous (driver-level)

```javascript
const driver = db.getDriver();

await driver.get('user');
await driver.get('user:628x@s.whatsapp.net');
await driver.set('user:628x@s.whatsapp.net', { limit: 30, money: 0 });
await driver.delete('user:628x@s.whatsapp.net');
await driver.exists('user:628x@s.whatsapp.net');

await driver.getAll();
await driver.clear();
await driver.getKeys('user*');
await driver.listNamespaces();

await driver.getDocument('user');
await driver.saveDocument('user', { ... });
await driver.deleteDocument('user');
await driver.countRecords('user');
```

Semua method driver memakai retry otomatis (default 3 percobaan, backoff eksponensial) untuk error yang bersifat sementara.

### transaction(fn)

```javascript
await driver.transaction(async tx => {
  const user = tx.get('user:628x@s.whatsapp.net');
  user.money += 100;
  tx.set('user:628x@s.whatsapp.net', user);
  tx.delete('user:628y@s.whatsapp.net');
});
```

`tx` menyediakan `get`, `set`, `delete`. Semua perubahan di-commit bersama setelah callback sukses; jika callback melempar error, tidak ada perubahan yang ditulis. Pada SQLite dipakai transaksi bawaan; pada PostgreSQL/MySQL memakai koneksi khusus dengan BEGIN/COMMIT.

### exportAll / importAll

```javascript
const snapshot = await driver.exportAll();
await target.importAll(snapshot, { replace: true });
```

## Monitoring

### healthCheck()
```javascript
const health = await db.healthCheck();
```
```json
{
  "manager": { "healthy": true, "type": "json", "degraded": false, "uptimeMs": 81234 },
  "driver":  { "healthy": true, "driver": "json", "latency": 0, "error": null },
  "store":   { "namespaces": 23, "dirty": 0, "flushes": 4 },
  "cache":   { "size": 2, "hits": 10, "misses": 1, "hitRate": 0.9091 }
}
```

### getStats()
```javascript
const stats = db.getStats();
```
Menambahkan statistik driver (`metrics.queries`, `avgQueryMs`, `connects`, `reconnects`, `errors`) dan untuk SQLite daftar jumlah baris per tabel.

### flushAll()
```javascript
await db.flushAll();
```
Menulis seluruh namespace dirty ke engine database. Dipanggil otomatis pada SIGINT/SIGTERM.

## Error Classes

Semua error database diturunkan dari `DatabaseError` dan memuat konteks:

```javascript
const { errors } = require('@Database');

try {
  await driver.get('user:x');
} catch (err) {
  if (err instanceof errors.ConnectionError) {
    // err.retryable === true, coba lagi atau reconnect
  } else if (err instanceof errors.QueryError) {
    // err.sql, err.params, err.namespace
  } else if (err instanceof errors.ValidationError) {
    // err.field
  } else if (err instanceof errors.MigrationError) {
    // err.step, err.rollbackAvailable
  } else if (err instanceof errors.DriverNotFoundError) {
    // err.type
  }
  err.toJSON();
}
```

## Wrappers kompatibel (dipakai plugin)

Lokasi: `database/wrappers/`, diekspos ulang lewat shim `App/function/*.js`.

### user.js
```javascript
addUser(jid) -> boolean
getUser(jid) -> object|false
reduceLimit(jid, amount=1) -> boolean
addLimit(jid, amount=1) -> boolean
claimLimit(jid, minutes=240) -> { success, message, amount? }
resetLimit(jid) -> boolean
addLevel(jid, amount=1) -> boolean
addLevelCache(jid, amount=1) -> boolean
editRole(jid, role) -> boolean
addMoney(jid, amount) -> boolean
reduceMoney(jid, amount) -> boolean
getUserStatistics() -> { totalUsers, topLimit, topLevel, topMoney }
```

### userDb.js (default export)
```javascript
ChatDB({ groupId, userId, action = 'add'|'reset'|'get', count = 1 })
```

### premium.js
```javascript
addPremiumUser(userId, duration) -> timestamp
checkPremiumUser(userId) -> boolean
getPremiumExpired(userId) -> timestamp|null
getPremiumPosition(userId) -> number
delPremiumUser(userId) -> { success, message, data }
getAllPremiumUser() -> [{ id, expired, status, remaining }]
expiredCheck() // interval 30 detik
createPremiumStore(storePath?) // storePath folder jadibot -> scoped store
```

### sewa.js
```javascript
getSewa(groupId?) -> object
addSewa(groupId, groupName, days) -> boolean
deleteSewa(groupId) -> boolean
listActiveSewa() -> [{ groupId, namegrup, start, expired, remaining }]
createSewaStore(dbPath?) // scoped store untuk jadibot
```

### bannedDB.js (default export)
```javascript
BannedDB({ userId, action = 'check'|'ban'|'unban', duration, reason })
```

### maintenance.js
```javascript
isMaintenance(owner, m) -> Promise<boolean>
enableMaintenance({ duration, reason })
disableMaintenance()
updateMaintenance(data)
getMaintenanceInfo()
formatDuration(ms)
formatDate(time)
```

### afkDb.js
```javascript
handleAFK({ Yudzxml, m })
setAFK(groupId, userId, reason)
unsetAFK(groupId, userId) -> data|false
getAFK(groupId, userId) -> data|null
addMention(groupId, userId) -> boolean
AFKController, TimeFormatter
```

### storage.js (generic)
```javascript
loadDB(filePath, defaultValue) -> data
saveDB(filePath, data) -> boolean
deleteDB(filePath) -> boolean
existsDB(filePath) -> boolean
```

### globalDB.js (pengganti lowdb)
```javascript
const { LowDBCompat, createGlobalDB } = require('@Database/wrappers/globalDB');
// API identik lowdb: .data, .read(), .write(), .chain
```

## Adapter per-file

```javascript
const JsonCompatAdapter = require('@Database/adapters/jsonAdapter');
const adapter = new JsonCompatAdapter('./Storage/custom.json', { hits: 0 });
adapter.loadDB();
adapter.saveDB({ hits: 1 });
adapter.update(data => ({ ...data, hits: data.hits + 1 }));
```

Namespace diturunkan dari path file: `Storage/redeem.json` menjadi `redeem`; file di `Storage/jadibot_sessions/<nomor>/<dataset>.json` menjadi `jadibot:<nomor>:<dataset>`.

## Integrasi website (REST)

Data yang sama dapat dibaca oleh backend website melalui koneksi langsung ke PostgreSQL/MySQL (tabel `users`, `premium_users`, `bot_sewa`, `payment_transactions`) sehingga tidak perlu endpoint tambahan. Gunakan kredensial read-only untuk keamanan. Lihat `docs/database-schema.md` untuk struktur tabel.

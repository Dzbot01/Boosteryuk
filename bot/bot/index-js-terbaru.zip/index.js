process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
const fs = require('fs');
function isBlockedByUser(err) {
    const message =
        err?.response?.body?.description ||
        err?.message ||
        String(err);

    return /403 Forbidden: bot was blocked by the user/i.test(String(message));
}
// Fungsi untuk menahan bot agar jadi "Zombie" dan nge-spam error di console
function tahanConsole(tipe, error) {
  if (isBlockedByUser(error)) return;
    console.log(`\n\n🚨🚨🚨 BOT MENGALAMI CRASH (${tipe}) 🚨🚨🚨`);
    console.log('TAPI SAYA TAHAN AGAR CONSOLE TIDAK TERTUTUP!');
    console.log('SILAKAN BACA ERROR DI BAWAH INI:\n');
    console.log(error.stack || error);
    console.log('\n=================================================');
    
    // Ini yang bikin bot ga mati dan terus nge-spam error tiap 5 detik
    setInterval(() => {
        console.log(`[ZOMBIE MODE] Penyebab Crash:`, error.message || error);
    }, 5000);
}

process.on('uncaughtException', function(err) {
    tahanConsole('UNCAUGHT EXCEPTION', err);
});

process.on('unhandledRejection', function(reason, promise) {
    tahanConsole('UNHANDLED REJECTION', reason);
});

const TelegramBot = require("node-telegram-bot-api");
const http = require('http');
const https = require('https');
const crypto = require('crypto');
const { Client } = require('ssh2');
const QRCode = require('qrcode');
const express = require('express');
const { exec } = require("child_process");
const ffmpeg = require('fluent-ffmpeg');
const path = require("path")
const axios = require("axios");
const settings = require("./database/settings.js");
// TAMBAH DI settings.json atau di atas
const LOG_CHANNEL_ID = -1003982464720; // ganti dengan ID channel log lu, harus diawali -100
const PUBLIC_IP = "185.205.222.202";
const PUBLIC_PORT = 10892;
const SMM_BASE = settings.smm.baseUrl;
const SMM_KEY = settings.smm.apiKey;
const SMM_ID = settings.smm.apiId;
const smmMode = new Set(); // user yg lagi mode cari kategori
// Mengambil adminId dari folder database/settings.js
const { adminId } = require('./database/settings'); 
const owner = settings.adminId;
const botToken = settings.token;
const adminfile = "./database/adminID.json";
const premiumUsersFile = "./database/premiumUsers.json";
const ASSEMBLY_API_KEY = "./database/settings.assemblyApiKey";
const domain = settings.domain;
const plta = settings.plta;
const pltc = settings.pltc;
let premiumUsers = [];
try {
  premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
} catch (error) {
  console.error("Error reading premiumUsers file:", error);
}
const bot = new TelegramBot(botToken, {
    polling: {
        params: {
            allowed_updates: JSON.stringify(["message", "callback_query"])
        }
    }
});
let adminUsers = [];
try {
  adminUsers = JSON.parse(fs.readFileSync(adminfile));
} catch (error) {
  console.error("Error reading adminUsers file:", error);
}
//Fungsi Auto Log ke Channel
// FUNGSI LOG UNIVERSAL
const originalLog = console.log;

//dbUser
// === DATABASE GLOBAL ===
// === DATABASE GLOBAL (aman) ===
global.dbUsers = global.dbUsers || {};
let dbUsers = global.dbUsers
//
function sendLog(title, data = "") {
    const text = String(data);
    
    // Tetap tampil di terminal
    originalLog(`[${title}]`, text);

    // Kirim ke channel - TANPA botUsername
    const logText = `📥 <b>${title}</b>
├ Data: <code>${text.slice(0, 3500)}</code>
└ Time: ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}`;

    if (LOG_CHANNEL_ID) {
        bot.sendMessage(LOG_CHANNEL_ID, logText, { parse_mode: "HTML" }).catch(e => {
            originalLog("Gagal kirim log ke channel:", e.message);
        });
    }
}

// OPTIONAL: Timpa console.log biar semua auto ke channel
console.log = (...args) => {
    const msg = args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ');
    sendLog("LOG", msg);
};
// Fungsi untuk mengambil data dari database timed
function getTimedServers() {
    const path = './database/timed_servers.json';
    try {
        if (!fs.existsSync(path)) {
            fs.writeFileSync(path, JSON.stringify({ slots: [], trialHistory: {} }));
        }
        let data = JSON.parse(fs.readFileSync(path));
        
        // Memaksa format menjadi Object jika data lama berbentuk Array
        if (Array.isArray(data)) data = { slots: data, trialHistory: {} };
        
        // Memastikan properti penting tidak kosong (Anti-Undefined)
        if (!data.slots) data.slots = [];
        if (!data.trialHistory) data.trialHistory = {};
        
        return data;
    } catch (e) {
        // Jika file rusak, kembalikan struktur default
        return { slots: [], trialHistory: {} };
    }
}
const SMM_FILE = path.join(__dirname, 'smm_services.json');

let globalServices = []; // cache 703 data di RAM

const FILE_TASK = path.join(__dirname, 'taskUser.json');

const campaigns = [
  {
    id: 'gmail',
    name: 'Buat Akun Gmail',
    photo: 'https://cdn.phototourl.com/member/2026-06-20-59db53e6-1c71-400e-af87-6c7c9d059ba8.png',
    bayaran: 1600,
    password: 'Ajax1122*',
    desc: `Buatkan Akun Gmail baru dengan nama Amerika Laki laki atau Perempuan, Ambil namanya wajib dari sini :\n\n• https://www.fakenamegenerator.com/gen-male-en-uk.php (Laki laki)\n• https://www.fakenamegenerator.com/gen-female-us-us.php (Perempuan)\n\nGunakan Password : Ajax1122*\n\nSetelah kirim tugas pastikan anda sudah Logout (menghapus akun dari perangkat anda) Jika tidak maka tugas akan di tolak.`
  }
  // nanti kalo ada campaign lain tinggal tambah di sini
];

const userState = {};
const smmCache = {};

const PET_IMAGES = {
  blaze: { // ganti dari egg
    baby: 'https://cdn.phototourl.com/member/2026-06-18-1096b0c3-6027-46dc-8e8b-85b5c9e59eb7.png',
    grown: 'https://cdn.phototourl.com/member/2026-06-18-854bab91-550e-4912-ad47-0d5d76ae3926.png',
    adult: 'https://cdn.phototourl.com/member/2026-06-18-dc895406-294e-4fd1-94fa-10c7f604477d.png'
  },
  leafy: { // ganti dari tree
    baby: 'https://cdn.phototourl.com/member/2026-06-18-5d2714d6-8cd2-43ca-a4c2-5979a7dfef2f.jpg',
    grown: 'https://cdn.phototourl.com/member/2026-06-18-9230e686-0c6b-4437-be4f-ec7c3b03d29e.png',
    adult: 'https://cdn.phototourl.com/member/2026-06-18-3c92c8dd-73d9-43b8-82df-6d85b23680fb.webp'
  },
  pawsy: { // ganti dari cat
    baby: 'https://cdn.phototourl.com/member/2026-06-18-5e0d7a24-1e3b-4792-97bd-4757af668870.jpg',
    grown: 'https://cdn.phototourl.com/member/2026-06-18-c7b304ea-3822-4d99-b877-2229e6bc180f.jpg',
    adult: 'https://cdn.phototourl.com/member/2026-06-18-cf2676ee-af6e-4655-b6e0-2f4b09da243a.jpg'
  }
}

function getPetImage(pet) {
  const typeMap = {
    egg: 'blaze',
    tree: 'leafy',
    cat: 'pawsy',
    blaze: 'blaze',
    leafy: 'leafy',
    pawsy: 'pawsy'
  }

  const type = (pet.type || 'blaze').toLowerCase()
  const key = typeMap[type] || 'blaze' // convert egg -> blaze
  const imgs = PET_IMAGES[key]

  if(!imgs) return 'https://via.placeholder.com/400x400.png?text=Pet'

  const maxLevel = pet.maxLevel || 10
  const level = pet.level || 0
  const halfLevel = Math.floor(maxLevel / 2)

  if(level >= maxLevel) return imgs.adult
  if(level >= halfLevel) return imgs.grown
  return imgs.baby
}

function getRemainingXP(pet, mode = 'next') {
  if(mode === 'next') {
    // Sisa XP buat naik level selanjutnya
    const needLevel = (pet.level + 1) * 10
    return needLevel - pet.xp
  } 
  if(mode === 'max') {
    // Sisa XP sampe level max
    const totalXP = pet.maxLevel * 10
    const currentXP = pet.level * 10 + pet.xp
    return totalXP - currentXP
  }
}


const DB_PATH = './database/pets.json' // bikin folder database kalo belum ada

// Load DB JSON
function loadDB() {
  if(!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, '{}') // bikin file kosong kalo belum ada
  }
  return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'))
}

// Simpen DB JSON
function saveDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2))
}

function cleanDesc(desc) {
  if (!desc) return 'Tidak ada deskripsi';

  // Hapus tag HTML, ganti <br> <p> jadi \n
  desc = desc.replace(/<br\s*\/?>/gi, '\n');
  desc = desc.replace(/<\/p>/gi, '\n');
  desc = desc.replace(/<[^>]+>/g, '');

  // Ganti simbol • jadi quote Telegram
  desc = desc.replace(/•/g, '▫️');

  // Hapus spasi berlebih
  desc = desc.replace(/\n\s*\n/g, '\n').trim();

  return desc;
}
//POTONG DAN REFUND SALDO DI WEBSITE
const WORKER = "https://boosteryuk.boosteryukid.workers.dev";

// Balasan Worker/website kadang bukan JSON (mis. halaman Cloudflare "error code: 502").
// Jangan lempar error "Unexpected token": kembalikan objek gagal yang jelas.
async function bacaJsonAman(r, label) {
  const txt = await r.text();
  try { return JSON.parse(txt); } catch {
    const ringkas = String(txt).replace(/\s+/g, " ").trim().slice(0, 80);
    console.log(`[${label}] balasan bukan JSON (HTTP ${r.status}): ${ringkas}`);
    return { status: false, success: false, gangguan: true, http: r.status, msg: `Server saldo/pembayaran sedang gangguan (HTTP ${r.status}). Coba lagi beberapa menit lagi.`, message: `gangguan HTTP ${r.status}`, raw: ringkas };
  }
}
const lastGangguanSaldo = {};
function laporGangguanSaldo(jenis, telegram_id, amount, res) {
  if (Date.now() - (lastGangguanSaldo[jenis] || 0) < 5 * 60 * 1000) return; // maks 1 notif / 5 menit per jenis
  lastGangguanSaldo[jenis] = Date.now();
  bot.sendMessage(settings.adminId, `<blockquote>⚠️ <b>WORKER SALDO GANGGUAN (${jenis})</b>\n🆔 User: <code>${telegram_id}</code>\n💵 Rp ${Number(amount).toLocaleString("id-ID")}\n❗ HTTP ${res.http}: ${String(res.raw || "").replace(/[<>&]/g, "")}\n\nCek boosteryuk.com/api & Worker. Kalau saldo user ternyata terpotong, kembalikan manual.</blockquote>`, { parse_mode: "HTML" }).catch(() => {});
}

async function potongSaldoReal(telegram_id, amount, note = "order bot") {
  try {
    const r = await fetch(`${WORKER}/api/telegram/deduct`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ telegram_id, amount, note }),
      signal: AbortSignal.timeout(20000)
    });
    const res = await bacaJsonAman(r, "DEDUCT"); // { status:true, new_balance, deducted } atau { status:false, msg }
    if (res.gangguan) laporGangguanSaldo("potong", telegram_id, amount, res);
    return res;
  } catch (e) {
    return { status: false, gangguan: true, msg: `Server saldo tidak bisa dihubungi (${e.message}). Coba lagi beberapa menit lagi.` };
  }
}
//TRIPAY API WORKER
const WORKER_TRIPAY = "https://boosteryuk.boosteryukid.workers.dev/api/tripay";
const qrisDiproses = new Set(); // referensi yang sudah diproses (idealnya simpan ke file/DB)
const qrisPending = new Map(); // reference -> { chatId, userId, session, amount, messageId, timer }

async function buatQrisTripay({ amount, merchant_ref, customer_name }) {
    const r = await fetch(`${WORKER_TRIPAY}/create`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount, method: "QRIS", merchant_ref, customer_name, expired_seconds: 1800 })
    });
    return await bacaJsonAman(r, "TRIPAY CREATE");
}

async function statusTripay(reference) {
    const r = await fetch(`${WORKER_TRIPAY}/status?reference=${encodeURIComponent(reference)}`);
    return await bacaJsonAman(r, "TRIPAY STATUS");
}
async function refundSaldoReal(telegram_id, amount, note = "refund bot") {
  const r = await fetch(`${WORKER}/api/telegram/refund`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ telegram_id, amount, note })
  });
  const res = await bacaJsonAman(r, "REFUND"); // { status:true, new_balance:33000, refunded:5000 }
  if (res.gangguan) laporGangguanSaldo("refund", telegram_id, amount, res);
  return res;
}
// ====================================================
// KREDIT SALDO WEBSITE (deposit, hadiah gacha)
// ====================================================
// Endpoint penambah saldo di Worker = /api/telegram/refund (sama dengan refundSaldoReal).
// Retry hanya kalau request tidak sampai (error jaringan). Kalau server sudah menjawab tapi
// jawabannya tidak jelas, JANGAN retry (bisa kredit ganda) -> catat pending & lapor admin.
const KREDIT_PENDING_FILE = "./database/kredit_pending.json";
function saldoSukses(r) {
    return !!r && (r.status === true || r.status === "true" || r.status === "success" || r.success === true || r.ok === true);
}
async function kreditSaldoWebsite(telegram_id, amount, note) {
    let alasan = "";
    for (let coba = 1; coba <= 2; coba++) {
        let resp;
        try {
            resp = await fetch(`${WORKER}/api/telegram/refund`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ telegram_id, amount, note }),
                signal: AbortSignal.timeout(20000)
            });
        } catch (e) {
            alasan = `jaringan: ${e.message}`;
            if (coba === 1) { await new Promise(r => setTimeout(r, 1500)); continue; }
            break;
        }
        const txt = await resp.text();
        let r; try { r = JSON.parse(txt); } catch { r = null; }
        if (saldoSukses(r)) return { ...r, status: true, new_balance: Number(r.new_balance ?? r.balance ?? r.saldo ?? 0) };
        alasan = (r && (r.msg || r.message)) || `respon tidak dikenal: ${String(txt).slice(0, 120)}`;
        break;
    }
    try {
        const list = fs.existsSync(KREDIT_PENDING_FILE) ? JSON.parse(fs.readFileSync(KREDIT_PENDING_FILE, "utf8")) : [];
        list.push({ telegram_id, amount, note, alasan, at: new Date().toISOString() });
        fs.writeFileSync(KREDIT_PENDING_FILE, JSON.stringify(list, null, 2));
    } catch (e) { console.log("Gagal catat kredit pending:", e.message); }
    bot.sendMessage(settings.adminId, `<blockquote>⚠️ <b>KREDIT SALDO WEBSITE GAGAL</b>\n🆔 User: <code>${telegram_id}</code>\n💵 Rp ${Number(amount).toLocaleString("id-ID")}\n📝 ${String(note).replace(/[<>&]/g, "")}\n❗ ${String(alasan).replace(/[<>&]/g, "")}\n\nTercatat di database/kredit_pending.json, kreditkan manual.</blockquote>`, { parse_mode: "HTML" }).catch(() => {});
    return { status: false, msg: alasan };
}
//Ambil saldo dari website boosteryuk
// TARUH DI ATAS SEKALI, DEKAT getStore()
// === GET SALDO REAL - VERSI FINAL ===
async function getSaldoReal(chatId) {
    try {
        const url = `https://boosteryuk.boosteryukid.workers.dev/api/telegram/check?telegram_id=${chatId}`;
        const response = await fetch(url);
        const text = await response.text();
        
        let res;
        try { res = JSON.parse(text); } catch(e) {
            // kalau dapet "Worker Active" (bukan JSON valid atau JSON ok/message)
            if (text.includes("Worker Active")) {
                console.log(`[CHECK WORKER ACTIVE] ${chatId}`);
                throw new Error("Worker Active");
            }
            console.log(`[CHECK 502] ${chatId} -> ${text.substring(0,100)}`);
            throw new Error("bukan json");
        }

        // FIX: support 2 format
        const isLinked = res.status === true || res.ok === true;
        if (isLinked) {
            const saldo = Number(res.balance || res.saldo || 0);
            if (global.dbUsers[chatId]) global.dbUsers[chatId].saldo = saldo;
            else global.dbUsers[chatId] = { saldo };
            dbUsers = global.dbUsers;
            return saldo;
        } else {
            // kalau msg nya Worker Active, jangan return 0, fallback ke lokal
            if ((res.msg || res.message || "").includes("Worker Active")) {
                throw new Error("Worker Active");
            }
            return 0;
        }
    } catch (e) {
        try {
            return Number(global.dbUsers[chatId]?.saldo || dbUsers[chatId]?.saldo || 0);
        } catch { return 0; }
    }
}
//Load Fayupedia
async function loadSMMServices() {
  try {
    // Cek file JSON ada ga
    if (fs.existsSync(SMM_FILE)) {
      const data = fs.readFileSync(SMM_FILE, 'utf8');
      globalServices = JSON.parse(data);
      console.log(`✅ Load ${globalServices.length} layanan dari smm_services.json`);

      // Auto refresh di background tiap 1 jam
      setInterval(refreshServices, 3600000);
      return;
    }

    // Kalo file ga ada, fetch baru
    await refreshServices();
    setInterval(refreshServices, 3600000);
  } catch (e) {
    console.error('Gagal load services:', e);
  }
}

async function refreshServices() {
  console.log('⏳ Refresh 703 layanan dari API...');
  try {
    const res = await axios.post(`${SMM_BASE}/services`, {
      api_id: SMM_ID,
      api_key: SMM_KEY,
      action: 'services'
    });

    if (res.data.status === true) {
      globalServices = res.data.services;
      fs.writeFileSync(SMM_FILE, JSON.stringify(globalServices));
      console.log(`✅ Berhasil refresh & simpan ${globalServices.length} layanan`);
    }
  } catch (e) {
    console.error('Gagal refresh services:', e.message);
  }
}

// ====================================================
// SMM: KATEGORI -> LAYANAN (berdasarkan field category, contoh "Tiktok Likes", "Tiktok View")
// ====================================================
const smmCariTerakhir = {}; // chatId -> kata kunci terakhir (untuk tombol kembali)
const smmEsc = t => String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
function smmHash(str) {
    let h = 0;
    for (const ch of String(str)) h = (h * 31 + ch.codePointAt(0)) >>> 0;
    return h.toString(36);
}
function smmKategoriDari(hash) {
    for (const s of globalServices) {
        const c = String(s.category || "").trim();
        if (c && smmHash(c) === hash) return c;
    }
    return null;
}
// -> [[kategori, jumlahLayanan, hargaTermurah]] yang cocok dengan kata kunci (nama kategori, lalu nama layanan)
function smmKategoriCocok(keyword) {
    const k = String(keyword || "").toLowerCase().trim();
    const map = new Map();
    const catat = s => {
        const c = String(s.category || "").trim();
        const ada = map.get(c) || [c, 0, Infinity];
        ada[1]++; ada[2] = Math.min(ada[2], Number(s.price) || Infinity);
        map.set(c, ada);
    };
    for (const s of globalServices) if (String(s.category || "").toLowerCase().includes(k)) catat(s);
    if (!map.size) for (const s of globalServices) if (String(s.name || "").toLowerCase().includes(k)) catat(s);
    return [...map.values()].sort((a, b) => a[0].localeCompare(b[0]));
}

async function smmKirimKategori(chatId, keyword) {
    const list = smmKategoriCocok(keyword);
    if (!list.length) {
        const kata3 = String(keyword).toLowerCase().slice(0, 3);
        const saran = [...new Set(globalServices.map(s => String(s.category || "").split(" ")[0]))]
            .filter(k => k && k.toLowerCase().includes(kata3)).slice(0, 6);
        await bot.sendMessage(chatId, `❌ Kategori "<b>${smmEsc(keyword)}</b>" tidak tersedia.` +
            (saran.length ? `\n\nMungkin maksud kamu: ${saran.map(x => `<code>${smmEsc(x)}</code>`).join(", ")}` : "") +
            `\n\nKetik ulang atau /cancel`, { parse_mode: "HTML" });
        return false;
    }
    smmCariTerakhir[chatId] = keyword;
    const total = list.reduce((n, x) => n + x[1], 0);
    const tampil = list.slice(0, 40);
    const btn = tampil.map(([cat, n], i) => [{ text: `📂 ${i + 1}. ${cat} (${n})`, callback_data: `sk|${smmHash(cat)}|1` }]);
    btn.push([{ text: "🔎 Cari Kategori Lain", callback_data: "kat" }]);
    const rp = n => Number.isFinite(n) ? `Rp${Number(n).toLocaleString("id-ID")}` : "-";
    // Rich message: deskripsi, garis pembatas, tabel; tombol menempel di pesan yang sama
    const gambar = /^https?:\/\//i.test(settings.pp || "") ? `<img src="${smmEsc(settings.pp)}"/>\n` : "";
    const html = `${gambar}<h3>💎 SMM PANEL</h3>\n` +
        `<p>Hasil "<b>${smmEsc(keyword)}</b>": ${list.length} kategori, ${total} layanan. Pilih jenis layanan (Follower, Like, View, dll) lewat tombol bernomor di bawah tabel.</p>\n<hr/>\n` +
        `<table bordered striped compact>\n  <tr><th>No</th><th>Kategori</th><th>Layanan</th><th>Mulai dari /1k</th></tr>\n` +
        tampil.map(([cat, n, min], i) => `  <tr><td>${i + 1}</td><td>${smmEsc(cat)}</td><td>${n}</td><td>${rp(min)}</td></tr>`).join("\n") +
        `\n</table>`;
    const caption = `<b>💎 SMM PANEL</b>\nHasil "<b>${smmEsc(keyword)}</b>": ${list.length} kategori, ${total} layanan\n━━━━━━━━━━━━━━━━━━\n` +
        `<blockquote>Pilih jenis layanan (Follower, Like, View, dll):</blockquote>`;
    await sendRichMessage(chatId, html, { reply_markup: { inline_keyboard: btn } })
        .catch(() => bot.sendPhoto(chatId, settings.pp, { caption, parse_mode: "HTML", reply_markup: { inline_keyboard: btn } }))
        .catch(() => bot.sendMessage(chatId, caption, { parse_mode: "HTML", reply_markup: { inline_keyboard: btn } }));
    return true;
}

async function smmKirimLayanan(chatId, messageId, kategori, page) {
    const semua = globalServices
        .filter(s => String(s.category || "").trim() === kategori)
        .sort((a, b) => (Number(a.price) || 0) - (Number(b.price) || 0));
    const perPage = 10;
    const totalPage = Math.max(1, Math.ceil(semua.length / perPage));
    page = Math.min(Math.max(1, page), totalPage);
    const list = semua.slice((page - 1) * perPage, page * perPage);

    const rp = n => `Rp${Number(n || 0).toLocaleString("id-ID")}`;
    const ang = n => Number(n || 0).toLocaleString("id-ID");
    // Rich message: deskripsi, garis pembatas, tabel; tombol menempel di pesan yang sama
    const html = `<h3>📑 ${smmEsc(kategori)}</h3>\n` +
        `<p>Halaman ${page}/${totalPage} • ${semua.length} layanan. Klik tombol bernomor di bawah tabel untuk order.</p>\n<hr/>\n` +
        `<table bordered striped compact>\n  <tr><th>No</th><th>Layanan</th><th>Harga /1k</th><th>Min</th><th>Max</th></tr>\n` +
        list.map((s, i) => `  <tr><td>${(page - 1) * perPage + i + 1}</td><td>${smmEsc(s.name)}</td><td>${rp(smmHargaPer1k(s))}</td><td>${ang(s.min)}</td><td>${ang(s.max)}</td></tr>`).join("\n") +
        `\n</table>`;
    let text = `<b>📑 ${smmEsc(kategori)}</b>\nHalaman ${page}/${totalPage} • ${semua.length} layanan\n━━━━━━━━━━━━━━━━━━\n\n`;
    list.forEach((s, i) => {
        text += `<b>${(page - 1) * perPage + i + 1}.</b> ${smmEsc(s.name)}\n   💰 ${rp(smmHargaPer1k(s))}/1k • Min ${Number(s.min).toLocaleString("id-ID")} • Max ${Number(s.max).toLocaleString("id-ID")}\n`;
    });
    text += `\n<i>Klik layanan untuk order.</i>`;

    const btn = list.map((s, i) => [{ text: `${(page - 1) * perPage + i + 1}. ${String(s.name).slice(0, 45)} • ${rp(smmHargaPer1k(s))}/1k`, callback_data: `o|${s.id}` }]);
    const h = smmHash(kategori);
    const nav = [];
    if (page > 1) nav.push({ text: "⬅️ Sebelumnya", callback_data: `sk|${h}|${page - 1}` });
    if (page < totalPage) nav.push({ text: "Selanjutnya ➡️", callback_data: `sk|${h}|${page + 1}` });
    if (nav.length) btn.push(nav);
    btn.push([{ text: "⬅️ Ganti Jenis Layanan", callback_data: "sks|" }, { text: "🔎 Cari Lain", callback_data: "kat" }]);

    if (messageId) await bot.deleteMessage(chatId, messageId).catch(() => {});
    return sendRichMessage(chatId, html, { reply_markup: { inline_keyboard: btn } })
        .catch(() => bot.sendMessage(chatId, text, { parse_mode: "HTML", reply_markup: { inline_keyboard: btn } }));
}

// ====================================================
// SMM: ORDER LAYANAN (link -> komentar/jumlah -> ringkasan -> Pesan)
// ====================================================
// Order dikirim langsung ke API panel SMM (settings.smm). Default endpoint `${baseUrl}/order`
// dengan api_id/api_key (pola yang sama dengan /services). Bisa diubah lewat settings.smm.orderPath.
const SMM_ORDER_FILE = path.join(__dirname, "database", "smm_orders.json");
const smmOrderLock = new Set();

// Harga jual per 1000 (harga panel + markup opsional settings.smm.markupPersen)
function smmHargaPer1k(s) {
    const m = Number((settings.smm || {}).markupPersen) || 0;
    return Math.ceil((Number(s.price) || 0) * (1 + m / 100));
}
function smmTotal(s, qty) {
    return Math.max(1, Math.ceil(smmHargaPer1k(s) * Number(qty) / 1000));
}
// Layanan komentar custom: user mengetik komentar sendiri, 1 baris = 1 komentar
function smmButuhKomentar(s) {
    const tipe = String(s.type || "").toLowerCase();
    if (tipe.includes("custom_comment") || tipe.includes("comments")) return true;
    const teks = `${s.name || ""} ${s.category || ""}`.toLowerCase();
    return /(komentar|comment)/.test(teks) && /(custom|kustom)/.test(teks);
}
function smmRp(n) { return `Rp${Number(n || 0).toLocaleString("id-ID")}`; }
function smmCatatOrder(rec) {
    try {
        const list = fs.existsSync(SMM_ORDER_FILE) ? JSON.parse(fs.readFileSync(SMM_ORDER_FILE, "utf8")) : [];
        list.push(rec);
        fs.writeFileSync(SMM_ORDER_FILE, JSON.stringify(list.slice(-2000), null, 2));
    } catch (e) { console.log("[SMM] gagal catat order:", e.message); }
}

// Pesan error panel -> bahasa user
function smmTerjemahError(msg) {
    const m = String(msg || "").toLowerCase();
    if (/saldo|balance|insufficient|not enough/.test(m)) return "Stok layanan di server sedang kosong. Admin sudah diberi tahu.";
    if (/link|target|url|username/.test(m)) return "Link/target tidak valid atau tidak bisa diproses. Periksa lagi link-nya (akun harus publik).";
    if (/min|max|quantity|jumlah/.test(m)) return "Jumlah pesanan di luar batas minimal/maksimal layanan.";
    if (/service|layanan|disabled|nonaktif|not found/.test(m)) return "Layanan ini sedang tidak tersedia. Pilih layanan lain.";
    if (/comment|komentar/.test(m)) return "Format komentar ditolak. Pastikan 1 baris = 1 komentar.";
    if (/active order|pending|sudah ada pesanan|duplicate/.test(m)) return "Masih ada pesanan aktif untuk link yang sama. Tunggu selesai dulu.";
    return "Pesanan ditolak server. Coba lagi beberapa saat atau pilih layanan lain.";
}

// Kirim order ke panel. Hasil: { ok, orderId, pesan, pasti } ; pasti=false = tidak jelas apakah order terbuat (timeout / bukan JSON)
async function smmBuatOrder({ serviceId, target, quantity, komentar }) {
    const c = settings.smm || {};
    const url = `${String(c.baseUrl || SMM_BASE).replace(/\/$/, "")}${c.orderPath || "/order"}`;
    const body = {
        api_id: c.apiId, api_key: c.apiKey, action: "order",
        service: serviceId, target, link: target, quantity
    };
    if (komentar) { body.custom_comments = komentar; body.comments = komentar; }
    let r;
    try {
        r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), signal: AbortSignal.timeout(30000) });
    } catch (e) {
        // Request mungkin sudah sampai; jangan refund otomatis
        return { ok: false, pasti: false, pesan: `koneksi ke panel terputus (${e.message})` };
    }
    const txt = await r.text();
    let d; try { d = JSON.parse(txt); } catch { d = null; }
    if (!d) return { ok: false, pasti: r.status >= 400 && r.status < 500, pesan: `balasan panel bukan JSON (HTTP ${r.status}): ${txt.replace(/\s+/g, " ").slice(0, 80)}` };
    const ok = d.status === true || d.status === "true" || d.status === "success" || d.success === true;
    const data = d.data && typeof d.data === "object" ? d.data : {};
    const orderId = data.id ?? data.order ?? data.order_id ?? d.order ?? d.order_id ?? d.id ?? null;
    const pesan = data.msg ?? d.msg ?? d.message ?? d.error ?? data.message ?? "";
    if (ok && orderId != null) return { ok: true, pasti: true, orderId: String(orderId), pesan };
    if (ok) return { ok: false, pasti: false, pesan: `panel menjawab sukses tanpa ID order: ${String(pesan).slice(0, 80)}` };
    return { ok: false, pasti: true, pesan: String(pesan || "ditolak tanpa keterangan") };
}

function smmBatalTombol() { return { inline_keyboard: [[{ text: "❌ Batal", callback_data: "smo_batal" }]] }; }

async function smmMulaiOrder(chatId, serviceId) {
    const s = globalServices.find(x => String(x.id) === String(serviceId));
    if (!s) return bot.sendMessage(chatId, "❌ Layanan tidak ditemukan. Daftar layanan mungkin baru diperbarui, silakan cari lagi.", { reply_markup: { inline_keyboard: [[{ text: "🔎 Cari Kategori", callback_data: "kat" }]] } });
    smmMode.delete(chatId);
    userSessions[chatId] = { type: "smm_order", step: "smm_link", serviceId: String(s.id) };
    const komentar = smmButuhKomentar(s);
    return bot.sendMessage(chatId,
        `<blockquote>🛒 <b>ORDER SMM</b>\n━━━━━━━━━━━━━━━━━━\n` +
        `📦 <b>${smmEsc(s.name)}</b>\n📂 ${smmEsc(s.category || "-")}\n` +
        `💰 ${smmRp(smmHargaPer1k(s))} / 1.000\n📊 Min ${Number(s.min).toLocaleString("id-ID")} • Max ${Number(s.max).toLocaleString("id-ID")}` +
        (komentar ? `\n💬 Layanan komentar: 1 baris = 1 komentar` : "") +
        `</blockquote>\n🔗 Kirim <b>link / URL target</b> (akun harus publik):`,
        { parse_mode: "HTML", reply_markup: smmBatalTombol() });
}

async function smmTampilRingkasan(chatId) {
    const ses = userSessions[chatId];
    const s = globalServices.find(x => String(x.id) === ses.serviceId);
    if (!s) { delete userSessions[chatId]; return bot.sendMessage(chatId, "❌ Layanan tidak ditemukan, silakan order ulang."); }
    ses.step = "smm_konfirm";
    ses.harga = smmTotal(s, ses.quantity);
    ses.paket = `SMM ${s.name} x${ses.quantity}`;
    const komen = ses.komentar ? `\n💬 Komentar: ${ses.quantity} baris` : "";
    return bot.sendMessage(chatId,
        `<blockquote>🧾 <b>RINGKASAN PESANAN</b>\n━━━━━━━━━━━━━━━━━━\n` +
        `📦 Layanan: <b>${smmEsc(s.name)}</b>\n🔗 Target: <code>${smmEsc(ses.target)}</code>\n` +
        `🔢 Jumlah: <b>${Number(ses.quantity).toLocaleString("id-ID")}</b>${komen}\n` +
        `💰 Harga: ${smmRp(smmHargaPer1k(s))} / 1.000\n━━━━━━━━━━━━━━━━━━\n💵 Total: <b>${smmRp(ses.harga)}</b></blockquote>\n` +
        `Pilih cara bayar, pesanan langsung diproses setelah pembayaran berhasil:`,
        {
            parse_mode: "HTML", reply_markup: { inline_keyboard: [
                [{ text: "🛒 Pesan • Bayar Saldo", callback_data: "smo_saldo", style: "success" }],
                [{ text: "⚡ Pesan • QRIS 1 (Fast)", callback_data: "smo_qris", style: "success" }],
                [{ text: "❌ Batal", callback_data: "smo_batal" }]
            ] }
        });
}

// Jalankan order setelah dibayar. Gagal pasti -> lempar error (pemanggil mengembalikan dana).
// Gagal tidak pasti -> tidak dilempar: admin cek manual supaya tidak terjadi order jalan + dana kembali.
async function smmProsesSetelahBayar(chatId, ses, refId) {
    const s = globalServices.find(x => String(x.id) === String(ses.serviceId)) || { name: ses.serviceId };
    await bot.sendMessage(chatId, "⏳ Memproses pesanan...").catch(() => {});
    const hasil = await smmBuatOrder({ serviceId: ses.serviceId, target: ses.target, quantity: ses.quantity, komentar: ses.komentar });
    const rec = { at: new Date().toISOString(), userId: chatId, ref: refId, serviceId: ses.serviceId, layanan: s.name, target: ses.target, quantity: ses.quantity, total: ses.harga, orderId: hasil.orderId || null, status: hasil.ok ? "SUKSES" : hasil.pasti ? "DITOLAK" : "PERLU_CEK", pesan: hasil.pesan };
    smmCatatOrder(rec);
    if (hasil.ok) {
        await bot.sendMessage(chatId,
            `<blockquote>✅ <b>PESANAN BERHASIL DIBUAT</b>\n━━━━━━━━━━━━━━━━━━\n🆔 ID Pesanan: <code>${hasil.orderId}</code>\n📦 ${smmEsc(s.name)}\n🔗 <code>${smmEsc(ses.target)}</code>\n🔢 ${Number(ses.quantity).toLocaleString("id-ID")}\n💵 ${smmRp(ses.harga)}\n\nPesanan sedang diproses panel. Simpan ID pesanan untuk cek status / refill.</blockquote>`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "🛍 Order Lagi", callback_data: "kat", style: "success" }]] } }).catch(() => {});
        bot.sendMessage(settings.adminId, `<blockquote>💎 <b>INCOME: SMM</b>\n━━━━━━━━━━━━━━━━━━\n🆔 User: <code>${chatId}</code>\n📦 ${smmEsc(s.name)}\n🔢 ${ses.quantity} • ${smmRp(ses.harga)}\n🧾 Order panel: <code>${hasil.orderId}</code> • Ref: <code>${refId}</code></blockquote>`, { parse_mode: "HTML" }).catch(() => {});
        return;
    }
    if (!hasil.pasti) {
        await bot.sendMessage(chatId, `⚠️ Server SMM tidak memberi jawaban yang jelas, jadi status pesananmu belum pasti.\nAdmin akan mengecek dan memproses atau mengembalikan dana. Ref: <code>${refId}</code>`, { parse_mode: "HTML" }).catch(() => {});
        bot.sendMessage(settings.adminId, `<blockquote>⚠️ <b>ORDER SMM PERLU DICEK</b>\n🆔 User: <code>${chatId}</code>\n📦 ${smmEsc(s.name)} (ID ${ses.serviceId})\n🔗 <code>${smmEsc(ses.target)}</code>\n🔢 ${ses.quantity} • ${smmRp(ses.harga)} (sudah dibayar)\n🧾 Ref: <code>${refId}</code>\n❗ ${smmEsc(hasil.pesan)}\n\nCek di dashboard panel: kalau order tidak ada, kembalikan dana user.</blockquote>`, { parse_mode: "HTML" }).catch(() => {});
        return;
    }
    if (/saldo|balance|insufficient/i.test(hasil.pesan)) {
        bot.sendMessage(settings.adminId, `<blockquote>⚠️ <b>SALDO PANEL SMM HABIS</b>\n${smmEsc(hasil.pesan)}\nOrder user ${chatId} ditolak & dana dikembalikan.</blockquote>`, { parse_mode: "HTML" }).catch(() => {});
    }
    const e = new Error(smmTerjemahError(hasil.pesan));
    e.detailPanel = hasil.pesan;
    throw e;
}

async function smmBayarSaldo(query) {
    const chatId = query.message.chat.id;
    const userId = query.from.id;
    const ses = userSessions[chatId];
    if (!ses || ses.type !== "smm_order" || ses.step !== "smm_konfirm") {
        return bot.answerCallbackQuery(query.id, { text: "Sesi pesanan sudah berakhir, silakan order ulang.", show_alert: true });
    }
    if (smmOrderLock.has(userId)) return bot.answerCallbackQuery(query.id, { text: "⏳ Pesanan sebelumnya masih diproses...", show_alert: true });
    smmOrderLock.add(userId);
    try {
        await bot.answerCallbackQuery(query.id, { text: "Memproses..." }).catch(() => {});
        const pesanan = { ...ses };
        const potong = await potongSaldoReal(userId, pesanan.harga, `Order ${pesanan.paket}`);
        if (!potong || !potong.status) {
            return bot.sendMessage(chatId, `❌ Pembayaran saldo gagal: ${(potong && (potong.msg || potong.message)) || "saldo tidak cukup"}\n💰 Total: ${smmRp(pesanan.harga)}\n\nBayar langsung pakai QRIS, atau top up saldo dulu.`, {
                reply_markup: { inline_keyboard: [
                    [{ text: "⚡ Pesan • QRIS 1 (Fast)", callback_data: "smo_qris", style: "success" }],
                    [{ text: "➕ Top Up Saldo", callback_data: "menu_deposit", style: "success" }]
                ] }
            });
        }
        delete userSessions[chatId];
        await bot.deleteMessage(chatId, query.message.message_id).catch(() => {});
        const refId = `SMM-${Date.now()}`;
        try {
            await smmProsesSetelahBayar(chatId, pesanan, refId);
        } catch (e) {
            const r = await refundSaldoReal(userId, pesanan.harga, `Refund ${refId} - ${e.detailPanel || e.message}`).catch(() => ({ status: false }));
            if (!r || !r.status) bot.sendMessage(settings.adminId, `⚠️ REFUND SMM GAGAL user ${userId} ${smmRp(pesanan.harga)} (${refId})`).catch(() => {});
            await bot.sendMessage(chatId, `❌ <b>Pesanan gagal</b>\n${smmEsc(e.message)}\n\n${r && r.status ? `↩️ Saldo ${smmRp(pesanan.harga)} sudah dikembalikan.` : "Admin akan mengembalikan saldo secara manual."}`, {
                parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "🔎 Pilih Layanan Lain", callback_data: "kat", style: "success" }]] }
            }).catch(() => {});
        }
    } finally {
        smmOrderLock.delete(userId);
    }
}

async function smmBayarQris(query) {
    const chatId = query.message.chat.id;
    const userId = query.from.id;
    const ses = userSessions[chatId];
    if (!ses || ses.type !== "smm_order" || !ses.harga) {
        return bot.answerCallbackQuery(query.id, { text: "Sesi pesanan sudah berakhir, silakan order ulang.", show_alert: true });
    }
    userSessions[userId] = { ...ses, type: "smm", userId, chatId }; // tipe "smm" dikenali QRIS & handlePaymentSuccess
    return bot.emit("callback_query", { ...query, data: "pay_qris_tripay" });
}

bot.on("callback_query", async (query) => {
    const data = query.data || "";
    if (!data.startsWith("smo_")) return;
    if (menuTertutupUntuk(data, query.from.id)) return;
    const chatId = query.message.chat.id;
    try {
        if (data === "smo_batal") {
            delete userSessions[chatId];
            await bot.answerCallbackQuery(query.id, { text: "Pesanan dibatalkan" }).catch(() => {});
            await bot.deleteMessage(chatId, query.message.message_id).catch(() => {});
            return bot.sendMessage(chatId, "❌ Pesanan SMM dibatalkan.", { reply_markup: { inline_keyboard: [[{ text: "🔎 Cari Layanan", callback_data: "kat", style: "success" }]] } });
        }
        if (data === "smo_saldo") return await smmBayarSaldo(query);
        if (data === "smo_qris") return await smmBayarQris(query);
    } catch (e) {
        console.log("[SMM ORDER] callback error:", e.message);
        bot.answerCallbackQuery(query.id, { text: "⚠️ Terjadi kesalahan, coba lagi.", show_alert: true }).catch(() => {});
    }
});

// Input teks: link -> komentar / jumlah
bot.on("message", async (msg) => {
    const chatId = msg.chat.id;
    const ses = userSessions[chatId];
    if (!ses || ses.type !== "smm_order" || !["smm_link", "smm_komentar", "smm_qty"].includes(ses.step) || !msg.text || msg.text.startsWith("/")) return;
    const s = globalServices.find(x => String(x.id) === ses.serviceId);
    if (!s) { delete userSessions[chatId]; return bot.sendMessage(chatId, "❌ Layanan tidak ditemukan, silakan order ulang."); }
    const min = Number(s.min) || 1, max = Number(s.max) || 1000000;
    const teks = msg.text.trim();
    try {
        if (ses.step === "smm_link") {
            if (!teks || /\s/.test(teks) || teks.length < 3 || teks.length > 500) {
                return bot.sendMessage(chatId, "❌ Link/target tidak valid. Kirim satu link tanpa spasi, contoh: <code>https://www.tiktok.com/@username/video/123</code>", { parse_mode: "HTML", reply_markup: smmBatalTombol() });
            }
            ses.target = teks;
            if (smmButuhKomentar(s)) {
                ses.step = "smm_komentar";
                return bot.sendMessage(chatId, `💬 Kirim <b>komentar</b>, <b>1 baris = 1 komentar</b> (tekan Enter untuk komentar berikutnya).\nJumlah komentar: min ${min.toLocaleString("id-ID")} • max ${max.toLocaleString("id-ID")}.\n\nContoh:\n<code>Keren banget!\nMantap kak\nSetuju 👍</code>`, { parse_mode: "HTML", reply_markup: smmBatalTombol() });
            }
            ses.step = "smm_qty";
            return bot.sendMessage(chatId, `🔢 Masukkan <b>jumlah pesanan</b> (min ${min.toLocaleString("id-ID")} • max ${max.toLocaleString("id-ID")}):`, { parse_mode: "HTML", reply_markup: smmBatalTombol() });
        }
        if (ses.step === "smm_komentar") {
            const baris = msg.text.split(/\r?\n/).map(x => x.trim()).filter(Boolean);
            if (baris.length < min || baris.length > max) {
                return bot.sendMessage(chatId, `❌ Jumlah komentar ${baris.length}, harus antara ${min.toLocaleString("id-ID")} dan ${max.toLocaleString("id-ID")}. Kirim ulang komentarnya (1 baris = 1 komentar).`, { reply_markup: smmBatalTombol() });
            }
            ses.komentar = baris.join("\n");
            ses.quantity = baris.length;
            return smmTampilRingkasan(chatId);
        }
        if (ses.step === "smm_qty") {
            const n = Number(teks.replace(/[.,\s]/g, ""));
            if (!Number.isInteger(n) || n < min || n > max) {
                return bot.sendMessage(chatId, `❌ Jumlah harus angka antara ${min.toLocaleString("id-ID")} dan ${max.toLocaleString("id-ID")}. Ketik ulang:`, { reply_markup: smmBatalTombol() });
            }
            ses.quantity = n;
            return smmTampilRingkasan(chatId);
        }
    } catch (e) {
        console.log("[SMM ORDER] input error:", e.message);
        bot.sendMessage(chatId, "⚠️ Terjadi kesalahan, coba lagi.").catch(() => {});
    }
});

bot.on("callback_query", async (query) => {
    const data = query.data || "";
    if (!(data === "kat" || data.startsWith("sk|") || data === "sks|")) return;
    if (menuTertutupUntuk(data, query.from.id)) return; // info maintenance dikirim handler utama
    const chatId = query.message.chat.id;
    try {
        await bot.answerCallbackQuery(query.id).catch(() => {});
        if (data === "kat") {
            smmMode.add(chatId);
            return await bot.sendMessage(chatId, "📝 Ketik kategori: instagram, tiktok, youtube, shopee, dll\n\nKetik /cancel untuk keluar.");
        }
        if (data === "sks|") {
            const k = smmCariTerakhir[chatId];
            if (!k) { smmMode.add(chatId); return await bot.sendMessage(chatId, "📝 Ketik kategori: instagram, tiktok, youtube, dll"); }
            await bot.deleteMessage(chatId, query.message.message_id).catch(() => {});
            return await smmKirimKategori(chatId, k);
        }
        const [, hash, page] = data.split("|");
        const kategori = smmKategoriDari(hash);
        if (!kategori) return await bot.sendMessage(chatId, "⚠️ Daftar layanan sudah diperbarui. Silakan cari kategori lagi.", { reply_markup: { inline_keyboard: [[{ text: "🔎 Cari Kategori", callback_data: "kat" }]] } });
        return await smmKirimLayanan(chatId, query.message.message_id, kategori, parseInt(page) || 1);
    } catch (e) {
        console.log("[SMM] callback error:", e.message);
    }
});

// Panggil pas bot nyala
loadSMMServices();
// Ambil data user
async function getUserPet(userId) {
  const db = getPets()
  const id = String(userId)

  if(!db[id]) {
    db[id] = { userId: id, pet: null } // bikin user baru kalo belum ada
    saveDB(db)
  }
  return db[id]
}

// Update data pet user
async function savePet(userId, pet) {
  const db = loadDB()
  const id = String(userId)

  if(!db[id]) db[id] = { userId: id }
  db[id].pet = pet
  saveDB(db)
}

// 1. Helper tanggal native
function today() {
  const now = new Date()
  const y = now.getFullYear()
  const m = String(now.getMonth() + 1).padStart(2, '0')
  const d = String(now.getDate()).padStart(2, '0')
  return `${y}-${m}-${d}` // format: 2026-04-17
}

function getWeekId() {
  const now = new Date()
  const year = now.getFullYear()
  const start = new Date(year, 0, 1)
  const days = Math.floor((now - start) / (24 * 60 * 60 * 1000))
  const week = Math.ceil((days + start.getDay() + 1) / 7)
  return `${year}-W${week}` // format: 2026-W16
}

// Fungsi untuk menyimpan data ke database timed
function saveTimedServers(data) {
    const path = './database/timed_servers.json';
    fs.writeFileSync(path, JSON.stringify(data, null, 2));
}
const dbPath = './database/timed_slots.json';
if (!fs.existsSync(dbPath)) {
    fs.writeFileSync(dbPath, JSON.stringify({ slots: [], history: [] }));
}

function getTimedDB() { return JSON.parse(fs.readFileSync(dbPath)); }
function saveTimedDB(data) { fs.writeFileSync(dbPath, JSON.stringify(data, null, 2)); }
// Database untuk melacak server yang akan dihapus otomatis
const timedDatabasePath = './database/timed_servers.json';
if (!fs.existsSync(timedDatabasePath)) fs.writeFileSync(timedDatabasePath, JSON.stringify([]));

// Generator Username & PW Acak
const genRandom = (length) => Math.random().toString(36).substring(2, 2 + length);
// Jalankan pengecekan setiap 60 detik (1 menit)
setInterval(async () => {
    try {
        const dbTimed = getTimedServers();
        const now = new Date();

        // Pastikan ada data slots
        if (!dbTimed.slots || dbTimed.slots.length === 0) return;

        // Ambil daftar yang sudah melewati waktu expired
        const toDelete = dbTimed.slots.filter(s => now > new Date(s.expiredAt));

        if (toDelete.length > 0) {
            console.log(`[SYSTEM] Menemukan ${toDelete.length} panel expired. Memulai penghapusan...`);
        }

        for (const srv of toDelete) {
            try {
                // 1. Hapus Server di Pterodactyl
                const resSrv = await fetch(`${settings.domain}/api/application/servers/${srv.serverId}`, {
                    method: "DELETE",
                    headers: { 
                        "Authorization": `Bearer ${settings.plta}`,
                        "Accept": "application/json",
                        "User-Agent": "Mozilla/5.0"
                    }
                });

                // 2. Hapus User di Pterodactyl
                const resUsr = await fetch(`${settings.domain}/api/application/users/${srv.userId}`, {
                    method: "DELETE",
                    headers: { 
                        "Authorization": `Bearer ${settings.plta}`,
                        "Accept": "application/json",
                        "User-Agent": "Mozilla/5.0"
                    }
                });

                // 3. Kirim Notifikasi ke User
                const msg = `<blockquote>⌛ <b>ᴜᴊɪ ᴄᴏʙᴀ ꜱᴇʟᴇꜱᴀɪ</b>\n\nᴡᴀᴋᴛᴜ 1 ᴊᴀᴍ ᴜᴊɪ ᴄᴏʙᴀ ᴀɴᴅᴀ ᴛᴇʟᴀʜ ʜᴀʙɪꜱ. ᴘᴀɴᴇʟ ᴏᴛᴏᴍᴀᴛɪꜱ ᴅɪʜᴀᴘᴜꜱ ᴏʟᴇʜ ꜱɪꜱᴛᴇᴍ.\n\nꜱɪʟᴀᴋᴀɴ ᴜᴘɢʀᴀᴅᴇ ᴋᴇ ᴘᴀᴋᴇᴛ ᴘʀᴇᴍɪᴜᴍ ᴜɴᴛᴜᴋ ᴅᴜʀᴀꜱɪ ᴘᴇʀᴍᴀɴᴇɴ!</blockquote>`;
                await bot.sendMessage(srv.chatId, msg, { parse_mode: "HTML" }).catch(() => {});

                // 4. Log Admin
                bot.sendMessage(settings.adminId, `🗑 <b>AUTO DELETE:</b> Panel ${srv.type} milik ${srv.chatId} telah dihapus.`);
                
            } catch (err) {
                console.log(`[ERROR] Gagal menghapus panel ${srv.serverId}:`, err.message);
            }
        }

        // 5. Update database: BUANG yang sudah dihapus dari list
        dbTimed.slots = dbTimed.slots.filter(s => now <= new Date(s.expiredAt));
        saveTimedServers(dbTimed);

    } catch (error) {
        console.log("[CRITICAL ERROR] Auto-delete interval error:", error.message);
    }
}, 60000); // 1 menit sekali
const sendMessage = (chatId, text) => bot.sendMessage(chatId, text);
const patunganPath = './database/patungan.json'; 
// Jalankan pengecekan setiap 10 menit
setInterval(() => {
    let dbPatungan = getPatungan();
    let dbUsers = getUsers();
    const now = new Date();

    Object.keys(dbPatungan).forEach(roomId => {
        const room = dbPatungan[roomId];
        const expiredDate = new Date(room.expiresAt);

        if (room.status === "OPEN" && now > expiredDate) {
            // PATUNGAN GAGAL - KEMBALIKAN SALDO KE PROFIL
            room.members.forEach(member => {
                if (!dbUsers[member.id]) dbUsers[member.id] = { saldo: 0 };
                
                // Refund ke saldo profil bot
                dbUsers[member.id].saldo = (dbUsers[member.id].saldo || 0) + member.amount;
                
                bot.sendMessage(member.id, `<blockquote>⚠️ <b>PATUNGAN EXPIRED</b>\n━━━━━━━━━━━━━━━━━━\nDana untuk Room <code>${roomId}</code> tidak terpenuhi hingga batas waktu.\n\nSaldo <b>Rp ${member.amount.toLocaleString()}</b> telah dikembalikan ke Profil Anda.</blockquote>`, { parse_mode: "HTML" });
            });

            room.status = "FAILED_EXPIRED";
            bot.sendMessage(settings.adminId, `⚠️ <b>PATUNGAN GAGAL:</b> Room <code>${roomId}</code> kedaluwarsa. Saldo member telah direfund.`);
        }
    });

    savePatungan(dbPatungan);
    saveUsers(dbUsers);
}, 10 * 60 * 1000);
// Fungsi Ambil Data Patungan
function getPatungan() {
    // Jika file belum ada, buat dengan objek kosong
    if (!fs.existsSync(patunganPath)) {
        fs.writeFileSync(patunganPath, JSON.stringify({}));
        return {};
    }

    try {
        // Baca file dan parse JSON
        const data = fs.readFileSync(patunganPath, 'utf8');
        // Jika isi file kosong, kembalikan objek kosong
        if (!data.trim()) return {};
        return JSON.parse(data);
    } catch (error) {
        // Jika terjadi error (misal format salah), reset file
        console.error('Error membaca file patungan, mereset data...', error.message);
        fs.writeFileSync(patunganPath, JSON.stringify({}));
        return {};
    }
}


// Fungsi Simpan Data Patungan
function savePatungan(data) {
    fs.writeFileSync(patunganPath, JSON.stringify(data, null, 2));
}

// Inisialisasi variabel agar tidak error (PENTING!)
let patunganRooms = getPatungan();
const startTime = Date.now(); 
//Fungsi Patungan
function sendJoinNotification(room, newUser) {
    const sisa = room.harga - room.current;
    const textNotif = `<b>🆕 MEMBER PATUNGAN BARU!</b>\n` +
                      `----------------------------------\n` +
                      `👤 <b>Username:</b> @${newUser.username}\n` +
                      `🆔 <b>ID Profil:</b> <code>${newUser.id}</code>\n` +
                      `🎖 <b>Role:</b> <b>${newUser.role}</b>\n\n` +
                      `💰 Kontribusi: Rp ${newUser.amount.toLocaleString()}\n` +
                      `📉 Sisa Dibutuhkan: Rp ${sisa > 0 ? sisa.toLocaleString() : "LUNAS"} lagi!`;

    // Kirim notif ke semua orang yang sudah bergabung di room tersebut
    room.members.forEach(member => {
        bot.sendMessage(member.id, textNotif, { parse_mode: "HTML" }).catch(()=>{});
    });
}
// Fungsi menentukan Role berdasarkan urutan
function getRoleByCount(count) {
    if (count === 0) return "CEO";
    if (count === 1) return "Partner";
    if (count === 2) return "Admin";
    if (count === 3) return "Reseller";
    return "Member";
}

// Fungsi bawaan asli Anda
function getRuntime() {
  const uptime = process.uptime(); 
  const hours = Math.floor(uptime / 3600);
  const minutes = Math.floor((uptime % 3600) / 60);
  const seconds = Math.floor(uptime % 60);
  return `${hours} Jam ${minutes} Menit ${seconds} Detik`;
}
// 1. BUAT VARIABEL UNTUK MENYIMPAN DATA SEMENTARA (Taruh di luar/di atas command)
const osDataCache = {}; 
const OS_PER_PAGE = 7; // Maksimal data per halaman
//fungsi saveUser

//Fungsi bulan 

function parseFlexibleDate(dateStr) {
    if (!dateStr) return new Date(NaN);

    // Jika formatnya murni DD-MM-YYYY (contoh: 10-05-2025)
    if (/^\d{1,2}-\d{1,2}-\d{4}$/.test(dateStr.trim())) {
        const p = dateStr.split('-');
        return new Date(`${p[2]}-${p[1]}-${p[0]}`);
    }

    // Jika formatnya verbose (contoh: 19 Mei 2026 pukul 10.17)
    let clean = dateStr.toLowerCase()
        .replace(/januari/g, '01').replace(/februari/g, '02').replace(/maret/g, '03')
        .replace(/april/g, '04').replace(/mei/g, '05').replace(/juni/g, '06')
        .replace(/juli/g, '07').replace(/agustus/g, '08').replace(/september/g, '09')
        .replace(/oktober/g, '10').replace(/november/g, '11').replace(/desember/g, '12')
        .replace(/pukul/g, '').replace(/\./g, ':').trim();

    const parts = clean.split(/\s+/);
    if (parts.length >= 3) {
        const day = parts[0].padStart(2, '0');
        const month = parts[1].padStart(2, '0');
        const year = parts[2];
        const time = parts[3] || "00:00";
        // Format ISO: YYYY-MM-DDTHH:mm:00
        return new Date(`${year}-${month}-${day}T${time}:00`);
    }
    return new Date(NaN);
}

//fungsi saldo profil user
function updateSaldo(chatId, nominal) {
    const dbUsers = getUsers();
    
    // 1. JIKA USER BELUM ADA DI DATABASE, BUATKAN PROFILNYA
    if (!dbUsers[chatId]) {
        dbUsers[chatId] = {
            saldo: 0,
            gachaCount: 0
            // (Kamu bisa tambahkan data default lain di sini jika ada)
        };
    }
    
    // 2. PASTIKAN NOMINAL ADALAH ANGKA (Mencegah hasil NaN / Not a Number)
    const jumlahTopup = parseInt(nominal) || 0;
    
    // 3. TAMBAHKAN SALDO KE USER
    dbUsers[chatId].saldo = (dbUsers[chatId].saldo || 0) + jumlahTopup;
    
    // 4. SIMPAN KE DATABASE
    saveUsers(dbUsers); 
    
    // 5. KEMBALIKAN NOMINAL SALDO TERBARU
    return dbUsers[chatId].saldo;
}

// Function Heleket Payment
function generateHeleketSign(data) {
    // 1. JSON stringify
    // 2. Escape slash tanpa menggunakan Regex agar tidak dianggap komentar oleh editor
    const jsonData = JSON.stringify(data).split('/').join('\\/');
    
    // 3. Convert ke Base64
    const base64Data = Buffer.from(jsonData).toString('base64');
    
    // 4. MD5(Base64 + API_KEY)
    const sign = crypto.createHash('md5').update(base64Data + settings.heleket.apiKey).digest('hex');
    
    return sign;
}

// 2. FUNGSI BANTUAN UNTUK MEMBUAT TAMPILAN HALAMAN
function generateOSPage(chatId, page) {
    const data = osDataCache[chatId];
    if (!data) return null; // Jika data sudah hilang/direstart

    const totalPages = Math.ceil(data.length / OS_PER_PAGE);
    const startIndex = (page - 1) * OS_PER_PAGE;
    const endIndex = startIndex + OS_PER_PAGE;
    const pageData = data.slice(startIndex, endIndex);

    let text = `🖥 <b>DAFTAR ID OS HOSTVDS</b>\n`;
    text += `📄 Halaman <b>${page}</b> dari <b>${totalPages}</b>\n\n`;

    pageData.forEach(os => {
        text += `<b>${os.name}</b>\n<code>${os.id}</code>\n\n`;
    });

    // Membuat tombol inline
    const inline_keyboard = [];
    const navigationRow = [];

    if (page > 1) {
        navigationRow.push({ text: "⬅️ Kembali", callback_data: `os_page_${page - 1}` });
    }
    if (page < totalPages) {
        navigationRow.push({ text: "Selanjutnya ➡️", callback_data: `os_page_${page + 1}` });
    }

    if (navigationRow.length > 0) {
        inline_keyboard.push(navigationRow);
    }

    return { text, reply_markup: { inline_keyboard } };
}

// 4. LISTENER UNTUK MENANGKAP KLIK TOMBOL (Taruh di luar command, berdiri sendiri)


    // Jika tombol yang ditekan adalah tombol navigasi OS
// ====================================================
// PANGGIL KONFIGURASI DARI FOLDER DATABASE
// ====================================================
const app = express();
app.use(express.json());

// ====================================================
// DATABASE SEMENTARA & MENU UTAMA
// ====================================================
const userSessions = {}; 
// Database sementara untuk menyimpan voucher aktif
const activeVouchers = {};
// ====================================================
// FUNGSI DATABASE USER (FORMAT BARU)
// ====================================================
const usersFile = path.join(__dirname, 'database', 'users.json');
if (!fs.existsSync(usersFile)) {
    fs.writeFileSync(usersFile, JSON.stringify({})); // Dibuat dalam bentuk Object {}
}

function getUsers() {
    let data = JSON.parse(fs.readFileSync(usersFile));
    // Keamanan jika format lama terdeteksi, ubah jadi format baru
    if (Array.isArray(data)) data = {}; 
    return data;
}
function saveUsers(data) {
    try {
        // Gunakan variabel usersFile agar searah dengan folder database kamu
        fs.writeFileSync(usersFile, JSON.stringify(data, null, 2), 'utf8');
    } catch (err) {
        console.error("Gagal menyimpan database user:", err.message);
    }
}
// ====================================================
// FUNGSI DATABASE TOKO (STOK VPS)
// ====================================================
const storeFile = path.join(__dirname, 'database', 'store.json');
if (!fs.existsSync(storeFile)) {
    // Default awal jika belum diatur admin
    fs.writeFileSync(storeFile, JSON.stringify({ vps_ram: "1GB", vps_price: 35000, vps_stock: 0 }, null, 2));
}

function getStore() {
    const isi = fs.readFileSync(storeFile, "utf8");
    try { return JSON.parse(isi); }
    catch (e) {
        // File diedit manual tanpa kurung kurawal luar ("vps_inventory": {...}) -> coba bungkus
        try { const v = JSON.parse(`{${isi}}`); console.log("[store] store.json tanpa { } luar, dibaca dengan dibungkus"); return v; }
        catch (_) { throw new Error(`database/store.json bukan JSON valid: ${e.message}`); }
    }
}

function updateStore(data) {
    fs.writeFileSync(storeFile, JSON.stringify(data, null, 2));
}
// ====================================================
// FUNGSI DATABASE (FORMAT MULTI-SERVER)
// ====================================================
function saveUser(chatId, username) {
    const users = getUsers();
    if (!users[chatId]) {
        users[chatId] = {
            id: chatId,
            username: username,
            servers: [] // <-- SEKARANG MENJADI ARRAY UNTUK MENYIMPAN BANYAK SERVER
        };
        fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
        return true; 
    }
    return false;
}

// extra: { jenis: "panel" | "vps_shared" | "vps_dedicated", harga, host }
function updateUserProfile(chatId, paketDibeli, usernamePanel, extra = {}) {
    const users = getUsers();
    if (!users[chatId]) return;
    if (!users[chatId].servers) users[chatId].servers = []; // Migrasi aman

    const now = new Date();
    const expired = new Date();
    expired.setDate(now.getDate() + 30); // Default 30 Hari

    const timeOptions = { timeZone: "Asia/Jakarta", day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' };

    // Push data server baru ke dalam array
    users[chatId].servers.push({
        username_panel: usernamePanel,
        paket: paketDibeli,
        order_date: now.toLocaleString("id-ID", timeOptions),
        expired_date: expired.toLocaleString("id-ID", timeOptions),
        expired_timestamp: expired.getTime(), // Disimpan dalam hitungan milidetik agar mudah ditambah nanti
        jenis: extra.jenis || "panel",
        harga: Number(extra.harga) || undefined, // harga sewa 30 hari, dipakai hitung perpanjangan
        host: extra.host || undefined,
        reminded: []
    });

    fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
}

// Fungsi Baru: Menambah masa aktif server
function extendServer(chatId, serverIndex, addDays) {
    const users = getUsers();
    if (!users[chatId] || !users[chatId].servers[serverIndex]) return;

    const server = users[chatId].servers[serverIndex];
    const timeOptions = { timeZone: "Asia/Jakarta", day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' };

    // Tambah hari dari expired lama; kalau sudah lewat / data lama tanpa timestamp, mulai dari sekarang
    const lama = serverExpiredMs(server);
    const dasar = Number.isFinite(lama) && lama > Date.now() ? lama : Date.now();
    const newExpiredTime = dasar + (addDays * 24 * 60 * 60 * 1000);
    server.reminded = [];
    server.expiredNotified = false;
    const newExpiredDate = new Date(newExpiredTime);

    server.expired_timestamp = newExpiredTime;
    server.expired_date = newExpiredDate.toLocaleString("id-ID", timeOptions);

    fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
    return server.username_panel; // Kembalikan username panel untuk notif
}
// ====================================================
// SERVER AKTIF: jenis, sisa waktu (hitung mundur), reminder H-3/H-2/H-1
// ====================================================
const JENIS_SERVER = { panel: "Panel", vps_shared: "VPS NAT", vps_dedicated: "VPS Dedicated" };
const HARI_MS = 24 * 60 * 60 * 1000;
function serverExpiredMs(srv) {
    const ts = Number(srv && srv.expired_timestamp);
    if (Number.isFinite(ts) && ts > 0) return ts;
    return parseFlexibleDate(srv && srv.expired_date).getTime();
}
function serverJenis(srv) {
    return JENIS_SERVER[srv.jenis] || (/vps/i.test(srv.paket || "") ? "VPS" : "Panel");
}
function serverSisa(ms) {
    if (!Number.isFinite(ms)) return "Tanggal tidak valid";
    const d = ms - Date.now();
    if (d <= 0) return "Expired";
    const h = Math.floor(d / HARI_MS), j = Math.floor((d % HARI_MS) / 3600000), m = Math.floor((d % 3600000) / 60000);
    if (h > 0) return `${h} hari ${j} jam`;
    if (j > 0) return `${j} jam ${m} menit`;
    return `${m} menit`;
}
function serverTglWIB(ms) {
    if (!Number.isFinite(ms)) return "-";
    return new Date(ms).toLocaleString("id-ID", { timeZone: "Asia/Jakarta", day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }).replace(/\./g, ":") + " WIB";
}
// Harga perpanjang per hari: harga sewa 30 hari / 30, default Rp 500 (panel)
function serverHargaPerHari(srv) {
    return srv && Number(srv.harga) > 0 ? Math.ceil(Number(srv.harga) / 30) : 500;
}

// Tabel server aktif sebagai rich message. tg-time format "r" = waktu relatif yang dihitung live oleh aplikasi Telegram.
async function kirimTabelServer(chatId, servers) {
    const esc = t => String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    const baris = (pakaiTimer) => servers.map((srv, i) => {
        const ms = serverExpiredMs(srv);
        const sisa = serverSisa(ms);
        const hidup = Number.isFinite(ms) && ms > Date.now();
        const sel = pakaiTimer && hidup ? `<tg-time unix="${Math.floor(ms / 1000)}" format="r">${esc(sisa)}</tg-time>` : (hidup ? esc(sisa) : `<b>${esc(sisa)}</b>`);
        const ikon = !hidup ? "🔴" : ms - Date.now() <= 3 * HARI_MS ? "🟡" : "🟢";
        return `  <tr><td>${i + 1}</td><td>${ikon} <code>${esc(srv.username_panel)}</code></td><td>${esc(serverJenis(srv))}</td><td>${esc(srv.paket)}</td><td>${sel}</td><td>${esc(serverTglWIB(ms))}</td></tr>`;
    }).join("\n");
    const html = (pakaiTimer) => `<h3>🟢 SERVER AKTIF</h3>\n<table bordered striped compact>\n` +
        `  <tr><th>No</th><th>Server</th><th>Jenis</th><th>Paket</th><th>Sisa Waktu</th><th>Expired</th></tr>\n${baris(pakaiTimer)}\n</table>\n` +
        `<p><i>🟢 aktif • 🟡 ≤ 3 hari • 🔴 expired. Masa sewa 30 hari, pengingat dikirim H-3, H-2, H-1.</i></p>`;
    const markup = { reply_markup: { inline_keyboard: [
        [{ text: "🔄 Perpanjang Server", callback_data: "extend_list", style: "success" }]
    ] } };
    try {
        return await sendRichMessage(chatId, html(true), markup);
    } catch (e1) {
        try {
            return await sendRichMessage(chatId, html(false), markup); // tanpa tg-time kalau tag ditolak
        } catch (e2) {
            const teks = `<blockquote>🟢 <b>SERVER AKTIF</b>\n` + servers.map((srv, i) => {
                const ms = serverExpiredMs(srv);
                return `\n${i + 1}. <code>${esc(srv.username_panel)}</code> (${esc(serverJenis(srv))})\n├ Paket: ${esc(srv.paket)}\n├ Sisa: <b>${esc(serverSisa(ms))}</b>\n└ Expired: ${esc(serverTglWIB(ms))}`;
            }).join("\n") + `</blockquote>`;
            return bot.sendMessage(chatId, teks, { parse_mode: "HTML", ...markup });
        }
    }
}

// Reminder hanya ke pemilik server. Cek tiap 15 menit, kirim sekali per tahap (H-3, H-2, H-1) + saat expired.
async function cekReminderServer() {
    let users;
    try { users = getUsers(); } catch { return; }
    let ubah = false;
    for (const [chatId, u] of Object.entries(users)) {
        if (!u || !Array.isArray(u.servers)) continue;
        for (let idx = 0; idx < u.servers.length; idx++) {
            const srv = u.servers[idx];
            const ms = serverExpiredMs(srv);
            if (!Number.isFinite(ms)) continue;
            const sisaMs = ms - Date.now();
            const tombol = { reply_markup: { inline_keyboard: [[{ text: "🔄 Perpanjang Server", callback_data: `ext_ui_${idx}_30`, style: "success" }]] } };
            if (!Array.isArray(srv.reminded)) srv.reminded = [];
            if (sisaMs <= 0) {
                if (srv.expiredNotified) continue;
                srv.expiredNotified = true; ubah = true;
                bot.sendMessage(chatId, `<blockquote>🔴 <b>SERVER EXPIRED</b>\n\n${serverJenis(srv)} <code>${srv.username_panel}</code> (${srv.paket}) sudah habis masa sewanya pada ${serverTglWIB(ms)}.\nPerpanjang sekarang agar server tetap bisa dipakai.</blockquote>`, { parse_mode: "HTML", ...tombol }).catch(() => {});
                continue;
            }
            const tahap = [1, 2, 3].find(n => sisaMs <= n * HARI_MS); // tahap terkecil yang sudah masuk
            if (!tahap || srv.reminded.includes(tahap)) continue;
            for (const n of [1, 2, 3]) if (n >= tahap && !srv.reminded.includes(n)) srv.reminded.push(n); // tahap yang terlewat tidak dikirim belakangan
            ubah = true;
            bot.sendMessage(chatId, `<blockquote>⏰ <b>PENGINGAT MASA SEWA (H-${tahap})</b>\n\n${serverJenis(srv)} <code>${srv.username_panel}</code>\n├ Paket: ${srv.paket}\n├ Sisa: <b>${serverSisa(ms)}</b>\n└ Expired: ${serverTglWIB(ms)}\n\nPerpanjang sebelum habis supaya server tidak berhenti.</blockquote>`, { parse_mode: "HTML", ...tombol }).catch(() => {});
        }
    }
    if (ubah) saveUsers(users);
}
setInterval(() => cekReminderServer().catch(e => console.log("[REMINDER SERVER]", e.message)), 15 * 60 * 1000);
setTimeout(() => cekReminderServer().catch(() => {}), 30 * 1000);

// Fungsi untuk membersihkan teks agar aman dikirim sebagai HTML
function escapeHTML(text) {
    return text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}
const ROLE_START = `Role: Helpful Hosting Assistant. 
Menu yang tersedia: Beli vps, Beli Panel, Patungan Vps, Rental Panel, Install Vps. 
Spek VPS: Intel Xeon Platinum, RAM 16GB, Core 4. 
Keunggulan: Server kami jauh lebih unggul, stabil, dan kencang dari pesaing karna menggunakan Vps yang 100% Legal.
Fitur Unggulan: Voice Note Command Order, Order via Voice Note lebih Cepat, Mudah, dan Hemat karna terdapat diskon potongan harga UpTo Rp. 2000
Keterangan: Arahkan user untuk pergi ke Menu utama untuk melihat semua menu yang tersedia, dan Arahkan user jika mengalami kendala atau ingin pre Order Vps bisa klik Button menu bantuan di bawah ini.`;

// ===== RICH MESSAGE HELPER =====
const escHtml = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

async function sendRichMessage(chatId, html, extra = {}) {
    const res = await fetch(`https://api.telegram.org/bot${bot.token}/sendRichMessage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            chat_id: chatId,
            rich_message: { html },
            ...extra // reply_markup masuk lewat sini
        })
    });
    const data = await res.json();
    if (!data.ok) throw new Error(data.description || "sendRichMessage gagal");
    return data.result;
}

// ===== COMMAND /start =====
bot.onText(/\/start/, async (msg) => {
    const chatId = msg.chat.id;
    const firstName = msg.from.first_name || "User"; 
    const username = msg.from.username ? `@${msg.from.username}` : msg.from.first_name;

    // 1. Simpan user & Notif Admin (TETAP ADA)
    const isNewUser = saveUser(chatId, username);
    if (isNewUser) {
        const dateNow = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
        const notifAdmin = `🎉 *Selamat! User baru telah bergabung*\n\n🆔 ID: \`${chatId}\`\n👤 Username: ${username}\n📅 Waktu: ${dateNow}`;
        bot.sendMessage(settings.adminId, notifAdmin, { parse_mode: "Markdown" }).catch(()=>{});
    }

    // 2. CEK VIA WORKER
    let isLinked = false;
    try {
        const res = await fetch(`https://boosteryuk.boosteryukid.workers.dev/api/telegram/check?telegram_id=${chatId}`).then(r => r.json());
        // support 2 format
        if (res.status === true || res.ok === true) {
            // kalau ok tapi message Worker Active, anggap belum link
            if ((res.message || "").includes("Worker Active")) isLinked = false;
            else isLinked = true;
        }
    } catch (e) {
        isLinked = false;
    }

    // 3. MENU TEXT (ASLI) - dipakai sebagai fallback
    const menuText = `<blockquote>────✧ <b>ɪɴꜰᴏʀᴍᴀᴛɪᴏɴ</b> ✧
ᴄᴀᴘᴇᴋ ʙᴇʟɪ ᴘᴀɴᴇʟ ᴍᴜʀᴀʜ ᴛᴀᴘɪ ᴛɪᴀᴘ 3-7 ʜᴀʀɪ ꜱᴇʀᴠᴇʀ ᴍᴀᴛɪ/ᴍᴏᴋᴀᴅ? ʙɪʟᴀɴɢ ɴʏᴀ ᴅɪ ʀᴀᴡᴀᴛ ᴛᴀᴘɪ ᴄᴜᴍᴀ ᴍᴀɴɪꜱ ᴅɪ ᴀᴡᴀʟ 
ᴘɪɴᴅᴀʜ ᴋᴇ ꜱᴇʀᴠᴇʀ ᴋᴀᴍɪ! 
ʟᴀʏᴀɴᴀɴ ᴏɴ 24/7ᴊᴀᴍ ᴊᴀʀɪɴɢᴀɴ ᴛᴀɴᴘᴀ ʙᴀᴛᴀꜱ - ꜱᴇᴡᴀ ʙᴜʟᴀɴᴀɴ ʙɪꜱᴀ ᴅɪ ᴘᴇʀᴘᴀɴᴊᴀɴɢ</blockquote>
<blockquote>Update Terbaru 2.0</blockquote>
<blockquote>Dear All, Kini Toko VPS & Panel Legal telah bekerja sama dengan Brand Digital : Boosteryuk Smm Panel 🚀</blockquote>
<blockquote>Dear user new, Silakan daftar ke website boosteryuk.com lalu kembali ke bot untuk klik tombol hubungkan akun website ke bot.</blockquote>
<blockquote>⪼ Runtime : <code>${getRuntime()}</code>
────────────⧽</blockquote>`;

    // 3b. MENU RICH (tabel + garis pembatas + blok ceklis buka-tutup)
    const bannerIsUrl = /^https?:\/\//i.test(settings.panelImage || "");
    const richHtml = `${bannerIsUrl ? `<img src="${settings.panelImage}"/>` : ""}
<blockquote>────✧ <b>ɪɴꜰᴏʀᴍᴀᴛɪᴏɴ</b> ✧

Dear All, Kini Toko VPS &amp; Panel Legal telah bekerja sama dengan Brand Digital : Boosteryuk Smm Panel 🚀</blockquote>
<hr>
<table bordered striped>
  <tr>
    <th><b>𝙵𝚒𝚝𝚞𝚛</b></th>
    <th>𝚄𝚗𝚐𝚐𝚞𝚕𝚊𝚗</th>
  </tr>
  <tr>
    <td>🤝 𝙿𝚊𝚝𝚞𝚗𝚐𝚊𝚗 𝚅𝙿𝚂</td>
    <td>Order VPS buat rame rame? makin HEMAT!</td>
  </tr>
  <tr>
    <td>🐿 𝙰𝚍𝚘𝚙𝚜𝚒 𝙿𝙴𝚃</td>
    <td>Rawat Peliharaan dapat VPS!</td>
  </tr>
  <tr>
    <td>🖥 𝚅𝙿𝚂 𝙽𝙰𝚃</td>
    <td>Jalanin Bot tetap lancar tanpa biaya besar? ini Rekomendasi</td>
  </tr>
  <tr>
    <td>💸 𝙵𝚛𝚎𝚎𝚕𝚊𝚗𝚌𝚎</td>
    <td>Kerjakan tugas dapat Uang!</td>
  </tr>
</table>
<details open>
  <summary>Keuntungan @PanelKitaLegalbot</summary>
  <ul>
    <li><input type="checkbox" checked>VPS MURAH & LEGAL</li>
    <li><input type="checkbox" checked>CS Bukan Robot</li>
    <li><input type="checkbox" checked>Bisa Menghasilkan Cuan.</li>
  </ul>
</details>
<blockquote>⪼ Runtime : <code>${getRuntime()}</code>
────────────⧽</blockquote>`;

    // 4. BUTTON DINAMIS
    let keyboardMenuPertama;
    if (isLinked) {
        // UDAH LINK = TOMBOL HUBUNGKAN HILANG
        keyboardMenuPertama = {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: "🌐 Go To Website", url: "https://boosteryuk.com", style: "primary" }
                    ],
                    [
                        { text: "𝘉𝘶𝘬𝘢 𝘔𝘦𝘯𝘶", callback_data: "mainmenu", style: "primary" }
                    ]
                ]
            }
        };
    } else {
        // BELUM LINK = MUNCUL
        keyboardMenuPertama = {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: "🌐 Daftar / Login Web", url: "https://boosteryuk.com", style: "primary" },
                        { text: "🔗 Hubungkan Akun", callback_data: "link_akun", style: "success" }
                    ],
                    [
                        { text: "𝘉𝘶𝘬𝘢 𝘔𝘦𝘯𝘶", callback_data: "mainmenu", style: "primary" }
                    ]
                ]
            }
        };
    }

    // Voice note acak (sama seperti sebelumnya)
    const kirimVoice = async () => {
        try {
            const voiceDir = path.join(__dirname, "voice");
            // maintenance*.ogg khusus menu yang ditutup, _*.ogg file sementara konversi
            const voiceFiles = fs.readdirSync(voiceDir).filter(file => /\.(ogg|oga)$/i.test(file) && !/^(maintenance|_)/i.test(file));
            if (voiceFiles.length === 0) throw new Error("Tidak ada file .ogg/.oga di folder voice");
            const voiceFile = voiceFiles[Math.floor(Math.random() * voiceFiles.length)];
            await bot.sendVoice(chatId, path.join(voiceDir, voiceFile));
        } catch (err) {
            console.error("Gagal mengirim voice note:", err.message);
        }
    };

    bot.sendChatAction(chatId, "typing");
    setTimeout(async () => {
        try {
            // Kalau panelImage bukan URL (file_id / path lokal), kirim fotonya dulu
            if (!bannerIsUrl && settings.panelImage) {
                await bot.sendPhoto(chatId, settings.panelImage);
            }
            await sendRichMessage(chatId, richHtml, keyboardMenuPertama);
            await kirimVoice();
        } catch (richErr) {
            if (isBlockedByUser(richErr)) return;
            console.log("Rich message gagal, pakai tampilan lama:", richErr.message);

            // FALLBACK: tampilan lama (foto + caption)
            bot.sendPhoto(chatId, settings.panelImage, {
                caption: menuText,
                parse_mode: "HTML",
                ...keyboardMenuPertama
            }).then(kirimVoice).catch((err) => {
                if (isBlockedByUser(err)) return;
                console.log("Gagal kirim foto start:", err.message);
                bot.sendMessage(chatId, menuText, {
                    parse_mode: "HTML",
                    ...keyboardMenuPertama
                }).catch((fallbackErr) => {
                    if (!isBlockedByUser(fallbackErr)) {
                        console.log("Gagal kirim menu:", fallbackErr.message);
                    }
                });
            });
        }
    }, 1000);
});

const keyboardMenuKedua = {
    inline_keyboard: [
        [
            { text: "🛍 SMM Panel", callback_data: "smm", style: "success" },
            { text: "📱 𝙽𝚘𝚖𝚘𝚛 𝙾𝚃𝙿", callback_data: "pilih_otp_server", style: "success" }
        ],
        [
            { text: "🛍 𝙱𝚎𝚕𝚒 𝚅𝚙𝚜", callback_data: "menu_vps", style: "success" },
            { text: "🛍 𝙱𝚎𝚕𝚒 𝙿𝚊𝚗𝚎𝚕", callback_data: "menu_panel", style: "success" }
        ],
        [
            { text: "💬 𝙱𝚊𝚗𝚝𝚞𝚊𝚗", callback_data: "menu_bantuan", style: "danger" },           
            { text: "👤 𝙿𝚛𝚘𝚏𝚒𝚕", callback_data: "menu_profil", style: "primary" }
        ],
        [
            { text: "➡️ 𝚂𝚎𝚕𝚊𝚗𝚓𝚞𝚝𝚗𝚢𝚊", callback_data: "menu_lainnya" } // Tombol ke Hal 2
        ], 
        [
            { text: "🔎 𝙲𝚎𝚔 𝙸𝚍", callback_data: "cekid", style: "primary" }
        ]
    ]
};
//Fungsi Vn Order

async function processVoiceToOrder(fileLink, chatId) {
    const inputPath = `./database/voice_${chatId}.oga`;
    const outputPath = `./database/voice_${chatId}.mp3`;

    try {
        const response = await axios({ url: fileLink, responseType: 'arraybuffer' });
        fs.writeFileSync(inputPath, response.data);

        return new Promise((resolve, reject) => {
            ffmpeg(inputPath).toFormat('mp3').on('end', async () => {
                try {
                    // Gunakan .trim() untuk pastikan tidak ada spasi di API KEY
                    const apiKey = settings.assemblyApiKey.trim();

                    // 1. Upload
                    const audioData = fs.readFileSync(outputPath);
                    const uploadRes = await axios.post('https://api.assemblyai.com/v2/upload', audioData, {
                        headers: { 
                            "authorization": apiKey, 
                            "content-type": "application/octet-stream" 
                        }
                    });

                    // 2. Minta Transkripsi (DIPERBAIKI DI SINI)
const transcriptRes = await axios.post('https://api.assemblyai.com/v2/transcript', {
    audio_url: uploadRes.data.upload_url,
    language_code: "id", // Bahasa Indonesia
    // PERBAIKAN: Masukkan dua model dalam array sesuai saran error tadi
    speech_models: ["universal-3-pro", "universal-2"] 
}, { 
    headers: { "authorization": apiKey } 
});

                    const transcriptId = transcriptRes.data.id;
                    let text = "";
                    
                    // 3. Polling
                    for (let i = 0; i < 30; i++) {
                        const pollingRes = await axios.get(`https://api.assemblyai.com/v2/transcript/${transcriptId}`, {
                            headers: { "authorization": apiKey }
                        });
                        
                        if (pollingRes.data.status === 'completed') {
                            text = pollingRes.data.text.toLowerCase();
                            break;
                        } else if (pollingRes.data.status === 'error') {
                            throw new Error("AI Error: " + pollingRes.data.error);
                        }
                        await new Promise(r => setTimeout(r, 1000));
                    }

                    if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath);
                    if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
                    resolve(text);
                } catch (e) { 
                    // Cetak error lengkap ke console jika gagal
                    console.log("LOG ERROR:", e.response?.data || e.message);
                    reject(e); 
                }
            }).save(outputPath);
        });
    } catch (err) {
        throw err;
    }
}
//uji coba
async function autoCreatePanelTimed(chatId, namaPaket, durasiJam, isTrial = false) {
    const genRandom = (len) => Math.random().toString(36).substring(2, 2 + len);
    const username = (isTrial ? "trial" : "hr") + genRandom(4);
    const password = "PW" + genRandom(8).toUpperCase();
    const email = `${username}@timed.bot`;
    
    const headersPtero = {
        "Accept": "application/json", 
        "Content-Type": "application/json", 
        "Authorization": `Bearer ${settings.plta}`,
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36"
    };

    try {
        // --- 1. CREATE USER ---
        const resUser = await fetch(`${settings.domain}/api/application/users`, {
            method: "POST",
            headers: headersPtero, 
            body: JSON.stringify({ email, username, first_name: username, last_name: "Timed", language: "en", password })
        });

        if (!resUser.ok) {
            const errLog = await resUser.text();
            console.log("Error Create User:", errLog);
            throw new Error(`Cloudflare/Server Error: ${resUser.status}`);
        }
        const dataUser = await resUser.json();
        const user = dataUser.attributes;

        // --- 2. CREATE SERVER ---
        const resServer = await fetch(`${settings.domain}/api/application/servers`, {
            method: "POST",
            headers: headersPtero, 
            body: JSON.stringify({
                name: username + "_Timed",
                user: user.id,
                egg: parseInt(settings.eggs),
                docker_image: "ghcr.io/parkervcp/yolks:nodejs_24",
                startup: "npm start",
                environment: { USER_UPLOAD: "0", AUTO_UPDATE: "0", MAIN_FILE: "index.js" },
                limits: { memory: 500, swap: 0, disk: 500, io: 500, cpu: 50 },
                feature_limits: { databases: 1, backups: 1, allocations: 1 },
                deploy: { locations: [parseInt(settings.loc)], dedicated_ip: false, port_range: [] }
            })
        });

        if (!resServer.ok) throw new Error("Banyak user sedang membuat Server di Pterodactyl, Coba lagi nanti.");
        const dataServer = await resServer.json();
        const server = dataServer.attributes;

        // --- 3. PROSES SIMPAN DATABASE (SAFETY MODE) ---
        const dbTimed = getTimedServers(); 
        const expiredDate = new Date();
        expiredDate.setHours(expiredDate.getHours() + durasiJam);

        // SAFETY CHECK: Pastikan .slots adalah Array sebelum .push
        if (!dbTimed.slots || !Array.isArray(dbTimed.slots)) {
            dbTimed.slots = [];
        }

        dbTimed.slots.push({
            chatId, 
            serverId: server.id, 
            userId: user.id,
            expiredAt: expiredDate.toISOString(), 
            type: isTrial ? "TRIAL" : "HOURLY"
        });

        // SAFETY CHECK: Update Counter Trial
        if (isTrial) {
            if (!dbTimed.trialHistory) dbTimed.trialHistory = {};
            dbTimed.trialHistory[chatId] = (dbTimed.trialHistory[chatId] || 0) + 1;
            
            // Log sukses ke Admin
            bot.sendMessage(settings.adminId, `✅ <b>TRIAL BERHASIL:</b> User ${chatId} (@${user.username}) telah menggunakan jatah ke-${dbTimed.trialHistory[chatId]}`);
        }

        saveTimedServers(dbTimed);

        // --- 4. NOTIFIKASI SUKSES ---
        const textSuccess = `<blockquote>( ✅ ) - <b>ᴜᴊɪ ᴄᴏʙᴀ ʙᴇʀʜᴀꜱɪʟ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ</b></blockquote>
<blockquote>🌐 ʟᴏɢɪɴ: ${settings.domain}
👤 ᴜꜱᴇʀɴᴀᴍᴇ: <code>${user.username}</code>
🔐 ᴘᴀꜱꜱᴡᴏʀᴅ: <code>${password}</code>

⏳ ᴅᴜʀᴀꜱɪ: <b>${durasiJam} ᴊᴀᴍ</b>
<i>ᴘᴀɴᴇʟ ᴀᴋᴀɴ ᴏᴛᴏᴍᴀᴛɪꜱ ᴅɪʜᴀᴘᴜꜱ ꜱᴀᴀᴛ ᴡᴀᴋᴛᴜ ʜᴀʙɪꜱ.</i></blockquote>`;

        bot.sendMessage(chatId, textSuccess, { parse_mode: "HTML" });

    } catch (error) {
        console.error("DEBUG ERROR:", error.message);
        bot.sendMessage(chatId, `⚠️ <b>ᴛᴇʀᴊᴀᴅɪ ᴋᴇꜱᴀʟᴀʜᴀɴ:</b> ${error.message}\n\n<i>Hubungi Admin</i>`, { parse_mode: "HTML" });
        // Rental berbayar: lempar lagi biar ke-refund di pay_via_saldo / QRIS 1
        if (!isTrial) throw error;
    }
}
// ====================================================
// FUNGSI AUTO CREATE PANEL PTERODACTYL
// ====================================================
async function autoCreatePanel(chatId, username, namaPaket) {
    bot.sendMessage(chatId, `⏳ Sedang memproses pembuatan panel untuk username: \`${username}\`...`, { parse_mode: "Markdown" });

    // 1. DETEKSI SPESIFIKASI BERDASARKAN PAKET
    let memo = "0"; let cpu = "0"; let disk = "0";

    if (namaPaket.includes("Started 1GB")) { memo = "1024"; cpu = "50"; disk = "10240"; }
    else if (namaPaket.includes("Started 2GB")) { memo = "2048"; cpu = "100"; disk = "20480"; }
    else if (namaPaket.includes("Medium 6GB")) { memo = "6144"; cpu = "150"; disk = "51200"; }
    else if (namaPaket.includes("Medium 8GB")) { memo = "8192"; cpu = "200"; disk = "71680"; }
    else if (namaPaket.includes("PRO")) { memo = "0"; cpu = "0"; disk = "0"; } // 0 = Unlimited

    // 2. PERSIAPAN HEADER & DATA
    // Menambahkan User-Agent agar tidak diblokir Cloudflare
    const headersPtero = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": `Bearer ${settings.plta}`,
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36"
    };

    const name = username + "_" + namaPaket.replace(/\s+/g, '');
    const email = `${username}@Buyeradmin`;
    const password = `${username}001`;
    const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/npm start';

    let user;
    let server;

    try {
        // --- CREATE USER ---
        const resUser = await fetch(`${settings.domain}/api/application/users`, {
            method: "POST",
            headers: headersPtero,
            body: JSON.stringify({
                email: email, username: username, first_name: username, last_name: username, language: "en", password: password
            })
        });
        
        // Cek jika response bukan JSON (Blokir Cloudflare)
        if (!resUser.ok) {
            const errBody = await resUser.text();
            console.log("Error Ptero User:", errBody);
            throw new Error(`Status ${resUser.status}. Cek log console.`);
        }

        const dataUser = await resUser.json();

        if (dataUser.errors) {
            console.log("Pterodactyl API Error (User):", dataUser.errors);
            bot.sendMessage(chatId, `⚠️ Gagal membuat user. Mungkin username/email sudah terdaftar, Silakan hubungi admin untuk konfirmasi lebih lanjut.\nError: ${dataUser.errors[0].detail}`);
            throw new Error(dataUser.errors[0].detail || "Gagal membuat user");
        }
        user = dataUser.attributes;

        // --- CREATE SERVER ---
        const resServer = await fetch(`${settings.domain}/api/application/servers`, {
            method: "POST",
            headers: headersPtero,
            body: JSON.stringify({
                name: name,
                description: "Auto Deploy by Bot",
                user: user.id,
                egg: parseInt(settings.eggs),
                docker_image: "ghcr.io/parkervcp/yolks:nodejs_24",
                startup: spc,
                environment: {
                    USER_UPLOAD: "0", AUTO_UPDATE: "0", MAIN_FILE: "index.js", NODE_PACKAGES: "", UNNODE_PACKAGES: "", GIT_ADDRESS: "", BRANCH: "", USERNAME: "", ACCESS_TOKEN: "", NODE_ARGS: ""
                },
                limits: { memory: parseInt(memo), swap: 0, disk: parseInt(disk), io: 500, cpu: parseInt(cpu) },
                feature_limits: { databases: 5, backups: 5, allocations: 1 },
                deploy: { locations: [parseInt(settings.loc)], dedicated_ip: false, port_range: [] }
            })
        });

        if (!resServer.ok) {
            const errBody = await resServer.text();
            console.log("Error Ptero Server:", errBody);
            throw new Error(`Status ${resServer.status}. Gagal membuat Server.`);
        }

        const dataServer = await resServer.json();

        if (dataServer.errors) {
            console.log("Pterodactyl API Error (Server):", dataServer.errors);
            bot.sendMessage(chatId, `⚠️ User terbuat, tapi gagal membuat Server, Silakan hubungi admin.\nError: ${dataServer.errors[0].detail}`);
            throw new Error(dataServer.errors[0].detail || "Gagal membuat Server");
        }
        server = dataServer.attributes;

    } catch (error) {
        bot.sendMessage(chatId, `⚠️ Terjadi error sistem: ${error.message}`);
        throw error; // INI KUNCI BIAR REFUND JALAN
    }

    // 3. KIRIM HASIL KE PEMBELI JIKA SUKSES
    if (user && server) {
        updateUserProfile(chatId, namaPaket, user.username);
        const textSuccess = `<blockquote>✅ <b>BERHASIL MEMBUAT PANEL!</b>

🌐 Login: ${settings.domain}
👤 Username: <code>${user.username}</code>
🔐 Password: <code>${password}</code>

🖥 <b>Spesifikasi Server:</b>
- Paket: ${namaPaket}
- Memory: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory + " MB"}
- CPU: ${server.limits.cpu === 0 ? "Unlimited" : server.limits.cpu + " %"}
- Disk: ${server.limits.disk === 0 ? "Unlimited" : server.limits.disk + " MB"}

<i>Harap simpan data ini dengan baik.</i></blockquote>`;

        if (settings.pp) {
            bot.sendAnimation(chatId, settings.pp, { caption: textSuccess, parse_mode: "HTML" });
        } else {
            bot.sendMessage(chatId, textSuccess, { parse_mode: "HTML" });
        }
    }
}
//AUTO CREATE VPS NAT
// Bot berjalan DI DALAM VPS NAT itu sendiri (185.205.222.202:10892 = IP publik bersama + port NAT).
// Mode "lokal": host kosong / 127.0.0.1 / localhost / IP publik NAT DAN bot jalan sebagai root ->
//   user Linux dibuat langsung di mesin ini (useradd/chpasswd), tanpa SSH & tanpa password root.
// Mode "ssh": host lain (server NAT terpisah) atau bot bukan root -> SSH root, password wajib.
// Dicek SEBELUM user membayar.
function vpsNatRoot() { return typeof process.getuid === "function" && process.getuid() === 0; }
function vpsNatConfig() {
    const hostSet = String(settings.vps_shared_host || "").trim();
    const hostLokal = !hostSet || ["127.0.0.1", "localhost", "::1", PUBLIC_IP].includes(hostSet);
    const password = settings.vps_shared_root_pass ? String(settings.vps_shared_root_pass) : "";
    if (hostLokal && vpsNatRoot()) return { mode: "lokal", host: "mesin ini", kurang: [], lengkap: true };
    // SSH: IP publik NAT -> port NAT publik; selain itu port settings / 22
    const host = hostSet || "127.0.0.1";
    const port = Number(settings.vps_shared_port) || (host === PUBLIC_IP ? PUBLIC_PORT : 22);
    const kurang = [];
    if (!password) kurang.push(hostLokal ? "vps_shared_root_pass (atau jalankan bot sebagai root)" : "vps_shared_root_pass");
    return { mode: "ssh", host, port, password, kurang, lengkap: kurang.length === 0 };
}
// Jalankan perintah di mesin ini (mode lokal). stdin opsional. Hasil { code, stdout, stderr }.
function vpsNatExecLokal(cmd, stdin) {
    return new Promise((resolve) => {
        const { spawn } = require("child_process");
        const p = spawn("bash", ["-c", cmd], { stdio: ["pipe", "pipe", "pipe"] });
        let stdout = "", stderr = "";
        const t = setTimeout(() => p.kill("SIGKILL"), 30000);
        p.stdout.on("data", d => stdout += d);
        p.stderr.on("data", d => stderr += d);
        p.on("error", e => { clearTimeout(t); resolve({ code: 1, stdout, stderr: e.message }); });
        p.on("close", code => { clearTimeout(t); resolve({ code: code === null ? 1 : code, stdout, stderr }); });
        p.stdin.end(stdin || "");
    });
}
function vpsNatLaporBelumSiap(chatId, cfg) {
    bot.sendMessage(settings.adminId, `<blockquote>⚠️ <b>VPS NAT BELUM BISA DIORDER</b>\n━━━━━━━━━━━━━━━━━━\nUser <code>${chatId}</code> mencoba order, ditolak sebelum bayar.\nYang kurang: <code>${cfg.kurang.join(", ")}</code>\n\nBot di VPS NAT ini: jalankan bot sebagai root (pm2 di user root) dan kosongkan/isi <code>vps_shared_host: "127.0.0.1"</code>, tidak perlu password.\nServer NAT lain: isi <code>vps_shared_host</code>, <code>vps_shared_port</code>, <code>vps_shared_root_pass</code> di database/settings.js.</blockquote>`, { parse_mode: "HTML" }).catch(() => {});
}
// Password VPS: 8-64 karakter, tanpa spasi/baris baru/titik dua (format chpasswd "user:pass").
function vpsNatPasswordValid(pw) {
    return typeof pw === "string" && /^[^\s:]{8,64}$/.test(pw);
}

// --- FUNGSI BARU: KHUSUS VPS SHARED (NAT) ---
async function autoCreateVPSShared(chatId, hostname, customPassword, namaPaket) {
    const cfg = vpsNatConfig();
    if (!cfg.lengkap) throw new Error(`Konfigurasi VPS NAT belum lengkap (${cfg.kurang.join(", ")} di settings.js)`);
    if (!/^[a-z0-9][a-z0-9-]{2,31}$/.test(String(hostname || ""))) throw new Error("Hostname VPS tidak valid");
    if (!vpsNatPasswordValid(customPassword)) throw new Error("Password VPS tidak valid");
    bot.sendMessage(chatId, `⏳ Sedang membuat user \`${hostname}\` di Data center Jakarta...`, { parse_mode: "Markdown" });

    // RAM mapping buat info aja
    let ram = "1GB";
    if (namaPaket.includes("2GB")) ram = "2GB";
    if (namaPaket.includes("4GB")) ram = "4GB";
    if (namaPaket.includes("8GB")) ram = "8GB";

    try {
        // Mode lokal (bot di VPS NAT ini) atau SSH (server NAT lain). Perintah sama untuk keduanya.
        let jalankan, tutup = () => {};
        if (cfg.mode === "lokal") {
            jalankan = (cmd, stdin) => vpsNatExecLokal(cmd, stdin);
        } else {
            const { NodeSSH } = require('node-ssh');
            const ssh = new NodeSSH();
            await ssh.connect({ host: cfg.host, port: cfg.port, username: 'root', password: cfg.password, readyTimeout: 60000 });
            jalankan = (cmd, stdin) => ssh.execCommand(cmd, stdin ? { stdin } : {});
            tutup = () => ssh.dispose();
        }

        // 1. Buat user linux (hostname sudah divalidasi [a-z0-9-])
        // 2. Password dikirim lewat stdin chpasswd -> tidak pernah masuk ke perintah shell (anti injeksi)
        try {
            const buat = await jalankan(`id ${hostname} >/dev/null 2>&1 || useradd -m -s /bin/bash ${hostname}`);
            if (buat.code) throw new Error(buat.stderr || `useradd gagal (kode ${buat.code})`);
            const pw = await jalankan("chpasswd", `${hostname}:${customPassword}\n`);
            if (pw.code) throw new Error(pw.stderr || `chpasswd gagal (kode ${pw.code})`);
            await jalankan(`usermod -aG sudo ${hostname}`);
        } finally {
            tutup();
        }

        const ipShared = settings.vps_shared_host;
        const port = 22; // atau port custom NAT lu, misal 2000 + id

        const textSuccess = `<blockquote>✅ VPS BERHASIL DIBUAT!

💻 Detail Server:
├ Hostname: ${hostname}
├ Paket: ${namaPaket} (${ram})
├ IP: ${PUBLIC_IP}
└ Status: Active

🌐 Detail Akses (SSH):
├ IP Address: ${PUBLIC_IP}
├ Username: ${hostname}
├ Password: ${customPassword}
└ Port: ${PUBLIC_PORT}

Gunakan Termius / Putty / Termux untuk login.\n\nLogin Sekarang: ssh ${hostname}@185.205.222.202 -p 10892\ndan Masukan Password.\n\n❌Dilarang Install Panel Pterodactyl\nMore : /natvps
</blockquote>`;

        await bot.sendMessage(chatId, textSuccess, { parse_mode: "HTML" });

        // Kurangi stok shared. VPS SUDAH dibuat: error di sini tidak boleh membatalkan order (memicu refund).
        try {
            const currentStore = getStore();
            if (currentStore.vps_inventory?.shared?.[ram]) {
                currentStore.vps_inventory.shared[ram].stock = Math.max(0, currentStore.vps_inventory.shared[ram].stock - 1);
                updateStore(currentStore);
            }
        } catch (e) {
            console.error("[VPS NAT] gagal kurangi stok:", e.message);
            bot.sendMessage(settings.adminId, `⚠️ VPS NAT ${hostname} sudah dibuat, tapi stok gagal dikurangi otomatis: ${e.message}`).catch(() => {});
        }

    } catch (error) {
        console.error("ERROR CREATE VPS SHARED:", error.message);
        bot.sendMessage(chatId, `⚠️ *Gagal membuat VPS Shared!* Error: ${error.message}`, { parse_mode: "Markdown" });
        throw error; // biar ke-refund otomatis di pay_via_saldo
    }
}
// ====================================================
// FUNGSI BANTUAN: LOGIN KE OPENSTACK HOSTVDS
// Mengembalikan { token, computeUrl }
// ====================================================
async function getHostvdsToken() {
    try {
        const authPayload = {
            auth: {
                identity: {
                    methods: ["password"],
                    password: {
                        user: {
                            name: settings.hostvds.username,
                            domain: { id: settings.hostvds.domainId },
                            password: settings.hostvds.password
                        }
                    }
                },
                scope: {
                    project: {
                        name: settings.hostvds.projectName,
                        domain: { id: settings.hostvds.domainId }
                    }
                }
            }
        };

        // Tembak Login Keystone v3
        const res = await axios.post(`${settings.hostvds.authUrl}/auth/tokens`, authPayload);
        const token = res.headers['x-subject-token'];
        
        // Ekstrak Catalog untuk mencari URL Nova Compute Region Amsterdam
        const catalog = res.data.token.catalog;
        const computeService = catalog.find(c => c.type === 'compute');
        
        if (!computeService) throw new Error("Layanan Compute tidak ditemukan di HostVDS!");

        let endpoint = computeService.endpoints.find(e => e.interface === 'public' && e.region === settings.hostvds.region);
        if (!endpoint) endpoint = computeService.endpoints.find(e => e.interface === 'public');

        return { token: token, computeUrl: endpoint.url };

    } catch (err) {
        console.error("ERROR LOGIN HOSTVDS:", err.response ? JSON.stringify(err.response.data) : err.message);
        throw new Error("Gagal login ke OpenStack HostVDS. Cek kredensial di settings.js!");
    }
}

// ====================================================
// FITUR ADMIN: AMBIL ID OS DARI HOSTVDS
// ====================================================

bot.onText(/\/link (.+)/, async (msg, match) => {
  const email = match[1].trim();
  const chatId = msg.chat.id;
  
  try {
    const res = await fetch( `${WORKER}/api/telegram/link`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, telegram_id: chatId })
    }).then(r=>r.json());

    console.log("[LINK RESULT]", res); // biar keliatan di logs
    
    if(res.status) {
      bot.sendMessage(chatId, "✅ Terhubung! /start lagi");
    } else {
      bot.sendMessage(chatId, "❌ " + (res.msg || res.message || JSON.stringify(res)));
    }
  } catch(e) {
    bot.sendMessage(chatId, "❌ Error: " + e.message);
  }
});
// 3. COMMAND /getos YANG SUDAH DIUBAH
bot.onText(/^\/getos/, async (msg) => {
    const chatId = msg.chat.id;
    if (String(chatId) !== String(settings.adminId)) return;

    const waitMsg = await bot.sendMessage(chatId, "⏳ <i>Login ke HostVDS dan mengambil data OS...</i>", { parse_mode: "HTML" });
    
    try {
        const hostvds = await getHostvdsToken();

        const res = await axios.get(`${hostvds.computeUrl}/images`, {
            headers: { "X-Auth-Token": hostvds.token }
        });
        
        // Simpan data array OS ke dalam cache berdasarkan chatId
        osDataCache[chatId] = res.data.images;

        // Buat tampilan untuk Halaman 1
        const pageContent = generateOSPage(chatId, 1);
        
        if (!pageContent) {
             return bot.editMessageText("❌ Data kosong.", { chat_id: chatId, message_id: waitMsg.message_id });
        }

        bot.editMessageText(pageContent.text, { 
            chat_id: chatId, 
            message_id: waitMsg.message_id, 
            parse_mode: "HTML",
            reply_markup: pageContent.reply_markup
        });

    } catch (err) {
        bot.editMessageText(`❌ Gagal mengambil OS:\n${err.message}`, { chat_id: chatId, message_id: waitMsg.message_id });
    }
});

// ====================================================
// COMMAND BROADCAST VOUCHER PROMO (DENGAN PANDUAN)
// ====================================================
// ====================================================
// KODE VN PROMO ON/OFF/SET
// ====================================================

bot.onText(/^\/vnpromo (on|off|set)/, async (msg, match) => {
    const chatId = msg.chat.id;
    if (chatId !== Number(settings.adminId)) return; // Hanya untuk admin

    const action = match[1];
    const args = msg.text.split(' ')[2];

    if (action === 'on') {
        settings.vnPromo.active = true;
        await bot.sendMessage(chatId, "<blockquote>✅ <b>Promo Diskon VN diaktifkan!</b></blockquote>", { parse_mode: "HTML" });
    } 
    else if (action === 'off') {
        settings.vnPromo.active = false;
        await bot.sendMessage(chatId, "<blockquote>❌ <b>Promo Diskon VN dimatikan!</b></blockquote>", { parse_mode: "HTML" });
    }
    else if (action === 'set' && args) {
        settings.vnPromo.discount = parseInt(args);
        await bot.sendMessage(chatId, `<blockquote>⚙️ <b>Nominal diskon VN diatur ke: Rp ${args}</b></blockquote>`, { parse_mode: "HTML" });
    }
});


bot.onText(/^\/addvoucher(?:\s+(.*))?$/, async (msg, match) => {
    const chatId = msg.chat.id;
    if (String(chatId) !== String(settings.adminId)) return;

    // 1. CEK JIKA ADMIN HANYA KETIK /sebarvoucher ATAU FORMAT SALAH
    const args = match[1] ? match[1].split(" ") : [];

    if (args.length < 5) {
        const panduanMsg = `<blockquote>⚠️ <b>FORMAT PERINTAH SALAH!</b>\n━━━━━━━━━━━━━━━━━━\n\nUntuk menyebar voucher diskon, gunakan format berikut:\n\n<code>/addvoucher [Kode_Voucher] [Diskon_%] [Kuota] [Nama_Paket] [Harga_Normal]</code>\n\n<b>📌 Contoh Penggunaan:</b>\n<code>/addvoucher RAMADHAN 50 10 Started_1GB 5000</code>\n\nDAFTAR PAKET:\nStarted_1GB\nStarted_2GB\nMedium_6GB\nMedium_8GB\nPRO_Unlimited\n\n<i>Keterangan:</i>\n- <b>RAMADHAN</b>: Nama kode voucher.\n- <b>50</b>: Diskon 50%.\n- <b>10</b>: Hanya berlaku untuk 10 orang tercepat.\n- <b>Started_1GB</b>: Nama paket (Gunakan garis bawah <code>_</code> untuk spasi).\n- <b>5000</b>: Harga asli paket sebelum diskon.</blockquote>`;
        
        return bot.sendMessage(chatId, panduanMsg, { parse_mode: "HTML" });
    }

    // 2. AMBIL VARIABEL DARI INPUT ADMIN
    const kodeVoucher = args[0].toUpperCase();
    const diskonPersen = parseInt(args[1]);
    const kuota = parseInt(args[2]);
    const namaPaket = args[3].replace(/_/g, " "); // Mengubah garis bawah kembali jadi spasi
    const hargaAsli = parseInt(args[4]);

    // Validasi angka agar tidak error
    if (isNaN(diskonPersen) || isNaN(kuota) || isNaN(hargaAsli)) {
        return bot.sendMessage(chatId, "⚠️ Diskon, Kuota, dan Harga Asli harus berupa angka!", { parse_mode: "HTML" });
    }

    // 3. SIMPAN VOUCHER KE MEMORI
    activeVouchers[kodeVoucher] = {
        diskon: diskonPersen,
        sisaKuota: kuota,
        paket: namaPaket,
        hargaNormal: hargaAsli
    };

    const users = getUsers();
    const userIds = Array.isArray(users) ? users : Object.keys(users);

    await bot.sendMessage(chatId, `⏳ Mengirim Voucher <b>${kodeVoucher}</b> ke <b>${userIds.length}</b> user...`, { parse_mode: "HTML" });

    // ====================================================
    // 4. FORMAT TANGGAL DAN JAM SAAT INI (WIB)
    // ====================================================
    const now = new Date();
    // Mengatur zona waktu ke Asia/Jakarta (WIB)
    const tglOptions = { timeZone: 'Asia/Jakarta', day: '2-digit', month: 'long', year: 'numeric' };
    const jamOptions = { timeZone: 'Asia/Jakarta', hour: '2-digit', minute: '2-digit', hour12: false };
    
    const tanggalStr = now.toLocaleDateString('id-ID', tglOptions); // Hasil: 15 Mei 2024
    const jamStr = now.toLocaleTimeString('id-ID', jamOptions).replace(/\./g, ':'); // Hasil: 14:30
    
    // Gabungkan Tanggal dan Jam
    const waktuBroadcast = `${tanggalStr} | ${jamStr} WIB`;

    // 5. FORMAT PESAN BROADCAST QUOTE (Dengan Tanggal & Jam)
    const broadcastMsg = `<blockquote>🎉 <b>VOUCHER DISKON SPESIAL!</b>
━━━━━━━━━━━━━━━━━━

Kode Voucher : <b>${kodeVoucher}</b>
Diskon <b>${diskonPersen}%</b>
Produk : Panel Pterodactyl paket <b>${namaPaket}</b>!

<i>Voucher Tersedia : ${kuota}

📆 <i>Diterbitkan : ${waktuBroadcast}</i></i></blockquote>`;

    const broadcastOptions = {
        parse_mode: "HTML",
        reply_markup: {
            inline_keyboard: [
                [{ text: `🎟 𝘉𝘦𝘭𝘪 𝘥𝘦𝘯𝘨𝘢𝘯 𝘝𝘰𝘶𝘤𝘩𝘦𝘳`, callback_data: `klaimvc_${kodeVoucher}` }]
            ]
        }
    };

    // 6. EKSEKUSI PENGIRIMAN (LOOPING AMAN)
    let sukses = 0;
    for (const userId of userIds) {
        try {
            await bot.sendMessage(userId, broadcastMsg, broadcastOptions);
            sukses++;
        } catch (error) {}
        await delay(50); // Jeda anti-banned Telegram
    }

    bot.sendMessage(chatId, `<blockquote>✅ <b>Broadcast Voucher Selesai!</b>\nBerhasil terkirim ke ${sukses} user.</blockquote>`, { parse_mode: "HTML" });
});
// ====================================================
// FITUR ADMIN: AMBIL ID SPEK (FLAVOR) DARI HOSTVDS
// ====================================================
bot.onText(/^\/getspek/, async (msg) => {
    const chatId = msg.chat.id;
    if (String(chatId) !== String(settings.adminId)) return;

    const waitMsg = await bot.sendMessage(chatId, "⏳ <i>Login ke HostVDS dan mengambil data Spek...</i>", { parse_mode: "HTML" });
    
    try {
        const hostvds = await getHostvdsToken();

        // Tembak API Asli HostVDS (Bukan baseUrl lagi)
        const res = await axios.get(`${hostvds.computeUrl}/flavors/detail`, {
            headers: { "X-Auth-Token": hostvds.token }
        });
        
        let text = "⚙️ <b>DAFTAR ID SPEK HOSTVDS</b>\n\n";
        res.data.flavors.forEach(f => {
            text += `<b>${f.name}</b> (RAM: ${f.ram}MB, CPU: ${f.vcpus})\nID: <code>${f.id}</code>\n\n`;
        });
        
        bot.editMessageText(text, { chat_id: chatId, message_id: waitMsg.message_id, parse_mode: "HTML" });
    } catch (err) {
        bot.editMessageText(`❌ Gagal mengambil Spek:\n${err.message}`, { chat_id: chatId, message_id: waitMsg.message_id });
    }
});

//handlePaymentSuccess

async function handlePaymentSuccess(chatId, session, orderId, messageId = null) {
    try {
        // --- 1. JIKA USER DEPOSIT ---
        if (session.type === "deposit") {
            // Saldo yang dipakai bayar ada di website (getSaldoReal / potongSaldoReal),
            // jadi deposit dikreditkan ke sana. updateSaldo lokal akan tertimpa getSaldoReal.
            const kredit = await kreditSaldoWebsite(chatId, session.amount, `Deposit ${orderId}`);
            if (!kredit || !kredit.status) {
                // Jangan throw: catch pemanggil akan refund lagi ke endpoint yang sama (risiko kredit ganda)
                const alasan = (kredit && (kredit.msg || kredit.message)) || "tidak diketahui";
                bot.sendMessage(chatId, `⚠️ Pembayaran deposit diterima, tapi saldo belum bisa ditambahkan otomatis.\nAdmin akan memprosesnya manual. Simpan Order ID: <code>${orderId}</code>`, { parse_mode: "HTML" }).catch(() => {});
                bot.sendMessage(settings.adminId, `<blockquote>⚠️ <b>DEPOSIT LUNAS, KREDIT SALDO GAGAL</b>\n━━━━━━━━━━━━━━━━━━\n🆔 ID: <code>${chatId}</code>\n💵 Nominal: Rp ${parseInt(session.amount).toLocaleString()}\n🧾 Order ID: <code>${orderId}</code>\n❗ ${alasan}</blockquote>`, { parse_mode: "HTML" }).catch(() => {});
                delete userSessions[chatId];
                return;
            }
            const saldoBaru = Number(kredit.new_balance) || 0;
            if (global.dbUsers && global.dbUsers[chatId]) global.dbUsers[chatId].saldo = saldoBaru;
            const textSukses = `<blockquote>✅ <b>DEPOSIT BERHASIL!</b>\n\n` +
                             `💰 Saldo Masuk: <b>Rp ${parseInt(session.amount).toLocaleString()}</b>\n` +
                             `💳 Total Saldo: <b>Rp ${saldoBaru.toLocaleString()}</b>\n\n` +
                             `Terima kasih sudah melakukan top up!</blockquote>`;

            if (messageId) await bot.editMessageText(textSukses, { chat_id: chatId, message_id: messageId, parse_mode: "HTML" }).catch(()=>{});
            else bot.sendMessage(chatId, textSukses, { parse_mode: "HTML" });

            bot.sendMessage(settings.adminId, `<blockquote>💰 <b>INCOME: DEPOSIT SALDO</b>\n━━━━━━━━━━━━━━━━━━\n🆔 ID: <code>${chatId}</code>\n💵 Nominal: Rp ${parseInt(session.amount).toLocaleString()}\n🧾 Order ID: <code>${orderId}</code></blockquote>`, { parse_mode: "HTML" });
            depKirimTestimoni(chatId, session, orderId); // testimoni ke channel (async, tidak menghambat user)
        } 
        
        // --- 2. JIKA PERPANJANG PANEL ---
        else if (session.type === "extend") {
            const panelUser = extendServer(chatId, session.serverIndex, session.days);
            const textSukses = `<blockquote>🎉 <b>PEMBAYARAN SUKSES!</b>\nPanel <code>${panelUser}</code> telah diperpanjang selama ${session.days} hari.</blockquote>`;

            if (messageId) await bot.editMessageCaption(textSukses, { chat_id: chatId, message_id: messageId, parse_mode: "HTML" }).catch(() => {});
            else bot.sendMessage(chatId, textSukses, { parse_mode: "HTML" });

            bot.sendMessage(settings.adminId, `<blockquote>💸 <b>INCOME: PERPANJANG PANEL</b>\n━━━━━━━━━━━━━━━━━━\n🆔 ID: <code>${chatId}</code>\n🖥 Panel: <code>${panelUser}</code>\n⏳ Tambah: ${session.days} Hari</blockquote>`, { parse_mode: "HTML" });
        } 

        // --- 3. JIKA USER IKUT PATUNGAN VPS (FITUR UTAMA) ---
        else if (session.type === "patungan") {
            const textSukses = `<blockquote>🎉 <b>PEMBAYARAN BERHASIL!</b>\n\nAnda resmi menjadi <b>${session.role}</b> di kelompok patungan ini. Memproses data...</blockquote>`;
            
            if (messageId) await bot.editMessageCaption(textSukses, { chat_id: chatId, message_id: messageId, parse_mode: "HTML" }).catch(() => {});
            else bot.sendMessage(chatId, textSukses, { parse_mode: "HTML" });

            let dbPatungan = getPatungan();
            let room = dbPatungan[session.roomId];

            // A. JIKA ROOM BELUM ADA (PEMBAYARAN CEO PERTAMA)
            if (!room) {
                const expiresAt = new Date();
                expiresAt.setHours(expiresAt.getHours() + (session.durasi || 24));

                dbPatungan[session.roomId] = {
                    id: session.roomId,
                    paket: session.paket,
                    targetHarga: session.hargaVps,
                    current: 0,
                    mode: session.mode,
                    slot: session.slot || 999,
                    members: [],
                    status: "OPEN",
                    expiresAt: expiresAt.toISOString(),
                    captainId: chatId
                };
                room = dbPatungan[session.roomId];
            }

            // B. TAMBAHKAN MEMBER BARU
            const newUser = {
                id: chatId,
                username: session.username_tg || "User",
                amount: session.harga,
                role: session.role
            };

            room.members.push(newUser);
            room.current += newUser.amount;
            savePatungan(dbPatungan);

            // C. NOTIFIKASI KE MEMBER LAIN & ADMIN
            sendJoinNotification(room, newUser);

            const notifAdmin = `<blockquote>🤝 <b>INCOME: JOIN PATUNGAN</b>\n━━━━━━━━━━━━━━━━━━\n🆔 ID: <code>${chatId}</code>\n🎖 Role: <b>${session.role}</b>\n📦 Paket: ${session.paket}\n📈 Progres: Rp ${room.current}/${room.targetHarga}\n⏳ Mode: ${session.mode.toUpperCase()}</blockquote>`;
            bot.sendMessage(settings.adminId, notifAdmin, { parse_mode: "HTML" }).catch(()=>{});

            // D. CEK JIKA DANA SUDAH TERKUMPUL (GOAL)
            if (room.current >= room.targetHarga) {
                room.status = "PROCESSING";
                savePatungan(dbPatungan);

                room.members.forEach(m => {
                    bot.sendMessage(m.id, `<blockquote>🔥 <b>DANA TERKUMPUL!</b>\n\nTarget Rp ${room.targetHarga.toLocaleString()} terpenuhi. VPS akan segera dibuat oleh sistem. Kapten (CEO) akan menerima datanya.</blockquote>`, { parse_mode: "HTML" }).catch(()=>{});
                });

                bot.sendMessage(settings.adminId, `<blockquote>🚀 <b>PATUNGAN SELESAI (FULL)</b>\nRoom: <code>${session.roomId}</code>\n\nDana sudah terkumpul penuh. Segera eksekusi pembuatan VPS.</blockquote>`, { parse_mode: "HTML" });
            }
        }

        // --- 4. JIKA VPS BARU ---
        // --- 4. JIKA VPS BARU ---
                // --- 4. JIKA VPS BARU ---
                // --- 4. JIKA VPS BARU ---
        else if (session.type === "vps" || session.type === "vps_shared" || session.type === "vps_dedicated" || String(session.type).startsWith("vps_")) {
            const textSukses = `<blockquote>🎉 <b>PEMBAYARAN SUKSES!</b>\n\nVPS Anda sedang dideploy otomatis...</blockquote>`;
            if (messageId) await bot.editMessageCaption(textSukses, { chat_id: chatId, message_id: messageId, parse_mode: "HTML" }).catch(() => {});
            else bot.sendMessage(chatId, textSukses, { parse_mode: "HTML" });

            // ROUTING FIX - SHARED HARUS DI ATAS
            if (session.type === "vps_shared") {
                // Ini yang bener buat VPS SHARED - pakai hostname & password request user
                await autoCreateVPSShared(chatId, session.hostname, session.password, session.paket);
                updateUserProfile(chatId, session.paket, session.hostname, { jenis: "vps_shared", harga: session.harga, host: `${PUBLIC_IP}:${PUBLIC_PORT}` });
            } else {
                // Ini baru buat DEDICATED (HostVDS Amsterdam)
                await autoCreateVPS(chatId, session.username, session.paket);
                updateUserProfile(chatId, session.paket, session.username, { jenis: "vps_dedicated", harga: session.harga });
            }

            bot.sendMessage(settings.adminId, `<blockquote>🖥️ <b>INCOME: VPS BARU</b>\n━━━━━━━━━━━━━━━━━━\n🆔 ID: <code>${chatId}</code>\n📦 Paket: ${session.paket}\n👤 Host: <code>${session.hostname || session.username}</code>\n🧾 Order ID: <code>${orderId}</code></blockquote>`, { parse_mode: "HTML" });
        }
        // --- 5. JIKA JASA INSTALL ---
        else if (session.type === "jasa_install") {
            bot.sendMessage(chatId, `<blockquote>🎉 <b>PEMBAYARAN JASA SUKSES!</b>\n\nSilakan kirimkan <b>IP VPS</b> Anda:</blockquote>`, { parse_mode: "HTML" });
            bot.sendMessage(settings.adminId, `<blockquote>🛠️ <b>INCOME: JASA INSTALL</b>\n━━━━━━━━━━━━━━━━━━\n🆔 ID: <code>${chatId}</code>\n🧾 Order ID: <code>${orderId}</code></blockquote>`, { parse_mode: "HTML" });
            userSessions[chatId] = { type: "install", step: "awaiting_install_ip" };
            return; 
        }
        
                // --- 6. DEFAULT (PANEL BARU) ---
        else if (session.type === "panel") {
            const textSukses = `<blockquote>🎉 <b>PEMBAYARAN SUKSES!</b>\n\nPanel Pterodactyl Anda sedang dibuat...</blockquote>`;
            if (messageId) await bot.editMessageCaption(textSukses, { chat_id: chatId, message_id: messageId, parse_mode: "HTML" }).catch(() => {});
            else bot.sendMessage(chatId, textSukses, { parse_mode: "HTML" });

            // FIX: CREATE DULU BARU INCOME, DAN AWAIT
            await autoCreatePanel(chatId, session.username, session.paket);
            bot.sendMessage(settings.adminId, `<blockquote>📦 <b>INCOME: PANEL BARU</b>\n━━━━━━━━━━━━━━━━━━\n🆔 ID: <code>${chatId}</code>\n👤 User: <code>${session.username}</code>\n🧾 Order ID: <code>${orderId}</code></blockquote>`, { parse_mode: "HTML" });
        }
        // --- 7. RENTAL PANEL PER JAM ---
        else if (session.type === "hourly") {
            const textSukses = `<blockquote>🎉 <b>PEMBAYARAN SUKSES!</b>\n\nPanel rental ${session.jam} jam Anda sedang dibuat...</blockquote>`;
            if (messageId) await bot.editMessageCaption(textSukses, { chat_id: chatId, message_id: messageId, parse_mode: "HTML" }).catch(() => {});
            else bot.sendMessage(chatId, textSukses, { parse_mode: "HTML" });

            await autoCreatePanelTimed(chatId, session.paket, session.jam);
            bot.sendMessage(settings.adminId, `<blockquote>🕒 <b>INCOME: RENTAL PANEL</b>\n━━━━━━━━━━━━━━━━━━\n🆔 ID: <code>${chatId}</code>\n⏳ Durasi: ${session.jam} Jam\n🧾 Order ID: <code>${orderId}</code></blockquote>`, { parse_mode: "HTML" });
        }
        // --- 8. NOMOR OTP (HEROSMS) ---
        // Gagal ambil nomor -> throw, pemanggil (QRIS 1) mengembalikan dana ke saldo
        else if (session.type === "otp") {
            try {
                await otpAmbilNomor({
                    userId: session.userId || chatId, chatId,
                    service: session.service, country: session.country,
                    cost: Number(session.cost), harga: Number(session.harga), username: session.tgUser
                });
            } catch (e) {
                // Dana dikembalikan ke saldo oleh pemanggil; setelah itu tawarkan harga lain (bisa dibayar pakai saldo tadi)
                if (OTP_HABIS_DI_HARGA.includes(e.message)) setTimeout(() => otpTawarkanHargaLain(chatId, session.service, session.country, Number(session.cost)), 1500);
                throw e;
            }
        }
        // --- 8b. NOMOR OTP SERVER 2 ---
        else if (session.type === "otp2") {
            try {
                await otp2AmbilNomor({
                    userId: session.userId || chatId, chatId,
                    service: session.service, country: session.country,
                    cost: Number(session.cost), pid: session.pid, harga: Number(session.harga), username: session.tgUser
                });
            } catch (e) {
                if (OTP2_HABIS_DI_HARGA.includes(e.message)) setTimeout(() => otp2TawarkanHargaLain(chatId, session.service, session.country, Number(session.cost), session.pid), 1500);
                throw e;
            }
        }
        // --- 8c. ORDER SMM (gagal pasti -> throw, pemanggil QRIS mengembalikan dana) ---
        else if (session.type === "smm") {
            await smmProsesSetelahBayar(chatId, session, orderId);
        }
        // --- 9. SAFETY: KALAU TYPE GAK DIKENAL JANGAN PAKSA JADI PANEL ---
        else {
            throw new Error(`Tipe order tidak dikenal: ${session.type} | paket: ${session.paket}`);
        }

        delete userSessions[chatId];

    } catch (e) {
        console.log("Error handlePaymentSuccess:", (e && e.stack) || e);
        bot.sendMessage(settings.adminId, `⚠️ <b>ERROR HANDLER</b> (${String(session && session.type).replace(/[<>&]/g, "")}): ${String(e && e.message).replace(/[<>&]/g, "")}`, { parse_mode: "HTML" }).catch(()=>{});
        // FIX: LEMPAR LAGI BIAR DI pay_via_saldo KETRIGGER REFUND
        throw e;
    }
}

// ====================================================
// QRIS 1 (FAST / TRIPAY): PROSES ORDER SETELAH LUNAS
// ====================================================
// Dipanggil oleh timer otomatis & tombol "CEK STATUS". Diteruskan ke handlePaymentSuccess,
// jadi autoCreatePanel / autoCreateVPS / autoCreateVPSShared / autoCreatePanelTimed / deposit /
// extend / patungan / jasa_install jalan sesuai session.type.
async function selesaikanQrisTripay(reference) {
    const order = qrisPending.get(reference);
    if (!order || qrisDiproses.has(reference)) return; // cegah proses ganda
    qrisDiproses.add(reference);
    clearInterval(order.timer);
    qrisPending.delete(reference);

    const { chatId, userId, session, amount, messageId } = order;
    await bot.deleteMessage(chatId, messageId).catch(() => {});
    await bot.sendMessage(chatId, `✅ <b>Pembayaran berhasil!</b>\nReferensi: <code>${reference}</code>\n\n⏳ Memproses pesanan...`, { parse_mode: "HTML" }).catch(() => {});

    try {
        session.metodeBayar = session.metodeBayar || "QRIS";
        await handlePaymentSuccess(chatId, session, reference);
    } catch (err) {
        // Dana QRIS sudah masuk, jadi kalau eksekusi gagal kembalikan ke saldo akun
        console.error(`[QRIS1] Gagal ${reference} type=${session.type} paket=${session.paket}:`, err.message);
        const refund = await refundSaldoReal(userId, amount, `Gagal eksekusi ${reference} - ${err.message}`).catch(e => ({ status: false, msg: e.message }));

        refund.status = saldoSukses(refund);
        if (refund.status) {
            await bot.sendMessage(chatId, `❌ Order gagal (${err.message}), dana Rp ${amount.toLocaleString()} sudah dimasukkan ke saldo akun.\nSisa saldo: Rp ${(Number(refund.new_balance) || 0).toLocaleString()}`);
        } else {
            await bot.sendMessage(chatId, `❌ FATAL: Order gagal & refund gagal! Hubungi admin dengan referensi ${reference}.\nError: ${err.message} | Refund: ${refund.msg}`);
        }
        bot.sendMessage(settings.adminId, `⚠️ <b>QRIS 1 LUNAS TAPI ORDER GAGAL</b>\n🆔 ID: <code>${chatId}</code>\n🧾 Ref: <code>${reference}</code>\n💵 Rp ${amount.toLocaleString()}\n❗ ${err.message}\n↩️ Refund saldo: ${refund.status ? "BERHASIL" : `GAGAL (${String(refund.msg || refund.message || "tanpa alasan").replace(/[<>&]/g, "")})`}`, { parse_mode: "HTML" }).catch(() => {});
    }
}
// ====================================================
// FUNGSI AUTO CREATE VPS (HOSTVDS) - FULL REAL API
// ====================================================
async function autoCreateVPS(chatId, vpsName, namaPaket) {
    bot.sendMessage(chatId, `⏳ Sedang mendeploy VPS \`${vpsName}\` di datacenter Amsterdam. Proses ini memakan waktu 1-2 menit...`, { parse_mode: "Markdown" });

    // 1. MAPPING ID SPEK ASLI DARI HOSTVDS
    let flavorId = ""; 
    if (namaPaket.includes("1GB")) flavorId = "f5ea1bc8-de85-437f-8b89-6c2bdd11bba5"; 
    else if (namaPaket.includes("2GB")) flavorId = "68b6357b-8c89-4ab7-a845-5afbd24852c6";
    else if (namaPaket.includes("4GB")) flavorId = "c356a6fe-ebff-4c44-aa1f-ada1d93023cc";

    // 👉 TUGAS ANDA: Ganti tulisan di bawah ini dengan ID hasil dari /getos
    let imageId = "c54a6fb6-1bc6-490b-a5cd-9559232c9a3f"; 

    // 2. GENERATE PASSWORD ACAK YANG AMAN
    const randomAngka = Math.floor(1000 + Math.random() * 9000);
    const passwordVps = `Root@${vpsName}${randomAngka}!`;

    try {
        // 3. LOGIN KE HOSTVDS (Otomatis dapat Token & URL Datacenter)
        const hostvds = await getHostvdsToken();

        // 4. SUSUN PERINTAH PEMBUATAN SERVER
        const payload = {
            server: {
                name: vpsName,
                imageRef: imageId,
                flavorRef: flavorId,
                networks: "auto", // Minta IP Publik otomatis
                adminPass: passwordVps // Pasang password kita
            }
        };

        // 5. TEMBAK API CREATE SERVER
        const res = await axios.post(`${hostvds.computeUrl}/servers`, payload, {
            headers: {
                "Content-Type": "application/json",
                "X-Auth-Token": hostvds.token // Gunakan tiket masuk yang baru
            }
        });

        const serverData = res.data.server;
        const ipAddress = serverData.accessIPv4 || "Sedang dialokasikan (Tunggu 1 menit)";

        // 6. KIRIM HASILNYA KE PEMBELI
                const textSuccess = `<blockquote>✅ <b>VPS BERHASIL DIDEPLOY!</b>

🖥 <b>Detail Server:</b>
├ Nama: <code>${serverData.name}</code>
├ Paket: ${namaPaket}
└ Status: <b>Active / Booting</b>

🌐 <b>Detail Akses (SSH):</b>
├ IP Address: <code>${ipAddress}</code>
├ Username: <code>root</code>
└ Password: <code>${passwordVps}</code>

<i>Catatan: Jika IP belum muncul, silakan tunggu 1-2 menit karena server sedang dalam proses instalasi Sistem Operasi. Gunakan aplikasi Termius/Putty/Termux untuk login.</i></blockquote>`;

        bot.sendMessage(chatId, textSuccess, { parse_mode: "HTML" });

        // (Opsional) Update Profil User di Bot
        const currentStore = getStore();
        if (currentStore.vps_stock > 0) {
            currentStore.vps_stock -= 1;
            updateStore(currentStore);
        }
        // updateUserProfile(chatId, namaPaket, vpsName);

    } catch (error) {
        console.error("ERROR CREATE VPS:", error.response ? JSON.stringify(error.response.data) : error.message);
        bot.sendMessage(chatId, "⚠️ *Gagal mendeploy VPS!* Stok mungkin habis. Silakan hubungi Admin.", { parse_mode: "Markdown" });
        // FIX: LEMPAR ERROR BIAR KE-TRIGGER REFUND DI pay_via_saldo
        throw error;
    }
}
// ====================================================
// FUNGSI AUTO INSTALL PTERODACTYL VIA SSH
// ====================================================
async function runPterodactylInstaller(chatId, ip, password, domain) {
    const conn = new Client();
    
    // Generate Akun Admin Panel Default
    const adminEmail = `admin@${domain}`;
    const adminUser = "admin";
    const adminPass = "Admin@" + Math.floor(1000 + Math.random() * 9000) + "!";

    // Lapor bahwa bot sedang mencoba masuk
    await bot.sendMessage(chatId, `<blockquote>🔄 <b>Menghubungkan ke VPS...</b>\n━━━━━━━━━━━━━━━━━━\nMencoba login SSH ke IP <code>${ip}</code>...</blockquote>`, { parse_mode: "HTML" });

    // JIKA BERHASIL LOGIN
    conn.on('ready', () => {
        bot.sendMessage(chatId, `<blockquote>✅ <b>Koneksi SSH Berhasil!</b>\n━━━━━━━━━━━━━━━━━━\nBot sedang melakukan instalasi Pterodactyl & Wings di background.\n\n☕️ <i>Proses ini memakan waktu sekitar 5 - 15 menit. Silakan tinggalkan chat ini sejenak, kami akan mengabari Anda jika sudah selesai.</i></blockquote>`, { parse_mode: "HTML" });

        // ==========================================
        // BASH SCRIPT (Perintah Linux Otomatis)
        // Catatan: Script ini menggunakan instalasi standar (bisa kamu ganti dengan script curl installer favoritmu/andalanmu)
        // ==========================================
        // ==========================================
        // BASH SCRIPT: AUTO INSTALL PTERODACTYL (MODE SILUMAN)
        // ==========================================
        const cmd = `
            export DEBIAN_FRONTEND=noninteractive;
            
            # 1. Update OS & Install Kebutuhan Dasar
            apt-get update -y && apt-get upgrade -y;
            apt-get install -y curl wget tar unzip git redis-server mariadb-server nginx certbot python3-certbot-nginx sudo;

            # 2. Install PHP 8.1 (Wajib untuk Pterodactyl)
            apt -y install software-properties-common apt-transport-https ca-certificates gnupg;
            LC_ALL=C.UTF-8 add-apt-repository -y ppa:ondrej/php;
            apt-get update -y;
            apt-get install -y php8.1 php8.1-{common,cli,gd,mysql,mbstring,bcmath,xml,fpm,curl,zip};

            # 3. Install Composer
            curl -sS https://getcomposer.org/installer | sudo php -- --install-dir=/usr/local/bin --filename=composer;

            # 4. Setup Database MariaDB (Otomatis)
            mysql -u root -e "CREATE DATABASE panel;";
            mysql -u root -e "CREATE USER 'pterodactyl'@'127.0.0.1' IDENTIFIED BY 'PteroPassword123!';";
            mysql -u root -e "GRANT ALL PRIVILEGES ON panel.* TO 'pterodactyl'@'127.0.0.1' WITH GRANT OPTION;";
            mysql -u root -e "FLUSH PRIVILEGES;";

            # 5. Download Panel Pterodactyl
            mkdir -p /var/www/pterodactyl;
            cd /var/www/pterodactyl;
            curl -Lo panel.tar.gz https://github.com/pterodactyl/panel/releases/latest/download/panel.tar.gz;
            tar -xzvf panel.tar.gz;
            chmod -R 755 storage/* bootstrap/cache/;

            # 6. Konfigurasi Environment (.env)
            cp .env.example .env;
            COMPOSER_ALLOW_SUPERUSER=1 composer install --no-dev --optimize-autoloader;
            php artisan key:generate --force;

            # Inject Data ke .env
            sed -i "s/APP_URL=http:\\/\\/localhost/APP_URL=https:\\/\\/${domain}/g" .env;
            sed -i "s/DB_PASSWORD=/DB_PASSWORD=PteroPassword123!/g" .env;

            # 7. Migrasi Database & Buat Akun Admin
            php artisan migrate --seed --force;
            php artisan p:user:make --email="${adminEmail}" --username="${adminUser}" --name-first="Admin" --name-last="Ganteng" --password="${adminPass}" --admin=1;

            # Set Kepemilikan Folder
            chown -R www-data:www-data /var/www/pterodactyl/*;

            # 8. Setup SSL (Gembok Hijau) & Nginx
            # PENTING: Perintah ini akan ERROR jika domain belum di pointing ke IP VPS!
            systemctl stop nginx;
            certbot certonly --standalone --non-interactive --agree-tos -m "${adminEmail}" -d "${domain}";

            # Download Config Nginx Pterodactyl
            curl -o /etc/nginx/sites-available/pterodactyl.conf https://raw.githubusercontent.com/pterodactyl/architecture/master/configs/nginx/pterodactyl.conf;
            sed -i "s/<domain>/${domain}/g" /etc/nginx/sites-available/pterodactyl.conf;
            ln -s /etc/nginx/sites-available/pterodactyl.conf /etc/nginx/sites-enabled/pterodactyl.conf;
            rm /etc/nginx/sites-enabled/default;

            systemctl restart nginx;

            # 9. Setup Cronjob & Worker
            echo "* * * * * php /var/www/pterodactyl/artisan schedule:run >> /dev/null 2>&1" | crontab -u www-data -;
            
            # Selesai! Mengirim sinyal sukses ke Bot Telegram
            echo "DONE_INSTALL";
        `;

        // Eksekusi Perintah
        conn.exec(cmd, (err, stream) => {
            if (err) {
                bot.sendMessage(chatId, `<blockquote>❌ <b>INSTALASI GAGAL!</b>\n━━━━━━━━━━━━━━━━━━\nTerjadi kesalahan saat mengeksekusi perintah di VPS Anda.</blockquote>`, { parse_mode: "HTML" });
                return conn.end();
            }

            stream.on('close', (code, signal) => {
                conn.end(); // Tutup koneksi SSH
                
                // Jika proses bash selesai dengan sukses (code 0)
                                if (code === 0) {
                    // 1. Kirim Pesan Sukses Panel
                    const textSuccess = `<blockquote>🎉 <b>INSTALASI PANEL SELESAI!</b>
━━━━━━━━━━━━━━━━━━
🌐 <b>URL Panel:</b> https://${domain}
👤 <b>Username:</b> <code>${adminUser}</code>
🔐 <b>Password:</b> <code>${adminPass}</code>

⚠️ <b>TAHAP AKHIR (INSTALL WINGS):</b>
Bot membutuhkan <b>Kode Konfigurasi Node</b> agar server bisa dinyalakan.

<b>Langkah-langkah:</b>
1. Login ke URL Panel di atas.
2. Ke menu Admin (Ikon Gear) ➔ Locations ➔ Create New.
3. Ke menu Nodes ➔ Create New ➔ Isi FQDN dengan <code>${domain}</code>.
4. Pergi ke tab <b>Configuration</b> pada Node yang baru dibuat.
5. Copy kode <b>Auto Deploy</b> (Biasanya berawalan <code>sudo ptero...</code> atau <code>curl...</code>).
6. <b>PASTE KODE TERSEBUT DI SINI!</b>

⏳ <i>Waktu Anda: 1 Menit dari sekarang. Jika lewat, Auto-Install Wings dibatalkan.</i></blockquote>`;

                    bot.sendMessage(chatId, textSuccess, { parse_mode: "HTML" });

                    // 2. Buat Timer 1 Menit (60.000 ms)
                    const timeoutId = setTimeout(() => {
                        if (userSessions[chatId] && userSessions[chatId].step === "awaiting_wings_token") {
                            bot.sendMessage(chatId, `<blockquote>⏰ <b>WAKTU HABIS!</b>\n━━━━━━━━━━━━━━━━━━\nAnda tidak mengirimkan Token Wings dalam 1 menit.\n\nInstalasi Wings otomatis dibatalkan. Anda harus menginstal ulang.</blockquote>`, { parse_mode: "HTML" });
                            delete userSessions[chatId]; // Hapus sesi
                        }
                    }, 60000); // 60000 ms = 1 Menit

                    // 3. Simpan Sesi untuk menunggu Token
                    userSessions[chatId] = {
                        type: "install_wings",
                        step: "awaiting_wings_token",
                        ip: ip,
                        pass: password,
                        timer: timeoutId // Simpan ID timer agar bisa dibatalkan jika user cepat
                    };

                } else {
                    bot.sendMessage(chatId, `<blockquote>❌ <b>INSTALASI GAGAL (ERROR CODE: ${code})</b>\n━━━━━━━━━━━━━━━━━━\nProses terhenti di tengah jalan. Pastikan OS VPS adalah Ubuntu 22.04 Fresh Install.</blockquote>`, { parse_mode: "HTML" });
                }
            }).on('data', (data) => {
                // Opsional: Jika ingin melihat log instalasi di console panelmu
                console.log(`[SSH LOG ${ip}]: ${data}`);
            }).stderr.on('data', (data) => {
                console.log(`[SSH ERROR ${ip}]: ${data}`);
            });
        });
    });

    // JIKA GAGAL LOGIN (IP Mati, Pass Salah, Port 22 ditutup)
    conn.on('error', (err) => {
        let alasan = "Terjadi kesalahan koneksi.";
        if (err.message.includes("authentication")) alasan = "Password Root salah!";
        else if (err.message.includes("connect")) alasan = "IP tidak aktif atau sedang booting. Tunggu 1 menit lalu coba lagi.";
        else if (err.message.includes("timeout")) alasan = "Koneksi Timeout (Server lambat lambat/IP Salah).";

        bot.sendMessage(chatId, `<blockquote>❌ <b>GAGAL LOGIN KE VPS</b>\n━━━━━━━━━━━━━━━━━━\n<b>Alasan:</b> ${alasan}\n\n<i>Silakan cek kembali IP dan Password Anda, lalu ulangi proses Auto Install.</i></blockquote>`, { parse_mode: "HTML" });
    });

    // Mulai Eksekusi Koneksi
    try {
        conn.connect({
            host: ip,
            port: 22,
            username: 'root',
            password: password,
            readyTimeout: 15000 // Timeout 15 detik
        });
    } catch (error) {
        bot.sendMessage(chatId, `<blockquote>❌ <b>KONEKSI DITOLAK</b>\n━━━━━━━━━━━━━━━━━━\nFormat IP salah atau server menolak koneksi Node.js.</blockquote>`, { parse_mode: "HTML" });
    }
}
// ====================================================
// FUNGSI AUTO INSTALL WINGS (TAHAP 2)
// ====================================================
async function runWingsInstaller(chatId, ip, password, tokenCommand) {
    const conn = new Client();
    
    bot.sendMessage(chatId, `<blockquote>🔄 <b>MENGINSTAL WINGS...</b>\n━━━━━━━━━━━━━━━━━━\nBot kembali login ke VPS Anda untuk menginstal sistem Docker dan Wings.\n\n<i>Proses ini memakan waktu sekitar 2-3 menit...</i></blockquote>`, { parse_mode: "HTML" });

    conn.on('ready', () => {
        // BASH SCRIPT: Install Docker, Download Wings, Eksekusi Token, Nyalakan Wings
        const cmdWings = `
            export DEBIAN_FRONTEND=noninteractive;
            
            # 1. Install Docker (Wajib untuk Wings)
            if ! [ -x "$(command -v docker)" ]; then
                curl -sSL https://get.docker.com/ | CHANNEL=stable bash;
                systemctl enable --now docker;
            fi

            # 2. Download Wings Binary
            mkdir -p /etc/pterodactyl;
            curl -L -o /usr/local/bin/wings https://github.com/pterodactyl/wings/releases/latest/download/wings_linux_$([[ "$(uname -m)" == "x86_64" ]] && echo "amd64" || echo "arm64");
            chmod u+x /usr/local/bin/wings;

            # 3. Setup Systemd Service
            curl -s -o /etc/systemd/system/wings.service https://raw.githubusercontent.com/pterodactyl/wings/main/systemd/wings.service;
            systemctl daemon-reload;

            # 4. EKSEKUSI TOKEN DARI USER (Untuk generate config.yml)
            ${tokenCommand}

            # 5. Nyalakan Wings
            systemctl enable --now wings;
            systemctl restart wings;
            
            echo "WINGS_DONE";
        `;

        conn.exec(cmdWings, (err, stream) => {
            if (err) return conn.end();

            stream.on('close', (code) => {
                conn.end();
                if (code === 0) {
                    bot.sendMessage(chatId, `<blockquote>🎉 <b>INSTALASI WINGS SUKSES!</b>\n━━━━━━━━━━━━━━━━━━\nNode Anda sekarang sudah terhubung dengan Panel Pterodactyl dan berstatus <b>Gembok Hijau (Online)</b>.\n\nAnda sudah bisa mulai membuat server game! 🎮</blockquote>`, { parse_mode: "HTML" });
                } else {
                    bot.sendMessage(chatId, `<blockquote>❌ <b>GAGAL MENYALAKAN WINGS</b>\nToken yang Anda masukkan mungkin salah atau tidak lengkap. Silakan cek menu Nodes di panel Anda.</blockquote>`, { parse_mode: "HTML" });
                }
            });
        });
    });

    conn.on('error', () => {
        bot.sendMessage(chatId, "⚠️ Gagal login kembali ke VPS. Instalasi Wings dibatalkan.");
    });

    try {
        conn.connect({ host: ip, port: 22, username: 'root', password: password, readyTimeout: 15000 });
    } catch (error) {}
}
// ====================================================
// HANDLER CALLBACK QUERY UTAMA (SUDAH FIX KURUNG KURAWAL)
// ====================================================

bot.on("callback_query", async (query) => {
    console.log("[CALLBACK DITERIMA]", query.data, query.message?.message_id);

// === KIRIM LOG KE CHANNEL ===
const logText = `📥 <b>CALLBACK DITERIMA</b>
├ Data: <code>${query.data}</code>
├ MsgID: <code>${query.message?.message_id}</code>
├ From: ${query.from.first_name} (@${query.from.username || '-'}) 
├ ID: <code>${query.from.id}</code>
└ Time: ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}`;

bot.sendMessage(LOG_CHANNEL_ID, logText, { parse_mode: "HTML" }).catch(e => {
    console.log("Gagal kirim log ke channel:", e.message);
});
    const data = query.data;
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;
    // Menu yang ditutup admin (/tutupmenu): balas info maintenance + voice, jangan proses
    {
        const sesi = userSessions[query.from.id] || userSessions[chatId];
        const menuTutup = menuTertutupUntuk(data, query.from.id, sesi);
        if (menuTutup) {
            await bot.answerCallbackQuery(query.id, { text: `🔧 Menu ${MENU_GRUP[menuTutup].nama} sedang ditutup (maintenance)` }).catch(() => {});
            await kirimInfoMenuTutup(chatId, menuTutup);
            return;
        }
    }
const caption = query.message.caption || query.message.text || '';
const matchKat = caption.match(/Kategori: (.+)/i);
  const katFromCap = matchKat? matchKat[1] : '';
const matchType = caption.match(/- (.+?)<\/b>/i);
  const typeFromCap = matchType? matchType[1] : '';
const type = matchType? matchType[1] : '';
    try { // <--- TRY DIBUKA DI SINI

  if (data === "link_akun") {
    await bot.answerCallbackQuery(q.id).catch(()=>{});
    bot.sendMessage(q.message.chat.id, "📧 Masukan email yang kamu gunakan sebagai akun di website boosteryuk.com");
  }
//pembatas

//pembatas
  if (data === 'smm') {
    const caption = `<b>💎 SMM PANEL</b>\n\n` +
                    `Suntik followers, likes, views, dll 100% aman & bergaransi.\n\n` +
                    `Klik "Pilih Kategori" lalu ketik kategori yang mau lu cari. Contoh: tiktok, instagram, youtube`;

    await bot.sendPhoto(chatId, 'https://cdn.phototourl.com/free/2026-04-10-466b4dc1-3abf-4c2d-b7d1-e626a6cf0e2c.png', { // ganti URL foto lu
      caption: caption,
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: '🔍 Pilih Kategori', callback_data: 'smm_pilih_kategori', style: "success" }],
          [{ text: '⬅️ Kembali', callback_data: 'menu_lainnya' }]
        ]
      }
    });
  }

  if (data === 'smm_pilih_kategori') {
smmMode.add(chatId); // MASUK MODE CARI KATEGORI
const userId = query.from.id;
    try {
      await bot.answerCallbackQuery(query.id); // tutup loading dulu
      
      if (globalServices.length === 0) {
        return bot.sendMessage(chatId, '⏳ Tunggu Sebentar..');
      }

      // JANGAN editMessageText. KIRIM BARU biar anti error
      await bot.sendMessage(chatId, `📝 Ketik kategori: instagram, tiktok, youtube, shopee, dll`, {
        parse_mode: 'HTML'
      });

    } catch (e) {
      console.log('Error pilih kategori:', e.message);
      // Fallback kirim baru kalo edit gagal
      bot.sendMessage(chatId, '✅ Silakan ketik kategori layanan: instagram, tiktok, youtube');
    }
  }
  if (data.startsWith('k|')) { // GANTI smm_kat_ JADI k|
  await bot.answerCallbackQuery(query.id);
  const chatId = query.message.chat.id;

  let [_, katEnc] = data.split('|'); // split pake | biar aman walau ada _
  let kategori = decodeURIComponent(katEnc || '');
  let katFromCap = kategori;

  // Generate tipe otomatis dari JSON
  const types = [...new Set(
    globalServices
     .filter(s => s?.category?.toLowerCase() === katFromCap.toLowerCase())
     .map(s => s.type)
  )];

  // Bikin keyboard + fallback juga pake t| jangan smm_type_
  const keyboard = types.length > 0
   ? types.map(t => [{text: t, callback_data: `t|${katEnc}|${encodeURIComponent(t)}|1` }])
    : [[{text: '📦 Kosong', callback_data: `t|${katEnc}||1` }]]; // fallback singkat

  // Tombol back juga disingkat
  keyboard.push([{text: '⬅️ Back', callback_data: 'kat'}]); // smm_pilih_kategori → kat

  await bot.editMessageCaption(
    `✅ Kategori: <b>${kategori}</b>\nPilih tipe layanan:`,
    {
      chat_id: chatId,
      message_id: query.message_id,
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: keyboard }
    }
  );
}
  // BARU: Klik layanan munculin deskripsi
// 1. DETAIL LAYAN o|
if (data.startsWith('o|')) {
  // Klik layanan -> langsung minta link target (lalu komentar/jumlah, ringkasan, tombol Pesan)
  await bot.answerCallbackQuery(query.id).catch(() => {});
  await smmMulaiOrder(chatId, data.split('|')[1]);
}

// 2. TOMBOL BACK back|
else if (data.startsWith('back|')) {
  await bot.answerCallbackQuery(query.id);

  let [_, katEnc, typEnc] = data.split('|');
  let kat = decodeURIComponent(katEnc || '');
  let type = decodeURIComponent(typEnc || '');

  // Langsung bikin data baru kayak klik tipe
  let newData = `t|${katEnc}|${encodeURIComponent(type)}|1`;
  query.data = newData;

  // Panggil ulang handler t| - aman karena ga fake caption
  // Kalo lu pake if-else, tinggal return aja biar ke-cek lagi
  return; // biar bot.on cek ulang data = t|
}
  // TERIMA TUGAS
  if (data.startsWith('approve_')) {
    const parts = data.split('_');
    const userId = parts[1];
    const taskIndex = parseInt(parts[2]);

    let tasks = [];
    if (fs.existsSync(FILE_TASK)) {
      tasks = JSON.parse(fs.readFileSync(FILE_TASK, 'utf8'));
    }

    const task = tasks[taskIndex];
    if (!task) {
      return bot.answerCallbackQuery(query.id, { text: 'Tugas tidak ditemukan' });
    }

    // Kredit saldo ke profil user
    const dbUsers = getUsers();
    if (!dbUsers[userId]) dbUsers[userId] = { saldoFreelance: 0 };
    dbUsers[userId].saldoFreelance += task.saldoPending;
    saveUsers(dbUsers);

    // Notif ke user
    await bot.sendMessage(userId,
  `<blockquote>✅ TUGAS DITERIMA</blockquote>\n` +
  `Tugas: ${task.task}\n` +
  `Saldo Rp${task.saldoPending.toLocaleString('id-ID')} sudah di kreditkan ke profil Anda.`,
  { 
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [{ text: '💵 Cek Profil', callback_data: 'menu_profil', style: "success" }]
      ]
    }
  }
);

    // Edit pesan admin
    await bot.editMessageText(
      query.message.text + '\n\n✅ Tugas Diterima oleh Admin',
      { chat_id: chatId, message_id: messageId, parse_mode: 'HTML' }
    );

    await bot.answerCallbackQuery(query.id, { text: 'Yeay! Tugas Berhasil Diterima' });
  }
//pembatas
const caption = query.message.caption || '';

  // Ambil kategori dari caption biar bisa balik
// Taruh di atas file, luar bot.on
const userState = {};

if (data.startsWith('t|')) {
  await bot.answerCallbackQuery(query.id);
  const userId = query.from.id;

  console.log('RAW:', data, 'PANJANG:', data.length);

  let [_, katEnc, typEnc, page] = data.split('|');
  let katFromCap = decodeURIComponent(katEnc || '');
  let type = decodeURIComponent(typEnc || ''); // fallback biar ga undefined
  page = parseInt(page) || 1;

  // Simpen buat tombol back
  userState[userId] = {kat: katFromCap, type: type};

  let filtered = globalServices.filter(s =>
    s?.category?.toLowerCase().includes(katFromCap.toLowerCase())
  );

  let finalServices = filtered.filter(s =>
    s?.name?.toLowerCase().includes((type || '').toLowerCase()) // <- fallback
  );

  const perPage = 15;
  const totalPage = Math.ceil(finalServices.length / perPage) || 1; // biar ga 0
  const start = (page - 1) * perPage;
  const list = finalServices.slice(start, start + perPage);

  const text = `<b>📑 ${katFromCap.toUpperCase()} - ${type.toUpperCase()}</b>\nPage ${page}/${totalPage} | Total: ${finalServices.length}\n\n<blockquote>Pilih layanan:</blockquote>\n`;

  const btn = list.map(s => [
    { text: `${s.name} | Rp${(s.price/1000).toLocaleString('id-ID')}/1k`, callback_data: `o|${s.id}` }
  ]);

  let nav = [];
  if(page > 1) nav.push({text: '⬅️ Sebelumnya', callback_data: `t|${katEnc}|${typEnc}|${page-1}`})
  if(page < totalPage) nav.push({text: 'Selanjutnya ➡️', callback_data: `t|${katEnc}|${typEnc}|${page+1}`})
  if(nav.length > 0) btn.push(nav);

  btn.push([{ text: '⬅️ Ganti Tipe', callback_data: `back|${katEnc}` }]);

  await bot.sendMessage(chatId, text, {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: btn }
  });
}
//pembatas
  // TOLAK TUGAS
  if (data.startsWith('reject_')) {
    const parts = data.split('_');
    const userId = parts[1];

    // Notif ke user
    await bot.sendMessage(userId,
      `<blockquote>❌ TUGAS DITOLAK</blockquote>\n` +
      `Tugas Anda ditolak admin karna alasan data tidak valid atau lainnya, jika terdapat kesalahan data harap hubungi pusat bantuan.`,
      { parse_mode: 'HTML' }
    );

    // Edit pesan admin
    await bot.editMessageText(
      query.message.text + '\n\n❌ Ditolak oleh Admin',
      { chat_id: chatId, message_id: messageId, parse_mode: 'HTML' }
    );

    await bot.answerCallbackQuery(query.id, { text: 'Tugas ditolak' });
  }
// HANDLE KERJAKAN TUGAS - dinamis
if (query.data.startsWith('do_')) {
  const campaignId = query.data.replace('do_', '');
  const campaign = campaigns.find(c => c.id === campaignId);

  if (!campaign) {
    await bot.answerCallbackQuery(query.id, { text: 'Campaign tidak ditemukan' });
    return;
  }

  const userId = query.from.id;

  // Simpan state step 1: nunggu email
  userState[userId] = { step: 'waiting_email', campaignId: campaign.id };

  await bot.deleteMessage(chatId, messageId);

  await bot.sendMessage(chatId,
    `<blockquote>📧 LANGKAH 1</blockquote>\n` +
    `Kirim alamat email Gmail Anda (Pastikan nama sudah sesuai dengan syarat & ketentuan yang berlaku).`,
    {
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: [[{ text: "« Batal", callback_data: "menu_freelance" }]] }
    }
  );

  await bot.answerCallbackQuery(query.id);
  return;
}

  // 1. HANDLE CAMPAIGN DETAIL - dinamis
  if (query.data.startsWith('campaign_')) {
  const userId = query.from.id;
    const campaignId = query.data.replace('campaign_', '');
    const campaign = campaigns.find(c => c.id === campaignId);
    
    if (!campaign) {
      await bot.answerCallbackQuery(query.id, { text: '❌ Campaign tidak ditemukan' });
      return;
    }

    const text = `<blockquote><b>${campaign.name}</b></blockquote>\n\n` +
                 `${campaign.desc}\n\n` +
                 `<b>Bayaran:</b> ${campaign.bayaran}/tugas`;

    const btn = [
      [{ text: "Kerjakan", callback_data: `do_${campaign.id}` }],
      [{ text: "« Kembali", callback_data: "menu_freelance" }]
    ];

    await bot.editMessageMedia(
      {
        type: 'photo',
        media: campaign.photo,
        caption: text,
        parse_mode: "HTML"
      },
      { chat_id: chatId, message_id: messageId, reply_markup: { inline_keyboard: btn } }
    );
    await bot.answerCallbackQuery(query.id);
    return; // stop biar ga masuk switch
  }
  
    if (data === 'stop_reminder') {
        const userId = query.from.id;
        const user = await getUserPet(userId)
        user.stopReminder = true
        await saveUser(userId, user)

        await bot.answerCallbackQuery(query.id, {
            text: 'Oke, reminder dimatiin selamanya. Kalo kangen sama pet, buka manual ya 😴',
            show_alert: true
        })

        // edit pesannya biar tombol ilang
        await bot.editMessageText('🔕 Reminder pet sudah dimatikan. Pet kamu sekarang tidur 😴', {
            chat_id: query.message.chat.id,
            message_id: query.message_id
        })
    }
        // ====================================================
        // INVOICE JASA INSTALL PTERODACTYL
        // ====================================================
        if (data === "buy_jasa_install") {
            const hargaAsli = 10000; // Harga Fix 10rb

            const textDetail = `<blockquote>📋 <b>DETAIL JASA INSTALL VPS</b>

📦 <b>Produk:</b> Auto Install Pterodactyl + SSL
💰 <b>Biaya Jasa:</b> Rp ${hargaAsli.toLocaleString('id-ID')}
━━━━━━━━━━━━━━━━━━
🧾 <b>Total Bayar:</b> <b>Rp ${hargaAsli.toLocaleString('id-ID')}</b>
<i>Bayar QRIS: + fee QRIS dihitung otomatis oleh gateway (terlihat di QR)</i>

<i>Apakah data pesanan di atas sudah benar? Jika sudah silakan klik lanjutkan dibawah ini</i></blockquote>`;

            const btnConfirm = {
                reply_markup: {
                    inline_keyboard: [
                        // Mengarah ke eksekusi pesanan Jasa
                        [{ text: "𝘓𝘢𝘯𝘫𝘶𝘵𝘬𝘢𝘯 𝘗𝘦𝘮𝘣𝘢𝘺𝘢𝘳𝘢𝘯 ✅", callback_data: "confirminstall_ready" }],
                        [{ text: "« 𝘉𝘢𝘵𝘢𝘭", callback_data: "menu_autoinstall" }]
                    ]
                }
            };

            await bot.deleteMessage(chatId, messageId).catch(()=>{});
            await bot.sendPhoto(chatId, settings.panelImage, { caption: textDetail, parse_mode: "HTML", ...btnConfirm }).catch(()=>{});
            await bot.answerCallbackQuery(query.id);
            return; 
        }
                // ====================================================
        // EKSEKUSI PEMESANAN JASA -> PILIH QRIS
        // ====================================================
                // ====================================================
        // EKSEKUSI PEMESANAN JASA -> PILIH QRIS
        // ====================================================
        if (data === "confirminstall_ready") {
            const hargaAsli = 10000;

            // KUNCI PENTING: Kita suntikkan "username" otomatis agar sistem QRIS tidak error
            userSessions[chatId] = {
                type: "jasa_install", 
                step: "awaiting_payment", 
                paket: "Jasa Auto Install Pterodactyl",
                harga: hargaAsli,
                username: `JasaInstall_${chatId}`, // <--- INI OBAT PENYEMBUHNYA
                lastBotMessageId: messageId 
            };

            await bot.deleteMessage(chatId, messageId).catch(()=>{});

            const btnPayment = {
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "⚡ 𝘘𝘳 𝘚𝘦𝘳𝘷𝘦𝘳 1 (𝘍𝘢𝘴𝘵)", callback_data: "pay_qris_tripay" }],
                    //    [{ text: "Crypto USD", callback_data: "qr_server_3" }],
                    [{ text: "💳 Bayar Pakai Saldo", callback_data: "pay_via_saldo", style: "success" }],
                        [{ text: "« 𝘉𝘢𝘵𝘢𝘭𝘬𝘢𝘯 𝘖𝘳𝘥𝘦𝘳", callback_data: "back_to_main" }]
                    ]
                }
            };
            
            const promptMsg = await bot.sendMessage(chatId, `<blockquote>✅ <b>Pesanan Jasa Install Dibuat.</b>\n━━━━━━━━━━━━━━━━━━\n\nSilakan Konfirmasi Metode pembayaran:</blockquote>`, { parse_mode: "HTML", ...btnPayment });
            
            userSessions[chatId].lastBotMessageId = promptMsg.message_id;
            await bot.answerCallbackQuery(query.id);
            return; 
        }
        // ====================================================
        // FITUR 1: MENU BANTUAN
        // ====================================================
        if (data === "menu_bantuan") {
            userSessions[chatId] = { step: "awaiting_bantuan", lastBotMessageId: messageId };
            
            await bot.deleteMessage(chatId, messageId).catch(()=>{});
            
            const helpMsg = await bot.sendMessage(chatId, `<blockquote>🆘 <b>LAYANAN BANTUAN (TICKET)</b>\n━━━━━━━━━━━━━━━━━━\n\nSilakan ketik keluhan, laporan bug, atau pertanyaan Anda di bawah ini.\n\nPesan Anda akan langsung diteruskan ke Admin kami. (Bisa sertakan link gambar jika ada bukti error).</blockquote>`, { 
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: [[{ text: "« 𝘉𝘢𝘵𝘢𝘭", callback_data: "back_to_main" }]] }
            });
            userSessions[chatId].lastBotMessageId = helpMsg.message_id;
            return;
        }

        // ====================================================
        // FITUR 2: MENU AUTO INSTALL PANEL
        // ====================================================
                // ====================================================
        // MENU AUTO INSTALL PANEL
        // ====================================================
        if (data === "menu_autoinstall") {
            const warningText = `<blockquote>⚙️ <b>AUTO INSTALL PTERODACTYL & WINGS</b>\n━━━━━━━━━━━━━━━━━━\n\nLayanan ini akan menginstal Panel dan Wings secara otomatis ke VPS Anda.\n\n⚠️ <b>SYARAT WAJIB:</b>\n1. OS VPS wajib Ubuntu 22.04 LTS.\n2. Siapkan Subdomain (Contoh: <code>panel.domain.com</code>).\n3. Subdomain SUDAH DI-POINTING ke IP VPS.\n\n💳 <b>Biaya Jasa: Rp 10.000</b> (Sekali Bayar)</blockquote>`;

            await bot.deleteMessage(chatId, messageId).catch(()=>{});
            
            await bot.sendMessage(chatId, warningText, {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        // Mengarah ke invoice Jasa Install
                        [{ text: "🛒 Beli Jasa Install", callback_data: "buy_jasa_install" }],
                        [{ text: "« 𝘒𝘦𝘮𝘣𝘢𝘭𝘪", callback_data: "back_to_main" }]
                    ]
                }
            });
            return;
        }

        // Mulai minta data VPS
        if (data === "start_install_ptero") {
            userSessions[chatId] = { type: "install", step: "awaiting_install_ip", lastBotMessageId: messageId };
            
            await bot.deleteMessage(chatId, messageId).catch(()=>{});
            const askIpMsg = await bot.sendMessage(chatId, `<blockquote>🖥 <b>TAHAP 1/3: IP ADDRESS</b>\n━━━━━━━━━━━━━━━━━━\n\nSilakan ketik <b>IP VPS</b> Anda:\n<i>(Contoh: 190.100.1.100)</i></blockquote>`, { parse_mode: "HTML" });
            userSessions[chatId].lastBotMessageId = askIpMsg.message_id;
            return;
        }
        // ====================================================
        // BAGIAN 1: LOGIKA "IF" UNTUK DATA DINAMIS
        // ====================================================
        
        // CEK STATUS QRIS 1 (FAST / TRIPAY) - TOMBOL MANUAL
        if (query.data.startsWith("cek_qris_")) {
            const reference = query.data.replace("cek_qris_", "");

            if (qrisDiproses.has(reference)) {
                return bot.answerCallbackQuery(query.id, { text: "✅ Pembayaran ini sudah diproses.", show_alert: true });
            }
            if (!qrisPending.has(reference)) {
                return bot.answerCallbackQuery(query.id, { text: "Data order tidak ditemukan / QRIS kedaluwarsa. Silakan order ulang.", show_alert: true });
            }

            try {
                const st = await statusTripay(reference);
                const s = st && st.data && st.data.status;

                if (s === "PAID") {
                    await bot.answerCallbackQuery(query.id, { text: "✅ Pembayaran SUKSES! Memproses Pesanan...", show_alert: true });
                    await selesaikanQrisTripay(reference); // -> handlePaymentSuccess
                } else {
                    await bot.answerCallbackQuery(query.id, { text: "⏳ Belum lunas. Silakan bayar dulu ya!", show_alert: true });
                }
            } catch (err) {
                bot.answerCallbackQuery(query.id, { text: "Gagal mengecek status.", show_alert: true });
            }
            return;
        }

        if (query.data.startsWith("check_pay_")) {
    const invoiceUuid = query.data.replace("check_pay_", "");
    const userId = query.from.id;
    const session = userSessions[userId];

    if (!session) return bot.answerCallbackQuery(query.id, { text: "Sesi hilang.", show_alert: true });

    const dataCheck = { uuid: invoiceUuid };
    const sign = generateHeleketSign(dataCheck);

    try {
        const response = await axios.post('https://api.heleket.com/v1/payment/info', dataCheck, {
            headers: { 'merchant': settings.heleket.merchant, 'sign': sign, 'Content-Type': 'application/json' }
        });

        if (response.data.result.status === "paid") {
            await bot.answerCallbackQuery(query.id, { text: "✅ Pembayaran Crypto Berhasil! Memproses Pesanan...", show_alert: true });
            
            // Panggil fungsi pusat eksekusi yang sama
            session.metodeBayar = "Crypto";
            await handlePaymentSuccess(userId, session, invoiceUuid, messageId);
        } else {
            await bot.answerCallbackQuery(query.id, { text: "⏳ Belum dibayar!.", show_alert: true });
        }
    } catch (err) {
        bot.answerCallbackQuery(query.id, { text: "Gagal Cek Server Crypto, Silakan Hubungi Admin.", show_alert: true });
    }
}
        
            if (data.startsWith('os_page_')) {
        const targetPage = parseInt(data.replace('os_page_', ''));
        const pageContent = generateOSPage(chatId, targetPage);

        if (pageContent) {
            // Update pesan dengan halaman baru
            bot.editMessageText(pageContent.text, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: "HTML",
                reply_markup: pageContent.reply_markup
            }).catch(err => console.log("Edit message error:", err)); // Mencegah unhandled rejection jika klik dobel
        } else {
            // Jika bot sempat direstart, cache hilang
            bot.answerCallbackQuery(query.id, { text: "⚠️ Data kadaluarsa, silahkan ketik /getos kembali.", show_alert: true });
        }
        
        // Selalu jawab callback query agar tombol tidak loading terus di Telegram pengguna
        bot.answerCallbackQuery(query.id).catch(()=>{});
    }
        
        if (data.startsWith("page_")) {
            const action = data.split("_")[1];
            
            // Jika Admin klik "Selesai", hapus pesannya
            if (action === "close") {
                await bot.deleteMessage(chatId, messageId).catch(()=>{});
                await bot.answerCallbackQuery(query.id, { text: "Menu ditutup." });
                return;
            }

            // Jika Admin klik Next / Prev, render halaman baru
            const pageNum = parseInt(action);
            await renderUserPage(chatId, pageNum, messageId);
            
            await bot.answerCallbackQuery(query.id);
            return;
        }

        if (data.startsWith("paket_")) {
            const tipe = data.split("_")[1];
            let caption = "";
            let buttons = [];

            if (tipe === "started") {
                caption = "<blockquote>🥉 <b>TIER STARTED (BASIC)</b> 🥉\nVPS: Intel Xeon Platinum (150%)\nDisk: NVMe Enterprise\nPilihan Stabil untuk Bot ringan seperti Whatsapp/Telegram atau lainnya\n\nSilakan pilih spesifikasi di bawah:</blockquote>";
                buttons = [
                    [{ text: "𝘙𝘈𝘔 1𝘎𝘉 | 𝘊𝘗𝘜 50% | DISK 10𝘎𝘉", callback_data: "buy_Started 1GB_2000" }],
                    [{ text: "𝘙𝘈𝘔 2𝘎𝘉 | 𝘊𝘗𝘜 100% | DISK 20𝘎𝘉", callback_data: "buy_Started 2GB_3000" }],
                    [{ text: "« 𝘒𝘦𝘮𝘣𝘢𝘭𝘪 𝘒𝘦 𝘗𝘢𝘬𝘦𝘵", callback_data: "menu_panel" }]
                ];
            } else if (tipe === "medium") {
                caption = "<blockquote>🥈 <b>TIER MEDIUM (MID)</b> 🥈\nVPS: Xeon Platinum (300%)\nDisk: NVMe Enterprise\nPilihan Stabil untuk project menengah seperti penggunaan Database/Website Api\n\nSilakan pilih spesifikasi di bawah:</blockquote>";
                buttons = [
                    [{ text: "𝘙𝘈𝘔 6𝘎𝘉 | 𝘊𝘗𝘜 150% | DISK 50𝘎𝘉", callback_data: "buy_Medium 6GB_5000" }],
                    [{ text: "𝘙𝘈𝘔 8𝘎𝘉 | 𝘊𝘗𝘜 200% | DISK 70𝘎𝘉", callback_data: "buy_Medium 8GB_9000" }],
                    [{ text: "« 𝘒𝘦𝘮𝘣𝘢𝘭𝘪 𝘒𝘦 𝘗𝘢𝘬𝘦𝘵", callback_data: "menu_panel" }]
                ];
            } else if (tipe === "pro") {
                caption = "<blockquote>🥇 <b>TIER PRO (HIGH)</b> 🥇\nCPU: Unlimited\nDisk: Unlimited NVMe\nPilihan Maksimal untuk semua kebutuhan hosting anda, tanpa batasan RAM dan lainnya\nSilakan pilih spesifikasi di bawah:</blockquote>";
                buttons = [
                    [{ text: "𝘜𝘯𝘭𝘪𝘮𝘪𝘵𝘦𝘥 𝘗𝘙𝘖", callback_data: "buy_PRO Unlimited_10000" }],
                    [{ text: "« 𝘒𝘦𝘮𝘣𝘢𝘭𝘪 𝘒𝘦 𝘗𝘢𝘬𝘦𝘵", callback_data: "menu_panel" }]
                ];
            }

            await bot.editMessageCaption(caption, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: buttons }
            });

            await bot.answerCallbackQuery(query.id);
            return; // <-- WAJIB RETURN
        }
                // ====================================================
        // KETIKA USER KLIK TOMBOL "KLAIM VOUCHER" DARI BROADCAST
        // =================================================
                // ====================================================
        // KETIKA USER KLIK TOMBOL "KLAIM VOUCHER"
        // ====================================================
if (data.startsWith("klaimvc_")) {
    const kode = data.split("_")[1];
    const voucher = activeVouchers[kode];

    if (!voucher) return bot.answerCallbackQuery(query.id, { text: "❌ Voucher kadaluarsa.", show_alert: true });
    if (voucher.sisaKuota <= 0) return bot.answerCallbackQuery(query.id, { text: "😭 Kuota voucher habis!", show_alert: true });

    // RUMUS MATEMATIKA (SAMA SEPERTI SEBELUMNYA)
    const hargaNormal = Number(voucher.hargaNormal);
    const diskonPersen = Number(voucher.diskon);
    
    // Hitung potongan & harga bersih
    const potonganDiskon = Math.floor(hargaNormal * (diskonPersen / 100));
    const hargaSetelahDiskon = hargaNormal - potonganDiskon;
    
    // Hitung Fee (Hanya jika bayar via QRIS)

    // Simpan ke sesi agar saat input username bot ingat ini adalah paket promo
    userSessions[chatId] = {
        type: "panel",
        paket: `${voucher.paket} (PROMO ${kode})`,
        harga: hargaSetelahDiskon, // Harga yang akan dipotong dari saldo
        step: "confirming_promo"
    };

    const textDetailPromo = `<blockquote>📋 <b>DETAIL PESANAN (PROMO)</b>

🎟 <b>Voucher:</b> <code>${kode}</code>
📦 <b>Produk:</b> Panel - ${voucher.paket}

💰 <b>Harga Normal:</b> <del>Rp ${hargaNormal.toLocaleString('id-ID')}</del>
📉 <b>Diskon ${diskonPersen}%:</b> -Rp ${potonganDiskon.toLocaleString('id-ID')}
💸 <b>Total Bayar:</b> Rp ${hargaSetelahDiskon.toLocaleString('id-ID')} <i>(QRIS: + fee QRIS dihitung otomatis oleh gateway)</i>
━━━━━━━━━━━━━━━━━━

<i>Apakah detail pesanan di atas sudah benar? Klik Lanjutkan untuk mengisi data username.</i></blockquote>`;

    const btnConfirmPromo = {
        reply_markup: {
            inline_keyboard: [
                // Kirim hargaSetelahDiskon ke tahap input username
                [{ text: "✅ 𝘓𝘢𝘯𝘫𝘶𝘵𝘬𝘢𝘯", callback_data: `confirmbuy_${voucher.paket}_${hargaSetelahDiskon}`, style: "success" }],
                [{ text: "« 𝘉𝘢𝘵𝘢𝘭", callback_data: "menu_panel" }]
            ]
        }
    };

    // Kurangi kuota voucher hanya saat user benar-benar MEMBAYAR nantinya (opsional)
    // Di sini kita biarkan dulu, atau jika ingin fix diklaim:
    voucher.sisaKuota -= 1; 

    await bot.deleteMessage(chatId, messageId).catch(()=>{});
    await bot.sendPhoto(chatId, settings.panelImage, { 
        caption: textDetailPromo, 
        parse_mode: "HTML", 
        ...btnConfirmPromo 
    }).catch(()=>{});

    await bot.answerCallbackQuery(query.id);
    return; 
}
         // ====================================================
        // B. KETIKA KLIK RAM (MEMUNCULKAN DETAIL & BIAYA ADMIN)
        // ====================================================
        
        if (data.startsWith("buy_")) {

    const parts = data.split("_");
    const detailPaket = parts[1]; // Contoh: "Started 1GB"
    const hargaAsli = parseInt(parts[2]); // Contoh: 25000

    // Rumus Estimasi Fee Pakasir (Hanya berlaku jika bayar via QRIS)

    // Simpan ke sesi sementara (PENTING: Simpan harga asli untuk potongan saldo nanti)
    userSessions[chatId] = {
        type: "panel", // Tipe order
        paket: detailPaket,
        harga: hargaAsli,
        step: "confirming_order"
    };

    const textDetail = `<blockquote>📋 <b>DETAIL PESANAN ANDA</b>

📦 <b>Produk:</b> Panel Pterodactyl - ${detailPaket}
💰 <b>Harga Paket:</b> Rp ${hargaAsli.toLocaleString('id-ID')}
💸 <b>Total Bayar:</b> Rp ${hargaAsli.toLocaleString('id-ID')} <i>(QRIS: + fee QRIS dihitung otomatis oleh gateway)</i>
━━━━━━━━━━━━━━━━━━

<i>Klik Lanjutkan jika pesanan sudah benar untuk mengisi data username panel Anda. Metode pembayaran dipilih setelahnya.</i></blockquote>`;

    const btnConfirm = {
        reply_markup: {
            inline_keyboard: [
                [{ text: "✅ 𝘓𝘢𝘯𝘫𝘶𝘵𝘬𝘢𝘯", callback_data: `confirmbuy_${detailPaket}_${hargaAsli}`, style: "success" }],
                [{ text: "« 𝘒𝘦𝘮𝘣𝘢𝘭𝘪", callback_data: "menu_panel" }]
            ]
        }
    };

    await bot.editMessageCaption(textDetail, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        ...btnConfirm
    }).catch(() => {});

    await bot.answerCallbackQuery(query.id);
    return; 
}

        // ====================================================
        // C. KETIKA KLIK "LANJUTKAN" (MEMINTA USERNAME)
        // ====================================================
        
                // ====================================================
        // FITUR INTERAKTIF +/- PERPANJANGAN SERVER
        // ====================================================
if (data.startsWith("ext_")) {
    const parts = data.split("_");
    const action = parts[1]; // ui, min, plus, confirm
    const srvIndex = parseInt(parts[2]);
    let days = parseInt(parts[3]);

    const dbUsers = getUsers();
    const myProfile = dbUsers[chatId];
    
    if (!myProfile || !myProfile.servers[srvIndex]) {
        await bot.answerCallbackQuery(query.id, { text: "Data server tidak valid.", show_alert: true });
        return;
    }

    const targetServer = myProfile.servers[srvIndex];

    // Logika Tombol Tambah / Kurang Hari
    if (action === "plus") days++;
    if (action === "min" && days > 1) days--;

    // Harga per hari: panel Rp 500, VPS = harga sewa 30 hari / 30
    const perHari = serverHargaPerHari(targetServer);
    const hargaPerpanjang = days * perHari;

    // ==========================================
    // 1. JIKA USER KLIK "LANJUTKAN" (PILIH PAYMENT)
    // ==========================================
    if (action === "confirm") {
        userSessions[chatId] = {
            type: "extend",
            serverIndex: srvIndex,
            days: days,
            paket: `Perpanjang [${targetServer.username_panel}] ${days} Hari`,
            harga: hargaPerpanjang, // Harga asli untuk potong saldo
            username: targetServer.username_panel
        };

        const textPay = `<blockquote>🔄 <b>KONFIRMASI PEMBAYARAN</b>\n\n` +
                      `🖥 Server: <code>${targetServer.username_panel}</code>\n` +
                      `⏳ Durasi: +${days} Hari\n` +
                      `💰 Harga: Rp ${hargaPerpanjang.toLocaleString('id-ID')}\n` +
                      `</blockquote>\n\n<i>Silakan pilih metode pembayaran:</i>`;

        const btnPayment = {
            reply_markup: {
                inline_keyboard: [
                    // Tombol Bayar Pakai Saldo
                    [{ text: "💳 Bayar Pakai Saldo", callback_data: "pay_via_saldo", style: "success" }],
                    // Metode Luar
                    [
                        { text: "⚡ QRIS FAST", callback_data: "pay_qris_tripay", style: "success" },
                        { text: "🪙 Koin Crypto", callback_data: "pay_crypto_heleket" }
                    ],
                    [{ text: "« Batal", callback_data: `ext_ui_${srvIndex}_${days}` }]
                ]
            }
        };

        // Tombol bisa datang dari foto (profil) atau pesan teks (reminder / tabel server)
        await bot.editMessageCaption(textPay, { chat_id: chatId, message_id: messageId, parse_mode: "HTML", ...btnPayment })
            .catch(() => bot.editMessageText(textPay, { chat_id: chatId, message_id: messageId, parse_mode: "HTML", ...btnPayment }))
            .catch(() => bot.sendMessage(chatId, textPay, { parse_mode: "HTML", ...btnPayment }))
            .catch(() => {});
        await bot.answerCallbackQuery(query.id);
        return;
    }

    // ==========================================
    // 2. TAMPILAN INTERAKTIF (+ / - HARI)
    // ==========================================

    const textExtend = `<blockquote>🔄 <b>ATUR DURASI PERPANJANG</b>

🖥 <b>Detail Server:</b>
├ User: <code>${targetServer.username_panel}</code>
├ Jenis: ${serverJenis(targetServer)}
├ Sisa: <b>${serverSisa(serverExpiredMs(targetServer))}</b>
└ Expired: <b>${serverTglWIB(serverExpiredMs(targetServer))}</b>

⏳ <b>Tambah:</b> ${days} Hari (Rp ${perHari.toLocaleString('id-ID')}/hr)
━━━━━━━━━━━━━━━━━━
💰 Harga Sewa: Rp ${hargaPerpanjang.toLocaleString('id-ID')}</blockquote>`;

    const btnInteractive = {
        reply_markup: {
            inline_keyboard: [
                [
                    { text: "➖ 𝘒𝘶𝘳𝘢𝘯𝘨", callback_data: `ext_min_${srvIndex}_${days}`, style: "danger" },
                    { text: `${days} Hari`, callback_data: "ignore" },
                    { text: "➕ 𝘛𝘢𝘮𝘣𝘢𝘩", callback_data: `ext_plus_${srvIndex}_${days}`, style: "success" }
                ],
                [{ text: "𝘓𝘢𝘯𝘫𝘶𝘵𝘬𝘢𝘯 ➡️", callback_data: `ext_confirm_${srvIndex}_${days}`, style: "success" }],
                [{ text: "« 𝘉𝘢𝘵𝘢𝘭", callback_data: "menu_profil" }]
            ]
        }
    };

    // Tombol bisa datang dari foto (profil) atau pesan teks (reminder / tabel server)
    await bot.editMessageCaption(textExtend, { chat_id: chatId, message_id: messageId, parse_mode: "HTML", ...btnInteractive })
        .catch(() => bot.editMessageText(textExtend, { chat_id: chatId, message_id: messageId, parse_mode: "HTML", ...btnInteractive }))
        .catch(() => bot.sendMessage(chatId, textExtend, { parse_mode: "HTML", ...btnInteractive }))
        .catch(() => {});
    await bot.answerCallbackQuery(query.id);
    return;
}

        // Fungsi Batal UI
        if (data === "cancel_order_ui") {
            delete userSessions[chatId];
            await bot.deleteMessage(chatId, messageId).catch(()=>{});
            await bot.sendMessage(chatId, "❌ Pesanan dibatalkan.", { reply_markup: { inline_keyboard: [[{ text: "« 𝘒𝘦𝘮𝘣𝘢𝘭𝘪 𝘒𝘦 𝘔𝘦𝘯𝘶", callback_data: "back_to_main" }]]} });
            await bot.answerCallbackQuery(query.id);
            return;
        }
        
        if (data.startsWith("confirmbuy_")) {
            const parts = data.split("_");
            const detailPaket = parts[1];
            const harga = parseInt(parts[2]);

            // Simpan data ke sesi sementara
            userSessions[chatId] = {
                type: "panel", // WAJIB: tanpa ini handlePaymentSuccess menolak order
                step: "awaiting_username",
                paket: detailPaket,
                harga: harga, // Yang disimpan harga asli, Pakasir akan otomatis nambahin fee-nya nanti
                lastBotMessageId: messageId 
            };

            // Hapus pesan foto panel detail
            await bot.deleteMessage(chatId, messageId).catch(()=>{});

            // Kirim pesan teks meminta username
            const promptMsg = await bot.sendMessage(chatId, `<blockquote>✅ Anda akan memesan <b>Paket ${detailPaket}</b>.\n\n📝 Silakan ketik <b>Username</b> (tanpa spasi) yang ingin digunakan untuk Panel Anda:</blockquote>`, { parse_mode: "HTML" });
            
            // Simpan ID pesan ini agar nanti dihapus otomatis setelah user ngetik
            userSessions[chatId].lastBotMessageId = promptMsg.message_id;

            await bot.answerCallbackQuery(query.id);
            return; 
        }   
        
                // ====================================================
        // 1. KETIKA KLIK "CEK KETERSEDIAAN VPS" (MUNCUL LOADING & STOK)
        // ====================================================
if (data === "check_vps_stock") {
    await bot.answerCallbackQuery(query.id, { text: "⏳ Sedang mengecek ketersediaan di server..." });

    const store = getStore();

    // Gabungin data lama (dari /setvps) + inventory baru biar gak hilang
    let inventory = store.vps_inventory || { dedicated: {}, shared: {} };
    
    // Fallback VPS Biasa dari /setvps
    if (store.vps_ram && store.vps_stock > 0) {
        inventory.dedicated[store.vps_ram] = { stock: store.vps_stock, price: store.vps_price };
    }
    // Fallback VPS Shared dari /setvps shared -> INI YANG BIKIN MUNCUL
    if (store.vps_shared_ram && store.vps_shared_stock > 0) {
        inventory.shared[store.vps_shared_ram] = { stock: store.vps_shared_stock, price: store.vps_shared_price };
    }

    const getSpec = (ram) => {
        if (ram.includes("1GB")) return { cpu: "1 Core Xeon", disk: "10 GB NVMe" };
        if (ram.includes("2GB")) return { cpu: "1 Core Xeon", disk: "20 GB NVMe" };
        if (ram.includes("4GB")) return { cpu: "2 Core Xeon", disk: "40 GB NVMe" };
        if (ram.includes("8GB")) return { cpu: "4 Core Xeon", disk: "80 GB NVMe" };
        return { cpu: "High Performance", disk: "NVMe SSD" };
    };

    let listDedicated = [];
    let listShared = [];
    let buttons = [];

    for (let ram of ["1GB","2GB","4GB","8GB"]) {
        let item = inventory.dedicated?.[ram];
        if (item && item.stock > 0) {
            listDedicated.push({ ram, ...item, ...getSpec(ram) });
            buttons.push([{ text: `✅ Dedicated ${ram} - Stok ${item.stock}`, callback_data: `confvps_ready_dedicated_${ram}` }]);
        }
    }
    // INI SEKARANG BACA SEMUA RAM SHARED, BUKAN CUMA 1GB
    for (let ram of Object.keys(inventory.shared)) {
        let item = inventory.shared[ram];
        if (item && item.stock > 0) {
            listShared.push({ ram, ...item });
            buttons.push([{ text: `⚡ NAT ${ram} - Stok ${item.stock}`, callback_data: `confvps_ready_shared_${ram}` }]);
        }
    }

    if (listDedicated.length === 0 && listShared.length === 0) {
        const textHabis = `<blockquote>❌ <b>MOHON MAAF, VPS SEDANG KOSONG</b>\n\nSaat ini belum ada alokasi VPS baru dari Admin.</blockquote>`;
        return bot.editMessageCaption(textHabis, {
            chat_id: chatId, message_id: messageId, parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "« Kembali Ke Menu", callback_data: "back_to_main" }]] }
        }).catch(()=>{});
    }

    let textTersedia = `<blockquote>✅ <b>VPS TERSEDIA - CEK REAL STOCK</b>\n\n`;

    if (listDedicated.length > 0) {
        textTersedia += `🖥️ <b>DEDICATED IP (IP Private)</b>\n`;
        listDedicated.forEach(v => {
            textTersedia += `├ ${v.ram} | ${v.cpu} | ${v.disk}\n`;
            textTersedia += `│  ├ Stok: <b>${v.stock} Unit</b>\n`;
            textTersedia += `│  └ Harga: <b>Rp ${v.price.toLocaleString('id-ID')}</b>\n`;
        });
        textTersedia += `\n`;
    }

    if (listShared.length > 0) {
        textTersedia += `🌐 <b>SHARED IP (NAT - Port Forward)</b>\n`;
        listShared.forEach(v => {
            textTersedia += `├ RAM: <b>${v.ram}</b>\n`;
            textTersedia += `│  ├ Stok: <b>${v.stock} Unit</b>\n`;
            textTersedia += `│  └ Harga: <b>Rp ${v.price.toLocaleString('id-ID')}</b>\n`;
        });
        textTersedia += `\n`;
    }

    textTersedia += `<i>Pilih paket di bawah sesuai RAM yang ready.</i></blockquote>`;

    buttons.push([{ text: "« Kembali", callback_data: "menu_vps" }]);

    await bot.deleteMessage(chatId, messageId).catch(()=>{});
    await bot.sendPhoto(chatId, settings.panelImage, {
        caption: textTersedia,
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: buttons }
    });
    return;
}

// === HANDLER PENGGANTI confvps_ready LAMA ===
if (data.startsWith("confvps_ready_")) {
    // data = confvps_ready_dedicated_1GB atau confvps_ready_shared_2GB
    const parts = data.replace("confvps_ready_","").split("_"); // [dedicated, 1GB]
    const type = parts[0]; // dedicated / shared
    const ram = parts[1]; // 1GB

    const store = getStore();
    const inventory = store.vps_inventory[type];
    if (!inventory || !inventory[ram] || inventory[ram].stock <= 0) {
        await bot.answerCallbackQuery(query.id, { text: "Stok baru saja habis!", show_alert: true });
        return;
    }

    const item = inventory[ram];

    userSessions[chatId] = {
        type: `vps_${type}`, // vps_dedicated atau vps_shared
        ram: ram,
        paket: `VPS ${type.toUpperCase()} ${ram}`,
        harga: item.price,
        step: "awaiting_hostname",
        lastBotMessageId: messageId
    };

    await bot.deleteMessage(chatId, messageId).catch(()=>{});
    const promptMsg = await bot.sendMessage(chatId, `<blockquote>✅ Anda memesan <b>${userSessions[chatId].paket}</b>\nHarga: <b>Rp ${item.price.toLocaleString('id-ID')}</b>\n\n📝 Silakan ketik <b>Hostname</b> Anda (Contoh: <code>bot-trading</code>):</blockquote>`, { parse_mode: "HTML" });
    userSessions[chatId].lastBotMessageId = promptMsg.message_id;

    await bot.answerCallbackQuery(query.id);
    return;
}

        // ====================================================
        // BAGIAN 2: LOGIKA "SWITCH" UNTUK MENU TETAP
        // ====================================================

        switch (data) {
            
            // ====================================================
            // MENU UTAMA & KEMBALI KE MENU
            // ====================================================
            case "mainmenu":
            case "back_to_main":
            
                           const textMainMenu = `<blockquote>( 👋 ) - <b>ʜᴀʟᴏ ꜱᴇʟᴀᴍᴀᴛ ᴅᴀᴛᴀɴɢ ᴅɪ ʙᴏᴛ ᴀᴜᴛᴏ ᴏʀᴅᴇʀ ᴘᴀɴᴇʟ ʟᴇɢᴀʟ 100%</b></blockquote>
<blockquote>ᴄᴀᴘᴇᴋ ʙᴇʟɪ ᴘᴀɴᴇʟ ᴍᴜʀᴀʜ ᴛᴀᴘɪ ᴛɪᴀᴘ 3-7 ʜᴀʀɪ ꜱᴇʀᴠᴇʀ ᴍᴀᴛɪ/ᴍᴏᴋᴀᴅ? ʙɪʟᴀɴɢ ɴʏᴀ ᴅɪ ʀᴀᴡᴀᴛ ᴛᴀᴘɪ ᴄᴜᴍᴀ ᴍᴀɴɪꜱ ᴅɪ ᴀᴡᴀʟ 
ᴘɪɴᴅᴀʜ ᴋᴇ ꜱᴇʀᴠᴇʀ ᴋᴀᴍɪ! 
ʟᴀʏᴀɴᴀɴ ᴏɴ 24/7ᴊᴀᴍ ᴊᴀʀɪɴɢᴀɴ ᴛᴀɴᴘᴀ ʙᴀᴛᴀꜱ - ꜱᴇᴡᴀ ʙᴜʟᴀɴᴀɴ ʙɪꜱᴀ ᴅɪ ᴘᴇʀᴘᴀɴᴊᴀɴɢ

ᴅᴀᴘᴀᴛᴋᴀɴ ᴅɪꜱᴋᴏɴ ꜱ/ᴅ 50% ᴜɴᴛᴜᴋ ᴘᴇᴍʙᴇʟɪᴀɴ ᴘᴀɴᴇʟ ᴘᴛᴇʀᴏᴅᴀᴄᴛʏʟ ᴍɪɴ 30 ʜᴀʀɪ (ᴛɪᴅᴀᴋ ᴛᴇʀᴍᴀꜱᴜᴋ ᴘᴇʀᴘᴀɴᴊᴀɴɢ)</blockquote><blockquote>ᴜᴄᴀᴘᴋᴀɴ ᴘᴇʀɪɴᴛᴀʜ ᴅɪʙᴀᴡᴀʜ ɪɴɪ ᴜɴᴛᴜᴋ ᴏʀᴅᴇʀ ɪɴꜱᴛᴀɴ :
"ʙᴇʟɪ ᴘᴀɴᴇʟ |ᴘᴀᴋᴇᴛ| ᴜꜱᴇʀɴᴀᴍᴇ |ɴᴀᴍᴀᴘᴀɴᴇʟ| ʙᴀʏᴀʀ ᴘᴀᴋᴀɪ |ᴘᴀʏᴍᴇɴᴛ|"

ᴄᴏɴᴛᴏʜ/: "ʙᴇʟɪ ᴘᴀɴᴇʟ ᴜɴʟɪ ᴜꜱᴇʀɴᴀᴍᴇ ᴀʙᴄ ʙᴀʏᴀʀ ᴘᴀᴋᴀɪ Qʀɪꜱ"

ᴘɪʟɪʜ ᴍᴇɴᴜ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ ᴜɴᴛᴜᴋ ᴍᴇᴍᴜʟᴀɪ
╭──✧ <i>𝘐𝘯𝘧𝘰𝘳𝘮𝘢𝘴𝘪</i> ✧
│ ⪼ Legalitas #No1
╰──────────⧽</blockquote>`;
                
              if (data === "mainmenu") {
    await bot.answerCallbackQuery(query.id).catch(() => {});
    await bot.deleteMessage(chatId, messageId).catch(() => {});
console.log("[HANDLER MAINMENU MASUK]");
    try {
        await bot.sendPhoto(chatId, settings.panelImage, {
            caption: textMainMenu,
            parse_mode: "HTML",
            reply_markup: keyboardMenuKedua
        });
    } catch (err) {
        console.error("Gagal mengirim foto menu utama:", err.response?.body || err.message);

        await bot.sendMessage(chatId, textMainMenu, {
            parse_mode: "HTML",
            reply_markup: keyboardMenuKedua
        });
    }
} else {
    // Biarkan bagian back_to_main yang sudah ada tetap di sini
                    // Jika dari tombol "Kembali", hapus pesan lama lalu kirim foto baru
                    await bot.deleteMessage(chatId, messageId).catch(()=>{});
                    
                    // UBAH MENJADI KIRIM FOTO DI SINI
                    await bot.sendPhoto(chatId, settings.panelImage, {
                        caption: textMainMenu,
                        parse_mode: "HTML",
                        reply_markup: keyboardMenuKedua
                    }).catch((err) => {
                        console.log("Gagal kirim foto menu utama:", err.message);
                        // Fallback aman jika gambar gagal dimuat
                        bot.sendMessage(chatId, textMainMenu, {
                            parse_mode: "HTML",
                            reply_markup: keyboardMenuKedua
                        });
                    });
                }
                break;
case "menu_lainnya": {
const textMenuLainnya = `<blockquote>( 👋 ) - <b>ʜᴀʟᴏ ꜱᴇʟᴀᴍᴀᴛ ᴅᴀᴛᴀɴɢ ᴅɪ ʙᴏᴛ ᴀᴜᴛᴏ ᴏʀᴅᴇʀ ᴘᴀɴᴇʟ ʟᴇɢᴀʟ 100%</b></blockquote>
<blockquote>ᴄᴀᴘᴇᴋ ʙᴇʟɪ ᴘᴀɴᴇʟ ᴍᴜʀᴀʜ ᴛᴀᴘɪ ᴛɪᴀᴘ 3-7 ʜᴀʀɪ ꜱᴇʀᴠᴇʀ ᴍᴀᴛɪ/ᴍᴏᴋᴀᴅ? ʙɪʟᴀɴɢ ɴʏᴀ ᴅɪ ʀᴀᴡᴀᴛ ᴛᴀᴘɪ ᴄᴜᴍᴀ ᴍᴀɴɪꜱ ᴅɪ ᴀᴡᴀʟ 
ᴘɪɴᴅᴀʜ ᴋᴇ ꜱᴇʀᴠᴇʀ ᴋᴀᴍɪ! 
ʟᴀʏᴀɴᴀɴ ᴏɴ 24/7ᴊᴀᴍ ᴊᴀʀɪɴɢᴀɴ ᴛᴀɴᴘᴀ ʙᴀᴛᴀꜱ - ꜱᴇᴡᴀ ʙᴜʟᴀɴᴀɴ ʙɪꜱᴀ ᴅɪ ᴘᴇʀᴘᴀɴᴊᴀɴɢ

ᴅᴀᴘᴀᴛᴋᴀɴ ᴅɪꜱᴋᴏɴ ꜱ/ᴅ 50% ᴜɴᴛᴜᴋ ᴘᴇᴍʙᴇʟɪᴀɴ ᴘᴀɴᴇʟ ᴘᴛᴇʀᴏᴅᴀᴄᴛʏʟ ᴍɪɴ 30 ʜᴀʀɪ (ᴛɪᴅᴀᴋ ᴛᴇʀᴍᴀꜱᴜᴋ ᴘᴇʀᴘᴀɴᴊᴀɴɢ)</blockquote><blockquote>ᴜᴄᴀᴘᴋᴀɴ ᴘᴇʀɪɴᴛᴀʜ ᴅɪʙᴀᴡᴀʜ ɪɴɪ ᴜɴᴛᴜᴋ ᴏʀᴅᴇʀ ɪɴꜱᴛᴀɴ :
"ʙᴇʟɪ ᴘᴀɴᴇʟ |ᴘᴀᴋᴇᴛ| ᴜꜱᴇʀɴᴀᴍᴇ |ɴᴀᴍᴀᴘᴀɴᴇʟ| ʙᴀʏᴀʀ ᴘᴀᴋᴀɪ |ᴘᴀʏᴍᴇɴᴛ|"

ᴄᴏɴᴛᴏʜ/: "ʙᴇʟɪ ᴘᴀɴᴇʟ ᴜɴʟɪ ᴜꜱᴇʀɴᴀᴍᴇ ᴀʙᴄ ʙᴀʏᴀʀ ᴘᴀᴋᴀɪ Qʀɪꜱ"

ᴘɪʟɪʜ ᴍᴇɴᴜ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ ᴜɴᴛᴜᴋ ᴍᴇᴍᴜʟᴀɪ
╭──✧ <i>𝘐𝘯𝘧𝘰𝘳𝘮𝘢𝘴𝘪</i> ✧
│ ⪼ Legalitas #No1
╰──────────⧽</blockquote>`;

    const keyboardMenuLainnya = {
        inline_keyboard: [
            // Pola sama dengan menu utama: baris berisi 2 tombol, lalu tombol lebar di bawah
            [
                { text: "🤝 𝙿𝚊𝚝𝚞𝚗𝚐𝚊𝚗 𝚅𝚙𝚜", callback_data: "menu_patungan", style: "success" },
                { text: "💈 𝙸𝚗𝚜𝚝𝚊𝚕𝚕 𝚅𝚙𝚜", callback_data: "menu_autoinstall", style: "success" }
            ],
            [
                { text: "🎮 𝚁𝚎𝚗𝚝𝚊𝚕 𝙿𝚊𝚗𝚎𝚕", callback_data: "menu_hourly", style: "success" },
                { text: "🐿 𝙰𝚍𝚘𝚙𝚜𝚒 𝙿𝚎𝚝", callback_data: "menu_pet", style: "success" }
            ],
            [
                { text: "💸 𝙵𝚛𝚎𝚎𝚕𝚊𝚗𝚌𝚎", callback_data: "menu_freelance", style: "success" }
            ],
            [
                { text: "⬅️ 𝙺𝚎𝚖𝚋𝚊𝚕𝚒", callback_data: "back_to_main" }
            ]
        ]
    };

    // Logika pengiriman (Sama dengan kode mainmenu kamu)
    await bot.editMessageCaption(textMenuLainnya, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: keyboardMenuLainnya
    }).catch(async () => {
        // Jika gagal edit, hapus dan kirim foto baru
        await bot.deleteMessage(chatId, messageId).catch(()=>{});
        await bot.sendPhoto(chatId, settings.panelImage, {
            caption: textMenuLainnya,
            parse_mode: "HTML",
            reply_markup: keyboardMenuLainnya
        });
    });
    break;
}
case "pay_qris_tripay": {
    const userId = query.from.id;
    const chatIdOrder = query.message ? query.message.chat.id : userId;
    // Cek 2 key biar gak hilang sesi (sama seperti pay_via_saldo)
    const session = userSessions[userId] || userSessions[chatIdOrder];
    const tipeDikenal = ["deposit", "extend", "patungan", "jasa_install", "panel", "hourly", "vps", "otp", "otp2", "smm"];

    if (!session || !session.harga) {
        return bot.answerCallbackQuery(query.id, { text: "⚠️ Harga tidak ditemukan, Silakan order ulang.", show_alert: true });
    }
    // Jangan sampai user bayar untuk order yang nanti tidak bisa dieksekusi handlePaymentSuccess
    if (!tipeDikenal.includes(session.type) && !String(session.type).startsWith("vps_")) {
        return bot.answerCallbackQuery(query.id, { text: "⚠️ Sesi order tidak valid, Silakan order ulang.", show_alert: true });
    }
    bot.answerCallbackQuery(query.id, { text: "Membuat QRIS..." }).catch(() => {});

    try {
        const amount = parseInt(String(session.harga).replace(/[^0-9]/g, ""));
        const ref = `QRIS1-${userId}-${Date.now()}`;

        const res = await buatQrisTripay({ amount, merchant_ref: ref, customer_name: query.from.first_name || "User" });
        if (!res.success) {
            console.log("QRIS 1 gagal:", JSON.stringify(res));
            return bot.sendMessage(chatIdOrder, "⚠️ Gagal membuat QRIS: " + (res.message || "coba lagi nanti."));
        }
        if (messageId) await bot.deleteMessage(chatIdOrder, messageId).catch(() => {});

        const d = res.data;
        // Rincian dari gateway: d.amount = yang dibayar user (nominal + fee gateway)
        const totalGateway = Number(d.amount) || amount;
        const feeGateway = Number(d.fee_customer ?? (totalGateway - amount)) || 0;
        const caption = `💳 <b>PEMBAYARAN QRIS</b>\n\n💰 Nominal: Rp ${amount.toLocaleString("id-ID")}\n` +
            `🧾 Fee gateway: Rp ${feeGateway.toLocaleString("id-ID")}\n━━━━━━━━━━━━━━\n` +
            `💵 Total Bayar: <b>Rp ${totalGateway.toLocaleString("id-ID")}</b>\n🆔 Referensi: <code>${d.reference}</code>\n\n<i>Scan QR di atas dengan e-wallet atau m-banking. Berlaku 30 menit.</i>`;
        const kb = {
            reply_markup: {
                inline_keyboard: [
                    [{ text: "🔄 CEK STATUS", callback_data: `cek_qris_${d.reference}`, style: "success" }],
                    [{ text: "« Kembali", callback_data: "back_to_main" }]
                ]
            }
        };

        let sent;
        if (d.qr_string) {
            const buf = await QRCode.toBuffer(d.qr_string, { width: 600, margin: 2 });
            sent = await bot.sendPhoto(chatIdOrder, buf, { caption, parse_mode: "HTML", ...kb }, { filename: "qris.png", contentType: "image/png" });
        } else {
            sent = await bot.sendPhoto(chatIdOrder, d.qr_url, { caption, parse_mode: "HTML", ...kb });
        }

        // Salin sesi saat QRIS dibuat, biar order tetap benar walau user buka menu lain
        const order = {
            chatId: chatIdOrder,
            userId,
            session: { ...session, orderId: d.reference },
            amount,
            messageId: sent.message_id,
            timer: null
        };
        qrisPending.set(d.reference, order);

        // Pantau status tiap 5 detik, maksimal 30 menit
        let n = 0;
        order.timer = setInterval(async () => {
            n++;
            try {
                const st = await statusTripay(d.reference);
                const s = st && st.data && st.data.status;

                if (s === "PAID") {
                    await selesaikanQrisTripay(d.reference); // -> handlePaymentSuccess
                } else if (s === "EXPIRED" || s === "FAILED" || n >= 372) { // 31 menit: sedikit lewat masa QR 30 menit
                    clearInterval(order.timer);
                    qrisPending.delete(d.reference);
                    bot.sendMessage(chatIdOrder, "⌛ QRIS kedaluwarsa atau gagal. Silakan order ulang.");
                }
            } catch (e) { /* coba lagi di putaran berikutnya */ }
        }, 5000);

    } catch (e) {
        console.log("QRIS error:", e.message);
        bot.sendMessage(chatIdOrder, "⚠️ Terjadi kesalahan saat membuat QRIS.");
    }
    break;
}
case "menu_hourly": {
    const text = `<blockquote>🕒 <b>MENU RENTAL PANEL</b>\n\nButuh Panel cuma sebentar? Sewa per jam aja!\n\n💰 Harga: <b>Rp 500 / Jam</b>\n\n🔋Spesifikasi: Panel 1GB CPU 50%\n\nSilakan masukkan jumlah jam yang ingin disewa (1-24):</blockquote>`;
    
    userSessions[chatId] = { type: "hourly", step: "input_hour" };
    bot.sendMessage(chatId, text, { parse_mode: "HTML" });
    break;
}
case "menu_trial": {
    const dbTimed = getTimedServers();
    
    // Safety check: pastikan dbTimed.slots ada sebelum di-filter
    const allSlots = dbTimed.slots || []; 
    const activeTrials = allSlots.filter(s => s.type === "TRIAL");
    
    const totalSlots = 1; // Sesuai permintaanmu sebelumnya
    const slotTerpakai = activeTrials.length;

    // --- CEK LIMIT 3 KALI ---
    const history = dbTimed.trialHistory || {};
    const usedTrials = history[chatId] || 0;
    const maxLimit = 3;

    if (usedTrials >= maxLimit) {
        const textLimit = `<blockquote>( ❌ ) - <b>ᴀᴋꜱᴇꜱ ᴅɪʙᴀᴛᴀꜱɪ</b></blockquote>
<blockquote>ᴍᴀᴀꜰ, ᴋᴀᴍᴜ ꜱᴜᴅᴀʜ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ᴊᴀᴛᴀʜ ᴜᴊɪ ᴄᴏʙᴀ ɢʀᴀᴛɪꜱ ꜱᴇʙᴀɴʏᴀᴋ <b>3/3 ᴋᴀʟɪ</b>.</blockquote>`;
        
        return bot.editMessageCaption(textLimit, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "⬅️ ᴋᴇᴍʙᴀʟɪ", callback_data: "menu_lainnya" }]] }
        });
    }

    // --- CEK SLOT PENUH ---
    if (slotTerpakai >= totalSlots) {
        const sorted = activeTrials.sort((a, b) => new Date(a.expiredAt) - new Date(b.expiredAt));
        const sisaWaktu = Math.ceil((new Date(sorted[0].expiredAt) - new Date()) / (1000 * 60));

        const textFull = `<blockquote>( ❌ ) - <b>ᴍᴀᴀꜰ ꜱʟᴏᴛ ᴜᴊɪ ᴄᴏʙᴀ ᴘᴇɴᴜʜ</b></blockquote>
<blockquote>ꜱʟᴏᴛ ᴀᴋᴀɴ ᴛᴇʀꜱᴇᴅɪᴀ ᴅᴀʟᴀᴍ ᴡᴀᴋᴛᴜ: <b>${sisaWaktu} ᴍᴇɴɪᴛ ʟᴀɢɪ</b></blockquote>`;

        return bot.editMessageCaption(textFull, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "⬅️ ᴋᴇᴍʙᴀʟɪ", callback_data: "menu_lainnya" }]] }
        });
    }

    // --- TAMPILKAN INFO ---
    const textInfoTrial = `<blockquote>( 🎁 ) - <b>ɪɴꜰᴏʀᴍᴀꜱɪ ᴜᴊɪ ᴄᴏʙᴀ ɢʀᴀᴛɪꜱ</b></blockquote>
<blockquote>📊 <b>ꜱᴛᴀᴛᴜꜱ ᴋᴜᴏᴛᴀ ᴋᴀᴍᴜ:</b>
- ᴛᴇʀᴘᴀᴋᴀɪ: ${usedTrials} / 3 ᴋᴀʟɪ
- ꜱɪꜱᴀ: ${maxLimit - usedTrials} ᴋᴀʟɪ ʟᴀɢɪ

ᴋʟɪᴋ ʙᴜᴛᴛᴏɴ ᴅɪ ʙᴀᴡᴀʜ ᴜɴᴛᴜᴋ ᴍᴇᴍᴜʟᴀɪ.</blockquote>`;

    await bot.editMessageCaption(textInfoTrial, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: {
            inline_keyboard: [
                [{ text: "✅ ᴍᴜʟᴀɪ ᴜᴊɪ ᴄᴏʙᴀ", callback_data: "start_trial_now", style: "success" }],
                [{ text: "⬅️ ᴋᴇᴍʙᴀʟɪ", callback_data: "menu_lainnya" }]
            ]
        }
    });
    break;
}
case "start_trial_now": {
    const dbTimed = getTimedServers();
    
    // --- SAFETY CHECK (PENTING!) ---
    // Pastikan jika .slots tidak ada, bot menggunakan array kosong [] agar tidak crash
    const allSlots = dbTimed.slots || []; 
    const activeTrials = allSlots.filter(s => s.type === "TRIAL");
    
    // Batas slot (Sesuaikan: tadi kamu minta 1 slot, di kode ini 3. Saya samakan dengan kodemu)
    if (activeTrials.length >= 1) {
        return bot.answerCallbackQuery(query.id, { 
            text: "Maaf, slot sedang penuh. Silakan kembali lagi nanti.", 
            show_alert: true 
        });
    }

    const textProses = `<blockquote>( ⚙️ ) - <b>ꜱᴇᴅᴀɴɢ ᴍᴇᴍᴘʀᴏꜱᴇꜱ</b></blockquote>
<blockquote>ᴘᴇʀᴍɪɴᴛᴀᴀɴ ᴜᴊɪ ᴄᴏʙᴀ ᴋᴀᴍᴜ ꜱᴇᴅᴀɴɢ ᴅɪᴘʀᴏꜱᴇꜱ ᴏʟᴇʜ ꜱɪꜱᴛᴇᴍ. ᴍᴏʜᴏɴ ᴛᴜɴɢɢᴜ ꜱᴇʙᴇɴᴛᴀʀ...</blockquote>`;

    await bot.editMessageCaption(textProses, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML"
    });

    // --- LOG ADMIN TRIAL ---
    const notifAdminTrial = `<blockquote>🎁 <b>ʟᴏɢ ᴀᴅᴍɪɴ: ᴜᴊɪ ᴄᴏʙᴀ ɢʀᴀᴛɪꜱ</b>\n━━━━━━━━━━━━━━━━━━\n🆔 ᴜꜱᴇʀ ɪᴅ: <code>${chatId}</code>\n👤 ᴜꜱᴇʀɴᴀᴍᴇ: @${query.from.username || 'ᴛᴀɴᴘᴀ ᴜꜱᴇʀɴᴀᴍᴇ'}\n\n<i>ꜱᴛᴀᴛᴜꜱ: ꜱᴇᴅᴀɴɢ ᴍᴇᴍᴘʀᴏꜱᴇꜱ ᴛʀɪᴀʟ 1 ᴊᴀᴍ...</i></blockquote>`;
    bot.sendMessage(settings.adminId, notifAdminTrial, { parse_mode: "HTML" }).catch(()=>{});

    // Jalankan fungsi pembuatan
    await autoCreatePanelTimed(chatId, "Trial 1GB", 1, true);
    break;
}
case "menu_patungan": {
    const text = `<blockquote><b>🤝 MENU PATUNGAN VPS (CROWDFUNDING)</b>\n\n` +
                 `Beli Vps buat rame rame? Cocok nih! Ajak teman mu untuk berkontribusi, Penyetor pertama akan mendapatkan Tittle CEO yang memegang data Vps!\n\n` +
                 `Jika durasi Patungan habis dan Progres tidak mencapai target, Saldo akan di Refund Otomatis.\n\n` +
                 `Pilih paket yang ingin kamu buka atau ikuti Progres yang sedang berlangsung. Pembayar pertama otomatis jadi <b>CEO</b>.</blockquote>`;
    
    const btn = [
        [{ text: "💈 INTEL XEON PT RAM 2GB", callback_data: "p_pilih_2GB" }],
        [{ text: "💈 INTEL XEON PT RAM 4GB", callback_data: "p_pilih_4GB" }],
        [{ text: "« Kembali", callback_data: "back_to_main" }]
    ];

    await bot.editMessageCaption(text, { 
        chat_id: chatId, message_id: messageId, 
        parse_mode: "HTML", reply_markup: { inline_keyboard: btn } 
    });
    break;
}
// --- MENU PILIH PAKET ---
case "p_pilih_2GB":
case "p_pilih_4GB": {
    const paketDipilih = query.data.split("_")[2];
    const hargaVps = (paketDipilih === "2GB") ? 35000 : 60000;

    // Simpan data awal ke sesi
    userSessions[chatId] = { 
        type: "patungan", 
        paket: paketDipilih, 
        hargaVps: hargaVps, // Harga asli VPS
        username_tg: query.from.username || "User"
    };

    const text = `<blockquote><b>💈 SETTING MODE PATUNGAN VPS</b>\n\n` +
                 `Paket: ${paketDipilih.toUpperCase()}\n` +
                 `Harga VPS: Rp ${hargaVps.toLocaleString()}\n\n` +
                 `Silakan pilih mode patungan:</blockquote>`;

    const btn = [
        [{ text: "👥 Mode Atur (Tentukan Slot)", callback_data: "p_mode_atur" }],
        [{ text: "🌊 Mode Fleksibel (Bebas Kontribusi)", callback_data: "p_mode_flex" }],
        [{ text: "« Batal", callback_data: "menu_patungan" }]
    ];
    await bot.editMessageCaption(text, { chat_id: chatId, message_id: messageId, parse_mode: "HTML", reply_markup: { inline_keyboard: btn } });
    break;
}

// --- PILIH MODE ---
case "p_mode_atur":
case "p_mode_flex": {
    const mode = query.data.split("_")[2];
    userSessions[chatId].mode = mode;

    let text, btn;
    if (mode === "atur") {
        text = `<blockquote><b>👥 MODE ATUR</b>\n\nBerapa jumlah orang yang boleh ikut patungan (termasuk kamu)?\n<i>Contoh: Jika diisi 5, maka Rp 35.000 / 5 = Rp 7.000 per orang.</i></blockquote>`;
        userSessions[chatId].step = "input_patungan_slot";
        await bot.sendMessage(chatId, text, { parse_mode: "HTML" });
    } else {
        text = `<blockquote><b>🌊 MODE FLEKSIBEL</b>\n\nMode ini dapat menampung banyak user (tanpa batas) hingga saldo mencapai target hanya user yang berkontribusi yang akan mendapatkan Tittle dan Akses, dan Penyetor pertama akan mendapatkan Tittle CEO.\n\nBerapa nominal yang ingin kamu bayar sekarang sebagai CEO?\n(Minimal Rp 1.000)</blockquote>`;
        userSessions[chatId].step = "input_patungan_nominal";
        await bot.sendMessage(chatId, text, { parse_mode: "HTML" });
    }
    break;
}
case "p_dur_24":
case "p_dur_48":
case "p_dur_168": {
    const jam = parseInt(query.data.split("_")[2]);
    userSessions[chatId].durasi = jam;
    userSessions[chatId].roomId = "R" + Date.now(); // Room baru karena dia CEO
    
    // Langsung panggil QRIS 1 (Fast)
    return bot.answerCallbackQuery(query.id, { text: "Mengarahkan ke pembayaran..." }).then(() => {
        // Trigger manual ke case pay_qris_tripay
        bot.emit('callback_query', { ...query, data: 'pay_qris_tripay' });
    });
    break;
}
            case "menu_panel":
                await bot.deleteMessage(chatId, messageId).catch(()=>{}); 
                                const captionPanel = "<blockquote>🖥 <b>PTERODACTYL PANEL - THE OPEN-SOURCE GAME MANAGEMENT SOLUTION</b>\n\nPilih tier paket dibawah ini sesuai kebutuhan anda...</blockquote>";
                
                const btnPaket = {
    reply_markup: {
        inline_keyboard: [
            // Baris 1: Started dan Medium Sejajar
            [
                { text: "🥉 𝘗𝘢𝘬𝘦𝘵 𝘚𝘵𝘢𝘳𝘵𝘦𝘥", callback_data: "paket_started", style: "success" },
                { text: "🥈 𝘗𝘢𝘬𝘦𝘵 𝘔𝘦𝘥𝘪𝘶𝘮", callback_data: "paket_medium", style: "success" }
            ],
            // Baris 2: Pro Sendirian
            [
                { text: "🥇 𝘗𝘢𝘬𝘦𝘵 𝘗𝘙𝘖", callback_data: "paket_pro", style: "success" }
            ],
            // Baris 3: Kembali
            [
                { text: "« 𝘒𝘦𝘮𝘣𝘢𝘭𝘪", callback_data: "back_to_main" }
            ]
        ]
    }
};
                
                // parse_mode diubah menjadi "HTML"
                await bot.sendPhoto(chatId, settings.panelImage, { caption: captionPanel, parse_mode: "HTML", ...btnPaket });
                break;
                            // DI DALAM SWITCH (DATA)
                            
                case "menu_vps":
                await bot.deleteMessage(chatId, messageId).catch(()=>{}); 
                
                // FORMAT QUOTE MENGGUNAKAN HTML
                let textVps = `<blockquote>🚀 <b>MENU - CLOUD VPS</b>\n`;
                textVps += `━━━━━━━━━━━━━━━━━━\n\n`;
                textVps += `<i>Beli Vps kualitas terbaik dengan standar kualitas global? Disini tempatnya!\nBukan spek Vps kaleng kaleng yang dijual murah kualitas buruk, punya potensi suspend dan gak tahan lama bisnis hosting mu bisa berantakan dong, vps kena suspend,pelanggan bisa kabur dan ngecap jelek nama baik kamu juga store mu. Mulai ganti Vps mu sekarang dengan yang Legal 100%</i>\n\n`;
                textVps += `Silakan cek ketersediaan stok VPS hari ini.</blockquote>`;
                
                const btnVps = {
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: "🔍 𝘊𝘦𝘬 𝘒𝘦𝘵𝘦𝘳𝘴𝘦𝘥𝘪𝘢𝘢𝘯 𝘝𝘗𝘚", callback_data: "check_vps_stock", style: "success" }],
                            [{ text: "« 𝘒𝘦𝘮𝘣𝘢𝘭𝘪", callback_data: "back_to_main" }]
                        ]
                    }
                };
                
                // SANGAT PENTING: parse_mode diubah menjadi "HTML"
                await bot.sendPhoto(chatId, settings.panelImage, { caption: textVps, parse_mode: "HTML", ...btnVps });
                break;
                        // ====================================================
            // FITUR 1: MENU PROFIL & LIST SERVER
            // ====================================================
            
           case "menu_profil": {
  const userId = query.from.id;
  const dbUsers = getUsers();
  const myProfile = dbUsers[chatId];
  const userData = dbUsers[userId] || {};

  if (!myProfile) {
    await bot.answerCallbackQuery(query.id, { text: "Profil tidak ditemukan. Ketik /start dulu.", show_alert: true });
    break;
  }

  // === REVISI: AMBIL SALDO PANEL DARI DB VIA WORKER ===
  let mySaldo = await getSaldoReal(chatId);
  //let saldoUser = myProfile.saldo || 0; // fallback lokal dulu
 // try {
//    const resPanel = await fetch(`https://boosteryuk.boosteryukid.workers.dev/api/telegram/check?telegram_id=${chatId}`).then(r => r.json());
   // if (resPanel.status === true && resPanel.balance !== undefined) {
    //  saldoUser = resPanel.balance; // INI DARI KOLOM balance
  //  }
//  } catch (e) {
   // console.log("Gagal ambil saldo panel:", e.message);
//  }

  const gachaSisa = 3 - (myProfile.gachaCount || 0);

  let saldoFreelance = userData.saldoFreelance || 0;
  let saldoPending = userData.saldoPending || 0;

  if (fs.existsSync(FILE_TASK)) {
      const tasks = JSON.parse(fs.readFileSync(FILE_TASK, "utf8"));
      const userTasks = tasks.filter(task => String(task.userId) === String(chatId));
      saldoPending = userTasks.reduce((total, task) => total + (task.saldoPending || 0), 0);
  }

  // === AMBIL DATA PET ===
  const userPet = await getUserPet(chatId);
  let textPet = "";
  if (userPet.pet) {
    const sisaExperiencePoint = getRemainingXP(userPet.pet);
    const halfLevel = Math.floor(userPet.pet.maxLevel / 2);
    let fase = "Bayi 🐣";
    if (userPet.pet.level >= userPet.pet.maxLevel) {
      fase = "Dewasa 👑";
    } else if (userPet.pet.level >= halfLevel) {
      fase = "Tumbuh 🌱";
    }
    textPet = `\n\n🐾 <b>PET: ${userPet.pet.name}</b>\n`;
    textPet += `├ Level: ${userPet.pet.level}/${userPet.pet.maxLevel} ${fase}\n`;
    textPet += `└ Experience Point: ${userPet.pet.xp}/10 | Sisa: ${sisaExperiencePoint} Experience Point`;
  } else {
    textPet = `\n\n🐾 <b>PET:</b> Belum ada\nKlik tombol "🐾 Pet" untuk adopsi`;
  }

  let textFreelance = `\n\n💼 <b>FREELANCE</b>\n`;
  textFreelance += `├ Saldo Freelance: Rp${saldoFreelance.toLocaleString("id-ID")}\n`;
  textFreelance += `└ Saldo Pending: Rp${saldoPending.toLocaleString("id-ID")}`;

  let textProfil = `<blockquote>👤 <b>PROFIL AKUN</b>\n\n`;
  textProfil += `🆔 ID: <code>${chatId}</code>\n`;
  textProfil += `💰 <b>SALDO WEBSITE: Rp ${mySaldo.toLocaleString("id-ID")}</b>\n`; // INI SUDAH DARI DB
  textProfil += `🎰 Gacha Hari Ini: <b>${gachaSisa > 0? gachaSisa : 0}x</b>`;
  textProfil += textFreelance;
  textProfil += textPet;
  const daftarServer = Array.isArray(myProfile.servers) ? myProfile.servers : [];
  const aktif = daftarServer.filter(srv => serverExpiredMs(srv) > Date.now()).length;
  textProfil += `\n\n🟢 <b>SERVER AKTIF:</b> ${daftarServer.length ? `${aktif} aktif dari ${daftarServer.length} server (rincian di tabel bawah)` : "<i>Belum ada server yang aktif.</i>"}`;

  let btnProfil = [
    [
      { text: "🎮 Gacha Harian", callback_data: "menu_gacha", style: "success" },
      { text: "➕ Top Up Saldo", callback_data: "menu_deposit", style: "success" }
    ],
    [
      { text: "🐾 Kelola Pet", callback_data: "menu_pet", style: "success" }
    ],
    [
      { text: "« Kembali", callback_data: "back_to_main" }
    ]
  ];
  if (daftarServer.length) {
    btnProfil.unshift([{ text: "🔄 Perpanjang Server", callback_data: "extend_list", style: "success" }]);
  }

  textProfil += `</blockquote>`;

  await bot.deleteMessage(chatId, messageId).catch(() => {});

  await bot.sendPhoto(chatId, settings.panelImage, {
    caption: textProfil,
    parse_mode: "HTML",
    reply_markup: { inline_keyboard: btnProfil }
  }).catch(() => {
    return bot.sendMessage(chatId, textProfil, { parse_mode: "HTML", reply_markup: { inline_keyboard: btnProfil } });
  });
  // Bagian Server Aktif: tabel rich message (panel, VPS NAT, VPS dedicated)
  if (daftarServer.length) await kirimTabelServer(chatId, daftarServer).catch(e => console.log("Tabel server gagal:", e.message));
  break;
}
case "roll_gacha": {
    const dbUsers = getUsers();
    const myProfile = dbUsers[chatId];

    // Spin hanya boleh setelah menjawab soal dengan benar (session gacha_ready)
    if (!myProfile || userSessions[chatId]?.step !== "gacha_ready") {
        return bot.answerCallbackQuery(query.id, { text: "Jawab soal Gacha Harian dulu ya (Profil → Gacha Harian).", show_alert: true });
    }
    if ((myProfile.gachaCount || 0) >= 3) {
        delete userSessions[chatId];
        return bot.editMessageText("❌ Kamu sudah melakukannya hari ini, Silakan datang kembali besok!.", { chat_id: chatId, message_id: messageId });
    }

    myProfile.gachaCount = (myProfile.gachaCount || 0) + 1;
    const gachaKe = myProfile.gachaCount;

    // simpan dulu sebelum ada await, supaya klik cepat berkali-kali tidak lolos batas 3x
    saveUsers(dbUsers);
    await bot.answerCallbackQuery(query.id).catch(() => {});

    const winRate = Math.random() < 0.5;
    let textResult = "";

    bot.sendMessage(settings.adminId, `🎰 <b>GACHA LOG</b>\nUser: ${chatId}\nUsername: ${myProfile.username}\nKlik Gacha ke-${gachaKe}`, { parse_mode: "HTML" }).catch(() => {});

    if (winRate) {
        const hadiah = Number(settings.gachaHadiah) || 5;
        // Kredit ke saldo website, sama seperti deposit
        const kredit = await kreditSaldoWebsite(chatId, hadiah, `Hadiah gacha harian ke-${gachaKe}`);
        if (kredit.status) {
            textResult = `🎉 <b>SELAMAT!</b>\n\nKamu mendapatkan saldo <b>Rp ${hadiah.toLocaleString("id-ID")}</b>!\n✅ Sudah masuk ke saldo website.\n💳 Saldo sekarang: <b>Rp ${kredit.new_balance.toLocaleString("id-ID")}</b>`;
            bot.sendMessage(settings.adminId, `🔥 <b>GACHA WINNER!</b>\nUser: ${chatId}\nMendapatkan: Rp ${hadiah} (masuk saldo website)`, { parse_mode: "HTML" }).catch(() => {});
        } else {
            textResult = `🎉 <b>SELAMAT!</b>\n\nKamu mendapatkan saldo <b>Rp ${hadiah.toLocaleString("id-ID")}</b>!\n⏳ Saldo website sedang tidak bisa dihubungi, hadiah akan dikreditkan admin.` +
                `\n<i>Pastikan akun website sudah terhubung (menu /start → Hubungkan Akun).</i>`;
        }
    } else {
        textResult = `🎰 <b>ZONK!</b>\n\nMaaf, kamu belum beruntung di putaran ke-${gachaKe}. Ayo coba lagi!`;
    }

    const sisa = 3 - gachaKe;
    let btnGacha = [];
    
    if (sisa > 0) {
        btnGacha.push([{ text: `🎰 SPIN LAGI (${sisa}x)`, callback_data: "roll_gacha", style: "success" }]);
    } else {
        delete userSessions[chatId];
    }
    btnGacha.push([{ text: "« Kembali ke Profil", callback_data: "menu_profil" }]);

    await bot.editMessageText(textResult, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: btnGacha }
    });
    break;
}
// 1. Klik Tombol Deposit
case "menu_deposit":
    userSessions[chatId] = { step: "waiting_depo_amount" };
    await bot.sendMessage(chatId, "💰 <b>TOP UP SALDO</b>\n\nMasukkan nominal yang ingin kamu deposit:\n(Min: 2000)", { parse_mode: "HTML" });
    break;
    
case "pay_via_saldo": {
    const userId = query.from.id;
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;
    // FIX: Cek 2 key biar gak hilang sesi (private chat userId == chatId, di grup beda)
    const session = userSessions[userId] || userSessions[chatId] || userSessions[String(userId)] || userSessions[String(chatId)];

    if (!session || !session.harga) {
        return bot.answerCallbackQuery(query.id, { text: "⚠️ Sesi order hilang, Harap order ulang.", show_alert: true });
    }

    const harga = parseInt(session.harga);
    const namaLayanan = session.paket || session.layanan || session.produk || session.username || 'ITEM';
    
    await bot.answerCallbackQuery(query.id, { text: "⏳ Sebentar ya...", show_alert: false });

    // 1. POTONG SALDO REAL DARI WEBSITE
    const potong = await potongSaldoReal(userId, harga, `Order ${namaLayanan}`);

    if (!potong || !potong.status) {
        // Callback sudah dijawab ("Sebentar ya..."), jadi jawaban kedua tidak akan tampil -> kirim pesan.
        // Sesi tetap disimpan supaya user bisa langsung bayar QRIS tanpa order ulang.
        return bot.sendMessage(chatId, `<blockquote>❌ <b>Pembayaran saldo gagal</b>\n${(potong && (potong.msg || potong.message)) || "Saldo tidak cukup"}\n\n💰 Harga: Rp ${harga.toLocaleString("id-ID")}\n\nBayar langsung pakai QRIS, atau top up saldo dulu.</blockquote>`, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [
                [{ text: "⚡ Bayar QRIS 1 (Fast)", callback_data: "pay_qris_tripay", style: "success" }],
                [{ text: "➕ Top Up Saldo", callback_data: "menu_deposit", style: "success" }, { text: "« Batalkan", callback_data: "back_to_main" }]
            ] }
        });
    }

    // 2. Kalau berhasil potong, edit pesan biar gak double loading - UI TETAP
    await bot.editMessageText(`✅ Saldo digunakan! Sisa Rp ${potong.new_balance.toLocaleString()}\n\n⏳ Proses order ${namaLayanan}...`, {
        chat_id: chatId,
        message_id: messageId
    });

    const walletOrderId = `WAL-${Date.now()}`;

    try {
        // FIX: Panggil pakai chatId (buat kirim pesan), tapi session tetap yang ada type-nya
        // Jangan pakai userId di sini, karena handlePaymentSuccess butuh chatId
        await handlePaymentSuccess(chatId, session, walletOrderId, messageId);
    } catch (err) {
        // 3. KALAU GAGAL, REFUND OTOMATIS - UI TETAP
        console.error(`[PAY_VIA_SALDO] Gagal ${namaLayanan} type=${session.type} paket=${session.paket}:`, err.message);
        const refund = await refundSaldoReal(userId, harga, `Gagal eksekusi ${walletOrderId} - ${err.message}`);
        
        if(refund.status){
            await bot.sendMessage(chatId, `❌ Order gagal (${err.message}), saldo Rp ${harga.toLocaleString()} sudah di refund.\nSisa saldo: Rp ${refund.new_balance.toLocaleString()}`);
        } else {
            await bot.sendMessage(chatId, `❌ FATAL: Order gagal & refund gagal! Hubungi admin.\nError: ${err.message} | Refund: ${refund.msg}`);
        }
    }
    
    break;
}
case "menu_gacha": {
    const dbUsers = getUsers();
    const myProfile = dbUsers[chatId];

    // --- LOGIKA RESET JAM 00.00 WIB ---
    const today = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Jakarta' }); 

    if (myProfile.lastGachaDate !== today) {
        myProfile.lastGachaDate = today;
        myProfile.gachaCount = 0;
        myProfile.gachaLocked = false;
        saveUsers(dbUsers);
    }

    if (myProfile.gachaLocked) {
        return bot.answerCallbackQuery(query.id, { 
            text: "❌ Jawaban kamu tadi salah, Kembali lagi besok ya!", 
            show_alert: true 
        });
    }

    if (myProfile.gachaCount >= 3) {
        return bot.answerCallbackQuery(query.id, { 
            text: "❌ Kamu sudah melakukannya hari ini, Kembali lagi besok ya!", 
            show_alert: true 
        });
    }

    // --- GENERATE SOAL (Penjumlahan, Pengurangan, Perkalian) ---
    const ops = ['+', '-', '*'];
    const op = ops[Math.floor(Math.random() * ops.length)];
    let a, b, hasil;

    if (op === '+') {
        a = Math.floor(Math.random() * 40) + 10; // 10 - 50
        b = Math.floor(Math.random() * 40) + 10; // 10 - 50
        hasil = a + b;
    } else if (op === '-') {
        a = Math.floor(Math.random() * 30) + 20; // 20 - 50
        b = Math.floor(Math.random() * 15) + 1;  // 1 - 15
        hasil = a - b; // Pastikan hasil selalu positif
    } else { // Perkalian (*)
        a = Math.floor(Math.random() * 10) + 2;  // 2 - 12
        b = Math.floor(Math.random() * 10) + 2;  // 2 - 12
        hasil = a * b; // Hasil selalu bulat (integer)
    }

    userSessions[chatId] = { 
        step: "waiting_gacha_answer", 
        answer: hasil 
    };

    const textGacha = `<blockquote>🎮 <b>TANTANGAN GACHA HARIAN</b>\n\n` +
                    `Selesaikan soal ini untuk mulai Spin:\n` +
                    `Berapakah hasil dari: <b>${a} ${op} ${b}</b> ?\n\n` +
                    `<i>Sisa Spin: ${3 - myProfile.gachaCount}x\n⚠️ Jika salah jawab, Spin hari ini HANGUS!</i></blockquote>`;

    await bot.deleteMessage(chatId, messageId).catch(()=>{});
    await bot.sendPhoto(chatId, settings.panelImage, { 
        caption: textGacha, 
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [[{ text: "« Kembali", callback_data: "menu_profil" }]] }
    });
    break;
}
            // ====================================================
            // FITUR 2: PILIH SERVER UNTUK DIPERPANJANG
            // ====================================================
            case "extend_list":
                const myData = getUsers()[chatId];
                if (!myData || !myData.servers || myData.servers.length === 0) break;

                let extButtons = [];
                myData.servers.forEach((srv, index) => {
                    // Tombol untuk masing-masing server
                    extButtons.push([{ text: `🖥 ${serverJenis(srv)}: ${srv.username_panel} • ${serverSisa(serverExpiredMs(srv))}`, callback_data: `ext_ui_${index}_30`, style: "success" }]);
                });
                extButtons.push([{ text: "« 𝘒𝘦𝘮𝘣𝘢𝘭𝘪 𝘒𝘦 𝘗𝘳𝘰𝘧𝘪𝘭", callback_data: "menu_profil" }]);

                await bot.deleteMessage(chatId, messageId).catch(()=>{});
                // Menggunakan gambar panel dari setting
                await bot.sendPhoto(chatId, settings.panelImage, { 
                    caption: "<blockquote>🔄 <b>PERPANJANG MASA SEWA</b>\n\nSilakan pilih server (Panel / VPS NAT / VPS Dedicated) yang ingin diperpanjang:</blockquote>", 
                    parse_mode: "HTML", 
                    reply_markup: { inline_keyboard: extButtons } 
                });
                break;
            // ====================================================
            // PAYMENT GATEWAY PAKASIR (CREATE QRIS)
            // ====================================================
            case "qr_server_1": {
    const userId = query.from.id;
    const session = userSessions[userId];

    // 1. VALIDASI SESI (Ditambahkan tipe 'patungan')
    if (!session || (!session.username && session.type !== "deposit" && session.type !== "patungan")) {
        await bot.answerCallbackQuery(query.id, { 
            text: "Sesi order habis. Harap order ulang.", 
            show_alert: true 
        });
        break;
    }

    await bot.answerCallbackQuery(query.id, { text: "Membuat QRIS, mohon tunggu..." });

    // --- BAGIAN PENENTUAN ORDER ID KHUSUS ---
    let prefix = "INV";
    if (session.type === "deposit") prefix = "DEP";
    if (session.type === "patungan") prefix = "PTG"; // ID Khusus Patungan
    
    const orderId = session.orderId || `${prefix}${Date.now()}`;
    
    try {
        const res = await axios.post(`${settings.pakasir.baseUrl}/transactioncreate/qris`, {
            project: settings.pakasir.slug,
            order_id: orderId,
            amount: session.harga, 
            api_key: settings.pakasir.apiKey
        });

        const qrisString = res.data.payment.payment_number; 
        const totalPayment = res.data.payment.total_payment; 
        
        userSessions[userId].orderId = orderId;
        userSessions[userId].amount = session.harga; 

        const qrisImageBuffer = await QRCode.toBuffer(qrisString, { 
            margin: 4, scale: 12,
            color: { dark: '#000000', light: '#FFFFFF' }
        });

        // --- BAGIAN DINAMIS (TIDAK MERUSAK STRUKTUR LAMA) ---
        let labelUser, valueUser, labelProduk, valueProduk, extraNote = "";

        if (session.type === "deposit") {
            labelUser = "UID";
            valueUser = userId;
            labelProduk = "Deposit";
            valueProduk = "Isi Saldo";
        } else if (session.type === "patungan") {
            // Deskripsi khusus Patungan
            labelUser = "Room ID";
            valueUser = session.roomId || "NEW ROOM";
            labelProduk = "Paket & Role";
            valueProduk = `${session.paket.toUpperCase()} (${session.role})`; // Menampilkan Role CEO/Partner dll
            extraNote = `\n<i>Setelah bayar, kamu otomatis menjadi <b>${session.role}</b></i>`;
        } else {
            // Default untuk Panel/VPS biasa
            labelUser = "Username";
            valueUser = session.username;
            labelProduk = "Produk";
            valueProduk = session.paket || "Panel Pterodactyl";
        }

        // 5. RENDER TEXT INVOICE (Menggunakan variabel dinamis di atas)
        const textQr = `<blockquote>🛒 <b>INVOICE ORDER</b>

📝 <b>Order ID:</b> <code>${orderId}</code>
👤 <b>${labelUser}:</b> <code>${valueUser}</code>
📦 <b>${labelProduk}:</b> ${valueProduk}
💰 <b>Total Bayar:</b> <b>Rp ${totalPayment}</b>\n(Termasuk Fee)\n\n${extraNote}

<i>Silakan scan QRIS di atas. Klik tombol di bawah jika sudah bayar.</i></blockquote>`;
                    
        await bot.deleteMessage(userId, messageId).catch(()=>{});
        
        await bot.sendPhoto(userId, qrisImageBuffer, {
            caption: textQr,
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: [ 
                    [{ text: "Cek Status Pembayaran ♻️", callback_data: "cek_payment_status", style: "success" }],
                    [{ text: "Batal ❌", callback_data: "back_to_main" }]
                ] 
            }
        });

    } catch (err) {
        console.error("Error Pakasir:", err.response ? err.response.data : err.message);
        await bot.sendMessage(userId, "⚠️ Gagal membuat QRIS. Silakan coba lagi atau hubungi admin.");
    }
    break;
}

case "pay_crypto_heleket": {
    const userId = query.from.id;
    const session = userSessions[userId];

    if (!session || !session.harga) {
        return bot.answerCallbackQuery(query.id, { text: "⚠️ Harga tidak ditemukan, Silakan order ulang.", show_alert: true });
    }

    try {
        // 1. Bersihkan Harga & Hitung USD
        const hargaMentah = String(session.harga).replace(/[^0-9]/g, '');
        const kurs = parseFloat(settings.heleket.kursUsd) || 17089;
        const amountUSD = (parseFloat(hargaMentah) / kurs).toFixed(2);
        
        // Buat Order ID yang lebih pendek (beberapa API sensitif terhadap panjang ID)
        const orderId = `INV${Math.floor(Date.now() / 1000)}`; 

        // 2. Buat Payload (Urutan: amount, currency, order_id)
        const payload = {
            amount: String(amountUSD),
            currency: "USD",
            order_id: String(orderId)
        };

        // 3. Stringify & Sign (Metode Paling Akurat)
        // Gunakan replace manual untuk memastikan slash di-escape dengan benar
        const rawBody = JSON.stringify(payload).replace(/\//g, "\\/");
        const base64Body = Buffer.from(rawBody).toString('base64');
        
        // Pastikan API Key bersih dari spasi di awal/akhir
        const cleanApiKey = settings.heleket.apiKey.trim();
        const cleanMerchant = settings.heleket.merchant.trim();

        const signature = crypto.createHash('md5')
            .update(base64Body + cleanApiKey)
            .digest('hex');

        // DEBUG: Cek terminal untuk memastikan data bersih
        console.log("--- DEBUG RE-CHECK ---");
        console.log("Payload:", rawBody);
        console.log("Sign:", signature);

        await bot.answerCallbackQuery(query.id, { text: "Menghubungkan ke Gateway..." });

        // 4. Kirim Request
        const response = await axios.post('https://api.heleket.com/v1/payment', rawBody, {
            headers: {
                'merchant': cleanMerchant,
                'sign': signature,
                'Content-Type': 'application/json'
            }
        });

        if (response.data.state === 0) {
            const res = response.data.result;
            let textPay = `💎 <b>PEMBAYARAN CRYPTO</b>\n\n` +
                          `💵 Total Tagihan: <b>$${amountUSD} USD</b>\n` +
                          `🆔 Invoice ID: <code>${res.uuid}</code>\n\n` +
                          `<i>Klik tombol di bawah untuk membayar. Link berlaku 60 menit.</i>`;

            const btnPay = {
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "🔗 BAYAR SEKARANG", url: res.url }],
                        [{ text: "🔄 CEK STATUS", callback_data: `check_pay_${res.uuid}`, style: "success" }],
                        [{ text: "« Kembali", callback_data: "back_to_main" }]
                    ]
                }
            };

            // PERBAIKAN DI SINI: Gunakan editMessageText karena pesan sebelumnya adalah teks
            await bot.editMessageText(textPay, {
                chat_id: userId,
                message_id: messageId,
                parse_mode: "HTML",
                ...btnPay
            }).catch((err) => {
                // Jika masih error, kirim sebagai pesan baru (fallback)
                bot.sendMessage(userId, textPay, { parse_mode: "HTML", ...btnPay });
            });

        } else {
            bot.answerCallbackQuery(query.id, { text: "Heleket: " + response.data.message, show_alert: true });
        }

    } catch (err) {
        console.error("HTTP ERROR:", err.response?.data || err.message);
        const msg = err.response?.data?.message || "Invalid Sign. Cek API Key di settings.";
        bot.answerCallbackQuery(query.id, { text: "Error: " + msg, show_alert: true });
    }
    break;
}

            case "qr_server_2":
                await bot.answerCallbackQuery(query.id, { text: "Server QRIS 2 sedang maintenance.", show_alert: true });
                break;
                
                case "qr_server_3":
                await bot.answerCallbackQuery(query.id, { text: "Server Crypto belum tersedia.", show_alert: true });
                return; // Return khusus alert

            // ====================================================
            // CEK STATUS PAKASIR (MANUAL BUTTON)
            // ====================================================
   case "cek_payment_status": {
    const userId = query.from.id;
    const curSession = userSessions[userId];

    if (!curSession || !curSession.orderId) {
        return bot.answerCallbackQuery(query.id, { text: "Data order tidak ditemukan.", show_alert: true });
    }

    try {
        const checkUrl = `${settings.pakasir.baseUrl}/transactiondetail?project=${settings.pakasir.slug}&amount=${curSession.amount}&order_id=${curSession.orderId}&api_key=${settings.pakasir.apiKey}`;
        const statusRes = await axios.get(checkUrl);
        const txStatus = statusRes.data.transaction.status; 

        if (txStatus === "completed") {
            await bot.answerCallbackQuery(query.id, { text: "✅ Pembayaran SUKSES! Memproses Pesanan...", show_alert: true });
            
            // Panggil fungsi pusat eksekusi (Sama dengan Heleket)
            await handlePaymentSuccess(userId, curSession, curSession.orderId, messageId);
        } else {
            await bot.answerCallbackQuery(query.id, { text: "⏳ Belum lunas. Silakan bayar dulu ya!", show_alert: true });
        }
    } catch (err) {
        bot.answerCallbackQuery(query.id, { text: "Gagal mengecek status.", show_alert: true });
    }
    break;
}
            // ====================================================
            // FITUR SIMULASI PEMBAYARAN (SANDBOX)
            // ====================================================
            case "simulate_payment":
                const simSession = userSessions[chatId];
                if (!simSession || !simSession.orderId) {
                    await bot.answerCallbackQuery(query.id, { text: "Data order tidak valid.", show_alert: true });
                    break;
                }

                await bot.answerCallbackQuery(query.id, { text: "Mengirim simulasi..." });

                try {
                    // Tembak API Simulasi Pakasir
                    await axios.post(`${settings.pakasir.baseUrl}/paymentsimulation`, {
                        project: settings.pakasir.slug,
                        order_id: simSession.orderId,
                        amount: simSession.amount,
                        api_key: settings.pakasir.apiKey
                    });

                    // Bot tidak perlu memanggil fungsi createPanel di sini. 
                    // Karena Pakasir akan otomatis mengirim ping ke WEBHOOK Anda, 
                    // dan fungsi webhook di bawah akan mengeksekusi create panel.
                    
                    await bot.sendMessage(chatId, "🧪 *SIMULASI DIKIRIM!*\nMenunggu respon Webhook dari server Pakasir...", { parse_mode: "Markdown" });

                } catch (err) {
                    console.error("Simulasi Error:", err.response ? err.response.data : err.message);
                    await bot.answerCallbackQuery(query.id, { text: "Gagal mengirim simulasi.", show_alert: true });
                }
                break;

            // ====================================================
            // FITUR BATALKAN PESANAN (CANCEL TRANSACTION)
            // ====================================================
            case "cancel_payment":
                const cancelSession = userSessions[chatId];
                if (!cancelSession || !cancelSession.orderId) {
                    await bot.answerCallbackQuery(query.id, { text: "Tidak ada order aktif yang bisa dibatalkan.", show_alert: true });
                    break;
                }

                await bot.answerCallbackQuery(query.id, { text: "Membatalkan pesanan..." });

                try {
                    // Tembak API Cancel Pakasir
                    await axios.post(`${settings.pakasir.baseUrl}/transactioncancel`, {
                        project: settings.pakasir.slug,
                        order_id: cancelSession.orderId,
                        amount: cancelSession.amount,
                        api_key: settings.pakasir.apiKey
                    });

                    // Edit caption foto QR menjadi "Pesanan Dibatalkan" agar tidak bisa discan lagi
                    await bot.editMessageCaption(`<blockquote>❌ <b>PESANAN DIBATALKAN</b>\n\nOrder ID: <code>${cancelSession.orderId}</code> telah berhasil dibatalkan oleh pengguna.</blockquote>`, {
                        chat_id: chatId,
                        message_id: messageId,
                        parse_mode: "HTML" // <-- UBAH KE HTML
                    });

                    // Hapus sesi user
                    delete userSessions[chatId];

                    // Tampilkan notifikasi pop-up
                    await bot.answerCallbackQuery(query.id, { text: "Pesanan berhasil dibatalkan dari sistem.", show_alert: true });

                } catch (err) {
                    console.error("Cancel Error:", err.response ? err.response.data : err.message);
                    await bot.answerCallbackQuery(query.id, { text: "Gagal membatalkan pesanan di server 1.", show_alert: true });
                }
                break;
            case "cekid":
                await bot.sendMessage(chatId, `ID Anda adalah: ${chatId}`);
                break;

            // === CASE 1: BUKA MENU PET ===
            case 'menu_pet': {
    const userId = query.from.id
    const user = await getUserPet(userId)

    // Keyboard adopsi - callback tetep pick_egg biar ga ngerusak flow lama
    const keyboardAdopt = {
        inline_keyboard: [
            [
                {text: '🥚 Blaze Telur Api', callback_data: 'pick_egg', style: "success"},
                {text: '🌱 Leafy Bibit Pohon', callback_data: 'pick_tree', style: "success"}
            ],
            [
                {text: '🐱 Pawsy Anak Kucing', callback_data: 'pick_cat', style: "success"}
            ],
            [{text: '⬅️ Kembali', callback_data: 'back_to_main'}]
        ]
    }

    if(!user ||!user.pet) {
        // Belum punya pet → hapus pesan lama + kirim teks baru
        try {
            await bot.deleteMessage(chatId, messageId)
        } catch(e) {}

        await bot.sendMessage(chatId,
            `<blockquote>🐾 <b>ADOPSI PET PERTAMA KAMU!</b>\n\nPilih bibit pet. Tiap pet punya 3 fase: Bayi → Tumbuh → Dewasa\nDapatkan Rewards hadiah menarik mulai dari produk VPS hingga saldo wallet yang bisa kamu cairkan!</blockquote>`,
            {parse_mode: 'HTML', reply_markup: keyboardAdopt}
        )
    } else {
        // Udah punya pet → tampil status + gambar sesuai level
        await showPetStatus(chatId, user.pet, messageId)
    }
    break
}

            // === CASE 2: ADOPSI PET BARU ===
            case 'pick_egg':
            case 'pick_tree':
            case 'pick_cat': {
    const userId = query.from.id
    const oldType = data.replace('pick_', '')

    // Mapping biar sinkron sama PET_IMAGES baru
    const typeMap = {egg: 'blaze', tree: 'leafy', cat: 'pawsy'}
    const type = typeMap[oldType]

    const petNames = {blaze: 'Blaze', leafy: 'Leafy', pawsy: 'Pawsy'}
    const maxLevels = {blaze: 100, leafy: 300, pawsy: 150}

    const newPet = {
        type, // sekarang 'blaze' bukan 'egg'
        name: petNames[type],
        level: 0,
        xp: 0,
        maxLevel: maxLevels[type],
        lastFeed: null, 
        lastDrinkFree: null,
        lastDrinkVoice: null,
        feedThisWeek: 0,
        weekId: getWeekId(),
        isNew: true, 
        stopReminder: false
    }

    await savePet(userId, newPet)
    await bot.deleteMessage(chatId, messageId).catch(()=>{})

    await bot.sendPhoto(chatId, PET_IMAGES[type].baby, {
        caption: `🎉 SELAMAT! Kamu adopsi ${newPet.name}!\n\nIni wujud dia masih bayi 🐣\nRawat pake VN "minta minum" +2 XP atau tunggu Sabtu-Minggu buat dapat makan gratis +5 XP\nKlik tombol "pet" buat cek status`,
        parse_mode: 'HTML',
        reply_markup: {
            inline_keyboard: [[{text: '🔄 Lihat Pet', callback_data: 'menu_pet', style: "success"}]]
        }
    })
    break
}

case 'drink_pet': {
    const userId = query.from.id
    const user = await getUserPet(userId)
    const today = new Date().toISOString().split('T')[0]

    if(user.pet.lastDrinkVoice === today) {
        await bot.answerCallbackQuery(query.id, {text: 'Udah minum hari ini! Besok lagi ya', show_alert: true})
        return
    }

    user.pet.xp += 2
    user.pet.lastDrinkVoice = today

    let msg = '+2 XP'
    if(user.pet.xp >= 10) {
        user.pet.level += 1
        user.pet.xp = 0
        msg = `🎉  +2 XP || ${user.pet.level}!`
    }

    await savePet(userId, user.pet)
    await bot.answerCallbackQuery(query.id, {text: msg})
    await showPetStatus(chatId, user.pet, messageId)
    break
}

case 'feed_pet': {
    const userId = query.from.id
    const chatId = query.message.chat.id
    const messageId = query.message_id
    const user = await getUserPet(userId)
    const today = new Date().toISOString().split('T')[0]

    if(!user?.pet) {
        await bot.answerCallbackQuery(query.id, {text: 'Kamu belum punya pet!', show_alert: true})
        return
    }

    // CEK WEEKEND - GAUSAH KUNCI TOMBOL
    const day = new Date().getDay() // 0=Minggu, 6=Sabtu
    const isWeekend = day === 0 || day === 6

    if(!isWeekend) {
        await bot.answerCallbackQuery(query.id, {text: '🍗 Kamu tidak punya makanannya', show_alert: true})
        return
    }

    if(user.pet.lastFeed === today) {
        await bot.answerCallbackQuery(query.id, {text: 'Udah dikasih makan hari ini! Besok lagi ya', show_alert: true})
        return
    }

    user.pet.xp += 2 // Makan = +2 XP
    user.pet.lastFeed = today

    let msg = '+2 XP 🍗'
    let levelUpMsg = ''

    while(user.pet.xp >= 10) {
        user.pet.level += 1
        user.pet.xp -= 10
        if(user.pet.level > user.pet.maxLevel) {
            user.pet.level = user.pet.maxLevel
            user.pet.xp = 0
            levelUpMsg = `\n👑 ${user.pet.name} udah max level!`
            break
        }
        levelUpMsg += `\n🎉 ${user.pet.name} naik ke Lv ${user.pet.level}!`
    }

    await savePet(userId, user.pet)
    await bot.answerCallbackQuery(query.id, {text: msg + levelUpMsg})
    await showPetStatus(chatId, user.pet, messageId)
    break
}

case "menu_freelance": {
  const userId = query.from.id;
  const text = `<blockquote><b>💼 MENU FREELANCE</b>\n\n` +
               `Kerjakan tugas, Dapat Uang 💸\n\n` +
               `Pilih campaign yang sedang berlangsung dibawah ini.</blockquote>`;

  const btn = campaigns.map(campaign => [{
    text: `${campaign.name}`,
    callback_data: `campaign_${campaign.id}`
  }]);

  btn.push([
    { text: "« Kembali", callback_data: "back_to_main" }, 
    { text: "💸 Withdraw", callback_data: "menu_withdraw" }
  ]);

  // Cek message awalnya foto apa text
  if (query.message.photo) {
    // Kalo ada foto = edit caption
    await bot.editMessageCaption(text, {
      chat_id: chatId, 
      message_id: messageId,
      parse_mode: "HTML", 
      reply_markup: { inline_keyboard: btn }
    });
  } else {
    // Kalo cuma text = edit text
    await bot.editMessageText(text, {
      chat_id: chatId, 
      message_id: messageId,
      parse_mode: "HTML", 
      reply_markup: { inline_keyboard: btn }
    });
  }

  await bot.answerCallbackQuery(query.id);
  break;
}
case /^approve_(\d+)_(\d+)$/: {
  const adminId = query.from.id;
  const matchResult = data.match(/^approve_(\d+)_(\d+)$/);
  const targetUserId = matchResult[1];
  const taskIndex = parseInt(matchResult[2], 10);

  const tasks = JSON.parse(fs.readFileSync(FILE_TASK, "utf8"));
  const task = tasks[taskIndex];

  if (!task || String(task.userId)!== targetUserId) {
    await bot.answerCallbackQuery(query.id, { text: "Data tugas tidak ditemukan", show_alert: true });
    break;
  }

  // Ambil teks pesan admin sebelum diedit
  const adminText = query.message.text.replace(/✅ TUGAS DITERIMA\n|❌ TUGAS DITOLAK\n|\n\n<b>Status:<\/b>.*$/g, "");

  // Pindahkan saldo pending ke saldo freelance user
  const dbUsers = getUsers();
  if (!dbUsers[targetUserId]) {
    dbUsers[targetUserId] = { saldoFreelance: 0 };
  }
  if (!dbUsers[targetUserId].saldoFreelance) {
    dbUsers[targetUserId].saldoFreelance = 0;
  }
  dbUsers[targetUserId].saldoFreelance += task.saldoPending;

  // Hapus tugas dari daftar pending
  tasks.splice(taskIndex, 1);
  fs.writeFileSync(FILE_TASK, JSON.stringify(tasks, null, 2));
  saveUsers(dbUsers);

  // Kirim notifikasi ke user
  await bot.sendMessage(
    targetUserId,
    `<blockquote>✅ Selamat, Tugas Anda kami terima!</blockquote>\n` +
    `Saldo Rp${task.saldoPending.toLocaleString("id-ID")} sudah dikreditkan ke profil Anda.`,
    { parse_mode: "HTML" }
  );

  // Update pesan admin
  await bot.editMessageText(
    `<blockquote>✅ TUGAS DITERIMA</blockquote>\n${adminText}\n\n<b>Status:</b> Saldo Rp${task.saldoPending.toLocaleString("id-ID")} sudah masuk ke user`,
    {
      chat_id: query.message.chat.id,
      message_id: query.message_id,
      parse_mode: "HTML"
    }
  );

  await bot.answerCallbackQuery(query.id, { text: "Tugas diterima" });
  break;
}

case /^reject_(\d+)_(\d+)$/: {
  const adminId = query.from.id;
  const matchResult = data.match(/^reject_(\d+)_(\d+)$/);
  const targetUserId = matchResult[1];
  const taskIndex = parseInt(matchResult[2], 10);

  const tasks = JSON.parse(fs.readFileSync(FILE_TASK, "utf8"));
  const task = tasks[taskIndex];

  if (!task || String(task.userId)!== targetUserId) {
    await bot.answerCallbackQuery(query.id, { text: "Data tugas tidak ditemukan", show_alert: true });
    break;
  }

  // Ambil teks pesan admin sebelum diedit
  const adminText = query.message.text.replace(/✅ TUGAS DITERIMA\n|❌ TUGAS DITOLAK\n|\n\n<b>Status:<\/b>.*$/g, "");

  // Hapus tugas dari daftar pending, saldo pending otomatis hilang
  tasks.splice(taskIndex, 1);
  fs.writeFileSync(FILE_TASK, JSON.stringify(tasks, null, 2));

  // Kirim notifikasi ke user
  await bot.sendMessage(userId,
  `<blockquote>❌ TUGAS DITOLAK</blockquote>\n` +
  `Tugas Anda ditolak admin karena alasan data tidak valid atau lainnya.\n` +
  `Jika terdapat kesalahan data harap hubungi pusat bantuan.`,
  { 
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '💬 Pusat Bantuan', callback_data: 'menu_bantuan', style: "danger" },
          { text: '💼 Kerjakan Lagi', callback_data: 'menu_freelance', style: "success" }
        ]
      ]
    }
  }
);

  // Update pesan admin
  await bot.editMessageText(
    `<blockquote>❌ TUGAS DITOLAK</blockquote>\n${adminText}\n\n<b>Status:</b> Saldo pending dihapus`,
    {
      chat_id: query.message.chat.id,
      message_id: query.message_id,
      parse_mode: "HTML"
    }
  );

  await bot.answerCallbackQuery(query.id, { text: "Tugas ditolak" });
  break;
}

case "menu_withdraw": {
  const dbUsers = getUsers();
  const myProfile = dbUsers[chatId];
  const saldoFreelance = myProfile.saldoFreelance || 0;

  let textWithdraw = `<blockquote>💸 <b>MENU WITHDRAW</b>\n\n`;
  textWithdraw += `Saldo Freelance Anda: $${saldoFreelance.toFixed(3)}\n\n`;
  textWithdraw += `⚠️ <b>PERHATIAN</b>\n`;
  textWithdraw += `Pastikan alamat penarikan tidak memiliki biaya admin atau fee. Jika terdapat biaya admin maka saldo tidak akan diteruskan.</blockquote>\n\n`;
  textWithdraw += `Silakan pilih metode penarikan:`;

  let btnWithdraw = [
    [
      { text: "💳 Wallet", callback_data: "withdraw_wallet" },
      { text: "📷 QRIS", callback_data: "withdraw_qris" }
    ],
    [
      { text: "« Kembali", callback_data: "back_to_main" }
    ]
  ];

  await bot.sendMessage(chatId, textWithdraw, {
    parse_mode: "HTML",
    reply_markup: { inline_keyboard: btnWithdraw }
  });
  break;
}

case "withdraw_wallet": {
  userState[chatId] = { step: "waiting_wallet" };
  await bot.sendMessage(chatId, `<blockquote>Kirim alamat wallet Anda sekarang.\nContoh: 0x123abc...</blockquote>`, { parse_mode: "HTML" });
  break;
}

case "withdraw_qris": {
  userState[chatId] = { step: "waiting_qris" };
  await bot.sendMessage(chatId, `<blockquote>Kirim foto QRIS Anda sekarang.\nPastikan foto jelas dan tidak buram.</blockquote>`, { parse_mode: "HTML" });
  break;
}

case /^withdraw_done_(\d+)$/: {
const userId = query.from.id;
  const targetUserId = data.match(/^withdraw_done_(\d+)$/)[1];

  if (String(userId)!== String(owner)) {
    await bot.answerCallbackQuery(query.id, { text: "Anda bukan admin", show_alert: true });
    break;
  }

  const dbUsers = getUsers();
  const saldoFreelance = dbUsers[targetUserId].saldoFreelance || 0;

  // Potong saldo freelance user
  dbUsers[targetUserId].saldoFreelance = 0;
  saveUsers(dbUsers);

  await bot.sendMessage(targetUserId, `<blockquote>Withdraw telah berhasil. Saldo $${saldoFreelance.toFixed(3)} akan segera dikirim ke alamat Anda.</blockquote>`, { parse_mode: "HTML" });

  await bot.editMessageCaption(`<blockquote>✅ WITHDRAW BERHASIL</blockquote>\n${query.message.caption}\n\n<b>Status:</b> Saldo sudah dikirim ke user`, {
    chat_id: query.message.chat.id,
    message_id: query.message_id,
    parse_mode: "HTML"
  }).catch(() => {
    bot.editMessageText(`<blockquote>✅ WITHDRAW BERHASIL</blockquote>\n${query.message.text}\n\n<b>Status:</b> Saldo sudah dikirim ke user`, {
      chat_id: query.message.chat.id,
      message_id: query.message_id,
      parse_mode: "HTML"
    });
  });

  await bot.answerCallbackQuery(query.id, { text: "Withdraw berhasil" });
  break;
}

case /^withdraw_reject_(\d+)$/: {
const userId = query.from.id;
  const targetUserId = data.match(/^withdraw_reject_(\d+)$/)[1];

  if (String(userId)!== String(owner)) {
    await bot.answerCallbackQuery(query.id, { text: "Anda bukan admin", show_alert: true });
    break;
  }

  await bot.sendMessage(targetUserId, `<blockquote>Withdraw ditolak karena alamat penarikan memiliki biaya admin atau fee.</blockquote>`, { parse_mode: "HTML" });

  await bot.editMessageCaption(`<blockquote>❌ WITHDRAW DITOLAK</blockquote>\n${query.message.caption}\n\n<b>Status:</b> Alamat memiliki fee`, {
    chat_id: query.message.chat.id,
    message_id: query.message_id,
    parse_mode: "HTML"
  }).catch(() => {
    bot.editMessageText(`<blockquote>❌ WITHDRAW DITOLAK</blockquote>\n${query.message.text}\n\n<b>Status:</b> Alamat memiliki fee`, {
      chat_id: query.message.chat.id,
      message_id: query.message_id,
      parse_mode: "HTML"
    });
  });

  await bot.answerCallbackQuery(query.id, { text: "Withdraw ditolak" });
  break;
}

        } // <--- PENUTUP SWITCH

        await bot.answerCallbackQuery(query.id).catch(()=>{});

    // ====================================================
    // CATCH (PENUTUP TRY - POSISI 100% AMAN DI SINI)
    // ====================================================
    } catch (error) { 
        console.error("Error di callback:", error);
        await bot.answerCallbackQuery(query.id, { text: "Terjadi kesalahan sistem." }).catch(()=>{});
    }
}); // <--- PENUTUP BOT.ON ("CALLBACK_QUERY")

bot.onText(/\/bangunin pet/, async (msg) => {
    const user = await getUser(msg.from.id)
    user.stopReminder = false
    await saveUser(msg.from.id, user)
    bot.sendMessage(msg.chat.id, '🔔 Reminder pet sudah diaktifin lagi! Pet akan berinteraksi dengan kamu lagi ~')
})
// ====================================================
// FITUR ADMIN: CEK DETAIL USER BERDASARKAN ID
// Command: /cek <id_telegram>
// ====================================================
bot.onText(/^\/cek (\d+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const targetId = match[1];

    if (String(chatId) !== String(settings.adminId)) return;

    const waitMsg = await bot.sendMessage(chatId, "⏳ <i>Wait, check...</i>", { parse_mode: "HTML" });

    try {
        const dbUsers = getUsers();
        const targetUser = dbUsers[targetId];

        if (!targetUser) {
            return bot.editMessageText(`❌ User dengan ID <code>${targetId}</code> tidak ditemukan.`, { chat_id: chatId, message_id: waitMsg.message_id, parse_mode: "HTML" });
        }

        let text = `🔍 <b>INFORMASI DETAIL USER</b>\n➖➖➖➖➖➖➖➖➖➖\n`;
        text += `🆔 <b>ID Telegram:</b> <code>${targetId}</code>\n`;
        text += `👤 <b>Username:</b> ${targetUser.username || "-"}\n`;
        text += `💰 <b>Saldo:</b> Rp ${(targetUser.saldo || 0).toLocaleString('id-ID')}\n\n`;

        if (targetUser.servers && targetUser.servers.length > 0) {
            text += `🟢 <b>SERVER AKTIF (${targetUser.servers.length} Panel):</b>\n`;
            
            targetUser.servers.forEach((srv, idx) => {
                // Menggunakan fungsi parseFlexibleDate agar mendukung format Indonesia
                const waktuSekarang = new Date();
                const waktuHabis = parseFlexibleDate(srv.expired_date);
                const selisihMS = waktuHabis - waktuSekarang;
                
                let statusExpired = "";
                if (!isNaN(waktuHabis.getTime())) {
                    if (selisihMS > 0) {
                        const hari = Math.floor(selisihMS / (1000 * 60 * 60 * 24));
                        const jam = Math.floor((selisihMS % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                        const menit = Math.floor((selisihMS % (1000 * 60 * 60)) / (1000 * 60));

                        if (hari > 0) {
                            statusExpired = `${hari} Hari ${jam} Jam`;
                        } else if (jam > 0) {
                            statusExpired = `${jam} Jam ${menit} Menit`;
                        } else {
                            statusExpired = `${menit} Menit lagi`;
                        }
                    } else {
                        statusExpired = "❌ SUDAH HABIS";
                    }
                } else {
                    statusExpired = "⚠️ Format Tgl Salah";
                }

                text += `\n<b>${idx + 1}. Username Panel: <code>${srv.username_panel}</code></b>\n`;
                text += `   ├ Paket: ${srv.paket}\n`;
                text += `   ├ Tgl Order: <code>${srv.order_date}</code>\n`;
                text += `   └ Expired: <b>${statusExpired}</b>\n`;
                text += `     (Tgl: <code>${srv.expired_date}</code>)\n`;
            });
        } else {
            text += `🔴 <b>SERVER AKTIF:</b> <i>Tidak ada server aktif.</i>\n`;
        }

        await bot.editMessageText(text, { chat_id: chatId, message_id: waitMsg.message_id, parse_mode: "HTML" });

    } catch (err) {
        console.error(err);
        bot.editMessageText("❌ Terjadi kesalahan saat memproses data.", { chat_id: chatId, message_id: waitMsg.message_id });
    }
});

// ====================================================
// FITUR ADMIN: ATUR STOK VPS
// Format: /setvps <RAM> <Harga> <Stok>
// ====================================================
// ====================================================
// FUNGSI BANTUAN UNTUK JEDA WAKTU BROADCAST (Taruh di luar, bebas dimana saja di bagian atas)
// ====================================================
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

// ====================================================
// COMMAND /setvps (UPDATE STOK & AUTO BROADCAST)
// ====================================================
// ====================================================
// COMMAND /setvps (UPDATE STOK & AUTO BROADCAST DENGAN PANDUAN)
// ====================================================
bot.onText(/^\/setvps(?:\s+(.*))?$/, async (msg, match) => {
    const chatId = msg.chat.id;
    if (String(chatId) !== String(settings.adminId)) return;

    const inputText = match[1];
    const botUsername = "@" + (await bot.getMe()).username; 

    // --- PANDUAN ---
    if (!inputText || inputText.trim().split(/\s+/).length < 3) {
        const panduanMsg = `<blockquote>⚠️ <b>FORMAT PERINTAH SALAH!</b>
━━━━━━━━━━━━━━━━━━

<b>Untuk VPS Biasa:</b>
<code>/setvps [Spek] [Harga] [Stok]</code>
Contoh: <code>/setvps 2GB 2 Core 15000 10</code>

<b>Untuk VPS Shared NAT:</b>
<code>/setvps shared [Spek] [Harga] [Stok]</code>
Contoh: <code>/setvps shared 1GB 10000 100</code>
</blockquote>`;
        return bot.sendMessage(chatId, panduanMsg, { parse_mode: "HTML" });
    }

    // --- DETEKSI TIPE ---
    let args = inputText.trim().split(/\s+/);
    let isShared = false;

    if (args[0].toLowerCase() === 'shared') {
        isShared = true;
        args.shift(); // hapus kata 'shared'
    }

    if (args.length < 3) {
        return bot.sendMessage(chatId, "<blockquote>⚠️ Format kurang lengkap!</blockquote>", { parse_mode: "HTML" });
    }

    const stok = parseInt(args.pop());
    const harga = parseInt(args.pop());
    const ram = args.join(" ").toUpperCase(); // biar konsisten 1GB

    if (isNaN(harga) || isNaN(stok)) {
        return bot.sendMessage(chatId, "<blockquote>⚠️ <b>Gagal:</b> Harga dan Stok harus angka!</blockquote>", { parse_mode: "HTML" });
    }

    // --- UPDATE DATABASE (SYNC KE INVENTORY) ---
    const store = getStore();
    let inventory = store.vps_inventory || { dedicated: {}, shared: {} };
    if (!inventory.dedicated) inventory.dedicated = {};
    if (!inventory.shared) inventory.shared = {};

    if (isShared) {
        inventory.shared[ram] = { stock: stok, price: harga };
        updateStore({ 
            vps_shared_ram: ram, 
            vps_shared_price: harga, 
            vps_shared_stock: stok,
            vps_inventory: inventory 
        });
    } else {
        inventory.dedicated[ram] = { stock: stok, price: harga };
        updateStore({ 
            vps_ram: ram, 
            vps_price: harga, 
            vps_stock: stok,
            vps_inventory: inventory
        });
    }

    const loadingMsg = await bot.sendMessage(chatId, `⏳ Stok ${isShared ? 'VPS SHARED' : 'VPS'} berhasil diupdate! Broadcast...`, { parse_mode: "Markdown" });

    // --- FORMAT BROADCAST ---
    let broadcastMsg = "";
    let callbackBtn = "";

    if (isShared) {
        broadcastMsg = `<blockquote>🖥 <b>RESTOCK VPS SHARED NAT</b>
━━━━━━━━━━━━━━━━━━

Spesifikasi terbaru telah tersedia!

—
1. <b>${ram}</b> | NAT VPS 
➥ Rp ${harga.toLocaleString('id-ID')} / Bulan

—
✅ <b>STOK TERSEDIA : ${stok} VPS</b>

${botUsername}
</blockquote>`;
        callbackBtn = "check_vps_stock"; // biar masuk ke menu yang lu mau tadi
    } else {
        broadcastMsg = `<blockquote>🖥 <b>RESTOCK CLOUD VPS</b>
━━━━━━━━━━━━━━━━━━

Spesifikasi VPS terbaru telah tersedia!

—
1. <b>${ram}</b> | High Performance NVMe
➥ Rp ${harga.toLocaleString('id-ID')} / Bulan

—
✅ <b>STOK TERSEDIA : ${stok} VPS</b>

${botUsername}
</blockquote>`;
        callbackBtn = "check_vps_stock";
    }

    const broadcastOptions = {
        parse_mode: "HTML",
        reply_markup: {
            inline_keyboard: [
                [{ text: isShared ? "🛒 Beli VPS Shared" : "🛒 Beli VPS Sekarang", callback_data: callbackBtn }]
            ]
        }
    };

    // --- BROADCAST ---
    const users = getUsers(); 
    const userIds = Array.isArray(users) ? users : Object.keys(users);
    
    let successCount = 0;
    let failCount = 0;

    for (const targetId of userIds) {
        try {
            await bot.sendMessage(targetId, broadcastMsg, broadcastOptions);
            successCount++;
        } catch (e) {
            failCount++;
        }
        await new Promise(r => setTimeout(r, 50));
    }

    await bot.deleteMessage(chatId, loadingMsg.message_id).catch(()=>{});
    return bot.sendMessage(chatId, `<blockquote>✅ <b>BROADCAST ${isShared ? 'VPS SHARED' : 'VPS'} SELESAI!</b>
━━━━━━━━━━━━━━━━━━
Jenis: ${isShared ? 'Shared' : 'Biasa'} - ${ram}
Berhasil: ${successCount} User
Gagal: ${failCount} User
</blockquote>`, { parse_mode: "HTML" });
});
// ====================================================
// FITUR ADMIN: LIST SEMUA USER (PAGINATION)
// Command: /users
// ====================================================
bot.onText(/^\/users/, async (msg) => {
    const chatId = msg.chat.id;
    if (String(chatId) !== String(settings.adminId)) return;
    
    // Panggil fungsi pembuat halaman (Halaman pertama = index 0)
    await renderUserPage(chatId, 0);
});
//Fungsi Fayu Pedia
async function getSMMServices() {
  try {
    const res = await axios.post(`${SMM_BASE}/services`, {
      api_id: settings.smm.apiId,   // WAJIB int
      api_key: settings.smm.apiKey, // WAJIB string
      action: 'services'
    });
    
    if (res.data.status === true) {
      return res.data.services;
    } else {
      console.log('SMM Error:', res.data.msg);
      return [];
    }
  } catch (err) {
    console.error('Gagal ambil services:', err.message);
    return [];
  }
}
// FUNGSI show Pet status
async function showPetStatus(chatId, pet, messageId = null) {
    // Kasih default biar ga undefined
    const nama = pet.name || pet.nama || 'Pet Kamu'
    const level = pet.level || 1
    const maxLevel = pet.maxLevel || 10
    const xp = pet.xp || 0
    const feedThisWeek = pet.feedThisWeek || 0

    const sisaXP = getRemainingXP({xp, maxLevel}) || 0
    const drinkFree = canDrinkFree(pet)? '✅ Gratis' : '❌ Besok'
    const drinkVoice = canDrinkVoice(pet)? '✅ VN 1x' : '❌ Besok'
    const feed = canFeed(pet)? `${2-feedThisWeek}x lagi` : 'Sabtu-Minggu'
    const imgUrl = getPetImage(pet) || 'https://via.placeholder.com/400x400.png?text=Pet'

    const halfLevel = Math.floor(maxLevel / 2)
    let fase = 'Bayi 🐣'
    if(level >= maxLevel) fase = 'Dewasa 👑'
    else if(level >= halfLevel) fase = 'Tumbuh 🌱'

    const caption = `<b>${nama}</b> - Lv ${level}/${maxLevel} ${fase}\nXP: ${xp}/10 | Sisa: ${sisaXP} XP\n🍗 Makan: ${feed}\n💧 Minum: ${drinkFree} | ${drinkVoice}\n\nKetik VN "peliharaan mau minum" +2 XP`

    const keyboard = {
        inline_keyboard: [
          [ 
          {text: '🥣 Kasih Makan', callback_data: 'feed_pet', style: "success"}, 
          {text: '🍶 Kasih Minum', callback_data: 'drink_pet', style: "success"}
          ],
          
            [{text: '🔄 Refresh', callback_data: 'menu_pet'}],
            [{text: '⬅️ Kembali', callback_data: 'back_to_main'}]
        ]
    }
if(messageId) {
    try {
        await bot.deleteMessage(chatId, messageId)
    } catch(e){}
}
await bot.sendPhoto(chatId, imgUrl, {
    caption: caption,
    parse_mode: 'HTML',
    reply_markup: keyboard
})

}

function getPets() {
  if(!fs.existsSync('./database/pets.json')) fs.writeFileSync('./database/pets.json', '{}')
  return JSON.parse(fs.readFileSync('./database/pets.json', 'utf8'))
}

function savePets(db) {
  fs.writeFileSync('./database/pets.json', JSON.stringify(db, null, 2))
}

function canDrinkFree(pet) {
  const today = new Date().toDateString()
  return pet.lastDrinkFree!== today
}
function canDrinkVoice(pet) {
  const today = new Date().toDateString()
  return pet.lastDrinkVoice!== today
}
function canFeed(pet) {
  const week = getWeekId()
  if(pet.weekId!== week) {
    pet.weekId = week
    pet.feedThisWeek = 0
  }
  return pet.feedThisWeek < 2
}

function startPetReminder() {
    console.log('[PET REMINDER] Aktif, cek tiap menit...')

    setInterval(async () => {
        const now = new Date()
        const hours = now.getHours()
        const minutes = now.getMinutes()

        // Jalan pas 05:00 WIB doang
        if (hours!== 5 || minutes!== 0) return

        console.log('[PET REMINDER] Jam 05.00! Mulai broadcast...')
        const today = new Date().toISOString().split('T')[0]
        const day = now.getDay() // 0=Minggu, 6=Sabtu
        const isWeekend = day === 0 || day === 6

        const dbUsers = getUsers()// ganti sesuai DB lu
        let sent = 0

        for (const userId in dbUsers) {
        const user = dbUsers[userId];
            if (!user.pet) continue
            if (user.stopReminder) continue // skip user yg udah silent

            const belumMinum = user.pet.lastDrink!== today
            const belumMakan = isWeekend && user.pet.lastFeed!== today

            // Skip kalo udah lengkap semua
            if (!belumMinum &&!belumMakan) continue

            let pesan = `🐾 <b>REMINDER PET</b> 🐾\n\n`
            pesan += `Hai majikan ${user.pet.name}!\n`
            pesan += `Udah jam 5 pagi nih, perut gue keroncongan 😭\n\n`

            if (belumMakan) pesan += `🍗 Makan: Belum dikasih. XP +2\n`
            else pesan += `🍗 Makan: Udah kenyang\n`

            if (belumMinum) pesan += `💧 Minum: Belum dikasih. XP +3\n`
            else pesan += `💧 Minum: Udah seger\n`

            pesan += `\nYuk kasih gue makan & minum~`

            const keyboard = {
                inline_keyboard: [
                    [{ text: '🐾 Buka Pet', callback_data: 'menu_pet', style: "success" }],
                    [{ text: '🔕 Silent Reminder Selamanya', callback_data: 'stop_reminder', style: "danger" }]
                ]
            }

            try {
                await bot.sendMessage(user.userId, pesan, {
                    parse_mode: 'HTML',
                    reply_markup: keyboard
                })
                sent++
                await new Promise(r => setTimeout(r, 100)) // anti spam
            } catch (e) {
                // user block bot, skip
            }
        }

        console.log(`[PET REMINDER] Selesai, terkirim ke ${sent} user`)
        await new Promise(r => setTimeout(r, 60000)) // delay 1 menit biar ga keulang
    }, 60000) // cek tiap 1 menit
}

// Jalanin pas bot start
startPetReminder()

// Logic minum dari VN
bot.on('voice', async (msg) => {
  if(!msg.voice) return
  if(!msg.text?.toLowerCase().includes('mau minum')) return

  const userId = msg.from.id
  const chatId = msg.chat.id
  const user = await getUserPet(userId)
  if(!user.pet) return bot.sendMessage(chatId, 'Kamu belum punya pet. Klik tombol "pet" buat adopsi dulu')

  const today = new Date().toDateString()
  let xpGain = 0
  let pesan = []

  // 1. Minum gratis harian +1 XP
  if(user.pet.lastDrinkFree !== today) {
    xpGain += 1
    user.pet.lastDrinkFree = today
    pesan.push('💧 Minum gratis +1 XP')
  }

  // 2. Minum dari VN +2 XP 
  if(user.pet.lastDrinkVoice !== today) {
    xpGain += 2
    user.pet.lastDrinkVoice = today
    pesan.push('🎤 VN +2 XP')
  } else {
    // Kalo VN udah dipake tapi gratis belum
    if(xpGain === 0) return bot.sendMessage(chatId, 'VN minum udah dipake hari ini. Besok lagi ya')
  }

  // Kalo sama sekali ga dapet XP
  if(xpGain === 0) return bot.sendMessage(chatId, 'Hari ini udah minum semua. Besok lagi ya')

  user.pet.xp += xpGain

  // Level up berkali-kali
  let levelUpMsg = ''
  while(user.pet.xp >= 10) {
    user.pet.level += 1
    user.pet.xp -= 10
    if(user.pet.level > user.pet.maxLevel) {
      user.pet.level = user.pet.maxLevel
      user.pet.xp = 0
      levelUpMsg = `\n👑 ${user.pet.name} udah max level!`
      break
    }
    levelUpMsg += `\n🎉 ${user.pet.name} naik ke Lv ${user.pet.level}!`
  }

  await savePet(userId, user.pet)
  await showPetStatus(chatId, user.pet)
  await bot.sendMessage(chatId, `${pesan.join(' + ')}\nTotal +${xpGain} XP${levelUpMsg}`)
})

function isWeekend() {
  const day = new Date().getDay() // 0=Minggu, 6=Sabtu
  return day === 0 || day === 6
}
bot.on('message', async (msg) => {
  const text = (msg.text || "").trim();
  // Dulu handler ini berhenti untuk semua teks yang bukan email, sehingga pencarian SMM,
  // password tugas, withdraw wallet/QRIS, dan /cancel di bawah tidak pernah jalan.
  if (!text && !msg.photo) return;
  if (text.startsWith("/") && text !== "/cancel") return;
  const userId = msg.from.id;
  const chatId = msg.chat.id;
  const lagiTugas = userState[userId] && ["waiting_email", "waiting_password"].includes(userState[userId].step);

  // HUBUNGKAN AKUN WEBSITE: hanya kalau teksnya email & user tidak sedang submit tugas freelance
  if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(text) && !lagiTugas) {

const res = await fetch(`https://boosteryuk.boosteryukid.workers.dev/api/telegram/link`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email: text, telegram_id: chatId })
  }).then(async r => {
    const txt = await r.text();
    try { return JSON.parse(txt); } catch { return { status: false, msg: txt.slice(0,200) }; }
  }).catch(()=>({status:false, msg:"Worker error"}));

  // FIX: support {status, msg} dan {ok, message} biar gak undefined
  const isOk = res.status === true || res.ok === true;
  const apiMsg = res.msg || res.message || "Unknown error";

  if (isOk) {
    bot.sendMessage(chatId, `✅ Berhasil! Akun berhasil di hubungkan silakan /start kembali`);
  } else {
    // kalau msg masih "Worker Active", ganti jadi pesan jelas
    if (apiMsg.includes("Worker Active")) {
      bot.sendMessage(chatId, `❌ Worker belum di-deploy. Cek Cloudflare Worker.`);
    } else {
      bot.sendMessage(chatId, `❌ ${apiMsg}`);
    }
  }
  return;
  }
  // 1. HANDLE SUBMIT TUGAS - paling atas biar tidak ke skip
// HANDLE SUBMIT TUGAS STEP 1: EMAIL
if (userState[userId] && userState[userId].step === 'waiting_email') {
  const email = text.trim();

  if (!email.includes('@gmail.com')) {
    return bot.sendMessage(chatId, 'Email harus menggunakan @gmail.com. Silakan kirim ulang.');
  }

  // Simpan email ke state, pindah ke step 2
  userState[userId].email = email;
  userState[userId].step = 'waiting_password';

  return bot.sendMessage(chatId,
    `<blockquote>🔒 LANGKAH 2</blockquote>\n` +
    `kirim password yang sesuai dengan aturan campaign ini.\n`, 
    { parse_mode: "HTML" }
  );
}

// HANDLE SUBMIT TUGAS STEP 2: PASSWORD
if (userState[userId] && userState[userId].step === 'waiting_password') {
  const password = text.trim();
  const campaignId = userState[userId].campaignId;
  const email = userState[userId].email;
  const campaign = campaigns.find(c => c.id === campaignId);

  if (!campaign) {
    delete userState[userId];
    return bot.sendMessage(chatId, 'Campaign tidak ditemukan. Kembali ke menu Freelance.');
  }

  // Validasi password
  if (password!== campaign.password) {
    return bot.sendMessage(chatId, 'Password salah. Silakan kirim ulang password yang benar.');
  }

  // Simpan ke file JSON - tanpa nama
  let tasks = [];
  if (fs.existsSync(FILE_TASK)) {
    tasks = JSON.parse(fs.readFileSync(FILE_TASK, 'utf8'));
  }

  const newTask = {
    userId: userId,
    username: msg.from.username || msg.from.first_name,
    task: campaign.name,
    email: email,
    password: password,
    saldoPending: campaign.bayaran,
    waktu: new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })
  };

  tasks.push(newTask);
  fs.writeFileSync(FILE_TASK, JSON.stringify(tasks, null, 2));

  // Kirim ke admin
  const adminText = `<blockquote>📥 TUGAS BARU MASUK</blockquote>\n` +
                    `<b>User:</b> ${newTask.username} <code>${userId}</code>\n\n` +
                    `<b>Tugas:</b> ${newTask.task}\n` +
                    `<b>Email:</b> <code>${email}</code>\n\n` +
                    `<b>Saldo Pending:</b> Rp${campaign.bayaran.toLocaleString("id-ID")}\n\n` +
                    `<b>Waktu:</b> ${newTask.waktu}`;

  const adminButtons = [
    [
      { text: "✅ Terima", callback_data: `approve_${userId}_${tasks.length - 1}` },
      { text: "❌ Tolak", callback_data: `reject_${userId}_${tasks.length - 1}` }
    ]
  ];

  await bot.sendMessage(owner, adminText, {
    parse_mode: "HTML",
    reply_markup: { inline_keyboard: adminButtons }
  });

  delete userState[userId]; // reset state
  return bot.sendMessage(chatId,
    `<blockquote>✅ TUGAS BERHASIL DIKIRIM</blockquote>\n` +
    `Email: ${email}\n` +
    `Reward Pending: Rp${campaign.bayaran.toLocaleString("id-ID")}\n` +
    `Tunggu verifikasi admin.`,
    { parse_mode: "HTML" }
  );
}

  // 2. HANDLE WITHDRAW WALLET
  if (userState[chatId] && userState[chatId].step === 'waiting_wallet' && text) {
    const walletAddress = text.trim();
    const dbUsers = getUsers();
    const saldoFreelance = dbUsers[chatId]?.saldoFreelance || 0;

    if (saldoFreelance <= 0) {
      delete userState[chatId];
      return bot.sendMessage(chatId, '<blockquote>Saldo Freelance Anda 0. Kerjakan tugas terlebih dahulu.</blockquote>', { parse_mode: 'HTML' });
    }

    const adminText = `<blockquote>💸 REQUEST WITHDRAW BARU</blockquote>\n` +
                      `<b>User:</b> ${msg.from.first_name} <code>${chatId}</code>\n` +
                      `<b>Metode:</b> Wallet\n` +
                      `<b>Saldo:</b> $${saldoFreelance.toFixed(3)}\n` +
                      `<b>Alamat:</b> <code>${walletAddress}</code>`;

    const adminButtons = [
      [
        { text: '✅ Done', callback_data: `withdraw_done_${chatId}` },
        { text: '❌ Tolak', callback_data: `withdraw_reject_${chatId}` }
      ]
    ];

    await bot.sendMessage(owner, adminText, {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: adminButtons }
    });

    delete userState[chatId];
    return bot.sendMessage(chatId, `<blockquote>Request withdraw $${saldoFreelance.toFixed(3)} ke wallet berhasil dikirim. Tunggu admin memproses.</blockquote>`, { parse_mode: 'HTML' });
  }

  // 3. HANDLE WITHDRAW QRIS
  if (userState[chatId] && userState[chatId].step === 'waiting_qris' && msg.photo) {
    const photoId = msg.photo[msg.photo.length - 1].file_id;
    const dbUsers = getUsers();
    const saldoFreelance = dbUsers[chatId]?.saldoFreelance || 0;

    if (saldoFreelance <= 0) {
      delete userState[chatId];
      return bot.sendMessage(chatId, '<blockquote>Saldo Freelance Anda 0. Kerjakan tugas terlebih dahulu.</blockquote>', { parse_mode: 'HTML' });
    }

    const adminCaption = `<blockquote>💸 REQUEST WITHDRAW BARU</blockquote>\n` +
                         `<b>User:</b> ${msg.from.first_name} <code>${chatId}</code>\n` +
                         `<b>Metode:</b> QRIS\n` +
                         `<b>Saldo:</b> $${saldoFreelance.toFixed(3)}`;

    const adminButtons = [
      [
        { text: '✅ Done', callback_data: `withdraw_done_${chatId}` },
        { text: '❌ Tolak', callback_data: `withdraw_reject_${chatId}` }
      ]
    ];

    await bot.sendPhoto(owner, photoId, {
      caption: adminCaption,
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: adminButtons }
    });

    delete userState[chatId];
    return bot.sendMessage(chatId, `<blockquote>Request withdraw $${saldoFreelance.toFixed(3)} melalui QRIS berhasil dikirim. Tunggu admin memproses.</blockquote>`, { parse_mode: 'HTML' });
  }
//pembatas
  
  // Command batal

  // 1. Command batal - cek paling atas
  if (text === '/cancel') {
    smmMode.delete(chatId);
    return bot.sendMessage(chatId, '❌ Mode Ditutup');
  }

  // 2. Keluar kalo user ga lagi mode cari kategori
  if (!smmMode.has(chatId)) return;
  if (!text || globalServices.length === 0) return;

  smmMode.delete(chatId); // hapus mode biar ga ke-trigger pas chat lain

  const msgLoading = await bot.sendMessage(chatId, '🔍 Mencari kategori...');

  // 3. Tampilkan kategori (field "category" dari Fayupedia) yang cocok dengan ketikan
  await bot.deleteMessage(chatId, msgLoading.message_id).catch(() => {});
  const adaHasil = await smmKirimKategori(chatId, text);
  if (!adaHasil) smmMode.add(chatId); // balikin mode biar user bisa ketik ulang
//pembatas
 
  // 4. HANDLE PET MAKAN - baru diproses jika bukan tugas/withdraw
  if (!text) return;
  if (text.toLowerCase()!== 'peliharaan makan') return;

  const user = await getUserPet(userId);
  if (!user.pet) return;

  if (!isWeekend()) {
    return bot.sendMessage(chatId, 'Pet hanya bisa makan pada hari Sabtu dan Minggu.');
  }
  if (!canFeed(user.pet)) {
    return bot.sendMessage(chatId, 'Minggu ini sudah 2 kali makan. Tunggu minggu depan.');
  }

  user.pet.xp += 5;
  user.pet.feedThisWeek += 1;
  user.pet.weekId = getWeekId();

  // Cek naik level berkali kali
  while (user.pet.xp >= 10) {
    user.pet.level += 1;
    user.pet.xp -= 10;
    if (user.pet.level > user.pet.maxLevel) {
      user.pet.level = user.pet.maxLevel;
      user.pet.xp = 0;
      break;
    }
    await bot.sendMessage(chatId, `🎉 ${user.pet.name} naik ke Level ${user.pet.level}!`);
  }

  await savePet(userId, user.pet);
  await showPetStatus(chatId, user.pet);
  await bot.sendMessage(chatId, `🍗 ${user.pet.name} kenyang! Mendapat tambahan 5 XP`);
});

// Fungsi bantuan untuk merender halaman User
async function renderUserPage(chatId, page, messageId = null) {
    const dbUsers = getUsers();
    const usersArray = Object.values(dbUsers); // Ubah object ke array agar bisa di-page
    const totalUsers = usersArray.length;
    const maxPerPage = 5;
    const totalPages = Math.ceil(totalUsers / maxPerPage);

    if (totalUsers === 0) {
        if (messageId) bot.deleteMessage(chatId, messageId).catch(()=>{});
        return bot.sendMessage(chatId, "⚠️ Belum ada user terdaftar di database.");
    }

    // Validasi batas halaman agar tidak error
    if (page < 0) page = 0;
    if (page >= totalPages) page = totalPages - 1;

    const startIdx = page * maxPerPage;
    const currentUsers = usersArray.slice(startIdx, startIdx + maxPerPage);

    let text = `👥 <b>DAFTAR PENGGUNA BOT</b>\n`;
    text += `<i>Halaman ${page + 1} dari ${totalPages} (Total: ${totalUsers} User)</i>\n➖➖➖➖➖➖➖➖➖➖\n\n`;

    currentUsers.forEach((u, i) => {
        const srvCount = u.servers ? u.servers.length : 0;
        text += `<b>${startIdx + i + 1}. ${u.username}</b>\n`;
        text += `   ├ ID: <code>${u.id}</code>\n`;
        text += `   └ Server Aktif: <b>${srvCount}</b>\n\n`;
    });

    // Buat Tombol Pagination Dinamis
    const navRow = [];
    if (page > 0) navRow.push({ text: "⬅️ Kembali", callback_data: `page_${page - 1}` });
    navRow.push({ text: "❌ Selesai", callback_data: `page_close` });
    if (page < totalPages - 1) navRow.push({ text: "Selanjutnya ➡️", callback_data: `page_${page + 1}` });

    const options = { parse_mode: "HTML", reply_markup: { inline_keyboard: [navRow] } };

    if (messageId) {
        await bot.editMessageText(text, { chat_id: chatId, message_id: messageId, ...options }).catch(()=>{});
    } else {
        await bot.sendMessage(chatId, text, options);
    }
}
// ====================================================
// /s&k (alias /snk): Syarat & Ketentuan, 2 halaman (Nokos, SMM Panel)
// Gambar = settings.panelImage, caption judul + blockquote, tombol halaman + Kembali ke Dashboard.
// Telegram tidak menganggap "&" bagian dari command, jadi /snk disediakan untuk menu command.
// ====================================================
const SNK_HALAMAN = [
`📜 <b>SYARAT DAN KETENTUAN ORDER NOKOS</b>

<blockquote><b>1. Shadow Ban (khusus nomor WhatsApp)</b>
Nomor WhatsApp dari nokos bisa terblokir dengan sendirinya (shadow ban) karena WhatsApp mendeteksi aktivitas tidak wajar pada device/IP yang dipakai saat mendaftar, misalnya VPN/proxy, emulator, sering ganti akun di satu device, atau langsung spam setelah daftar. Ini kebijakan WhatsApp dan di luar kendali bot.

<b>2. OTP belum diterima</b>
Kamu berhak membatalkan pesanan untuk memilih nomor lain atau saat berubah pikiran. Dana dikembalikan ke saldo akun.

<b>3. OTP sudah diterima</b>
Pesanan dinyatakan SELESAI dan tidak bisa dibatalkan/refund, termasuk jika nomor terkena banned setelahnya.</blockquote>`,
`📜 <b>SYARAT DAN KETENTUAN ORDER SMM PANEL</b>

<blockquote><b>1.</b> Bot tidak berafiliasi dengan Instagram, TikTok, YouTube, Facebook, maupun platform lain yang tersedia.

<b>2.</b> Semua kesalahan di luar pesanan (salah link, username diganti, akun dihapus/diblokir platform) bukan tanggung jawab bot.

<b>3. Wajib akun PUBLIC.</b> Jika tetap private, pesanan tidak akan masuk dan dinyatakan selesai. Jika beruntung status menjadi <b>Canceled</b>, artinya masih ada kesempatan order ulang dengan data yang benar / akun public.

<b>4. Khusus Instagram Followers:</b> wajib mematikan fitur <i>Laporan untuk ditinjau</i>.
Caranya: masuk ke Pengaturan → cari menu <b>Ikuti dan undang teman</b> → nonaktifkan <b>Laporan untuk ditinjau</b>.</blockquote>`
];
function snkMarkup(hal) {
    const nav = hal === 0
        ? [{ text: "Halaman Selanjutnya ➡️", callback_data: "snk_1" }]
        : [{ text: "⬅️ Halaman Sebelumnya", callback_data: "snk_0" }];
    return { inline_keyboard: [nav, [{ text: "🏠 Kembali ke Dashboard", callback_data: "back_to_main", style: "success" }]] };
}
bot.onText(/^\/(?:s&k|snk)(?:@\w+)?\s*$/i, async (msg) => {
    const chatId = msg.chat.id;
    try {
        await bot.sendPhoto(chatId, settings.panelImage, { caption: SNK_HALAMAN[0], parse_mode: "HTML", reply_markup: snkMarkup(0) });
    } catch (e) {
        await bot.sendMessage(chatId, SNK_HALAMAN[0], { parse_mode: "HTML", reply_markup: snkMarkup(0) }).catch(() => {});
    }
});
bot.on("callback_query", async (query) => {
    const data = query.data || "";
    if (!/^snk_[01]$/.test(data)) return;
    const hal = Number(data.slice(4));
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;
    await bot.answerCallbackQuery(query.id).catch(() => {});
    const opsi = { chat_id: chatId, message_id: messageId, parse_mode: "HTML", reply_markup: snkMarkup(hal) };
    if (query.message.photo) await bot.editMessageCaption(SNK_HALAMAN[hal], opsi).catch(() => {});
    else await bot.editMessageText(SNK_HALAMAN[hal], opsi).catch(() => {});
});

//NATVPS
bot.onText(/\/natvps/, async (msg) => {
  const chatId = msg.chat.id;
  const imageUrl = "https://zcxtbtleeeaeqeryiwea.supabase.co/storage/v1/object/public/video/cara-kerja-nat.png";
  
  const teks = `
🖥️ <b>APA ITU NAT VPS?</b>

<blockquote>
NAT VPS adalah VPS murah yang share IP Public dengan user lain.

Cara kerjanya kayak kos-kosan:

1. IP Public itu alamat gedung (1 IP dipakai rame-rame)
2. Port itu nomor kamar kamu (misal 1024, 2024, dll)
3. Akses VPS kamu via IP:PORT

Penggunaan untuk menjalankan Bot seperti bot WhatsApp, Telegram atau lainnya bisa langsung jalankan di VPS tanpa Panel Pterodactyl.

Penggunaan untuk Bisnis bisa langsung Add user di VPS tanpa Panel Pterodactyl.

✅ Cocok untuk: Bot, Hosting, Belajar Linux
❌ Tidak untuk: Game port default, IP Dedicated
❌ Dilarang Install Pterodactyl
</blockquote>
`;

  await bot.sendPhoto(chatId, imageUrl, {
    caption: teks,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "✅ Cek Ketersediaan", callback_data: "check_vps_stock", style: "success" }
        ]
      ]
    }
  });
});

// ====================================================
// FITUR ADMIN: AMBIL ID OS DARI HOSTVDS
// ====================================================
// ====================================================
// FITUR ADMIN: AMBIL ID OS DARI HOSTVDS (SUDAH DIPERBAIKI)
// ====================================================
bot.onText(/^\/getos/, async (msg) => {
    const chatId = msg.chat.id;
    if (String(chatId) !== String(settings.adminId)) return;

    const waitMsg = await bot.sendMessage(chatId, "⏳ <i>Login ke HostVDS dan mengambil data OS...</i>", { parse_mode: "HTML" });
    
    try {
        const hostvds = await getHostvdsToken();

        // ⚠️ INILAH PENYEBAB ERROR-NYA: Pastikan penulisan URL-nya 100% sama seperti ini
        const res = await axios.get(`${hostvds.computeUrl}/images`, {
            headers: { "X-Auth-Token": hostvds.token }
        });
        
        let text = "🖥 <b>DAFTAR ID OS HOSTVDS</b>\n\n";
        res.data.images.forEach(os => {
            text += `<b>${os.name}</b>\n<code>${os.id}</code>\n\n`;
        });
        
        bot.editMessageText(text, { chat_id: chatId, message_id: waitMsg.message_id, parse_mode: "HTML" });
    } catch (err) {
        console.error("ERROR /GETOS:", err.message);
        bot.editMessageText(`❌ Gagal mengambil OS:\n${err.message}`, { chat_id: chatId, message_id: waitMsg.message_id });
    }
});
// ====================================================
// FITUR ADMIN: AMBIL ID SPEK (FLAVOR) DARI HOSTVDS
// ====================================================
bot.onText(/^\/getspek/, async (msg) => {
    const chatId = msg.chat.id;
    console.log("Ada yang akses /getspek :", chatId);

    if (String(chatId) !== String(settings.adminId)) {
        bot.sendMessage(chatId, "❌ Akses Ditolak. Anda bukan Admin.");
        return;
    }

    bot.sendMessage(chatId, "⏳ <i>Mengambil data Spek dari HostVDS...</i>", { parse_mode: "HTML" });
    try {
        const res = await axios.get(`${settings.hostvds.baseUrl}/flavors/detail`, {
            headers: { "X-Auth-Token": settings.hostvds.token }
        });
        
        let text = "⚙️ <b>DAFTAR ID SPEK HOSTVDS</b>\n\n";
        res.data.flavors.forEach(f => {
            text += `<b>${f.name}</b> (RAM: ${f.ram}MB, CPU: ${f.vcpus})\nID: <code>${f.id}</code>\n\n`;
        });
        bot.sendMessage(chatId, text, { parse_mode: "HTML" });
    } catch (err) {
        console.error("API GETSPEK ERROR:", err.message);
        bot.sendMessage(chatId, `❌ Gagal mengambil Spek: ${err.message}\nCek Token HostVDS Anda di setting.js!`);
    }
});
// ====================================================
// WEBHOOK LISTENER UNTUK PAKASIR (AUTO DEPLOY)
// ====================================================
// ====================================================
// WEBHOOK LISTENER UNTUK PAKASIR (AUTO DEPLOY)
// ====================================================
app.post('/webhook', async (req, res) => {
    try {
        const dataWebhook = req.body;
        console.log("Webhook Pakasir:", JSON.stringify(dataWebhook));

        if (dataWebhook && dataWebhook.status === "completed") {
            const orderIdLunas = dataWebhook.order_id;
            
            for (const [chatId, session] of Object.entries(userSessions)) {
                if (session.orderId === orderIdLunas) {
                    console.log(`Order LUNAS ${orderIdLunas} untuk ${chatId} type ${session.type}`);
                    // Panggil 1 pintu aja, semua logic deposit/vps/panel/patungan/hourly ada di sini
                    await handlePaymentSuccess(chatId, session, orderIdLunas);
                    break;
                }
            }
        }
        res.status(200).send("OK");
    } catch (e) {
        console.log("Error webhook:", e.message);
        res.status(500).send("Error");
    }
});

const port = process.env.SERVER_PORT || 8080;
app.listen(port, () => {
    console.log(`Server Webhook berjalan pada port ${port}`);
});
//Kode Listener Vn Order - VERSI UPDATE
bot.on('voice', async (msg) => {
    const chatId = msg.chat.id;
    const user = msg.from;
    const { adminId, vnPromo } = require('./database/settings');

    try {
        // Respon Awal
        const waitMsg = await bot.sendMessage(chatId, "<blockquote>⏳ <i>Sedang memproses perintah suara...</i></blockquote>", { parse_mode: "HTML" });

        const fileLink = await bot.getFileLink(msg.voice.file_id);
        const rawText = await processVoiceToOrder(fileLink, chatId);

        // 1. NORMALISASI FONETIK - TAMBAH KATA PET
        let text = rawText.toLowerCase()
          .replace(/[.,]/g, "")
          .replace(/gebe|ge be|giga|gibi/g, "gb")
          .replace(/kris|keris|crhis|khris|qr|chris/g, "qris")
          .replace(/kripto|koin|coin/g, "crypto")
          .replace(/pake|pakek|bayar|pakai/g, "pakai")
          .replace(/stater|starter|start/g, "started")
          .replace(/satu/g, "1").replace(/dua/g, "2").replace(/enam/g, "6").replace(/delapan/g, "8")
          .replace(/unlimited|unlim|unli|only/g, "unlimited")
          .replace(/minom|minum|air putih|haus/g, "minum") // filter typo minum
          .replace(/peliharaan|pet|hewan/g, "pet"); // filter pet

        console.log(`[VN LOG] User ${chatId}: "${text}"`);

        // === DETEKSI PERINTAH MINUM PET ===
        const petKeywords = ['pet', 'minum', 'air', 'haus']
        const isPetCommand = petKeywords.some(k => text.includes(k)) && text.includes('pet') && text.includes('minum')

        if(isPetCommand) {
            await bot.deleteMessage(chatId, waitMsg.message_id).catch(()=>{})

            const userData = await getUserPet(chatId)
            if(!userData?.pet) {
                return bot.sendMessage(chatId,
                    `<blockquote>🐾 Kamu belum punya pet!\n\nKetik /pet buat adopsi bibit dulu, baru bisa kasih minum via suara~</blockquote>`,
                    {parse_mode: "HTML"}
                )
            }

            // Cek limit minum 2x/hari
            const today = new Date().toISOString().split('T')[0]
            const canFree = userData.pet.lastDrinkFree!== today
            const canVoice = userData.pet.lastDrinkVoice!== today

            if(!canFree &&!canVoice) {
                return bot.sendMessage(chatId,
                    `<blockquote>💧 Pet kamu udah minum 2x hari ini!\n\nBesok pagi jam 00:00 jatah reset lagi ya~</blockquote>`,
                    {parse_mode: "HTML"}
                )
            }

            // Kasih XP sesuai logic lu
            let xpGain = 0
            let pesan = []

            if(canFree) {
                xpGain += 1
                userData.pet.lastDrinkFree = today
                pesan.push('💧 Gratis +1 XP')
            }
            if(canVoice) {
                xpGain += 2
                userData.pet.lastDrinkVoice = today
                pesan.push('🎤 VN +2 XP')
            }

            userData.pet.xp += xpGain

            let levelUpMsg = ''
            while(userData.pet.xp >= 10) {
                userData.pet.level += 1
                userData.pet.xp -= 10
                if(userData.pet.level > userData.pet.maxLevel) {
                    userData.pet.level = userData.pet.maxLevel
                    userData.pet.xp = 0
                    levelUpMsg = `\n👑 ${userData.pet.name} udah max level!`
                    break
                }
                levelUpMsg += `\n🎉 ${userData.pet.name} naik ke Lv ${userData.pet.level}!`
            }

            await savePet(chatId, userData.pet)

            // LOG KE ADMIN KHUS PET
            const logPetToAdmin = async () => {
                try {
                    const adminCaption = `<blockquote>🐾 <b>LOG VOICE PET MINUM</b>\n\n` +
                                       `👤 <b>User:</b> ${user.first_name} (@${user.username || '-'})\n` +
                                       `📝 <b>STT:</b> <i>"${rawText.replace(/<|>/g, "")}"</i>\n` +
                                       `🐾 <b>Pet:</b> ${userData.pet.name} Lv${userData.pet.level}\n` +
                                       `💧 <b>XP:</b> +${xpGain} | ${pesan.join(' + ')}\n` +
                                       `📊 <b>Status:</b> Lv${userData.pet.level} XP${userData.pet.xp}/10</blockquote>`;

                    await bot.sendVoice(Number(adminId), msg.voice.file_id, {
                        caption: adminCaption,
                        parse_mode: "HTML"
                    });
                } catch (e) { console.error("❌ ERROR LOG PET:", e.message); }
            };
            logPetToAdmin();

            await showPetStatus(chatId, userData.pet)
            return bot.sendMessage(chatId,
                `${pesan.join(' + ')}\nTotal +${xpGain} XP${levelUpMsg}`,
                {parse_mode: "HTML"}
            )
        }
        // === END DETEKSI PET ===

        // LANJUT LOGIC ORDER PANEL LU - GA DIUBAH
        let paket = ""; let harga = 0; let type = "panel"; let method = ""; let methodLabel = ""; let usernameVoice = "";

        if (text.includes("1gb")) {
            paket = "Started 1GB"; harga = 2000;
        } else if (text.includes("2gb")) {
            paket = "Started 2GB"; harga = 3000;
        } else if (text.includes("6gb")) {
            paket = "Medium 6GB"; harga = 5000;
        } else if (text.includes("8gb")) {
            paket = "Medium 8GB"; harga = 9000;
        } else if (text.includes("unlimited") || text.includes("pro")) {
            paket = "PRO Unlimited"; harga = 10000;
        } else if (text.includes("vps") || text.includes("server")) {
            const store = getStore();
            paket = `VPS RAM ${store.vps_ram}`; harga = store.vps_price; type = "vps";
        }
        // Order lewat voice/teks ikut terkunci kalau menunya ditutup admin
        const menuOrderTutup = paket && bacaMenuTutup()[type === "vps" ? "vps" : "panel"];
        if (menuOrderTutup) return kirimInfoMenuTutup(chatId, type === "vps" ? "vps" : "panel");

        if (text.includes("saldo")) {
            method = "pay_via_saldo"; methodLabel = "Saldo Akun";
        } else if (text.includes("qris")) {
            method = "pay_qris_tripay"; methodLabel = "QRIS (Fast)";
        } else if (text.includes("crypto") || text.includes("kripto")) {
            method = "pay_crypto_heleket"; methodLabel = "Crypto";
        }

        const words = text.split(/\s+/);
        const userKeywords = ["username", "user", "nama"];
        const stopKeywords = ["pakai", "pake", "bayar", "saldo", "qris", "crypto", "kripto", "dengan", "via"];

        let userIndex = -1;
        for (let i = 0; i < words.length; i++) {
            if (userKeywords.includes(words[i])) { userIndex = i; break; }
        }

        if (userIndex!== -1) {
            let extractedWords = [];
            for (let i = userIndex + 1; i < words.length; i++) {
                if (stopKeywords.includes(words[i])) break;
                extractedWords.push(words[i]);
            }
            usernameVoice = extractedWords.join("").trim();
        }

        let hargaFinal = harga;
        let promoNotif = "";
        if (vnPromo.active && harga > 0) {
            hargaFinal = harga - vnPromo.discount;
            if (hargaFinal < 0) hargaFinal = 0;
            promoNotif = `\n\n✨ <b>PROMO VOICE NOTE:</b>\nAnda mendapatkan diskon <b>Rp ${vnPromo.discount.toLocaleString('id-ID')}</b> karena memesan melalui suara!`;
        }

        // LOG KE ADMIN ORDER
        const logToAdmin = async () => {
            try {
                const adminCaption = `<blockquote>📢 <b>LOG VOICE ORDER</b>\n\n` +
                                   `👤 <b>User:</b> ${user.first_name} (@${user.username || '-'})\n` +
                                   `📝 <b>Raw:</b> <i>"${rawText.replace(/<|>/g, "")}"</i>\n\n` +
                                   `📦 <b>Paket:</b> ${paket || "❌"}\n` +
                                   `👤 <b>User Panel:</b> ${usernameVoice || "❌"}\n` +
                                   `💳 <b>Payment:</b> ${methodLabel || "❌"}\n` +
                                   `💰 <b>Final:</b> Rp ${hargaFinal.toLocaleString('id-ID')}</blockquote>`;

                await bot.sendVoice(Number(adminId), msg.voice.file_id, {
                    caption: adminCaption,
                    parse_mode: "HTML"
                });
            } catch (e) { console.error("❌ ERROR LOG ADMIN:", e.message); }
        };
        logToAdmin();

        await bot.deleteMessage(chatId, waitMsg.message_id).catch(()=>{});

        if (paket && method && usernameVoice) {
            userSessions[chatId] = {
                type: type, paket: paket, harga: hargaFinal,
                username: usernameVoice, username_panel: usernameVoice,
                step: "awaiting_payment"
            };

            const hargaDisplay = vnPromo.active && harga > hargaFinal
              ? `<s>Rp ${harga.toLocaleString('id-ID')}</s> <b>Rp ${hargaFinal.toLocaleString('id-ID')}</b>`
                : `<b>Rp ${harga.toLocaleString('id-ID')}</b>`;

            const responseText = `<blockquote>🛍 <b>KONFIRMASI PESAN ANDA</b>\n\n` +
                                `📦 Produk: <b>${paket}</b>\n` +
                                `👤 Username: <code>${usernameVoice}</code>\n` +
                                `💳 Payment: <b>${methodLabel}</b>\n` +
                                `💸 Total: ${hargaDisplay}${promoNotif}\n\n` +
                                `<i>Silakan klik tombol di bawah untuk membayar:</i></blockquote>`;

            await bot.sendMessage(chatId, responseText, {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [[{ text: `✅ KONFIRMASI & BAYAR`, callback_data: method, style: "danger" }]]
                }
            });
        } else {
            let missingInfo = "";
            if (!paket) missingInfo += "- Paket (1gb/2gb/6gb/8gb/unlimited)\n";
            if (!usernameVoice) missingInfo += "- Username (Sebutkan kata 'Username')\n";
            if (!method) missingInfo += "- Metode (Saldo/Qris/Crypto)\n";

            const safeText = text.replace(/<|>/g, "");

            const errorText = `<blockquote>❓ <b>PERINTAH TIDAK LENGKAP</b>\n\n` +
                             `Saya mendengar: <i>"${safeText}"</i>\n\n` +
                             `<b>Data yang kurang:</b>\n${missingInfo}\n` +
                             `<b>Contoh:</b> <i>"Beli panel unli username budi bayar pakai qris"</i></blockquote>`;

            await bot.sendMessage(chatId, errorText, { parse_mode: "HTML" });
        }
    } catch (err) {
        console.error(err);
        bot.sendMessage(chatId, "<blockquote>❌ Gagal memproses suara. Pastikan suara terdengar jelas.</blockquote>", { parse_mode: "HTML" });
    }
});
//INI KODE LAMA HATI HATI

// ====================================================
//===================MENU CPANEL===≈====≈============//
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//

bot.on("message", async (msg) => {
    const chatId = msg.chat.id;
    const text = msg.text;
    const session = userSessions[chatId]; 
    if (!text || text.startsWith("/")) return;

// Di dalam bot.on('message', async (msg) => { ...
if (session && session.step === "input_hour") {
    const jam = parseInt(msg.text);
    if (isNaN(jam) || jam < 1 || jam > 24) return bot.sendMessage(chatId, "❌ Masukkan angka 1 sampai 24.");

    session.jam = jam;
    session.harga = jam * 500; // Rp 1.000 per jam
    session.paket = "Rental_" + jam + "H";
    session.username = "user" + Math.floor(Math.random() * 1000);
    
    const textKonfirmasi = `<blockquote>🎯 <b>KONFIRMASI RENTAL PANEL</b>\n\n⏳ Durasi: ${jam} Jam\n💰 Total Bayar: <b>Rp ${session.harga.toLocaleString()}</b>\n\nLanjut ke pembayaran?</blockquote>`;
    
    bot.sendMessage(chatId, textKonfirmasi, { 
        parse_mode: "HTML", 
        reply_markup: { inline_keyboard: [[{ text: "✅ Bayar Sekarang (QRIS Fast)", callback_data: "pay_qris_tripay", style: "danger" }]] }
    });
}
if (session && session.step === "input_patungan_slot") {
    const slot = parseInt(msg.text);
    if (isNaN(slot) || slot < 2) return bot.sendMessage(chatId, "❌ Minimal patungan adalah 2 orang.");
    
    session.slot = slot;
    session.harga = Math.ceil(session.hargaVps / slot); // HARGA DINAMIS (Bagi rata)
    session.role = "CEO";
    session.step = "pilih_durasi";
    
    kirimPilihanDurasi(chatId, session);
} 

else if (session && session.step === "input_patungan_nominal") {
    const nominal = parseInt(msg.text);
    if (isNaN(nominal) || nominal < 1000) return bot.sendMessage(chatId, "❌ Minimal kontribusi Rp 1.000.");
    
    session.harga = nominal; // HARGA DINAMIS (Sesuai input)
    session.role = "CEO";
    session.step = "pilih_durasi";
    
    kirimPilihanDurasi(chatId, session);
}

// Fungsi bantu tampilkan durasi
async function kirimPilihanDurasi(chatId, session) {
    const text = `<blockquote><b>⏳ PILIH DURASI PATUNGAN</b>\n\n` +
                 `Paket: ${session.paket.toUpperCase()}\n` +
                 `Mode: ${session.mode.toUpperCase()}\n` +
                 `Pembayaran Kamu: <b>Rp ${session.harga.toLocaleString()}</b>\n\n` +
                 `Berapa lama waktu pengumpulan dana? Jika lewat batas, saldo dikembalikan otomatis.</blockquote>`;
    
    const btn = [
        [{ text: "24 Jam", callback_data: "p_dur_24" }, { text: "2 Hari", callback_data: "p_dur_48" }],
        [{ text: "7 Hari (Maksimal)", callback_data: "p_dur_168" }]
    ];
    bot.sendMessage(chatId, text, { parse_mode: "HTML", reply_markup: { inline_keyboard: btn } });
}

// Di dalam bot.on('message', ...)
if (userSessions[chatId]?.step === "waiting_gacha_answer") {
    const userAnswer = parseInt(text);
    const correctAnswer = userSessions[chatId].answer;
    const dbUsers = getUsers();

    // Pastikan input adalah angka valid
    if (isNaN(userAnswer)) {
        return bot.sendMessage(chatId, "⚠️ Masukkan jawaban dalam bentuk <b>ANGKA</b> saja!", { parse_mode: "HTML" });
    }

    if (userAnswer === correctAnswer) {
        // JANGAN hapus session dulu di sini agar tombol SPIN tahu ini session yang valid
        userSessions[chatId].step = "gacha_ready";
        
        await bot.sendMessage(chatId, "✅ <b>JAWABAN BENAR!</b>\n\nSpin Gacha telah terbuka. Klik tombol di bawah untuk mulai spin!", {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: [[{ text: "🎰 SPIN SEKARANG", callback_data: "roll_gacha", style: "danger" }]] // FIX: Ganti ke callback_data
            }
        });
    } else {
        // Jika salah, kunci gacha hari ini agar tidak bisa coba-coba lagi
        if (!dbUsers[chatId]) dbUsers[chatId] = { id: chatId, username: msg.from.username };
        
        dbUsers[chatId].gachaLocked = true;
        saveUsers(dbUsers);
        
        // Hapus session karena sudah gagal
        delete userSessions[chatId];
        
        await bot.sendMessage(chatId, "⚠️ <b>JAWABAN SALAH!</b>\n\nKembali lagi besok ya!", { parse_mode: "HTML" });
    }
    return; // Keluar dari listener agar tidak mengecek perintah lain
}
// 2. Di dalam bot.on('message'), tangkap nominalnya
if (userSessions[chatId] && userSessions[chatId].step === "waiting_depo_amount") {
    const nominal = parseInt(text.replace(/\D/g, ''));
    
    if (isNaN(nominal) || nominal < 1000) {
    return bot.sendMessage(chatId, "❌ Minimal deposit Rp 1.000. Silakan masukkan angka kembali:");
}
if (nominal > 100000) { // Contoh maksimal 100k
    return bot.sendMessage(chatId, "❌ Maksimal deposit adalah Rp 100.000 dalam satu transaksi.");
}

    // Fee TIDAK dihitung bot. Tagihan QRIS = nominal, fee ditambahkan gateway (Tripay) sendiri.

    // SIMPAN DATA LENGKAP (Identik dengan format Panel/VPS)
    userSessions[chatId] = { 
        type: "deposit", 
        paket: `Deposit Saldo Rp ${nominal.toLocaleString()}`,
        username: msg.from && msg.from.username ? `@${msg.from.username}` : ((msg.from && msg.from.first_name) || "User"),
        amount: nominal,      // Nominal bersih yang jadi saldo
        harga: nominal,       // Harga dasar untuk Crypto
        orderId: `DEP${Date.now()}${chatId}`, // ID Unik
        step: "waiting_payment" 
    };

    const btnDepo = {
        reply_markup: {
            inline_keyboard: [
                [
                    { text: "⚡ 𝘘𝘳 𝘚𝘦𝘳𝘷𝘦r 1 (𝘍𝘢𝘴𝘵)", callback_data: "pay_qris_tripay", style: "success" },
                 //   { text: "🪙 Koin Crypto", callback_data: "pay_crypto_heleket", style: "danger" }
                ],
           //     [{ text: "𝘘𝘳 𝘚𝘦𝘳𝘷𝘦 r 2 (𝘔𝘢𝘪𝘯𝘵𝘦𝘯𝘢𝘯𝘤𝘦) ❌", callback_data: "qr_server_2", style: "danger" }],
                [{ text: "« Batal", callback_data: "menu_profil" }]
            ]
        }
    };

    const textKonfirmasi = `<blockquote>💳 <b>KONFIRMASI DEPOSIT</b>\n\n` +
                         `💰 Nominal: <b>Rp ${nominal.toLocaleString()}</b>\n` +
                         `💳 Fee: <i>dihitung otomatis oleh gateway saat QRIS dibuat</i>\n` +
                         `🆔 Order ID: <code>${userSessions[chatId].orderId}</code>\n\n` +
                         `<i>Silakan pilih metode pembayaran di bawah ini:</i></blockquote>`;

    await bot.sendMessage(chatId, textKonfirmasi, { parse_mode: "HTML", ...btnDepo });
    return;
}
    // ====================================================
    // PENANGKAP: TOKEN AUTO-DEPLOY WINGS
    // ====================================================
    if (userSessions[chatId] && userSessions[chatId].step === "awaiting_wings_token") {
        const tokenCommand = text.trim();
        const session = userSessions[chatId];

        // 1. Matikan Timer 1 Menit (Karena user berhasil kirim sebelum waktu habis)
        clearTimeout(session.timer);

        // 2. Validasi sederhana (Pastikan yang dikirim adalah script, bukan teks biasa)
        if (!tokenCommand.includes("curl") && !tokenCommand.includes("sudo") && !tokenCommand.includes("pterodactyl")) {
            return bot.sendMessage(chatId, "⚠️ <b>Kode tidak valid!</b> Harus berupa script Auto Deploy Pterodactyl. Coba paste ulang:", { parse_mode: "HTML" });
        }

        // 3. Hapus pesan token user dari Telegram agar rapi dan aman
        await bot.deleteMessage(chatId, msg.message_id).catch(()=>{});

        // 4. Jalankan Fungsi SSH Wings
        runWingsInstaller(chatId, session.ip, session.pass, tokenCommand);

        // 5. Hapus Sesi
        delete userSessions[chatId];
        return;
    }
    // ==========================================
    // Untuk Panel Pterodactyl
    // ==========================================
if (userSessions[chatId] && userSessions[chatId].step === "awaiting_username") {
    
    // 1. Ambil harga dari sesi (saldo tidak dicek di sini; dicek saat user memilih Bayar Pakai Saldo)
    const hargaPanel = userSessions[chatId].harga || 0;

    userSessions[chatId].username = text;
    userSessions[chatId].username_panel = text; // Agar sinkron dengan fungsi autoCreatePanel
    userSessions[chatId].step = "awaiting_payment";

    await bot.deleteMessage(chatId, userSessions[chatId].lastBotMessageId).catch(()=>{});
    await bot.deleteMessage(chatId, msg.message_id).catch(()=>{});

    // 2. Susun Tombol Pembayaran Lengkap (Saldo, QRIS, Crypto)
    const btnPayment = {
        reply_markup: {
            inline_keyboard: [
                // Baris 1: Tombol Bayar Pakai Saldo (Fitur Baru)
                [{ text: "💳 Bayar Pakai Saldo", callback_data: "pay_via_saldo", style: "success" }],
                
                // Baris 2: Metode Pembayaran Luar (QRIS & Crypto)
                [
                    { text: "⚡ 𝘘𝘳 𝘚𝘦𝘳𝘷𝘦r 1 (𝘍𝘢𝘴𝘵)", callback_data: "pay_qris_tripay", style: "success" },
                   // { text: "🪙 Koin Crypto", callback_data: "pay_crypto_heleket", style: "success" }
                ],
                
                // Baris 3: Server Maintenance & Batal
               [{ text: "𝘘𝘳 𝘚𝘦𝘳𝘷𝘦r 2 (𝘔𝘢𝘪𝘯𝘵𝘦𝘯𝘢𝘯𝘤𝘦) ❌", callback_data: "qr_server_2", style: "danger" }],
                [{ text: "« 𝘉𝘢𝘵𝘢𝘭𝘬𝘢𝘯 𝘖𝘳𝘥𝘦𝘳", callback_data: "back_to_main" }]
            ]
        }
    };

    // Gunakan teks asli kamu, tapi tambahkan info rincian Harga & Saldo
    const textFix = `<blockquote>✅ <b>Username Tersimpan:</b> <code>${text}</code>\n\n` +
                    `💰 <b>Harga Paket:</b> Rp ${hargaPanel.toLocaleString('id-ID')}\n\n` +
                    `Silakan pilih Metode Pembayaran untuk Panel:</blockquote>`;

    await bot.sendMessage(chatId, textFix, { parse_mode: "HTML", ...btnPayment });
    
    return; // WAJIB ADA INI
}

    
    // ==========================================
    // ---> TAMBAHKAN INI UNTUK VPS HOSTVDS <---
    // ==========================================
    
    if (userSessions[chatId] && (userSessions[chatId].step === "awaiting_vps_name" || userSessions[chatId].step === "awaiting_hostname")) {
    // FIX 1: Jangan block /link, /start dll
    if (msg.text && msg.text.startsWith('/')) return;

    const hargaVps = userSessions[chatId].harga;

    // Bersihkan inputan - FIX 2: pakai msg.text bukan text
    const cleanText = msg.text.replace(/[^a-zA-Z0-9-]/g, "").toLowerCase();
    if (cleanText.length < 3) {
        return bot.sendMessage(chatId, "❌ Hostname minimal 3 karakter, ketik ulang:");
    }

    // Simpan data ke sesi
    userSessions[chatId].username = cleanText; 
    userSessions[chatId].username_panel = cleanText;
    userSessions[chatId].hostname = cleanText; // FIX buat vps_shared
    
    await bot.deleteMessage(chatId, userSessions[chatId].lastBotMessageId).catch(()=>{});
    await bot.deleteMessage(chatId, msg.message_id).catch(()=>{});

    // --- CABANG KHUSUS VPS SHARED: MINTA PASSWORD CUSTOM DULU ---
    if (userSessions[chatId].type === "vps_shared") {
        userSessions[chatId].step = "awaiting_vps_password";
        
        const promptPass = await bot.sendMessage(chatId, `<blockquote>✅ <b>HOSTNAME TERSIMPAN</b>\n\n🌐 Hostname: <code>${cleanText}</code>\n📦 Produk: <b>${userSessions[chatId].paket}</b>\n\n🔑 Sekarang ketik <b>Password</b> yang kamu inginkan untuk VPS (min 8 karakter):</blockquote>`, { parse_mode: "HTML" });
        userSessions[chatId].lastBotMessageId = promptPass.message_id;
        return;
    }

    // --- UNTUK DEDICATED / PANEL / LAINNYA: LANGSUNG KE PAYMENT (UI TETAP) ---
    userSessions[chatId].step = "awaiting_payment";
    
    // 2. Susun Tombol Pembayaran (Lengkap: Saldo, QRIS, Crypto)
    const btnPayment = {
        reply_markup: {
            inline_keyboard: [
                // Baris 1: Bayar Pakai Saldo (Paling Cepat)
                [{ text: "💳 Bayar Pakai Saldo", callback_data: "pay_via_saldo", style: "success" }],
                
                // Baris 2: Metode Pembayaran Luar
                [
                   { text: "⚡ QRIS Server 1 (Fast)", callback_data: "pay_qris_tripay", style: "success" }
                   // { text: "💎 Crypto", callback_data: "pay_crypto_heleket", style: "success" }
             ],
                
                // Baris 3: Batal
                [{ text: "« 𝘉𝘢𝘵𝘢𝘭𝘬𝘢𝘯 𝘖𝘳𝘥𝘦𝘳", callback_data: "back_to_main" }]
            ]
        }
    };
    
    // Tampilkan rincian akhir sebelum bayar
    const textFinal = `<blockquote>✅ <b>HOSTNAME TERSIMPAN</b>\n\n` +
                    `🌐 Hostname: <code>${cleanText}</code>\n` +
                    `📦 Produk: <b>${userSessions[chatId].paket}</b>\n` +
                    `💰 Harga: <b>Rp ${hargaVps.toLocaleString('id-ID')}</b>\n\n` +
                    `<i>Silakan pilih metode pembayaran di bawah ini:</i></blockquote>`;

    await bot.sendMessage(chatId, textFinal, { parse_mode: "HTML", ...btnPayment });
    
    return; // WAJIB ADA INI
}

// --- TAMBAHAN BARU: STEP PASSWORD UNTUK VPS SHARED (TARUH TEPAT DI BAWAH BLOK DI ATAS) ---
if (userSessions[chatId] && userSessions[chatId].step === "awaiting_vps_password") {
    const customPassword = text.trim();
    if (!vpsNatPasswordValid(customPassword)) {
        return bot.sendMessage(chatId, "❌ Password 8-64 karakter, tanpa spasi dan tanpa tanda titik dua (:). Ketik ulang:");
    }
    // Cek konfigurasi server NAT SEBELUM user membayar (cegah dana masuk tapi VPS gagal dibuat)
    const natCfg = vpsNatConfig();
    if (!natCfg.lengkap) {
        vpsNatLaporBelumSiap(chatId, natCfg);
        delete userSessions[chatId];
        return bot.sendMessage(chatId, "<blockquote>🛠 <b>VPS NAT sedang maintenance</b>\n\nPesanan belum bisa diproses dan kamu belum ditagih. Admin sudah diberi tahu, silakan coba lagi nanti.</blockquote>", { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅️ Kembali", callback_data: "back_to_main", style: "success" }]] } });
    }

    const hargaVps = userSessions[chatId].harga;

    userSessions[chatId].password = customPassword;
    userSessions[chatId].step = "awaiting_payment";

    await bot.deleteMessage(chatId, userSessions[chatId].lastBotMessageId).catch(()=>{});
    await bot.deleteMessage(chatId, msg.message_id).catch(()=>{});

    const btnPayment = {
        reply_markup: {
            inline_keyboard: [
                [{ text: "💳 Bayar Pakai Saldo", callback_data: "pay_via_saldo", style: "success" }, 
                   { text: "⚡ QRIS Server 1 (Fast)", callback_data: "pay_qris_tripay", style: "success" }
                ],
                [{ text: "« 𝘉𝘢𝘵𝘢𝘭𝘬𝘢𝘯 𝘖𝘳𝘥𝘦𝘳", callback_data: "back_to_main" }]
            ]
        }
    };
    
    const textFinal = `<blockquote>✅ <b>HOSTNAME TERSIMPAN</b>\n\n` +
                    `🌐 Hostname: <code>${userSessions[chatId].hostname}</code>\n` +
                    `📦 Produk: <b>${userSessions[chatId].paket}</b>\n` +
                    `💰 Harga: <b>Rp ${hargaVps.toLocaleString('id-ID')}</b>\n\n` +
                    `<i>Silakan pilih metode pembayaran di bawah ini:</i></blockquote>`;

    await bot.sendMessage(chatId, textFinal, { parse_mode: "HTML", ...btnPayment });
    return;
}
    
        // ====================================================
    // PENANGKAP: BANTUAN / TICKET
    // ====================================================
    if (userSessions[chatId] && userSessions[chatId].step === "awaiting_bantuan") {
        const keluhan = text;
        
        await bot.deleteMessage(chatId, userSessions[chatId].lastBotMessageId).catch(()=>{});
        await bot.deleteMessage(chatId, msg.message_id).catch(()=>{});

        // 1. Kirim Laporan ke Admin
        const formatLaporan = `<blockquote>🚨 <b>TIKET BANTUAN BARU</b>\n━━━━━━━━━━━━━━━━━━\n👤 Dari: @${msg.from.username || msg.from.first_name} (ID: <code>${chatId}</code>)\n\n📝 <b>Pesan:</b>\n${keluhan}</blockquote>`;
        await bot.sendMessage(settings.adminId, formatLaporan, { 
            parse_mode: "HTML",
            // Tombol agar admin bisa langsung balas via bot (Opsional, gunakan fitur direct message yg sblmnya kita buat)
            reply_markup: { inline_keyboard: [[{ text: "Balas Pesan Ini", callback_data: `reply_ticket_${chatId}`, style: "success" }]] }
        });

        // 2. Balas ke User
        await bot.sendMessage(chatId, `<blockquote>✅ <b>Laporan Berhasil Terkirim!</b>\n━━━━━━━━━━━━━━━━━━\nAdmin kami akan segera membaca dan merespon pesan Anda. Mohon ditunggu ya!</blockquote>`, { parse_mode: "HTML" });
        
        delete userSessions[chatId];
        return;
    }

    // ====================================================
    // PENANGKAP: AUTO INSTALL VPS (IP -> PASS -> DOMAIN)
    // ====================================================
    if (session && session.type === "install") {
        
        await bot.deleteMessage(chatId, session.lastBotMessageId).catch(()=>{});
        await bot.deleteMessage(chatId, msg.message_id).catch(()=>{});

        // TAHAP 1: Menangkap IP
        if (session.step === "awaiting_install_ip") {
            session.vpsIp = text.trim();
            session.step = "awaiting_install_pass";
            
            const askPassMsg = await bot.sendMessage(chatId, `<blockquote>🔐 <b>TAHAP 2/3: PASSWORD ROOT</b>\n━━━━━━━━━━━━━━━━━━\n\nIP <code>${session.vpsIp}</code> tersimpan.\n\nSilakan ketik <b>Password Root</b> VPS Anda:\n<i>(Pesan Anda aman dan akan dihapus otomatis setelah instalasi)</i></blockquote>`, { parse_mode: "HTML" });
            session.lastBotMessageId = askPassMsg.message_id;
            return;
        }

        // TAHAP 2: Menangkap Password
        if (session.step === "awaiting_install_pass") {
            session.vpsPass = text.trim();
            session.step = "awaiting_install_domain";
            
            const askDomainMsg = await bot.sendMessage(chatId, `<blockquote>🌐 <b>TAHAP 3/3: SUBDOMAIN PTERODACTYL</b>\n━━━━━━━━━━━━━━━━━━\n\nSilakan ketik <b>Subdomain</b> yang sudah Anda pointing ke IP tersebut:\n<i>(Contoh: panel.serverku.com)</i></blockquote>`, { parse_mode: "HTML" });
            session.lastBotMessageId = askDomainMsg.message_id;
            return;
        }

        // TAHAP 3: Menangkap Domain & Eksekusi Instalasi
        if (session.step === "awaiting_install_domain") {
            session.vpsDomain = text.trim().toLowerCase();
            
            // Konfirmasi Akhir sebelum Bot bekerja keras
            const textReady = `<blockquote>⚙️ <b>MEMULAI PROSES INSTALASI</b>\n━━━━━━━━━━━━━━━━━━\n\n🖥 <b>IP:</b> <code>${session.vpsIp}</code>\n🌐 <b>Domain:</b> <code>${session.vpsDomain}</code>\n\n⏳ Bot sedang login ke VPS Anda dan melakukan instalasi Pterodactyl Panel + Wings + SSL.\n\n<i>Proses ini memakan waktu 5 hingga 15 menit. Bot akan mengirimkan pesan otomatis saat instalasi selesai. Silakan tinggalkan chat ini sejenak.</i></blockquote>`;
            
            await bot.sendMessage(chatId, textReady, { parse_mode: "HTML" });

            // ====================================================
            // DI SINI NANTI KITA TARUH FUNGSI SSH AUTO INSTALL-NYA
          runPterodactylInstaller(chatId, session.vpsIp, session.vpsPass, session.vpsDomain);
            // ====================================================
            
            delete userSessions[chatId]; // Hapus sesi agar user bisa pakai menu lain sambil nunggu
            return;
        }
    }

}); // <--- INI PENUTUP BOT.ON("MESSAGE")

//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
//fitur pm user
bot.onText(/^\/pm (\d+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const targetId = match[1];
    const pesanAdmin = match[2];

    // Cek apakah yang mengetik command ini adalah Admin
    if (String(chatId) !== String(settings.adminId)) {
        return bot.sendMessage(chatId, "⚠️ Akses Ditolak. Command ini khusus Admin.");
    }

    try {
        await bot.sendMessage(targetId, `<blockquote>📩 <b>Pesan dari Admin:</b>\n\n${pesanAdmin}</blockquote>`, { parse_mode: "HTML" });
        bot.sendMessage(chatId, `<blockquote>✅ <b>Sukses!</b> Pesan berhasil dikirim ke ID: <code>${targetId}</code></blockquote>`, { parse_mode: "HTML" });
    } catch (error) {
        bot.sendMessage(chatId, `❌ *Gagal!* Pastikan ID benar dan user belum memblokir bot.`);
    }
});
// ====================================================
// FITUR NOMOR OTP (HEROSMS - PROTOKOL SMS-ACTIVATE)
// ====================================================
// Alur: menu_otp -> pilih layanan -> pilih negara -> konfirmasi -> bayar saldo website
//       -> getNumberV2 -> pantau getStatus -> kirim kode ke user.
// Belum dapat kode lalu batal / waktu habis => saldo dikembalikan (refundSaldoReal).
// Konfigurasi di settings.herosms (apiKey, kurs, markup, layanan). Kalau apiKey kosong, menu tampil "belum aktif".
const OTP_DB_FILE = "./database/otp_orders.json";
const otpOrders = new Map();      // activationId -> order
const otpBeliLock = new Set();    // userId yang sedang proses beli (anti double klik)
const otpCache = {};              // { countries: {at, data}, services: {at, data} }

const OTP_LAYANAN_DEFAULT = [
    { code: "wa", name: "WhatsApp" }, { code: "tg", name: "Telegram" },
    { code: "ig", name: "Instagram" }, { code: "fb", name: "Facebook" },
    { code: "go", name: "Google/Gmail" }, { code: "lf", name: "TikTok" },
    { code: "tw", name: "Twitter/X" }, { code: "ds", name: "Discord" }
];

function otpCfg() {
    const c = settings.herosms || {};
    return {
        apiKey: String(c.apiKey || process.env.HEROSMS_API_KEY || "").trim(),
        baseUrl: c.baseUrl || "https://hero-sms.com/stubs/handler_api.php",
        kurs: Number(c.kurs) || 17000,                 // 1 USD (mata uang akun HeroSMS) = Rp
        markupPersen: c.markupPersen ?? 20,            // keuntungan %
        markupMin: c.markupMin ?? 1000,                // keuntungan minimal Rp
        maxNegara: c.maxNegara || 10,                  // jumlah negara termurah yang ditampilkan
        maxTingkat: c.maxTingkat || 20,                // jumlah pilihan harga per negara yang ditampilkan
        restUrl: c.restUrl,
        negaraUtama: c.negaraUtama ?? 6,               // 6 = Indonesia, selalu di paling atas
        intervalCek: c.intervalCek || 5000,
        layanan: Array.isArray(c.layanan) && c.layanan.length ? c.layanan : OTP_LAYANAN_DEFAULT
    };
}

async function heroApi(action, params = {}) {
    const cfg = otpCfg();
    if (!cfg.apiKey) throw new Error("API key HeroSMS belum diatur");
    const qs = new URLSearchParams({ api_key: cfg.apiKey, action, ...params });
    const r = await fetch(`${cfg.baseUrl}?${qs.toString()}`, { signal: AbortSignal.timeout(20000) });
    const txt = (await r.text()).trim();
    try { return JSON.parse(txt); } catch { return txt; }
}

// REST v1 (header Authorization: ApiKey ...). Dipakai untuk /activations/offers (peta harga -> stok).
async function heroRest(pathUrl, params = {}) {
    const cfg = otpCfg();
    if (!cfg.apiKey) throw new Error("API key HeroSMS belum diatur");
    const base = (cfg.restUrl || "https://hero-sms.com/api/v1").replace(/\/$/, "");
    const qs = new URLSearchParams(params).toString();
    const r = await fetch(`${base}${pathUrl}${qs ? "?" + qs : ""}`, {
        headers: { Authorization: `ApiKey ${cfg.apiKey}`, Accept: "application/json" },
        signal: AbortSignal.timeout(20000)
    });
    const txt = (await r.text()).trim();
    let data; try { data = JSON.parse(txt); } catch { data = txt; }
    if (!r.ok) {
        const kode = (data && data.title) || (r.status === 401 ? "BAD_KEY" : `HTTP_${r.status}`);
        throw new Error(kode);
    }
    return data;
}

// Kode error HeroSMS: teks ("NO_NUMBERS", "BAD_KEY") atau JSON { title, details, info }
function heroErr(res) {
    if (res && typeof res === "object" && !Array.isArray(res) && res.title) return res.title;
    if (typeof res === "string" && !/^(ACCESS_|STATUS_)/.test(res)) return res.split(":")[0] || "UNKNOWN";
    return null;
}

const OTP_ERR_TEKS = {
    NO_NUMBERS: "Nomor di harga ini sedang habis.",
    NO_BALANCE: "Stok server OTP sedang kosong. Admin sudah diberi tahu, coba lagi nanti.",
    BAD_KEY: "Konfigurasi server OTP bermasalah. Admin sudah diberi tahu.",
    NO_KEY: "Konfigurasi server OTP bermasalah. Admin sudah diberi tahu.",
    WRONG_MAX_PRICE: "Harga di tingkat ini baru saja berubah.",
    CHANNELS_LIMIT: "Server OTP sedang penuh. Coba lagi beberapa menit lagi.",
    BAD_SERVICE: "Layanan tidak valid.",
    BANNED: "Server OTP sedang dibatasi. Coba lagi nanti."
};

// Error konfigurasi (key salah, saldo HeroSMS habis) dilaporkan ke admin, maks 1x per 10 menit per kode
const otpLaporTerakhir = {};
function otpLaporAdmin(kode, detail) {
    if (!["BAD_KEY", "NO_KEY", "NO_BALANCE", "CHANNELS_LIMIT", "BANNED"].includes(kode)) return;
    if (Date.now() - (otpLaporTerakhir[kode] || 0) < 10 * 60 * 1000) return;
    otpLaporTerakhir[kode] = Date.now();
    const saran = kode === "BAD_KEY" || kode === "NO_KEY"
        ? "Cek settings.herosms.apiKey (salah salin / ada spasi / key sudah di-reset di hero-sms.com)."
        : "Cek saldo & akun di hero-sms.com.";
    bot.sendMessage(settings.adminId, `<blockquote>⚠️ <b>HEROSMS ERROR</b>: <code>${kode}</code>\n${String(detail || "").replace(/[<>&]/g, "")}\n\n${saran}</blockquote>`, { parse_mode: "HTML" }).catch(() => {});
}

const OTP_HABIS_DI_HARGA = ["NO_NUMBERS", "WRONG_MAX_PRICE"];
function otpTawarkanHargaLain(chatId, service, country, cost) {
    return otpTampilHarga(chatId, null, service, country, { kecuali: cost, pesan: `⚠️ Nomor di harga ${otpRp(otpHarga(cost))} sedang tidak tersedia. Pilih harga lain:` })
        .catch(e => console.log("[OTP] gagal tampil harga lain:", e.message));
}

function otpHarga(cost) {
    const cfg = otpCfg();
    const modal = Number(cost) * cfg.kurs;
    const jual = Math.max(modal * (1 + cfg.markupPersen / 100), modal + cfg.markupMin);
    return Math.ceil(jual / 100) * 100;
}

const otpRp = n => `Rp ${Number(n).toLocaleString("id-ID")}`;

async function otpCached(key, loader, ttlMs = 6 * 3600 * 1000) {
    const c = otpCache[key];
    if (c && Date.now() - c.at < ttlMs) return c.data;
    const data = await loader();
    otpCache[key] = { at: Date.now(), data };
    return data;
}

async function otpNegaraMap() {
    return otpCached("countries", async () => {
        const res = await heroApi("getCountries");
        if (heroErr(res)) throw new Error(heroErr(res));
        const list = Array.isArray(res) ? res : Object.values(res || {});
        const map = {};
        for (const c of list) if (c && c.id !== undefined) map[String(c.id)] = c.eng || c.rus || `Negara ${c.id}`;
        return map;
    });
}

async function otpDaftarLayanan() {
    return otpCached("services", async () => {
        const res = await heroApi("getServicesList", { lang: "en" });
        if (heroErr(res)) throw new Error(heroErr(res));
        return (res && res.services) || [];
    });
}

async function otpNamaLayanan(code) {
    const lokal = otpCfg().layanan.find(l => l.code === code);
    if (lokal) return lokal.name;
    const semua = await otpDaftarLayanan().catch(() => []);
    return (semua.find(s => s.code === code) || {}).name || code.toUpperCase();
}

// -> [{ country, cost, count }] untuk satu layanan (stok > 0)
async function otpHargaPerNegara(service, country) {
    const params = { service };
    if (country !== undefined) params.country = country;
    const res = await heroApi("getPrices", params);
    if (heroErr(res)) throw new Error(heroErr(res));
    const byCountry = Array.isArray(res) ? Object.assign({}, ...res) : (res || {});
    const out = [];
    for (const [cty, svcs] of Object.entries(byCountry)) {
        const p = svcs && svcs[service];
        if (p && Number(p.count) > 0) out.push({ country: cty, cost: Number(p.cost), count: Number(p.count) });
    }
    return out;
}

function otpSimpan() {
    try {
        const data = [...otpOrders.values()].map(({ timer, busy, ...o }) => o);
        fs.writeFileSync(OTP_DB_FILE, JSON.stringify(data, null, 2));
    } catch (e) { console.log("[OTP] gagal simpan:", e.message); }
}

// OTP dicek otomatis di latar belakang (otpMulaiPantau), jadi tidak ada tombol "Cek SMS".
function otpKeyboard(o) {
    if (o.codes.length && o.status === "WAIT") { // menunggu SMS berikutnya setelah "Minta SMS Lagi"
        return { inline_keyboard: [[{ text: "✅ Selesai", callback_data: `otp_f_${o.id}`, style: "success" }]] };
    }
    if (o.codes.length) {
        return { inline_keyboard: [
            [{ text: "🔁 Minta SMS Lagi", callback_data: `otp_r_${o.id}` }, { text: "✅ Selesai", callback_data: `otp_f_${o.id}`, style: "success" }]
        ] };
    }
    return { inline_keyboard: [[{ text: "❌ Batalkan", callback_data: `otp_x_${o.id}`, style: "danger" }]] };
}


async function otpUpdatePesan(o) {
    await otpGantiPesanOrder(o, "1");
}

// Kembalikan saldo sekali saja per order
async function otpRefund(o, alasan) {
    if (o.refunded) return;
    o.refunded = true;
    otpSimpan();
    const r = await refundSaldoReal(o.userId, o.harga, `Refund OTP ${o.id} - ${alasan}`).catch(e => ({ status: false, msg: e.message }));
    if (r && r.status) {
        bot.sendMessage(o.chatId, `↩️ Saldo ${otpRp(o.harga)} dikembalikan (${alasan}).\nSisa saldo: ${otpRp(r.new_balance || 0)}`).catch(() => {});
    } else {
        bot.sendMessage(o.chatId, `⚠️ Refund otomatis gagal. Admin akan memproses manual. ID: ${o.id}`).catch(() => {});
        bot.sendMessage(settings.adminId, `<blockquote>⚠️ <b>REFUND OTP GAGAL</b>\n🆔 User: <code>${o.userId}</code>\n🧾 Aktivasi: <code>${o.id}</code>\n💵 ${otpRp(o.harga)}\n❗ ${(r && (r.msg || r.message)) || "-"}</blockquote>`, { parse_mode: "HTML" }).catch(() => {});
    }
}

function otpSelesai(o, status) {
    clearInterval(o.timer);
    o.status = status;
    otpOrders.delete(o.id);
    otpSimpan();
}

// Satu putaran cek status, dipanggil otomatis oleh timer (otpMulaiPantau). Handler otp_k_ hanya untuk pesan lama.
async function otpCekStatus(o) {
    if (o.busy || !otpOrders.has(o.id)) return;
    o.busy = true;
    try {
        if (Date.now() > o.endTime) {
            if (o.codes.length) {
                await heroApi("setStatus", { id: o.id, status: 6 }).catch(() => {});
                otpSelesai(o, "DONE");
            } else {
                await heroApi("setStatus", { id: o.id, status: 8 }).catch(() => {});
                otpSelesai(o, "EXPIRED");
                await otpGantiPesanOrder(o, "1", { akhir: "⌛ <b>Waktu habis, SMS tidak masuk.</b>", markup: otpTombolPesanLagi(`otp_n_${o.service}_${o.country}`) });
                await otpRefund(o, "SMS tidak masuk");
            }
            return;
        }

        const res = await heroApi("getStatus", { id: o.id });
        if (typeof res !== "string") return;

        if (res.startsWith("STATUS_OK:")) {
            const kode = res.slice("STATUS_OK:".length);
            if (!o.codes.includes(kode)) {
                o.codes.push(kode);
                o.status = "CODE";
                clearInterval(o.timer); // berhenti sampai user minta SMS lagi
                otpSimpan();
                await otpUpdatePesan(o);
                bot.sendMessage(o.chatId, `🔑 Kode OTP ${o.serviceName}: <code>${kode}</code>`, { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "📋 Salin Kode OTP", copy_text: { text: String(kode) } }]] } }).catch(() => {});
                await otpKirimSukses(o, "1");
                otpSimpan();
            }
        } else if (res === "STATUS_CANCEL") {
            otpSelesai(o, "CANCEL");
            if (!o.codes.length) {
                await otpGantiPesanOrder(o, "1", { akhir: "❌ <b>Aktivasi dibatalkan.</b>", markup: otpTombolPesanLagi(`otp_n_${o.service}_${o.country}`) });
                await otpRefund(o, "aktivasi dibatalkan");
            }
        }
        // STATUS_WAIT_CODE / STATUS_WAIT_RETRY / STATUS_WAIT_RESEND: tunggu putaran berikutnya
    } catch (e) {
        console.log(`[OTP] cek ${o.id} gagal:`, e.message);
    } finally {
        o.busy = false;
    }
}

function otpMulaiPantau(o) {
    clearInterval(o.timer);
    o.timer = setInterval(() => otpCekStatus(o), otpCfg().intervalCek);
    setTimeout(() => otpCekStatus(o), 2000); // cek pertama lebih cepat
}

// Lanjutkan order yang masih jalan setelah bot restart
try {
    if (fs.existsSync(OTP_DB_FILE)) {
        for (const o of JSON.parse(fs.readFileSync(OTP_DB_FILE, "utf8")) || []) {
            otpOrders.set(o.id, o);
            if (o.status === "WAIT") otpMulaiPantau(o);
        }
    }
} catch (e) { console.log("[OTP] gagal memuat order:", e.message); }

async function otpTampilMenu(chatId, messageId) {
    const cfg = otpCfg();
    if (!cfg.apiKey) {
        return bot.sendMessage(chatId, "<blockquote>📱 <b>NOMOR OTP</b>\n\nFitur ini segera hadir. Pantau terus ya!</blockquote>", {
            parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅️ Kembali", callback_data: "back_to_main" }]] }
        });
    }
    const tombol = cfg.layanan.map(l => ({ text: l.name, callback_data: `otp_s_${l.code}` }));
    const baris = [];
    for (let i = 0; i < tombol.length; i += 2) baris.push(tombol.slice(i, i + 2));
    baris.push([{ text: "🔎 Cari Layanan Lain", callback_data: "otp_cari", style: "primary" }, { text: "📜 Pesanan Aktif", callback_data: "otp_aktif", style: "primary" }]);
    baris.push([{ text: "⬅️ Kembali", callback_data: "back_to_main" }]);

    const teks = `<blockquote>📱 <b>NOMOR OTP / VERIFIKASI</b>\n━━━━━━━━━━━━━━━━━━\n` +
        `Nomor virtual untuk menerima kode verifikasi (WhatsApp, Telegram, dll).\n\n` +
        `1️⃣ Pilih layanan\n2️⃣ Ketik nama negara\n3️⃣ Pilih harga (termurah → termahal, stok terlihat)\n4️⃣ Bayar QRIS 1 atau saldo\n5️⃣ Kode OTP dikirim otomatis\n\n` +
        `<i>SMS tidak masuk? Batalkan, dana kembali ke saldo akun.</i></blockquote>`;
    if (messageId) await bot.deleteMessage(chatId, messageId).catch(() => {});
    return bot.sendMessage(chatId, teks, { parse_mode: "HTML", reply_markup: { inline_keyboard: baris } });
}

// Nama negara versi Indonesia -> kata kunci bahasa Inggris di getCountries
const OTP_ALIAS_NEGARA = {
    amerika: "usa", "amerika serikat": "usa", as: "usa", inggris: "united kingdom", rusia: "russia",
    filipina: "philippines", brasil: "brazil", belanda: "netherlands", jerman: "germany", prancis: "france",
    perancis: "france", jepang: "japan", korea: "south korea", "korea selatan": "south korea", tiongkok: "china",
    cina: "china", arab: "saudi arabia", "arab saudi": "saudi arabia", mesir: "egypt", turki: "turkey",
    spanyol: "spain", italia: "italy", kamboja: "cambodia", myanmar: "myanmar", "hong kong": "hong kong"
};

function otpCariNegara(peta, ketik) {
    const k = String(ketik || "").trim().toLowerCase();
    if (!k) return [];
    const kunci = OTP_ALIAS_NEGARA[k] || k;
    const semua = Object.entries(peta).map(([id, nama]) => ({ id, nama }));
    const persis = semua.filter(n => n.nama.toLowerCase() === kunci);
    if (persis.length) return persis;
    return semua.filter(n => n.nama.toLowerCase().includes(kunci)).slice(0, 10);
}

// Pilihan harga 1 negara: [{ cost, harga, stok }] urut termurah -> termahal (semua tingkat yang ada stoknya).
// Sumber (berurutan):
//  1. REST GET /activations/offers/sms -> data[service][country].map = { "harga": stok } (resmi, "Price -> quantity")
//  2. getTopCountriesByService&freePrice=true -> physicalPriceMap (deprecated)
//  3. getPrices -> 1 harga
async function otpTingkatHarga(service, country) {
    const tambah = (arr, c, n) => { if (Number(c) > 0 && Number(n) > 0) arr.push({ cost: Number(c), stok: Number(n) }); };
    let baris = [];
    let sumber = "";
    try {
        const res = await heroRest("/activations/offers/sms", { services: service, countries: String(country) });
        const o = res && res.data && res.data[service] && res.data[service][String(country)];
        if (o) {
            for (const [c, n] of Object.entries(o.map || {})) tambah(baris, c, n);
            if (!baris.length) { // peta per operator digabung
                const gab = {};
                for (const op of Object.values(o.operators || {})) for (const [c, n] of Object.entries(op.map || {})) gab[c] = (gab[c] || 0) + Number(n);
                for (const [c, n] of Object.entries(gab)) tambah(baris, c, n);
            }
            if (!baris.length && o.prices && o.counts) tambah(baris, o.prices.default, o.counts.defaultPrice || o.counts.total);
            if (baris.length) sumber = "offers";
        }
    } catch (e) {
        if (["BAD_KEY", "NO_KEY"].includes(e.message)) throw e;
        console.log("[OTP] offers gagal, pakai cadangan:", e.message);
    }
    if (!baris.length) {
        try {
            const res = await heroApi("getTopCountriesByService", { service, freePrice: "true" });
            if (heroErr(res)) throw new Error(heroErr(res));
            let list = Array.isArray(res) ? res : Object.values(res || {});
            if (list.length && !("country" in list[0]) && list[0][service]) list = list[0][service];
            const row = list.find(r => String(r.country) === String(country));
            if (row) {
                for (const [c, n] of Object.entries(row.physicalPriceMap || row.priceMap || {})) tambah(baris, c, n);
                if (!baris.length) tambah(baris, row.price, row.count);
            }
            if (baris.length) sumber = "top";
        } catch (e) {
            if (["BAD_KEY", "NO_KEY"].includes(e.message)) throw e;
        }
    }
    if (!baris.length) {
        const p = (await otpHargaPerNegara(service, country)).find(h => String(h.country) === String(country));
        if (p) { tambah(baris, p.cost, p.count); sumber = "prices"; }
    }
    // Gabungkan tingkat yang harga jualnya sama setelah markup & pembulatan.
    // cost tertinggi dipakai sebagai maxPrice supaya semua stok di harga jual itu bisa terbeli.
    const perRp = new Map();
    for (const b of baris) {
        const harga = otpHarga(b.cost);
        const ada = perRp.get(harga);
        if (ada) { ada.stok += b.stok; ada.cost = Math.max(ada.cost, b.cost); }
        else perRp.set(harga, { cost: b.cost, harga, stok: b.stok, sumber });
    }
    return [...perRp.values()].sort((a, b) => a.harga - b.harga).slice(0, otpCfg().maxTingkat);
}

const otpStok = n => Number(n).toLocaleString("id-ID");

// Kirim rich message (tabel), jatuh ke HTML biasa kalau sendRichMessage ditolak
async function otpKirimRich(chatId, judul, info, extraHtml, rows, catatan) {
    const esc = t => String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    const rich = `<h3>${esc(judul)}</h3>\n<table bordered striped>\n` +
        info.map(([k, v]) => `  <tr><td><b>${esc(k)}</b></td><td>${v}</td></tr>`).join("\n") +
        `\n</table>\n${extraHtml || ""}${catatan ? `\n<p><i>${esc(catatan)}</i></p>` : ""}`;
    try {
        return await sendRichMessage(chatId, rich, { reply_markup: { inline_keyboard: rows } });
    } catch (e) {
        const biasa = `<blockquote><b>${esc(judul)}</b>\n━━━━━━━━━━━━━━━━━━\n` +
            info.map(([k, v]) => `${esc(k)}: ${v}`).join("\n") + (catatan ? `\n\n<i>${esc(catatan)}</i>` : "") + `</blockquote>`;
        return bot.sendMessage(chatId, biasa, { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } });
    }
}

async function otpMintaNegara(chatId, messageId, service) {
    const nama = await otpNamaLayanan(service);
    userSessions[chatId] = { type: "otp", step: "otp_negara", service };
    if (messageId) await bot.deleteMessage(chatId, messageId).catch(() => {});
    return bot.sendMessage(chatId, `<blockquote>🌍 <b>${nama}</b>\n\nKetik nama negara nomor yang kamu mau.\nContoh: <code>indonesia</code>, <code>malaysia</code>, <code>amerika</code></blockquote>`, {
        parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅️ Ganti Layanan", callback_data: "menu_otp" }]] }
    });
}

// opsi.kecuali = cost yang baru gagal dibeli (disembunyikan), opsi.pesan = keterangan di atas daftar
async function otpTampilHarga(chatId, messageId, service, country, opsi = {}) {
    const [semuaTingkat, negara, nama] = await Promise.all([otpTingkatHarga(service, country), otpNegaraMap(), otpNamaLayanan(service)]);
    const tingkat = opsi.kecuali ? semuaTingkat.filter(t => Math.abs(t.cost - opsi.kecuali) > 1e-9 && t.harga !== otpHarga(opsi.kecuali)) : semuaTingkat;
    if (messageId) await bot.deleteMessage(chatId, messageId).catch(() => {});
    const namaNegara = negara[country] || `Negara ${country}`;
    if (!tingkat.length) {
        userSessions[chatId] = { type: "otp", step: "otp_negara", service };
        return bot.sendMessage(chatId, `<blockquote>😔 Stok <b>${nama}</b> untuk <b>${namaNegara}</b> sedang kosong.\nKetik nama negara lain:</blockquote>`, {
            parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅️ Ganti Layanan", callback_data: "menu_otp" }]] }
        });
    }
    const totalStok = tingkat.reduce((s, t) => s + t.stok, 0);
    const tabel = `<table bordered striped compact>\n  <tr><th>Pilihan</th><th>Harga</th><th>Stok</th></tr>\n` +
        tingkat.map((t, i) => `  <tr><td>${i + 1}</td><td>${otpRp(t.harga)}</td><td>${otpStok(t.stok)}</td></tr>`).join("\n") + `\n</table>`;
    const rows = tingkat.map((t, i) => [{ text: `${i + 1}. ${otpRp(t.harga)} • stok ${otpStok(t.stok)}`, callback_data: `otp_t_${service}_${country}_${t.cost}` }]);
    rows.push([{ text: "🌍 Ganti Negara", callback_data: `otp_s_${service}` }, { text: "⬅️ Ganti Layanan", callback_data: "menu_otp" }]);
    return otpKirimRich(chatId, "💰 PILIH HARGA", [
        ["Layanan", nama], ["Negara", namaNegara], ["Total Stok", otpStok(totalStok)]
    ], `${opsi.pesan ? `<p><b>${opsi.pesan}</b></p>\n` : ""}<p>Urut dari termurah. Kalau harga termurah habis, pilih harga berikutnya.</p>\n${tabel}`, rows);
}

async function otpKonfirmasi(chatId, messageId, userId, service, country, cost) {
    const [tingkat, negara, nama] = await Promise.all([
        otpTingkatHarga(service, country), otpNegaraMap(), otpNamaLayanan(service)
    ]);
    const t = tingkat.find(x => Math.abs(x.cost - cost) < 1e-9) || tingkat.find(x => otpHarga(x.cost) === otpHarga(cost));
    if (messageId) await bot.deleteMessage(chatId, messageId).catch(() => {});
    if (!t) {
        return bot.sendMessage(chatId, "<blockquote>😔 Harga ini baru saja habis. Silakan pilih harga lain.</blockquote>", {
            parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅️ Pilihan Harga", callback_data: `otp_n_${service}_${country}` }]] }
        });
    }
    const rows = [[{ text: "⚡ Bayar QRIS 1 (Fast)", callback_data: `otp_q_${service}_${country}_${t.cost}`, style: "success" }]];
    rows.push([{ text: "💳 Bayar Pakai Saldo", callback_data: `otp_b_${service}_${country}_${t.cost}`, style: "primary" }]);
    rows.push([{ text: "⬅️ Pilihan Harga", callback_data: `otp_n_${service}_${country}` }]);
    return otpKirimRich(chatId, "🧾 KONFIRMASI ORDER OTP", [
        ["Layanan", nama], ["Negara", negara[country] || country], ["Stok", otpStok(t.stok)],
        ["Harga", `<b>${otpRp(t.harga)}</b>`]
    ], "", rows, "Pilih metode pembayaran. Nomor dibuat otomatis setelah pembayaran berhasil.");
}

// Beli nomor ke HeroSMS & buat order. Dipakai jalur saldo & jalur QRIS 1 (handlePaymentSuccess).
// Lempar Error(kode) kalau gagal; pemanggil yang mengembalikan dana.
async function otpAmbilNomor({ userId, chatId, service, country, cost, harga, username }) {
    const res = await heroApi("getNumberV2", { service, country, maxPrice: cost });
    const err = heroErr(res);
    if (err || !res || !res.activationId) {
        const kode = err || "UNKNOWN";
        otpLaporAdmin(kode, res && res.details);
        const e = new Error(kode);
        e.teksUser = OTP_ERR_TEKS[kode] || `Gagal mengambil nomor (${kode}).`;
        throw e;
    }
    const negara = await otpNegaraMap().catch(() => ({}));
    const o = {
        id: String(res.activationId),
        userId, chatId,
        phone: String(res.phoneNumber),
        service, serviceName: await otpNamaLayanan(service),
        country: String(country), countryName: negara[country] || String(country),
        harga, cost: Number(res.activationCost) || cost,
        endTime: Date.parse(res.activationEndTime) || Date.now() + 20 * 60 * 1000,
        codes: [], status: "WAIT", refunded: false, messageId: null, username: username || "User", incomeLogged: false
    };
    o.messageId = await otpKirimPesanOrder(o, "1");
    otpOrders.set(o.id, o);
    otpSimpan();
    otpMulaiPantau(o);
    // Log income admin baru dikirim setelah OTP diterima (otpKirimSukses)
    return o;
}

async function otpBeliSaldo(query, service, country, cost) {
    const userId = query.from.id;
    const chatId = query.message.chat.id;
    if (otpBeliLock.has(userId)) return bot.answerCallbackQuery(query.id, { text: "⏳ Pesanan sebelumnya masih diproses...", show_alert: true });
    otpBeliLock.add(userId);
    const harga = otpHarga(cost); // harga jual selalu dihitung dari modal yang dikunci sebagai maxPrice
    let dipotong = 0;
    try {
        await bot.answerCallbackQuery(query.id, { text: "Memproses..." }).catch(() => {});
        const potong = await potongSaldoReal(userId, harga, `Order OTP ${service}/${country}`);
        if (!potong || !potong.status) {
            return bot.sendMessage(chatId, `❌ Pembayaran saldo gagal: ${(potong && (potong.msg || potong.message)) || "saldo tidak cukup"}\n💰 Harga: ${otpRp(harga)}\n\nBayar langsung pakai QRIS, atau top up saldo dulu.`, {
                reply_markup: { inline_keyboard: [
                    [{ text: "⚡ Bayar QRIS 1 (Fast)", callback_data: `otp_q_${service}_${country}_${cost}`, style: "success" }],
                    [{ text: "➕ Top Up Saldo", callback_data: "menu_deposit", style: "success" }]
                ] }
            });
        }
        dipotong = harga;
        await bot.deleteMessage(chatId, query.message.message_id).catch(() => {});
        await otpAmbilNomor({ userId, chatId, service, country, cost, harga, username: otpNamaUser(query.from) });
        dipotong = 0; // sudah jadi order; refund selanjutnya lewat otpRefund
    } catch (e) {
        console.log("[OTP] beli gagal:", e.message);
        if (dipotong) {
            const r = await refundSaldoReal(userId, dipotong, `Refund OTP gagal beli - ${e.message}`).catch(() => ({ status: false }));
            if (!r || !r.status) bot.sendMessage(settings.adminId, `⚠️ REFUND OTP GAGAL user ${userId} ${otpRp(dipotong)}: ${e.message}`).catch(() => {});
            await bot.sendMessage(chatId, `❌ ${e.teksUser || "Terjadi kesalahan."}\n${r && r.status ? "Saldo sudah dikembalikan." : "Admin akan mengembalikan saldo manual."}`).catch(() => {});
            if (OTP_HABIS_DI_HARGA.includes(e.message)) await otpTawarkanHargaLain(chatId, service, country, cost);
        } else {
            bot.sendMessage(chatId, `⚠️ ${e.teksUser || "Terjadi kesalahan, coba lagi nanti."}`).catch(() => {});
        }
    } finally {
        otpBeliLock.delete(userId);
    }
}

// QRIS 1: simpan sesi bertipe "otp" lalu lempar ke pay_qris_tripay.
// Setelah PAID, handlePaymentSuccess memanggil otpAmbilNomor; kalau gagal, selesaikanQrisTripay mengembalikan dana ke saldo.
async function otpBayarQris(query, service, country, cost) {
    const userId = query.from.id;
    const chatId = query.message.chat.id;
    const harga = otpHarga(cost);
    const [nama, negara] = await Promise.all([otpNamaLayanan(service), otpNegaraMap().catch(() => ({}))]);
    userSessions[userId] = {
        type: "otp", service, country: String(country), cost, harga,
        paket: `OTP ${nama} - ${negara[country] || country}`, userId, chatId, tgUser: otpNamaUser(query.from)
    };
    return bot.emit("callback_query", { ...query, data: "pay_qris_tripay" });
}

async function otpAksi(query, aksi, id) {

    const o = otpOrders.get(id);
    const jawab = (text, alert = true) => bot.answerCallbackQuery(query.id, { text, show_alert: alert }).catch(() => {});
    if (!o) return jawab("Pesanan ini sudah selesai / tidak ditemukan.");
    if (String(o.userId) !== String(query.from.id)) return jawab("Ini bukan pesanan kamu.");

    if (aksi === "k") { // cek manual
        await otpCekStatus(o);
        return jawab(o.codes.length ? `🔑 Kode: ${o.codes[o.codes.length - 1]}` : "⏳ SMS belum masuk, tunggu sebentar ya.");
    }
    if (aksi === "x") { // batalkan
        if (o.codes.length) return jawab("Kode sudah diterima, pesanan tidak bisa dibatalkan.");
        const res = await heroApi("setStatus", { id, status: 8 }).catch(e => ({ title: e.message }));
        if (res === "ACCESS_CANCEL") {
            otpSelesai(o, "CANCEL");
            await otpGantiPesanOrder(o, "1", { akhir: "❌ <b>Pesanan dibatalkan.</b> Dana dikembalikan ke saldo akun.", markup: otpTombolPesanLagi(`otp_n_${o.service}_${o.country}`) });
            await otpRefund(o, "dibatalkan");
            return jawab("Pesanan dibatalkan, saldo dikembalikan.", false);
        }
        const err = heroErr(res);
        if (err === "EARLY_CANCEL_DENIED") {
            const tunggu = (res.info && res.info.minActivationTime) || 120;
            return jawab(`Pembatalan baru bisa ${Math.ceil(tunggu / 60)} menit setelah nomor dibuat. Coba lagi sebentar.`);
        }
        if (err === "OTP_RECEIVED") { await otpCekStatus(o); return jawab("Kode sudah masuk, cek pesan di atas."); }
        return jawab(`Gagal membatalkan (${err || res}).`);
    }
    if (aksi === "r") { // minta SMS lagi
        const res = await heroApi("setStatus", { id, status: 3 }).catch(e => ({ title: e.message }));
        if (res === "ACCESS_RETRY_GET") {
            o.status = "WAIT";
            otpSimpan();
            otpMulaiPantau(o);
            await otpUpdatePesan(o);
            return jawab("Menunggu SMS baru, akan muncul otomatis...", false);
        }
        return jawab(`Tidak bisa minta SMS lagi (${heroErr(res) || res}).`);
    }
    if (aksi === "f") { // selesai
        await heroApi("setStatus", { id, status: 6 }).catch(() => {});
        otpSelesai(o, "DONE");
        await otpGantiPesanOrder(o, "1", { akhir: otpStatusTeks(o) + "\n\n✅ <b>Selesai. Terima kasih!</b>", markup: null });
        return jawab("Pesanan selesai.", false);
    }
}

bot.on("callback_query", async (query) => {
    const data = query.data || "";
    if (data !== "menu_otp" && !data.startsWith("otp_")) return;
    if (menuTertutupUntuk(data, query.from.id)) return; // info maintenance dikirim handler utama
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;
    const userId = query.from.id;
    try {
        if (data === "menu_otp") {
            await bot.answerCallbackQuery(query.id).catch(() => {});
            return await otpTampilMenu(chatId, messageId);
        }
        if (!otpCfg().apiKey) return bot.answerCallbackQuery(query.id, { text: "Fitur OTP belum aktif.", show_alert: true });

        if (data === "otp_cari") {
            await bot.answerCallbackQuery(query.id).catch(() => {});
            userSessions[chatId] = { type: "otp", step: "otp_search" };
            return bot.sendMessage(chatId, "🔎 Ketik nama aplikasi yang dicari (contoh: <code>shopee</code>, <code>gojek</code>, <code>dana</code>):", { parse_mode: "HTML" });
        }
        if (data === "otp_aktif") {
            const aktif = [...otpOrders.values()].filter(o => String(o.userId) === String(userId));
            await bot.answerCallbackQuery(query.id).catch(() => {});
            if (!aktif.length) return bot.sendMessage(chatId, "Tidak ada pesanan OTP yang aktif.");
            for (const o of aktif) {
                o.messageId = await otpKirimPesanOrder(o, "1"); // tampilan terbaru yang di-update
            }
            return otpSimpan();
        }
        let m;
        // pilih layanan -> minta user mengetik negara
        if ((m = data.match(/^otp_s_([a-z0-9]+)$/i))) {
            await bot.answerCallbackQuery(query.id).catch(() => {});
            return await otpMintaNegara(chatId, messageId, m[1]);
        }
        // negara dipilih (dari hasil ketik yang cocok lebih dari satu) -> daftar harga
        if ((m = data.match(/^otp_n_([a-z0-9]+)_(\d+)$/i))) {
            await bot.answerCallbackQuery(query.id, { text: "Mengambil harga..." }).catch(() => {});
            return await otpTampilHarga(chatId, messageId, m[1], m[2]);
        }
        // tingkat harga dipilih -> konfirmasi
        if ((m = data.match(/^otp_t_([a-z0-9]+)_(\d+)_([\d.]+)$/i))) {
            await bot.answerCallbackQuery(query.id).catch(() => {});
            return await otpKonfirmasi(chatId, messageId, userId, m[1], m[2], Number(m[3]));
        }
        if ((m = data.match(/^otp_b_([a-z0-9]+)_(\d+)_([\d.]+)$/i))) return await otpBeliSaldo(query, m[1], m[2], Number(m[3]));
        if ((m = data.match(/^otp_q_([a-z0-9]+)_(\d+)_([\d.]+)$/i))) return await otpBayarQris(query, m[1], m[2], Number(m[3]));
        if ((m = data.match(/^otp_([kxrf])_(\d+)$/))) return await otpAksi(query, m[1], m[2]);
        return bot.answerCallbackQuery(query.id, { text: "Menu ini sudah kedaluwarsa, buka ulang Nomor OTP.", show_alert: true });
    } catch (e) {
        // await di atas penting: tanpa itu error lolos jadi unhandled rejection
        const kode = String(e.message || "").split(":")[0];
        console.log("[OTP] callback error:", e.message);
        otpLaporAdmin(kode, e.message);
        const teks = OTP_ERR_TEKS[kode] || "Server OTP tidak merespons, coba lagi.";
        bot.answerCallbackQuery(query.id, { text: "⚠️ " + teks, show_alert: true }).catch(() => {});
    }
});

// Input teks OTP: cari layanan & ketik nama negara
bot.on("message", async (msg) => {
    const chatId = msg.chat.id;
    const s = userSessions[chatId];
    if (!s || s.type !== "otp" || !["otp_search", "otp_negara"].includes(s.step) || !msg.text || msg.text.startsWith("/")) return;
    const ketik = msg.text.trim();
    const aman = ketik.replace(/[<>&]/g, "");
    try {
        if (s.step === "otp_search") {
            delete userSessions[chatId];
            const kata = ketik.toLowerCase();
            const hasil = (await otpDaftarLayanan())
                .filter(x => x.code.toLowerCase() === kata || String(x.name).toLowerCase().includes(kata))
                .slice(0, 10);
            if (!hasil.length) {
                return bot.sendMessage(chatId, `Layanan "<b>${aman}</b>" tidak ditemukan.`, {
                    parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "🔎 Cari Lagi", callback_data: "otp_cari" }, { text: "⬅️ Menu OTP", callback_data: "menu_otp" }]] }
                });
            }
            const baris = hasil.map(x => [{ text: x.name, callback_data: `otp_s_${x.code}` }]);
            baris.push([{ text: "⬅️ Menu OTP", callback_data: "menu_otp" }]);
            return bot.sendMessage(chatId, `🔎 Hasil pencarian "${aman}":`, { reply_markup: { inline_keyboard: baris } });
        }

        // step otp_negara
        const cocok = otpCariNegara(await otpNegaraMap(), ketik);
        if (!cocok.length) {
            return bot.sendMessage(chatId, `Negara "<b>${aman}</b>" tidak ditemukan. Coba ketik nama dalam bahasa Inggris, contoh: <code>malaysia</code>, <code>united kingdom</code>.`, { parse_mode: "HTML" });
        }
        if (cocok.length > 1) {
            const baris = cocok.map(n => [{ text: n.nama, callback_data: `otp_n_${s.service}_${n.id}` }]);
            baris.push([{ text: "⬅️ Ganti Layanan", callback_data: "menu_otp" }]);
            return bot.sendMessage(chatId, `Ada beberapa negara yang cocok dengan "${aman}", pilih salah satu:`, { reply_markup: { inline_keyboard: baris } });
        }
        delete userSessions[chatId];
        return await otpTampilHarga(chatId, null, s.service, cocok[0].id);
    } catch (e) {
        const kode = String(e.message || "").split(":")[0];
        otpLaporAdmin(kode, e.message);
        bot.sendMessage(chatId, "⚠️ " + (OTP_ERR_TEKS[kode] || "Server OTP tidak merespons, coba lagi nanti."));
    }
});

// ====================================================
// OTP BERSAMA (Server 1 & 2): catatan batal, sensor nomor, pesan sukses
// ====================================================
const OTP_CATATAN_BATAL = `\n\n<i>ℹ️ OTP tidak masuk? Klik tombol Batalkan dan saldo akan di-refund. Jika bayar dengan QRIS, dana otomatis di-refund ke saldo akun. Selama OTP belum diterima kamu dapat membatalkan pesanan, baik karena OTP tidak masuk maupun berubah pikiran. Jika OTP sudah diterima, pesanan dinyatakan selesai.</i>`;
const OTP_BOT_URL = "https://t.me/PanelKitaLegalbot";

// +62812******* : kode negara + 3 digit awal terlihat, sisanya bintang
function otpSensorNomor(phone) {
    const d = String(phone || "").replace(/\D/g, "");
    const awal = d.startsWith("62") ? 5 : Math.min(5, Math.max(2, d.length - 4));
    return "+" + d.slice(0, awal) + "*".repeat(Math.max(3, d.length - awal));
}
function otpNamaUser(from) {
    if (!from) return "User";
    return from.username ? `@${from.username}` : (from.first_name || "User");
}
function otpTombolPesanLagi(cb) {
    return { inline_keyboard: [[{ text: "🔁 Pesan Lagi", callback_data: cb, style: "success" }]] };
}

// ID channel testimoni (hardcode, sengaja tidak di settings.js). Kosong = testimoni ke channel tidak dikirim.
let OTP_TESTI_CHANNEL_ID = "-1003992898454"; // channel testimoni (bot harus admin di channel)

// Gambar OTP dinamis (folder ./gambar-otp, butuh @napi-rs/canvas). Kalau modul/canvas tidak ada,
// bot tetap jalan dan pesan sukses memakai cadangan (rich message / teks).
let modulGambarOtp;
function gambarOtp() {
    if (modulGambarOtp === undefined) {
        try { modulGambarOtp = require("./gambar-otp"); }
        catch (e) { console.log("[gambar-otp] tidak tersedia, pakai cadangan:", e.message); modulGambarOtp = null; }
    }
    return modulGambarOtp;
}
async function otpBuatGambar(kode) {
    const g = gambarOtp();
    if (!g) return null;
    try {
        const { buffer, mime } = await g.buatGambarOtp(String(kode));
        return Buffer.isBuffer(buffer) && buffer.length ? { buffer, mime } : null;
    } catch (e) {
        console.log("[gambar-otp] gagal membuat gambar:", e.message); // pesan error tidak memuat kode OTP
        return null;
    }
}

// Kirim satu pesan sukses ke `tujuan`: foto dinamis + caption blockquote + tombol; cadangan rich message lalu teks.
async function otpKirimPesanSukses(tujuan, o, kode, gambar) {
    const markup = { reply_markup: { inline_keyboard: [
        [{ text: "📋 Salin Kode OTP", copy_text: { text: String(kode) } }],
        [{ text: "🛒 Beli OTP Murah", url: OTP_BOT_URL, style: "success" }]
    ] } };
    const baris = [["User", otpEsc(o.username || "User")], ["Layanan", otpEsc(o.serviceName)], ["Nomor", otpSensorNomor(o.phone)], ["OTP", `<code>${otpEsc(kode)}</code>`]];
    const caption = `<blockquote>✅ <b>OTP BERHASIL DITERIMA</b>\n━━━━━━━━━━━━━━━━━━\n` +
        baris.map(([k, v]) => `${k} : ${v}`).join("\n") +
        `</blockquote>\nNomor virtual siap pakai, OTP masuk otomatis.`;
    if (gambar) {
        try {
            const ext = gambar.mime === "image/jpeg" ? "jpg" : String(gambar.mime).split("/")[1];
            return await bot.sendPhoto(tujuan, gambar.buffer, { caption, parse_mode: "HTML", ...markup }, { filename: `otp.${ext}`, contentType: gambar.mime });
        } catch (e) { console.log("[OTP] kirim foto sukses gagal, pakai cadangan:", e.message); }
    }
    const html = `<h3>✅ OTP BERHASIL DITERIMA</h3>\n<hr/>\n<table bordered striped>\n` +
        baris.map(([k, v]) => `  <tr><td><b>${k}</b></td><td>${v}</td></tr>`).join("\n") +
        `\n</table>\n<blockquote>Nomor virtual siap pakai, OTP masuk otomatis.</blockquote>`;
    try {
        return await sendRichMessage(tujuan, html, markup);
    } catch (e) {
        return bot.sendMessage(tujuan, caption, { parse_mode: "HTML", ...markup }).catch(err => console.log("[OTP] pesan sukses gagal:", err.message));
    }
}

// Dipanggil sekali saat OTP pertama diterima: log income admin + testimoni ke channel.
// Admin TIDAK dikirimi salinan pesan testimoni (cukup log income); user tetap dapat pesan kode sendiri.
// Pesan kode OTP ke user tetap dikirim terpisah oleh otpCekStatus/otp2CekStatus (tidak diubah di sini).
async function otpKirimSukses(o, server) {
    if (o.incomeLogged) return;
    o.incomeLogged = true;
    const kode = o.codes[o.codes.length - 1];
    const label = server === "2" ? " (SERVER 2)" : "";
    bot.sendMessage(settings.adminId, `<blockquote>📱 <b>INCOME: NOMOR OTP${label}</b>\n━━━━━━━━━━━━━━━━━━\n🆔 ID: <code>${o.userId}</code> ${otpEsc(o.username || "")}\n🧩 ${o.serviceName} / ${o.countryName}\n💵 ${otpRp(o.harga)} (modal $${o.cost})\n🧾 Aktivasi: <code>${o.id}</code>\n✅ OTP sudah diterima user</blockquote>`, { parse_mode: "HTML" }).catch(() => {});

    if (OTP_TESTI_CHANNEL_ID) {
        const gambar = await otpBuatGambar(kode);
        await otpKirimPesanSukses(OTP_TESTI_CHANNEL_ID, o, kode, gambar)
            .catch(e => console.log("[OTP] testimoni channel gagal:", e.message));
    }
}
function otpEsc(t) { return String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }

// ---------- Testimoni DEPOSIT ke channel (channel sama dengan testimoni OTP) ----------
// Gambar "Deposit Rp xxx" dibuat dinamis oleh ./gambar-otp (buatGambarDeposit). Kalau modul/canvas
// tidak ada atau gagal -> cadangan rich message lalu teks. Tidak pernah melempar error ke alur deposit.
async function depBuatGambar(nominal) {
    const g = gambarOtp();
    if (!g || typeof g.buatGambarDeposit !== "function") return null;
    try {
        const { buffer, mime } = await g.buatGambarDeposit(Number(nominal));
        return Buffer.isBuffer(buffer) && buffer.length ? { buffer, mime } : null;
    } catch (e) {
        console.log("[gambar-deposit] gagal membuat gambar:", e.message);
        return null;
    }
}
function depMetode(session, orderId) {
    if (session && session.metodeBayar) return session.metodeBayar;
    return /^[0-9a-f]{8}-[0-9a-f]{4}-/i.test(String(orderId || "")) ? "Crypto" : "QRIS";
}
async function depKirimTestimoni(chatId, session, orderId) {
    if (!OTP_TESTI_CHANNEL_ID) return;
    try {
        const u = global.dbUsers && global.dbUsers[chatId];
        const nama = session.username || (u && u.username ? (String(u.username).startsWith("@") ? u.username : "@" + u.username) : "User");
        const nominal = parseInt(session.amount) || 0;
        const baris = [["User", otpEsc(nama)], ["Metode", otpEsc(depMetode(session, orderId))], ["Nominal", `Rp ${nominal.toLocaleString("id-ID")}`]];
        const markup = { reply_markup: { inline_keyboard: [[{ text: "💰 Top Up Sekarang", url: OTP_BOT_URL, style: "success" }]] } };
        const caption = `<blockquote>✅ <b>DEPOSIT BERHASIL</b>\n━━━━━━━━━━━━━━━━━━\n` + baris.map(([k, v]) => `${k} : ${v}`).join("\n") + `</blockquote>`;
        const gambar = await depBuatGambar(nominal);
        if (gambar) {
            try {
                const ext = gambar.mime === "image/jpeg" ? "jpg" : String(gambar.mime).split("/")[1];
                return await bot.sendPhoto(OTP_TESTI_CHANNEL_ID, gambar.buffer, { caption, parse_mode: "HTML", ...markup }, { filename: `deposit.${ext}`, contentType: gambar.mime });
            } catch (e) { console.log("[DEPOSIT] kirim foto testimoni gagal, pakai cadangan:", e.message); }
        }
        const html = `<h3>✅ DEPOSIT BERHASIL</h3>\n<hr/>\n<table bordered striped>\n` +
            baris.map(([k, v]) => `  <tr><td><b>${k}</b></td><td>${v}</td></tr>`).join("\n") + `\n</table>`;
        try { return await sendRichMessage(OTP_TESTI_CHANNEL_ID, html, markup); }
        catch (e) { return await bot.sendMessage(OTP_TESTI_CHANNEL_ID, caption, { parse_mode: "HTML", ...markup }); }
    } catch (e) {
        console.log("[DEPOSIT] testimoni channel gagal:", e.message);
    }
}

// ---------- Pesan order (halaman menunggu OTP) sebagai tabel rich message ----------
// Status di bawah tabel; "\n" = baris baru, "\n\n" = paragraf baru.
function otpStatusTeks(o, akhir) {
    if (akhir) return akhir;
    if (o.codes.length) {
        return `🔑 <b>Kode OTP:</b> <code>${o.codes[o.codes.length - 1]}</code>` +
            (o.codes.length > 1 ? `\n<i>Kode sebelumnya: ${o.codes.slice(0, -1).join(", ")}</i>` : "") +
            (o.status === "WAIT" ? `\n\n⏳ <i>Menunggu SMS berikutnya, akan muncul otomatis.</i>` : "");
    }
    return `⏳ <b>Menunggu OTP masuk...</b>\n<i>Kode OTP akan muncul otomatis di pesan ini, tidak perlu menekan apa pun.</i>` + OTP_CATATAN_BATAL;
}
function otpBarisInfo(o) {
    const batas = new Date(o.endTime).toLocaleTimeString("id-ID", { timeZone: "Asia/Jakarta", hour: "2-digit", minute: "2-digit" });
    return [["Layanan", `<b>${otpEsc(o.serviceName)}</b>`], ["Negara", otpEsc(o.countryName)], ["Nomor", `<code>+${otpEsc(o.phone)}</code>`],
        ["Harga", otpRp(o.harga)], ["ID", `<code>${otpEsc(o.id)}</code>`], ["Berlaku s/d", `${batas} WIB`]];
}
// Kirim pesan order baru (rich: judul + garis + tabel + status; cadangan teks biasa). Hasil: message_id.
async function otpKirimPesanOrder(o, server, opsi = {}) {
    const judul = server === "2" ? "📱 NOMOR OTP • SERVER 2" : "📱 NOMOR OTP";
    const baris = otpBarisInfo(o);
    const status = otpStatusTeks(o, opsi.akhir);
    const markup = opsi.markup !== undefined ? opsi.markup : (server === "2" ? otp2Keyboard(o) : otpKeyboard(o));
    const extra = markup ? { reply_markup: markup } : {};
    const html = `<h3>${judul}</h3>\n<hr/>\n<table bordered striped>\n` +
        baris.map(([k, v]) => `  <tr><td><b>${k}</b></td><td>${v}</td></tr>`).join("\n") + `\n</table>\n` +
        status.split(/\n{2,}/).filter(Boolean).map(par => `<p>${par.replace(/\n/g, "<br>")}</p>`).join("\n");
    try {
        const r = await sendRichMessage(o.chatId, html, extra);
        return r && r.message_id;
    } catch (e) {
        const teks = `<blockquote>📱 <b>${judul.replace("📱 ", "")}</b>\n━━━━━━━━━━━━━━━━━━\n` +
            baris.map(([k, v]) => `${k}: ${v}`).join("\n") + `\n\n${status}</blockquote>`;
        const m = await bot.sendMessage(o.chatId, teks, { parse_mode: "HTML", ...extra }).catch(() => null);
        return m && m.message_id;
    }
}
// Rich message tidak di-edit: kirim versi terbaru, lalu hapus pesan lama.
async function otpGantiPesanOrder(o, server, opsi = {}) {
    const lama = o.messageId;
    const baru = await otpKirimPesanOrder(o, server, opsi);
    if (baru) {
        o.messageId = baru;
        if (lama && lama !== baru) await bot.deleteMessage(o.chatId, lama).catch(() => {});
    }
}

// ====================================================
// NOMOR OTP SERVER 2 (provider kedua, protokol SMS-Activate)
// ====================================================
// Modul terpisah dari Server 1: fungsi, callback (o2_*), sesi (type "otp2"), file order dan
// pengaturan (settings.smsbower) sendiri. Nama provider tidak pernah tampil ke user.
// Yang dipakai bersama hanya helper murni: heroErr, otpRp, otpStok, otpCariNegara, otpKirimRich.
const OTP2_DB_FILE = "./database/otp2_orders.json";
const otp2Orders = new Map();     // activationId -> order
const otp2BeliLock = new Set();
const otp2Cache = {};

function otp2Cfg() {
    const c = settings.smsbower || {};
    return {
        apiKey: String(c.apiKey || process.env.SMSBOWER_API_KEY || "").trim(),
        baseUrl: c.baseUrl || "https://smsbower.page/stubs/handler_api.php",
        kurs: Number(c.kurs) || 17000,             // 1 USD saldo server 2 = Rp
        markupPersen: c.markupPersen ?? 20,
        markupMin: c.markupMin ?? 1000,
        maxTingkat: c.maxTingkat || 20,
        intervalCek: c.intervalCek || 5000,
        masaAktifMenit: c.masaAktifMenit || 20,    // dipakai kalau API tidak mengirim waktu habis
        layanan: Array.isArray(c.layanan) && c.layanan.length ? c.layanan : OTP_LAYANAN_DEFAULT
    };
}

async function otp2Api(action, params = {}) {
    const cfg = otp2Cfg();
    if (!cfg.apiKey) throw new Error("NO_KEY");
    const qs = new URLSearchParams({ api_key: cfg.apiKey, action, ...params });
    const r = await fetch(`${cfg.baseUrl}?${qs.toString()}`, { signal: AbortSignal.timeout(20000) });
    const txt = (await r.text()).trim();
    try { return JSON.parse(txt); } catch { return txt; }
}

const OTP2_ERR_TEKS = { ...OTP_ERR_TEKS, NO_ACTIVATION: "Aktivasi tidak ditemukan.", BAD_ACTION: "Server OTP menolak permintaan." };
const OTP2_HABIS_DI_HARGA = ["NO_NUMBERS", "WRONG_MAX_PRICE"];

const otp2LaporTerakhir = {};
function otp2LaporAdmin(kode, detail) {
    if (!["BAD_KEY", "NO_KEY", "NO_BALANCE", "BANNED"].includes(kode)) return;
    if (Date.now() - (otp2LaporTerakhir[kode] || 0) < 10 * 60 * 1000) return;
    otp2LaporTerakhir[kode] = Date.now();
    const saran = kode === "BAD_KEY" || kode === "NO_KEY" ? "Cek settings.smsbower.apiKey." : "Cek saldo akun server 2.";
    bot.sendMessage(settings.adminId, `<blockquote>⚠️ <b>OTP SERVER 2 ERROR</b>: <code>${kode}</code>\n${String(detail || "").replace(/[<>&]/g, "")}\n\n${saran}</blockquote>`, { parse_mode: "HTML" }).catch(() => {});
}

function otp2Harga(cost) {
    const cfg = otp2Cfg();
    const modal = Number(cost) * cfg.kurs;
    const jual = Math.max(modal * (1 + cfg.markupPersen / 100), modal + cfg.markupMin);
    return Math.ceil(jual / 100) * 100;
}

async function otp2Cached(key, loader, ttlMs = 6 * 3600 * 1000) {
    const c = otp2Cache[key];
    if (c && Date.now() - c.at < ttlMs) return c.data;
    const data = await loader();
    otp2Cache[key] = { at: Date.now(), data };
    return data;
}
async function otp2NegaraMap() {
    return otp2Cached("countries", async () => {
        const res = await otp2Api("getCountries");
        if (heroErr(res)) throw new Error(heroErr(res));
        const list = Array.isArray(res) ? res : Object.values(res || {});
        const map = {};
        for (const c of list) if (c && c.id !== undefined) map[String(c.id)] = c.eng || c.rus || `Negara ${c.id}`;
        return map;
    });
}
async function otp2DaftarLayanan() {
    return otp2Cached("services", async () => {
        const res = await otp2Api("getServicesList");
        if (heroErr(res)) throw new Error(heroErr(res));
        return (res && res.services) || [];
    });
}
async function otp2NamaLayanan(code) {
    const lokal = otp2Cfg().layanan.find(l => l.code === code);
    if (lokal) return lokal.name;
    const semua = await otp2DaftarLayanan().catch(() => []);
    return (semua.find(s => s.code === code) || {}).name || code.toUpperCase();
}

// Urai satu node harga dari berbagai versi getPrices:
//  V3: { "<providerId>": { cost|price, count } }  -> pilihan per provider (dibeli dengan providerIds)
//  V2: { "<harga>": <stok> }                      -> pilihan per harga
//  V1: { cost, count }                            -> 1 harga
function otp2UraiNode(node) {
    if (!node || typeof node !== "object" || Array.isArray(node)) return [];
    if ("cost" in node || "price" in node) {
        const c = Number(node.cost ?? node.price), n = Number(node.count ?? 0);
        return c > 0 && n > 0 ? [{ cost: c, stok: n }] : [];
    }
    const out = [];
    for (const [k, v] of Object.entries(node)) {
        if ((typeof v === "number" || (typeof v === "string" && v.trim() !== "" && !isNaN(v))) && !isNaN(k)) {
            if (Number(k) > 0 && Number(v) > 0) out.push({ cost: Number(k), stok: Number(v) });
        } else if (v && typeof v === "object" && ("cost" in v || "price" in v)) {
            const c = Number(v.cost ?? v.price), n = Number(v.count ?? 0);
            if (c > 0 && n > 0) out.push({ cost: c, stok: n, pid: /^\d+$/.test(k) ? k : undefined });
        }
    }
    return out;
}
function otp2UraiHarga(res, service, country) {
    if (!res || typeof res !== "object") return [];
    const kandidat = [res?.[country]?.[service], res?.[service]?.[country], res?.[country], res?.[service], res];
    for (const node of kandidat) {
        const t = otp2UraiNode(node);
        if (t.length) return t;
    }
    return [];
}

// Pilihan harga 1 negara (urut termurah). Sumber: getPricesV3 -> getPricesV2 -> getPrices.
async function otp2TingkatHarga(service, country) {
    let baris = [];
    for (const action of ["getPricesV3", "getPricesV2", "getPrices"]) {
        try {
            const res = await otp2Api(action, { service, country: String(country) });
            const err = heroErr(res);
            if (err) { if (["BAD_KEY", "NO_KEY"].includes(err)) throw new Error(err); continue; }
            baris = otp2UraiHarga(res, service, String(country));
            if (baris.length) break;
        } catch (e) {
            if (["BAD_KEY", "NO_KEY"].includes(e.message)) throw e;
            console.log(`[OTP2] ${action} gagal:`, e.message);
        }
    }
    // Gabungkan yang harga jualnya sama. Satu provider -> simpan pid (beli tepat dari provider itu).
    const perRp = new Map();
    for (const b of baris) {
        const harga = otp2Harga(b.cost);
        const ada = perRp.get(harga);
        if (ada) { ada.stok += b.stok; ada.cost = Math.max(ada.cost, b.cost); if (ada.pid !== b.pid) ada.pid = undefined; }
        else perRp.set(harga, { cost: b.cost, harga, stok: b.stok, pid: b.pid });
    }
    return [...perRp.values()].sort((a, b) => a.harga - b.harga).slice(0, otp2Cfg().maxTingkat);
}
const otp2Token = t => `${t.cost}_${t.pid || 0}`; // bagian callback_data untuk satu pilihan harga

function otp2Simpan() {
    try {
        const data = [...otp2Orders.values()].map(({ timer, busy, ...o }) => o);
        fs.writeFileSync(OTP2_DB_FILE, JSON.stringify(data, null, 2));
    } catch (e) { console.log("[OTP2] gagal simpan:", e.message); }
}
// OTP dicek otomatis di latar belakang (otp2MulaiPantau), jadi tidak ada tombol "Cek SMS".
function otp2Keyboard(o) {
    if (o.codes.length && o.status === "WAIT") {
        return { inline_keyboard: [[{ text: "✅ Selesai", callback_data: `o2_f_${o.id}`, style: "success" }]] };
    }
    if (o.codes.length) {
        return { inline_keyboard: [[{ text: "🔁 Minta SMS Lagi", callback_data: `o2_r_${o.id}` }, { text: "✅ Selesai", callback_data: `o2_f_${o.id}`, style: "success" }]] };
    }
    return { inline_keyboard: [[{ text: "❌ Batalkan", callback_data: `o2_x_${o.id}`, style: "danger" }]] };
}
async function otp2UpdatePesan(o) {
    await otpGantiPesanOrder(o, "2");
}
async function otp2Refund(o, alasan) {
    if (o.refunded) return;
    o.refunded = true;
    otp2Simpan();
    const r = await refundSaldoReal(o.userId, o.harga, `Refund OTP S2 ${o.id} - ${alasan}`).catch(e => ({ status: false, msg: e.message }));
    if (r && r.status) {
        bot.sendMessage(o.chatId, `↩️ Saldo ${otpRp(o.harga)} dikembalikan (${alasan}).\nSisa saldo: ${otpRp(r.new_balance || 0)}`).catch(() => {});
    } else {
        bot.sendMessage(o.chatId, `⚠️ Refund otomatis gagal. Admin akan memproses manual. ID: ${o.id}`).catch(() => {});
        bot.sendMessage(settings.adminId, `<blockquote>⚠️ <b>REFUND OTP SERVER 2 GAGAL</b>\n🆔 User: <code>${o.userId}</code>\n🧾 Aktivasi: <code>${o.id}</code>\n💵 ${otpRp(o.harga)}\n❗ ${(r && (r.msg || r.message)) || "-"}</blockquote>`, { parse_mode: "HTML" }).catch(() => {});
    }
}
function otp2Selesai(o, status) {
    clearInterval(o.timer);
    o.status = status;
    otp2Orders.delete(o.id);
    otp2Simpan();
}
async function otp2CekStatus(o) {
    if (o.busy || !otp2Orders.has(o.id)) return;
    o.busy = true;
    try {
        if (Date.now() > o.endTime) {
            if (o.codes.length) {
                await otp2Api("setStatus", { id: o.id, status: 6 }).catch(() => {});
                otp2Selesai(o, "DONE");
            } else {
                await otp2Api("setStatus", { id: o.id, status: 8 }).catch(() => {});
                otp2Selesai(o, "EXPIRED");
                await otpGantiPesanOrder(o, "2", { akhir: "⌛ <b>Waktu habis, SMS tidak masuk.</b>", markup: otpTombolPesanLagi(`o2_n_${o.service}_${o.country}`) });
                await otp2Refund(o, "SMS tidak masuk");
            }
            return;
        }
        const res = await otp2Api("getStatus", { id: o.id });
        if (typeof res !== "string") return;
        if (res.startsWith("STATUS_OK:")) {
            const kode = res.slice("STATUS_OK:".length).trim();
            if (!o.codes.includes(kode)) {
                o.codes.push(kode);
                o.status = "CODE";
                clearInterval(o.timer);
                otp2Simpan();
                await otp2UpdatePesan(o);
                bot.sendMessage(o.chatId, `🔑 Kode OTP ${o.serviceName}: <code>${kode}</code>`, { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "📋 Salin Kode OTP", copy_text: { text: String(kode) } }]] } }).catch(() => {});
                await otpKirimSukses(o, "2");
                otp2Simpan();
            }
        } else if (res === "STATUS_CANCEL" || res === "NO_ACTIVATION") {
            otp2Selesai(o, "CANCEL");
            if (!o.codes.length) {
                await otpGantiPesanOrder(o, "2", { akhir: "❌ <b>Aktivasi dibatalkan.</b>", markup: otpTombolPesanLagi(`o2_n_${o.service}_${o.country}`) });
                await otp2Refund(o, "aktivasi dibatalkan");
            }
        }
        // STATUS_WAIT_CODE / STATUS_WAIT_RETRY: tunggu putaran berikutnya
    } catch (e) {
        console.log(`[OTP2] cek ${o.id} gagal:`, e.message);
    } finally {
        o.busy = false;
    }
}
function otp2MulaiPantau(o) {
    clearInterval(o.timer);
    o.timer = setInterval(() => otp2CekStatus(o), otp2Cfg().intervalCek);
    setTimeout(() => otp2CekStatus(o), 2000); // cek pertama lebih cepat
}
try {
    if (fs.existsSync(OTP2_DB_FILE)) {
        for (const o of JSON.parse(fs.readFileSync(OTP2_DB_FILE, "utf8")) || []) {
            otp2Orders.set(o.id, o);
            if (o.status === "WAIT") otp2MulaiPantau(o);
        }
    }
} catch (e) { console.log("[OTP2] gagal memuat order:", e.message); }

// ---------- Pilih server (pintu masuk dari menu utama) ----------
async function otpPilihServer(chatId, messageId) {
    const s1 = !!otpCfg().apiKey, s2 = !!otp2Cfg().apiKey;
    if (s1 && !s2) return otpTampilMenu(chatId, messageId);   // Server 1 apa adanya
    if (s2 && !s1) return otp2TampilMenu(chatId, messageId);
    if (!s1 && !s2) return otpTampilMenu(chatId, messageId);  // tampil "segera hadir" dari Server 1
    if (messageId) await bot.deleteMessage(chatId, messageId).catch(() => {});
    return bot.sendMessage(chatId, `<blockquote>📱 <b>NOMOR OTP / VERIFIKASI</b>\n━━━━━━━━━━━━━━━━━━\nPilih server. Stok & harga tiap server berbeda.\n\n<i>Kalau nomor di satu server habis atau SMS tidak masuk, coba server lainnya.</i></blockquote>`, {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [
            [{ text: "⚡ Server 1", callback_data: "menu_otp", style: "success" }, { text: "🚀 Server 2", callback_data: "o2_menu", style: "success" }],
            [{ text: "⬅️ Kembali", callback_data: "back_to_main" }]
        ] }
    });
}

async function otp2TampilMenu(chatId, messageId) {
    const cfg = otp2Cfg();
    if (messageId) await bot.deleteMessage(chatId, messageId).catch(() => {});
    if (!cfg.apiKey) {
        return bot.sendMessage(chatId, "<blockquote>📱 <b>NOMOR OTP • SERVER 2</b>\n\nServer ini segera hadir.</blockquote>", {
            parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅️ Pilih Server", callback_data: "pilih_otp_server" }]] }
        });
    }
    const tombol = cfg.layanan.map(l => ({ text: l.name, callback_data: `o2_s_${l.code}` }));
    const baris = [];
    for (let i = 0; i < tombol.length; i += 2) baris.push(tombol.slice(i, i + 2));
    baris.push([{ text: "🔎 Cari Layanan Lain", callback_data: "o2_cari", style: "primary" }, { text: "📜 Pesanan Aktif", callback_data: "o2_aktif", style: "primary" }]);
    baris.push([{ text: "⬅️ Pilih Server", callback_data: "pilih_otp_server" }]);
    const teks = `<blockquote>📱 <b>NOMOR OTP • SERVER 2</b>\n━━━━━━━━━━━━━━━━━━\n` +
        `1️⃣ Pilih layanan\n2️⃣ Ketik nama negara\n3️⃣ Pilih harga (termurah → termahal, stok terlihat)\n4️⃣ Bayar QRIS 1 atau saldo\n5️⃣ Kode OTP dikirim otomatis\n\n` +
        `<i>SMS tidak masuk? Batalkan, dana kembali ke saldo akun.</i></blockquote>`;
    return bot.sendMessage(chatId, teks, { parse_mode: "HTML", reply_markup: { inline_keyboard: baris } });
}

async function otp2MintaNegara(chatId, messageId, service) {
    const nama = await otp2NamaLayanan(service);
    userSessions[chatId] = { type: "otp2", step: "otp2_negara", service };
    if (messageId) await bot.deleteMessage(chatId, messageId).catch(() => {});
    return bot.sendMessage(chatId, `<blockquote>🌍 <b>${nama}</b> • Server 2\n\nKetik nama negara nomor yang kamu mau.\nContoh: <code>indonesia</code>, <code>malaysia</code>, <code>amerika</code></blockquote>`, {
        parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅️ Ganti Layanan", callback_data: "o2_menu" }]] }
    });
}

async function otp2TampilHarga(chatId, messageId, service, country, opsi = {}) {
    const [semua, negara, nama] = await Promise.all([otp2TingkatHarga(service, country), otp2NegaraMap(), otp2NamaLayanan(service)]);
    const tingkat = opsi.kecuali ? semua.filter(t => otp2Token(t) !== opsi.kecuali) : semua;
    if (messageId) await bot.deleteMessage(chatId, messageId).catch(() => {});
    const namaNegara = negara[country] || `Negara ${country}`;
    if (!tingkat.length) {
        userSessions[chatId] = { type: "otp2", step: "otp2_negara", service };
        return bot.sendMessage(chatId, `<blockquote>😔 Stok <b>${nama}</b> untuk <b>${namaNegara}</b> di Server 2 sedang kosong.\nKetik nama negara lain, atau coba Server 1.</blockquote>`, {
            parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅️ Ganti Layanan", callback_data: "o2_menu" }, { text: "⚡ Server 1", callback_data: "menu_otp" }]] }
        });
    }
    const totalStok = tingkat.reduce((s, t) => s + t.stok, 0);
    const tabel = `<table bordered striped compact>\n  <tr><th>Pilihan</th><th>Harga</th><th>Stok</th></tr>\n` +
        tingkat.map((t, i) => `  <tr><td>${i + 1}</td><td>${otpRp(t.harga)}</td><td>${otpStok(t.stok)}</td></tr>`).join("\n") + `\n</table>`;
    const rows = tingkat.map((t, i) => [{ text: `${i + 1}. ${otpRp(t.harga)} • stok ${otpStok(t.stok)}`, callback_data: `o2_t_${service}_${country}_${otp2Token(t)}` }]);
    rows.push([{ text: "🌍 Ganti Negara", callback_data: `o2_s_${service}` }, { text: "⬅️ Ganti Layanan", callback_data: "o2_menu" }]);
    return otpKirimRich(chatId, "💰 PILIH HARGA • SERVER 2", [
        ["Layanan", nama], ["Negara", namaNegara], ["Total Stok", otpStok(totalStok)]
    ], `${opsi.pesan ? `<p><b>${opsi.pesan}</b></p>\n` : ""}<p>Urut dari termurah. Kalau harga termurah habis, pilih harga berikutnya.</p>\n${tabel}`, rows);
}

async function otp2Konfirmasi(chatId, messageId, service, country, cost, pid) {
    const [tingkat, negara, nama] = await Promise.all([otp2TingkatHarga(service, country), otp2NegaraMap(), otp2NamaLayanan(service)]);
    const token = `${cost}_${pid || 0}`;
    const t = tingkat.find(x => otp2Token(x) === token) || tingkat.find(x => x.harga === otp2Harga(cost));
    if (messageId) await bot.deleteMessage(chatId, messageId).catch(() => {});
    if (!t) {
        return bot.sendMessage(chatId, "<blockquote>😔 Harga ini baru saja habis. Silakan pilih harga lain.</blockquote>", {
            parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅️ Pilihan Harga", callback_data: `o2_n_${service}_${country}` }]] }
        });
    }
    const tk = otp2Token(t);
    const rows = [
        [{ text: "⚡ Bayar QRIS 1 (Fast)", callback_data: `o2_q_${service}_${country}_${tk}`, style: "success" }],
        [{ text: "💳 Bayar Pakai Saldo", callback_data: `o2_b_${service}_${country}_${tk}`, style: "primary" }],
        [{ text: "⬅️ Pilihan Harga", callback_data: `o2_n_${service}_${country}` }]
    ];
    return otpKirimRich(chatId, "🧾 KONFIRMASI ORDER OTP • SERVER 2", [
        ["Layanan", nama], ["Negara", negara[country] || country], ["Stok", otpStok(t.stok)], ["Harga", `<b>${otpRp(t.harga)}</b>`]
    ], "", rows, "Pilih metode pembayaran. Nomor dibuat otomatis setelah pembayaran berhasil.");
}

function otp2TawarkanHargaLain(chatId, service, country, cost, pid) {
    return otp2TampilHarga(chatId, null, service, country, { kecuali: `${cost}_${pid || 0}`, pesan: `⚠️ Nomor di harga ${otpRp(otp2Harga(cost))} sedang tidak tersedia. Pilih harga lain:` })
        .catch(e => console.log("[OTP2] gagal tampil harga lain:", e.message));
}

// Beli nomor & buat order. Lempar Error(kode) kalau gagal; pemanggil yang mengembalikan dana.
async function otp2AmbilNomor({ userId, chatId, service, country, cost, pid, harga, username }) {
    const params = { service, country: String(country), maxPrice: cost };
    if (pid) params.providerIds = String(pid); // pilihan harga dari provider tertentu
    const res = await otp2Api("getNumberV2", params);
    const err = heroErr(res);
    if (err || !res || !res.activationId) {
        const kode = err || "UNKNOWN";
        otp2LaporAdmin(kode, res && res.details);
        const e = new Error(kode);
        e.teksUser = OTP2_ERR_TEKS[kode] || `Gagal mengambil nomor (${kode}).`;
        throw e;
    }
    const negara = await otp2NegaraMap().catch(() => ({}));
    const o = {
        id: String(res.activationId), userId, chatId,
        phone: String(res.phoneNumber),
        service, serviceName: await otp2NamaLayanan(service),
        country: String(country), countryName: negara[country] || String(country),
        harga, cost: Number(res.activationCost) || cost,
        endTime: Date.parse(res.activationEndTime) || Date.now() + otp2Cfg().masaAktifMenit * 60 * 1000,
        codes: [], status: "WAIT", refunded: false, messageId: null, username: username || "User", incomeLogged: false
    };
    o.messageId = await otpKirimPesanOrder(o, "2");
    otp2Orders.set(o.id, o);
    otp2Simpan();
    otp2MulaiPantau(o);
    // Log income admin baru dikirim setelah OTP diterima (otpKirimSukses)
    return o;
}

async function otp2BeliSaldo(query, service, country, cost, pid) {
    const userId = query.from.id;
    const chatId = query.message.chat.id;
    if (otp2BeliLock.has(userId)) return bot.answerCallbackQuery(query.id, { text: "⏳ Pesanan sebelumnya masih diproses...", show_alert: true });
    otp2BeliLock.add(userId);
    const harga = otp2Harga(cost);
    const tk = `${cost}_${pid || 0}`;
    let dipotong = 0;
    try {
        await bot.answerCallbackQuery(query.id, { text: "Memproses..." }).catch(() => {});
        const potong = await potongSaldoReal(userId, harga, `Order OTP S2 ${service}/${country}`);
        if (!potong || !potong.status) {
            return bot.sendMessage(chatId, `❌ Pembayaran saldo gagal: ${(potong && (potong.msg || potong.message)) || "saldo tidak cukup"}\n💰 Harga: ${otpRp(harga)}\n\nBayar langsung pakai QRIS, atau top up saldo dulu.`, {
                reply_markup: { inline_keyboard: [
                    [{ text: "⚡ Bayar QRIS 1 (Fast)", callback_data: `o2_q_${service}_${country}_${tk}`, style: "success" }],
                    [{ text: "➕ Top Up Saldo", callback_data: "menu_deposit", style: "success" }]
                ] }
            });
        }
        dipotong = harga;
        await bot.deleteMessage(chatId, query.message.message_id).catch(() => {});
        await otp2AmbilNomor({ userId, chatId, service, country, cost, pid, harga, username: otpNamaUser(query.from) });
        dipotong = 0;
    } catch (e) {
        console.log("[OTP2] beli gagal:", e.message);
        if (dipotong) {
            const r = await refundSaldoReal(userId, dipotong, `Refund OTP S2 gagal beli - ${e.message}`).catch(() => ({ status: false }));
            if (!r || !r.status) bot.sendMessage(settings.adminId, `⚠️ REFUND OTP SERVER 2 GAGAL user ${userId} ${otpRp(dipotong)}: ${e.message}`).catch(() => {});
            await bot.sendMessage(chatId, `❌ ${e.teksUser || "Terjadi kesalahan."}\n${r && r.status ? "Saldo sudah dikembalikan." : "Admin akan mengembalikan saldo manual."}`).catch(() => {});
            if (OTP2_HABIS_DI_HARGA.includes(e.message)) await otp2TawarkanHargaLain(chatId, service, country, cost, pid);
        } else {
            bot.sendMessage(chatId, `⚠️ ${e.teksUser || "Terjadi kesalahan, coba lagi nanti."}`).catch(() => {});
        }
    } finally {
        otp2BeliLock.delete(userId);
    }
}

// QRIS 1: sesi type "otp2" -> pay_qris_tripay -> setelah PAID handlePaymentSuccess -> otp2AmbilNomor
async function otp2BayarQris(query, service, country, cost, pid) {
    const userId = query.from.id;
    const chatId = query.message.chat.id;
    const [nama, negara] = await Promise.all([otp2NamaLayanan(service), otp2NegaraMap().catch(() => ({}))]);
    userSessions[userId] = {
        type: "otp2", service, country: String(country), cost, pid: pid || undefined, harga: otp2Harga(cost),
        paket: `OTP ${nama} - ${negara[country] || country} (Server 2)`, userId, chatId, tgUser: otpNamaUser(query.from)
    };
    return bot.emit("callback_query", { ...query, data: "pay_qris_tripay" });
}

async function otp2Aksi(query, aksi, id) {
    const o = otp2Orders.get(id);
    const jawab = (text, alert = true) => bot.answerCallbackQuery(query.id, { text, show_alert: alert }).catch(() => {});
    if (!o) return jawab("Pesanan ini sudah selesai / tidak ditemukan.");
    if (String(o.userId) !== String(query.from.id)) return jawab("Ini bukan pesanan kamu.");
    if (aksi === "k") {
        await otp2CekStatus(o);
        return jawab(o.codes.length ? `🔑 Kode: ${o.codes[o.codes.length - 1]}` : "⏳ SMS belum masuk, tunggu sebentar ya.");
    }
    if (aksi === "x") {
        if (o.codes.length) return jawab("Kode sudah diterima, pesanan tidak bisa dibatalkan.");
        const res = await otp2Api("setStatus", { id, status: 8 }).catch(e => e.message);
        if (res === "ACCESS_CANCEL" || res === "ACCESS_CANCEL_ALREADY") {
            otp2Selesai(o, "CANCEL");
            await otpGantiPesanOrder(o, "2", { akhir: "❌ <b>Pesanan dibatalkan.</b> Dana dikembalikan ke saldo akun.", markup: otpTombolPesanLagi(`o2_n_${o.service}_${o.country}`) });
            await otp2Refund(o, "dibatalkan");
            return jawab("Pesanan dibatalkan, saldo dikembalikan.", false);
        }
        const err = heroErr(res);
        if (err === "EARLY_CANCEL_DENIED") return jawab("Pembatalan baru bisa beberapa menit setelah nomor dibuat. Coba lagi sebentar.");
        return jawab(`Gagal membatalkan (${err || res}). Coba lagi sebentar.`);
    }
    if (aksi === "r") {
        const res = await otp2Api("setStatus", { id, status: 3 }).catch(e => e.message);
        if (res === "ACCESS_RETRY_GET") {
            o.status = "WAIT";
            otp2Simpan();
            otp2MulaiPantau(o);
            await otp2UpdatePesan(o);
            return jawab("Menunggu SMS baru, akan muncul otomatis...", false);
        }
        return jawab(`Tidak bisa minta SMS lagi (${heroErr(res) || res}).`);
    }
    if (aksi === "f") {
        await otp2Api("setStatus", { id, status: 6 }).catch(() => {});
        otp2Selesai(o, "DONE");
        await otpGantiPesanOrder(o, "2", { akhir: otpStatusTeks(o) + "\n\n✅ <b>Selesai. Terima kasih!</b>", markup: null });
        return jawab("Pesanan selesai.", false);
    }
}

bot.on("callback_query", async (query) => {
    const data = query.data || "";
    if (data !== "pilih_otp_server" && !data.startsWith("o2_")) return;
    if (menuTertutupUntuk(data, query.from.id)) return; // info maintenance dikirim handler utama
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;
    const userId = query.from.id;
    try {
        if (data === "pilih_otp_server") {
            await bot.answerCallbackQuery(query.id).catch(() => {});
            return await otpPilihServer(chatId, messageId);
        }
        if (data === "o2_menu") {
            await bot.answerCallbackQuery(query.id).catch(() => {});
            return await otp2TampilMenu(chatId, messageId);
        }
        if (!otp2Cfg().apiKey) return bot.answerCallbackQuery(query.id, { text: "Server 2 belum aktif.", show_alert: true });
        if (data === "o2_cari") {
            await bot.answerCallbackQuery(query.id).catch(() => {});
            userSessions[chatId] = { type: "otp2", step: "otp2_search" };
            return bot.sendMessage(chatId, "🔎 Ketik nama aplikasi yang dicari (Server 2), contoh: <code>shopee</code>, <code>gojek</code>, <code>dana</code>:", { parse_mode: "HTML" });
        }
        if (data === "o2_aktif") {
            const aktif = [...otp2Orders.values()].filter(o => String(o.userId) === String(userId));
            await bot.answerCallbackQuery(query.id).catch(() => {});
            if (!aktif.length) return bot.sendMessage(chatId, "Tidak ada pesanan OTP Server 2 yang aktif.");
            for (const o of aktif) {
                o.messageId = await otpKirimPesanOrder(o, "2");
            }
            return otp2Simpan();
        }
        let m;
        if ((m = data.match(/^o2_s_([a-z0-9]+)$/i))) {
            await bot.answerCallbackQuery(query.id).catch(() => {});
            return await otp2MintaNegara(chatId, messageId, m[1]);
        }
        if ((m = data.match(/^o2_n_([a-z0-9]+)_(\d+)$/i))) {
            await bot.answerCallbackQuery(query.id, { text: "Mengambil harga..." }).catch(() => {});
            return await otp2TampilHarga(chatId, messageId, m[1], m[2]);
        }
        if ((m = data.match(/^o2_t_([a-z0-9]+)_(\d+)_([\d.]+)_(\d+)$/i))) {
            await bot.answerCallbackQuery(query.id).catch(() => {});
            return await otp2Konfirmasi(chatId, messageId, m[1], m[2], Number(m[3]), m[4] !== "0" ? m[4] : undefined);
        }
        if ((m = data.match(/^o2_b_([a-z0-9]+)_(\d+)_([\d.]+)_(\d+)$/i))) return await otp2BeliSaldo(query, m[1], m[2], Number(m[3]), m[4] !== "0" ? m[4] : undefined);
        if ((m = data.match(/^o2_q_([a-z0-9]+)_(\d+)_([\d.]+)_(\d+)$/i))) return await otp2BayarQris(query, m[1], m[2], Number(m[3]), m[4] !== "0" ? m[4] : undefined);
        if ((m = data.match(/^o2_([kxrf])_(\d+)$/))) return await otp2Aksi(query, m[1], m[2]);
        return bot.answerCallbackQuery(query.id, { text: "Menu ini sudah kedaluwarsa, buka ulang Nomor OTP.", show_alert: true });
    } catch (e) {
        const kode = String(e.message || "").split(":")[0];
        console.log("[OTP2] callback error:", e.message);
        otp2LaporAdmin(kode, e.message);
        bot.answerCallbackQuery(query.id, { text: "⚠️ " + (OTP2_ERR_TEKS[kode] || "Server 2 tidak merespons, coba lagi atau pakai Server 1."), show_alert: true }).catch(() => {});
    }
});

bot.on("message", async (msg) => {
    const chatId = msg.chat.id;
    const s = userSessions[chatId];
    if (!s || s.type !== "otp2" || !["otp2_search", "otp2_negara"].includes(s.step) || !msg.text || msg.text.startsWith("/")) return;
    const ketik = msg.text.trim();
    const aman = ketik.replace(/[<>&]/g, "");
    try {
        if (s.step === "otp2_search") {
            delete userSessions[chatId];
            const kata = ketik.toLowerCase();
            const hasil = (await otp2DaftarLayanan()).filter(x => String(x.code).toLowerCase() === kata || String(x.name).toLowerCase().includes(kata)).slice(0, 10);
            if (!hasil.length) {
                return bot.sendMessage(chatId, `Layanan "<b>${aman}</b>" tidak ditemukan di Server 2.`, {
                    parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "🔎 Cari Lagi", callback_data: "o2_cari" }, { text: "⬅️ Menu Server 2", callback_data: "o2_menu" }]] }
                });
            }
            const baris = hasil.map(x => [{ text: x.name, callback_data: `o2_s_${x.code}` }]);
            baris.push([{ text: "⬅️ Menu Server 2", callback_data: "o2_menu" }]);
            return bot.sendMessage(chatId, `🔎 Hasil pencarian "${aman}" (Server 2):`, { reply_markup: { inline_keyboard: baris } });
        }
        const cocok = otpCariNegara(await otp2NegaraMap(), ketik);
        if (!cocok.length) {
            return bot.sendMessage(chatId, `Negara "<b>${aman}</b>" tidak ditemukan. Coba ketik nama dalam bahasa Inggris, contoh: <code>malaysia</code>, <code>united kingdom</code>.`, { parse_mode: "HTML" });
        }
        if (cocok.length > 1) {
            const baris = cocok.map(n => [{ text: n.nama, callback_data: `o2_n_${s.service}_${n.id}` }]);
            baris.push([{ text: "⬅️ Ganti Layanan", callback_data: "o2_menu" }]);
            return bot.sendMessage(chatId, `Ada beberapa negara yang cocok dengan "${aman}", pilih salah satu:`, { reply_markup: { inline_keyboard: baris } });
        }
        delete userSessions[chatId];
        return await otp2TampilHarga(chatId, null, s.service, cocok[0].id);
    } catch (e) {
        const kode = String(e.message || "").split(":")[0];
        otp2LaporAdmin(kode, e.message);
        bot.sendMessage(chatId, "⚠️ " + (OTP2_ERR_TEKS[kode] || "Server 2 tidak merespons, coba lagi atau pakai Server 1."));
    }
});

//fitur broadcast
// Fungsi Jeda Waktu (Taruh di paling atas file index.js mu jika belum ada, abaikan jika sudah ada)
// ==========================================
// COMMAND BROADCAST (SUPPORT MULTI-LINE / ENTER)
// ==========================================
// PERHATIKAN BARIS DI BAWAH INI, REGEX-NYA SUDAH KU UBAH:
// ==========================================
// BROADCAST RICH MESSAGE (/broadcast & /broadcastpin)
// ==========================================
// Isi pesan = Rich HTML Telegram (sendRichMessage). Ketik /broadcast atau /broadcastpin
// tanpa teks untuk melihat panduan + contoh. Pratinjau dikirim ke admin dulu; kalau HTML
// ditolak Telegram, broadcast dibatalkan sebelum sampai ke user.
const BC_CONTOH = `<h3>🔥 Promo Akhir Pekan</h3>
<p>Diskon <b>30%</b> untuk semua <u>VPS NAT</u> sampai <i>Minggu</i>!</p>
<hr/>
<table bordered striped>
  <tr><th>Paket</th><th>Harga</th></tr>
  <tr><td>NAT 1GB</td><td>Rp 15.000</td></tr>
  <tr><td>NAT 2GB</td><td>Rp 25.000</td></tr>
</table>
<ul>
  <li><input type="checkbox" checked>Aktif instan</li>
  <li><input type="checkbox" checked>Garansi 30 hari</li>
</ul>
<details>
  <summary>Syarat &amp; Ketentuan</summary>
  <p>Berlaku untuk pembelian baru. Kode: <code>NAT30</code></p>
</details>
<blockquote>Info lengkap di <a href="https://boosteryuk.com">boosteryuk.com</a></blockquote>
#tombol 🖥 Beli VPS | menu_vps
#tombol 🌐 Website | https://boosteryuk.com`;

const bcEscape = t => String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

function bcPanduan(cmd) {
    const pin = cmd === "/broadcastpin";
    return `<b>📢 PANDUAN ${cmd.toUpperCase()}</b>\n` +
        (pin ? `Pesan dikirim ke semua user <b>lalu di-pin</b> di chat mereka.\n\n` : `Pesan dikirim ke semua user.\n\n`) +
        `<b>Cara pakai:</b>\n<code>${cmd} isi pesan</code>\n` +
        `Isi pesan boleh teks biasa (enter tetap jadi baris baru) atau <b>Rich HTML</b>.\n\n` +
        `<b>Tag yang bisa dipakai:</b>\n` +
        `• Judul: <code>&lt;h1&gt;</code> s/d <code>&lt;h6&gt;</code>\n` +
        `• Paragraf: <code>&lt;p&gt;</code>, baris baru <code>&lt;br&gt;</code>, garis <code>&lt;hr/&gt;</code>\n` +
        `• Teks: <code>&lt;b&gt; &lt;i&gt; &lt;u&gt; &lt;s&gt; &lt;code&gt; &lt;mark&gt; &lt;tg-spoiler&gt;</code>\n` +
        `• Link: <code>&lt;a href="https://..."&gt;teks&lt;/a&gt;</code>\n` +
        `• Kutipan: <code>&lt;blockquote&gt;</code>\n` +
        `• Daftar: <code>&lt;ul&gt;/&lt;ol&gt;</code> + <code>&lt;li&gt;</code>, ceklis <code>&lt;li&gt;&lt;input type="checkbox" checked&gt;</code>\n` +
        `• Tabel: <code>&lt;table bordered striped&gt;</code> + <code>&lt;tr&gt; &lt;th&gt; &lt;td&gt;</code>\n` +
        `• Buka-tutup: <code>&lt;details&gt;&lt;summary&gt;Judul&lt;/summary&gt;...&lt;/details&gt;</code>\n` +
        `• Gambar: <code>&lt;img src="https://link-gambar.jpg"/&gt;</code>\n\n` +
        `<b>Tombol</b> (opsional, satu baris satu tombol, ditaruh di akhir):\n` +
        `<code>#tombol Teks | menu_vps</code>  → buka menu bot\n` +
        `<code>#tombol Teks | https://link</code>  → buka link\n` +
        `Tanpa #tombol, otomatis pakai tombol Beli VPS & Beli Panel.\n\n` +
        `<b>Penting:</b> tulis <code>&amp;amp;</code> untuk simbol &amp;, <code>&amp;lt;</code> untuk &lt;. ` +
        `Pratinjau dikirim ke kamu dulu; kalau formatnya salah, broadcast dibatalkan.\n\n` +
        `<b>Contoh lengkap</b> (salin semua lalu kirim):\n<pre>${bcEscape(`${cmd} ${BC_CONTOH}`)}</pre>`;
}

// Pisahkan baris "#tombol Teks | target" dari isi pesan
function bcParse(raw) {
    const tombol = [];
    const isi = [];
    for (const line of String(raw).split("\n")) {
        const m = line.match(/^\s*#tombol\s+(.+?)\s*\|\s*(\S+)\s*$/i);
        if (m) tombol.push(/^https?:\/\//i.test(m[2]) ? { text: m[1], url: m[2] } : { text: m[1], callback_data: m[2].slice(0, 64) });
        else isi.push(line);
    }
    let body = isi.join("\n").trim();
    // Teks biasa tanpa tag: amankan simbol & ubah enter jadi baris baru
    if (!/<[a-z][\s\S]*>/i.test(body)) {
        body = body.split(/\n{2,}/).map(par => `<p>${bcEscape(par).replace(/\n/g, "<br>")}</p>`).join("\n");
    }
    const rows = [];
    for (let i = 0; i < tombol.length; i += 2) rows.push(tombol.slice(i, i + 2));
    return { body, rows };
}

async function bcKirimRich(chatId, html, rows) {
    try {
        return await sendRichMessage(chatId, html, { reply_markup: { inline_keyboard: rows } });
    } catch (e) {
        const tunggu = Number((e.message.match(/retry after (\d+)/i) || [])[1]);
        if (!tunggu) throw e;
        await delay((tunggu + 1) * 1000); // kena limit Telegram: tunggu lalu coba sekali lagi
        return sendRichMessage(chatId, html, { reply_markup: { inline_keyboard: rows } });
    }
}

async function jalankanBroadcast(msg, raw, pin) {
    const chatId = msg.chat.id;
    const cmd = pin ? "/broadcastpin" : "/broadcast";
    if (String(chatId) !== String(settings.adminId)) {
        return bot.sendMessage(chatId, "⚠️ Akses Ditolak. Command ini khusus Admin.");
    }
    if (!raw || !raw.trim()) {
        await bot.sendMessage(chatId, bcPanduan(cmd), { parse_mode: "HTML" });
        const contoh = bcParse(BC_CONTOH);
        return bcKirimRich(chatId, `<p><i>⬇️ Hasil contoh di atas:</i></p>\n${contoh.body}`, contoh.rows)
            .catch(e => bot.sendMessage(chatId, `⚠️ Pratinjau contoh gagal: ${e.message}`));
    }

    const users = getUsers();
    const userIds = (Array.isArray(users) ? users : Object.keys(users)).filter(id => String(id) !== String(chatId));
    if (userIds.length === 0) return bot.sendMessage(chatId, "⚠️ Belum ada user di database.");

    const now = new Date();
    const tanggalStr = now.toLocaleDateString("id-ID", { timeZone: "Asia/Jakarta", day: "2-digit", month: "long", year: "numeric" });
    const jamStr = now.toLocaleTimeString("id-ID", { timeZone: "Asia/Jakarta", hour: "2-digit", minute: "2-digit", hour12: false }).replace(/\./g, ":");

    const { body, rows } = bcParse(raw);
    const judul = pin ? "📌 PENGUMUMAN PENTING" : "📢 INFORMASI TERBARU";
    const html = `<h3>${judul}</h3>\n<hr/>\n${body}\n<hr/>\n<footer>📅 Diterbitkan: ${tanggalStr} | ${jamStr} WIB</footer>`;
    const tombol = rows.length ? rows : [[
        { text: "🖥 𝘉𝘦𝘭𝘪 𝘝𝘗𝘚", callback_data: "menu_vps", style: "success" },
        { text: "📡 𝘉𝘦𝘭𝘪 𝘗𝘢𝘯𝘦𝘭", callback_data: "menu_panel", style: "success" }
    ]];

    // 1. Pratinjau ke admin = validasi format
    try {
        await bcKirimRich(chatId, html, tombol);
    } catch (e) {
        return bot.sendMessage(chatId, `❌ <b>Broadcast dibatalkan</b>, format ditolak Telegram:\n<code>${bcEscape(e.message)}</code>\n\nKetik <code>${cmd}</code> tanpa teks untuk melihat panduan.`, { parse_mode: "HTML" });
    }

    await bot.sendMessage(chatId, `⏳ Pratinjau di atas sedang dikirim${pin ? " & di-pin" : ""} ke <b>${userIds.length}</b> user...`, { parse_mode: "HTML" });

    let sukses = 0, gagal = 0, blokir = 0;
    for (const userId of userIds) {
        try {
            const sent = await bcKirimRich(userId, html, tombol);
            if (pin && sent && sent.message_id) await bot.pinChatMessage(userId, sent.message_id).catch(() => {});
            sukses++;
        } catch (e) {
            if (/blocked|deactivated|chat not found/i.test(e.message)) blokir++; else gagal++;
        }
        // ±20 pesan/detik, di bawah batas Telegram 30/detik (pin = 2 aksi, jadi lebih lambat)
        await delay(pin ? 100 : 50);
    }

    bot.sendMessage(chatId, `<blockquote>✅ <b>Broadcast${pin ? " & Pin" : ""} Selesai!</b>\n━━━━━━━━━━━━━━━━━━\n\n` +
        `🟢 Terkirim: ${sukses} user\n🚫 Blokir/akun hapus: ${blokir} user\n🔴 Gagal lain: ${gagal} user</blockquote>`, { parse_mode: "HTML" });
}

bot.onText(/^\/broadcast(?:@\w+)?(?:\s+([\s\S]+))?$/, (msg, match) => jalankanBroadcast(msg, match[1], false));
bot.onText(/^\/broadcastpin(?:@\w+)?(?:\s+([\s\S]+))?$/, (msg, match) => jalankanBroadcast(msg, match[1], true));

// ====================================================
// TUTUP / BUKA MENU (MAINTENANCE) + KONVERSI VOICE
// ====================================================
// /tutupmenu <menu> [keterangan] -> menu ditutup + broadcast pin ke semua user.
// Saat ditutup, semua tombol menu itu (termasuk sub-tombol & pembayaran ordernya) hanya
// membalas "menu sedang ditutup" + voice note voice/maintenance.ogg. Berlaku untuk semua orang, termasuk admin.
const MENU_TUTUP_FILE = path.join(__dirname, "database", "menu_tutup.json"); // absolut: tidak tergantung folder tempat pm2 dijalankan
const MENU_GRUP = {
    panel:      { nama: "Beli Panel",          exact: ["menu_panel"], prefix: ["buy_", "confirmbuy_", "klaimvc_", "paket_"], tipe: ["panel"] },
    vps:        { nama: "Beli VPS",            exact: ["menu_vps", "check_vps_stock"], prefix: ["confvps_", "os_page_"], tipe: ["vps", "vps_dedicated", "vps_shared"] },
    otp:        { nama: "Nomor OTP",           exact: ["menu_otp", "pilih_otp_server"], prefix: ["otp_", "o2_"], tipe: ["otp", "otp2"] },
    smm:        { nama: "SMM Panel",           exact: ["smm", "smm_pilih_kategori", "kat", "sks|"], prefix: ["sk|", "k|", "t|", "o|", "c|", "back|", "smo_"], tipe: ["smm", "smm_order"] },
    patungan:   { nama: "Patungan VPS",        exact: ["menu_patungan"], prefix: ["p_"], tipe: ["patungan"] },
    install:    { nama: "Install VPS",         exact: ["menu_autoinstall", "buy_jasa_install", "confirminstall_ready"], prefix: [], tipe: ["jasa_install"] },
    rental:     { nama: "Rental Panel",        exact: ["menu_hourly"], prefix: [], tipe: ["hourly"] },
    trial:      { nama: "Trial Panel",         exact: ["menu_trial", "start_trial_now"], prefix: [], tipe: [] },
    pet:        { nama: "Adopsi Pet",          exact: ["menu_pet", "pick_egg", "pick_cat", "pick_tree", "feed_pet", "drink_pet"], prefix: [], tipe: [] },
    freelance:  { nama: "Freelance",           exact: ["menu_freelance", "menu_withdraw", "withdraw_wallet", "withdraw_qris"], prefix: ["campaign_", "do_"], tipe: [] },
    deposit:    { nama: "Top Up / Deposit",    exact: ["menu_deposit"], prefix: [], tipe: ["deposit"] },
    gacha:      { nama: "Gacha Harian",        exact: ["menu_gacha", "roll_gacha"], prefix: [], tipe: [] },
    perpanjang: { nama: "Perpanjang Server",   exact: ["extend_list"], prefix: ["ext_"], tipe: ["extend"] }
};
const MENU_ALIAS = { topup: "deposit", depo: "deposit", nomorotp: "otp", sms: "otp", smmpanel: "smm", autoinstall: "install", jasainstall: "install", hourly: "rental", sewa: "rental", extend: "perpanjang" };
const MENU_BAYAR = ["pay_via_saldo", "pay_qris_tripay", "pay_crypto_heleket"];

function bacaMenuTutup() {
    try { return fs.existsSync(MENU_TUTUP_FILE) ? JSON.parse(fs.readFileSync(MENU_TUTUP_FILE, "utf8")) || {} : {}; }
    catch { return {}; }
}
function simpanMenuTutup(data) {
    try {
        fs.mkdirSync(path.dirname(MENU_TUTUP_FILE), { recursive: true });
        fs.writeFileSync(MENU_TUTUP_FILE, JSON.stringify(data, null, 2));
        return true;
    } catch (e) {
        console.log("Gagal simpan menu_tutup:", e.message);
        return false;
    }
}
function kunciMenu(nama) {
    const k = String(nama || "").toLowerCase().replace(/[^a-z]/g, "");
    return MENU_GRUP[k] ? k : (MENU_ALIAS[k] || null);
}
// callback_data (+ sesi untuk tombol bayar) -> kunci menu, atau null
function menuDariCallback(data, session) {
    if (!data) return null;
    if (MENU_BAYAR.includes(data) || data.startsWith("qr_server_")) {
        const tipe = session && String(session.type || "");
        if (!tipe) return null;
        return Object.keys(MENU_GRUP).find(k => MENU_GRUP[k].tipe.includes(tipe) || (k === "vps" && tipe.startsWith("vps_"))) || null;
    }
    for (const [k, g] of Object.entries(MENU_GRUP)) if (g.exact.includes(data)) return k;
    for (const [k, g] of Object.entries(MENU_GRUP)) if (g.prefix.some(p => data.startsWith(p))) return k;
    return null;
}
// Kunci menu yang sedang ditutup untuk callback ini (null = boleh lewat). Berlaku juga untuk admin.
function menuTertutupUntuk(data, userId, session) {
    const k = menuDariCallback(data, session);
    return k && bacaMenuTutup()[k] ? k : null;
}

const voiceMaintenanceTerakhir = new Map(); // userId -> waktu kirim terakhir (anti spam voice)
async function kirimInfoMenuTutup(chatId, kunci) {
    const g = MENU_GRUP[kunci] || { nama: kunci };
    const info = bacaMenuTutup()[kunci] || {};
    await bot.sendMessage(chatId, `<blockquote>🔧 <b>MENU ${g.nama.toUpperCase()} SEDANG DITUTUP</b>\n\nLayanan sedang <b>Maintenance</b>.` +
        (info.keterangan ? `\n📝 ${String(info.keterangan).replace(/[<>&]/g, "")}` : "") +
        `\n\nSilakan coba lagi nanti. Menu lain tetap bisa digunakan.</blockquote>`, {
        parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅️ Kembali", callback_data: "back_to_main", style: "success" }]] }
    }).catch(() => {});
    const terakhir = voiceMaintenanceTerakhir.get(String(chatId)) || 0;
    if (Date.now() - terakhir < 60 * 1000) return; // voice maksimal 1x per menit per user
    voiceMaintenanceTerakhir.set(String(chatId), Date.now());
    const file = path.join(__dirname, "voice", "maintenance.ogg");
    if (fs.existsSync(file)) await bot.sendVoice(chatId, file).catch(e => console.log("Voice maintenance gagal:", e.message));
}

function daftarMenuTeks() {
    const tutup = bacaMenuTutup();
    return Object.entries(MENU_GRUP).map(([k, g]) => `${tutup[k] ? "🔴" : "🟢"} <code>${k}</code> — ${g.nama}${tutup[k] ? " (ditutup)" : ""}`).join("\n");
}

bot.onText(/^\/tutupmenu(?:@\w+)?(?:\s+(\S+))?(?:\s+([\s\S]+))?$/, async (msg, match) => {
    const chatId = msg.chat.id;
    if (String(chatId) !== String(settings.adminId)) return bot.sendMessage(chatId, "⚠️ Akses Ditolak. Command ini khusus Admin.");
    if (!match[1]) {
        return bot.sendMessage(chatId, `<b>🔧 TUTUP MENU (MAINTENANCE)</b>\n\nCara pakai:\n<code>/tutupmenu panel</code>\n<code>/tutupmenu vps Upgrade server sampai jam 22.00</code>\n\nMenu ditutup, lalu pengumuman di-broadcast & di-pin ke semua user. Buka lagi dengan <code>/bukamenu panel</code>.\n\n<b>Daftar menu:</b>\n${daftarMenuTeks()}`, { parse_mode: "HTML" });
    }
    const kunci = kunciMenu(match[1]);
    if (!kunci) return bot.sendMessage(chatId, `❌ Menu "<b>${String(match[1]).replace(/[<>&]/g, "")}</b>" tidak dikenal.\n\n${daftarMenuTeks()}`, { parse_mode: "HTML" });
    const keterangan = (match[2] || "").trim();
    const data = bacaMenuTutup();
    data[kunci] = { sejak: new Date().toISOString(), keterangan };
    if (!simpanMenuTutup(data)) { // tutup dulu, baru umumkan
        return bot.sendMessage(chatId, `❌ Gagal menyimpan status menu ke ${MENU_TUTUP_FILE}. Menu BELUM ditutup dan broadcast dibatalkan. Cek izin folder database.`);
    }
    if (!bacaMenuTutup()[kunci]) {
        return bot.sendMessage(chatId, `❌ Status menu tidak terbaca ulang dari ${MENU_TUTUP_FILE}. Menu BELUM ditutup dan broadcast dibatalkan.`);
    }
    const nama = MENU_GRUP[kunci].nama;
    if (!fs.existsSync(path.join(__dirname, "voice", "maintenance.ogg"))) {
        bot.sendMessage(chatId, "ℹ️ voice/maintenance.ogg belum ada, jadi user hanya menerima teks. Buat dengan /konversivoice.").catch(() => {});
    }
    const isi = `<p>🔧 Layanan <b>${nama}</b> sedang <b>maintenance</b> dan untuk sementara akan <b>ditutup</b>.</p>\n` +
        (keterangan ? `<p>📝 ${bcEscape(keterangan)}</p>\n` : "") +
        `<p>Menu ${nama} tidak bisa dibuka sampai ada pemberitahuan berikutnya. Layanan lain tetap berjalan normal.</p>\n` +
        `<p><i>Mohon maaf atas ketidaknyamanannya 🙏</i></p>\n#tombol 🏠 Menu Utama | mainmenu`;
    await jalankanBroadcast(msg, isi, true);
});

bot.onText(/^\/bukamenu(?:@\w+)?(?:\s+(\S+))?(?:\s+(umumkan))?\s*$/i, async (msg, match) => {
    const chatId = msg.chat.id;
    if (String(chatId) !== String(settings.adminId)) return bot.sendMessage(chatId, "⚠️ Akses Ditolak. Command ini khusus Admin.");
    if (!match[1]) {
        return bot.sendMessage(chatId, `Cara pakai: <code>/bukamenu panel</code>\nTambahkan <code>umumkan</code> untuk broadcast bahwa menu sudah dibuka lagi.\n\n${daftarMenuTeks()}`, { parse_mode: "HTML" });
    }
    const kunci = kunciMenu(match[1]);
    if (!kunci) return bot.sendMessage(chatId, `❌ Menu tidak dikenal.\n\n${daftarMenuTeks()}`, { parse_mode: "HTML" });
    const data = bacaMenuTutup();
    if (!data[kunci]) return bot.sendMessage(chatId, `ℹ️ Menu <b>${MENU_GRUP[kunci].nama}</b> memang sedang terbuka.`, { parse_mode: "HTML" });
    delete data[kunci];
    if (!simpanMenuTutup(data)) return bot.sendMessage(chatId, `❌ Gagal menyimpan status menu ke ${MENU_TUTUP_FILE}. Menu masih tertutup.`);
    await bot.sendMessage(chatId, `✅ Menu <b>${MENU_GRUP[kunci].nama}</b> dibuka kembali.`, { parse_mode: "HTML" });
    if (match[2]) {
        await jalankanBroadcast(msg, `<p>✅ Layanan <b>${MENU_GRUP[kunci].nama}</b> sudah <b>normal kembali</b> dan bisa digunakan lagi.</p>\n<p>Terima kasih sudah menunggu 🙏</p>\n#tombol 🏠 Menu Utama | mainmenu`, false);
    }
});

// /konversivoice: ubah audio (wav/mp3/m4a/ogg) jadi voice note Telegram (OGG/Opus mono 48 kHz, sama seperti voice/welcome.ogg)
//  - balas (reply) pesan audio/voice/file dengan: /konversivoice maintenance
//  - atau file yang sudah ada di folder voice:   /konversivoice tts_1.wav maintenance
function konversiKeVoice(input, output) {
    return new Promise((resolve, reject) => {
        ffmpeg(input).noVideo().audioChannels(1).audioFrequency(48000).audioCodec("libopus").audioBitrate("32k")
            .outputOptions(["-application voip"]).format("ogg")
            .on("end", () => resolve(output)).on("error", reject).save(output);
    });
}
const namaFileAman = n => path.basename(String(n || "")).replace(/[^a-zA-Z0-9._-]/g, "");

bot.onText(/^\/konversivoice(?:@\w+)?(?:\s+(\S+))?(?:\s+(\S+))?\s*$/, async (msg, match) => {
    const chatId = msg.chat.id;
    if (String(chatId) !== String(settings.adminId)) return bot.sendMessage(chatId, "⚠️ Akses Ditolak. Command ini khusus Admin.");
    const voiceDir = path.join(__dirname, "voice");
    if (!fs.existsSync(voiceDir)) fs.mkdirSync(voiceDir, { recursive: true });
    const r = msg.reply_to_message;
    const media = r && (r.voice || r.audio || r.document);
    let sumber, namaOut;
    try {
        if (media) {
            namaOut = namaFileAman(match[1]) || "voice_" + Date.now();
            const unduhan = await bot.downloadFile(media.file_id, voiceDir); // API node-telegram-bot-api
            sumber = path.join(voiceDir, `_sumber_${Date.now()}`);
            fs.renameSync(unduhan, sumber);
        } else {
            if (!match[1]) {
                const daftar = fs.readdirSync(voiceDir).filter(x => !x.startsWith("_sumber_"));
                return bot.sendMessage(chatId, `<b>🎙 KONVERSI VOICE</b>\n\n1. Reply file audio/voice dengan:\n<code>/konversivoice maintenance</code>\n2. Atau file di folder voice:\n<code>/konversivoice tts_1.wav maintenance</code>\n\nHasil: <code>voice/&lt;nama&gt;.ogg</code> (OGG/Opus, siap dipakai bot).\n• <code>maintenance.ogg</code> dipakai saat menu ditutup\n• file .ogg lain diputar acak di /start\n\n<b>Isi folder voice:</b>\n${daftar.map(x => `• <code>${x}</code>`).join("\n") || "-"}`, { parse_mode: "HTML" });
            }
            const nama = namaFileAman(match[1]);
            sumber = path.join(voiceDir, nama);
            if (!fs.existsSync(sumber)) return bot.sendMessage(chatId, `❌ File voice/${nama} tidak ada.`);
            namaOut = namaFileAman(match[2]) || nama.replace(/\.[^.]+$/, "");
        }
        namaOut = namaOut.replace(/\.(ogg|oga)$/i, "");
        const hasil = path.join(voiceDir, `${namaOut}.ogg`);
        const sementara = path.join(voiceDir, `_konversi_${Date.now()}.ogg`);
        await bot.sendMessage(chatId, "⏳ Mengonversi...");
        await konversiKeVoice(sumber, sementara);
        fs.renameSync(sementara, hasil); // ganti file lama hanya kalau konversi berhasil
        await bot.sendVoice(chatId, hasil, { caption: `✅ Tersimpan: voice/${namaOut}.ogg` });
    } catch (e) {
        bot.sendMessage(chatId, `❌ Konversi gagal: ${e.message}\nPastikan ffmpeg terpasang di server (apt install ffmpeg).`);
    } finally {
        if (sumber && path.basename(sumber).startsWith("_sumber_")) fs.unlink(sumber, () => {});
    }
});

// cekid
bot.onText(/\/cekid/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const firstName = msg.from.first_name || '';
  const lastName = msg.from.last_name || '';
  const username = msg.from.username ? '@' + msg.from.username : 'Tidak ada';

  const caption = `\`\`\`👤\nUSERNAME : ${username}\nID : ${userId}\`\`\``;

  try {
    const userProfilePhotos = await bot.getUserProfilePhotos(userId, { limit: 1 });

    if (userProfilePhotos.total_count === 0) throw new Error("No profile photo");

    const fileId = userProfilePhotos.photos[0][0].file_id;

    await bot.sendPhoto(chatId, fileId, {
      caption: caption,
      parse_mode: 'Markdown',
      reply_to_message_id: msg.message_id,
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: `${firstName} ${lastName}`,
              url: `tg://user?id=${userId}`
            }
          ]
        ]
      }
    });
  } catch (err) {
    await bot.sendMessage(chatId, `ID : \`${userId}\``, {
      parse_mode: 'Markdown',
      reply_to_message_id: msg.message_id
    });
  }
});

//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// delprem
bot.onText(/\/delprem (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = match[1];
  if (msg.from.id.toString() === owner) {
    const index = premiumUsers.indexOf(userId);
    if (index !== -1) {
      premiumUsers.splice(index, 1);
      fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers));
      bot.sendMessage(
        chatId,
        `User ${userId} Tidak Dapet Mengakses Fitur Premium`
      );
    } else {
      bot.sendMessage(chatId, `User ${userId} is not a premium user.`);
    }
  } else {
    bot.sendMessage(chatId, "Only the owner can perform this action.");
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// addowner
bot.onText(/\/addowner (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = match[1];

  if (msg.from.id.toString() === owner) {
    if (!adminUsers.includes(userId)) {
      adminUsers.push(userId);
      fs.writeFileSync(adminfile, JSON.stringify(adminUsers));
      bot.sendMessage(
        chatId,
        `User ${userId} Dapet Mengakses Fitur Owner.`
      );
    } else {
      bot.sendMessage(chatId, `User ${userId} is already an admin user.`);
    }
  } else {
    bot.sendMessage(chatId, "Only the owner can perform this action.");
  }
});

//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// delowner
bot.onText(/\/delowner (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = match[1];

  if (msg.from.id.toString() === owner) {
    const index = adminUsers.indexOf(userId);
    if (index !== -1) {
      adminUsers.splice(index, 1);
      fs.writeFileSync(adminfile, JSON.stringify(adminUsers));
      bot.sendMessage(chatId, `User ${userId} Tidak Dapet Lagi Mengakses Fitur Owner`);
    } else {
      bot.sendMessage(chatId, `User ${userId} is not an admin user.`);
    }
  } else {
    bot.sendMessage(chatId, "Only the owner can perform this action.");
  }
});

bot.onText(/\/1gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, "KHUSUS PREMIUM ❌", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "BOT", url: "https://t.me/Panelkitalegalbot" }],
        ],
      },
    });
    return;
  }
  const t = text.split(",");
  if (t.length < 2) {
    bot.sendMessage(chatId, "Invalid format. Usage: /1gb namapanel,idtele");
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + "1gb";
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = "256";
  const cpu = "30";
  const disk = "1024";
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/npm start';
  const email = `${username}@Buyeradmin`;
  const akunlo = settings.pp;
  const password = `${username}001`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      // Tambahkan console.log agar kamu tau apa error aslinya di console
      console.log("Pterodactyl API Error:", data.errors); 

      if (
        data.errors[0]?.meta?.rule === "unique" &&
        data.errors[0]?.meta?.source_field === "email"
      ) {
        bot.sendMessage(
          chatId,
          "Email already exists. Please use a different email."
        );
      } else {
        bot.sendMessage(
          chatId,
          `Error: ${JSON.stringify(data.errors[0], null, 2)}`
        );
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_24",
        startup: spc,
        environment: {
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          MAIN_FILE: "index.js",
          NODE_PACKAGES: "",
          UNNODE_PACKAGES: "",
          GIT_ADDRESS: "",
          BRANCH: "",
          USERNAME: "",
          ACCESS_TOKEN: "",
          NODE_ARGS: ""
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });
const data2 = await response2.json();
    
    // Wajib ditambah agar kamu tau error dari Pterodactyl kalau gagal lagi
    if (data2.errors) {
       console.log("ALASAN SERVER 1GB GAGAL DIBUAT:", JSON.stringify(data2.errors, null, 2));
    }

    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(
      chatId,
      `BERIKUT DATA PANEL ANDA
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? "Unlimited" : server.limits.disk} MB
CPU: ${server.limits.cpu}%`
    );
    if (akunlo) {
      bot.sendAnimation(u, akunlo, {
        caption: `Hai @${u}

 |[ DATA PANEL KAMU ]|
🌐 Login : ${domain}
👤 Username : ${user.username}
🔐 Password : ${password} 
Jangan Ddos Server
Wajib tutup domain saat screenshot`,
      });
      bot.sendMessage(
        chatId,
        "Data panel berhasil dikirim ke ID Telegram yang dimaksud."
      );
    }
  } else {
    bot.sendMessage(chatId, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
// 2gb
bot.onText(/\/2gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, "KHUSUS PREMIUM ❌", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "BOT", url: "https://t.me/Panelkitalegalbot" }],
        ],
      },
    });
    return;
  }
  const t = text.split(",");
  if (t.length < 2) {
    bot.sendMessage(chatId, "Invalid format. Usage: /2gb namapanel,idtele");
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + "2gb";
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = "2048";
  const cpu = "60";
  const disk = "2048";
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/npm start';
  const email = `${username}_${u}@Buyeradmin`;
  const akunlo = settings.pp;
  const password = `${username}001`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      // Tambahkan console.log agar kamu tau apa error aslinya di console
      console.log("Pterodactyl API Error:", data.errors); 

      if (
        data.errors[0]?.meta?.rule === "unique" &&
        data.errors[0]?.meta?.source_field === "email"
      ) {
        bot.sendMessage(
          chatId,
          "Email already exists. Please use a different email."
        );
      } else {
        bot.sendMessage(
          chatId,
          `Error: ${JSON.stringify(data.errors[0], null, 2)}`
        );
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_24",
        startup: spc,
        environment: {
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          MAIN_FILE: "index.js",
          NODE_PACKAGES: "",
          UNNODE_PACKAGES: "",
          GIT_ADDRESS: "",
          BRANCH: "",
          USERNAME: "",
          ACCESS_TOKEN: "",
          NODE_ARGS: ""
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(
      chatId,
      `BERIKUT DATA PANEL ANDA
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? "Unlimited" : server.limits.disk} MB
CPU: ${server.limits.cpu}%`
    );
    if (akunlo) {
      bot.sendAnimation(u, akunlo, {
        caption: `Hai @${u}

 |[ DATA PANEL KAMU ]|
🌐 Login : ${domain}
👤 Username : ${user.username}
🔐 Password : ${password} 

JANGAN DDOS SERVER 
WAJIB TUTUP DOMAIN SAAT SCREENSHOT
`,
      });
      bot.sendMessage(
        chatId,
        "Data panel berhasil dikirim ke ID Telegram yang dimaksud."
      );
    }
  } else {
    bot.sendMessage(chatId, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 3gb
// 3gb
bot.onText(/\/3gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, "KHUSUS PREMIUM ❌", {
      reply_markup: {
        inline_keyboard: [[{ text: "OWNER", url: "@helpboosteryuk" }]],
      },
    });
    return;
  }
  const t = text.split(",");
  if (t.length < 2) {
    bot.sendMessage(chatId, "Invalid format. Usage: /3gb namapanel,idtele");
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + "3gb";
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = "3072";
  const cpu = "90";
  const disk = "3072";
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/npm start';
  const email = `${username}@Buyeradmin`;
  const akunlo = settings.pp;
  const password = `${username}001`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });
    const data = await response.json();
 if (data.errors) {
      // Tambahkan console.log agar kamu tau apa error aslinya di console
      console.log("Pterodactyl API Error:", data.errors); 

      if (
        data.errors[0]?.meta?.rule === "unique" &&
        data.errors[0]?.meta?.source_field === "email"
      ) {
        bot.sendMessage(chatId, "Email&user telah ada di data panel vemos.");
      } else {
        bot.sendMessage(
          chatId,
          `Error: ${JSON.stringify(data.errors[0], null, 2)}`
        );
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: spc,
       environment: {
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          MAIN_FILE: "index.js",
          NODE_PACKAGES: "",
          UNNODE_PACKAGES: "",
          GIT_ADDRESS: "",
          BRANCH: "",
          USERNAME: "",
          ACCESS_TOKEN: "",
          NODE_ARGS: ""
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(
      chatId,
      `BERIKUT DATA PANEL ANDA
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? "Unlimited" : server.limits.disk} MB
CPU: ${server.limits.cpu}%`
    );
    if (akunlo) {
      bot.sendAnimation(u, akunlo, {
        caption: `Hai @${u}

|[ DATA PANEL KAMU ]|
🌐 Login : ${domain}
👤 Username : ${user.username}
🔐 Password : ${password} 

|[ RULES ]|
JANGAN DDOS SERVER 
WAJIB TUTUP DOMAIN SAAT SCREENSHOT
JNGAN BAGIKAN DOMAIN KE SIAPAPUN
JANGAN LUPA GANTI PASSWORD PANEL
ADMIN CUMA KASIH DATA 1X
NO RUSUH MAKASIH ITU AJA

CPANEL BY @helpboosteryuk`,
      });
      bot.sendMessage(
        chatId,
        "Data panel berhasil dikirim ke ID Telegram yang dimaksud."
      );
    }
  } else {
    bot.sendMessage(chatId, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 4gb
bot.onText(/\/4gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, "KHUSUS PREMIUM ❌", {
      reply_markup: {
        inline_keyboard: [[{ text: "OWNER", url: "@helpboosteryuk" }]],
      },
    });
    return;
  }
  const t = text.split(",");
  if (t.length < 2) {
    bot.sendMessage(chatId, "Invalid format. Usage: /4gb namapanel,idtele");
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + "4gb";
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = "4048";
  const cpu = "110";
  const disk = "4048";
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/npm start';
  const email = `${username}@Buyeradmin`;
  const akunlo = settings.pp;
  const password = `${username}001`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });
    const data = await response.json();
if (data.errors) {
      // Tambahkan console.log agar kamu tau apa error aslinya di console
      console.log("Pterodactyl API Error:", data.errors); 

      if (
        data.errors[0]?.meta?.rule === "unique" &&
        data.errors[0]?.meta?.source_field === "email"
      ) {
        bot.sendMessage(
          chatId,
          "Email already exists. Please use a different email."
        );
      } else {
        bot.sendMessage(
          chatId,
          `Error: ${JSON.stringify(data.errors[0], null, 2)}`
        );
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: spc,
        environment: {
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          MAIN_FILE: "index.js",
          NODE_PACKAGES: "",
          UNNODE_PACKAGES: "",
          GIT_ADDRESS: "",
          BRANCH: "",
          USERNAME: "",
          ACCESS_TOKEN: "",
          NODE_ARGS: ""
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(
      chatId,
      `BERIKUT DATA PANEL ANDA
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? "Unlimited" : server.limits.disk} MB
CPU: ${server.limits.cpu}%`
    );
    if (akunlo) {
      bot.sendAnimation(u, akunlo, {
        caption: `Hai @${u}

 |[ DATA PANEL KAMU ]|
🌐 Login : ${domain}
👤 Username : ${user.username}
🔐 Password : ${password} 
|[ RULES ]| :
JANGAN DDOS SERVER 
WAJIB TUTUP DOMAIN SAAT SCREENSHOT
JNGAN BAGIKAN DOMAIN KE SIAPAPUN
JANGAN LUPA GANTI PASSWORD PANEL
ADMIN CUMA KASIH DATA 1X
NO RUSUH MAKASIH ITU AJA

CPANEL BY @helpboosteryuk`,
      });
      bot.sendMessage(
        chatId,
        "Data panel berhasil dikirim ke ID Telegram yang dimaksud."
      );
    }
  } else {
    bot.sendMessage(chatId, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 5gb
bot.onText(/\/5gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, "KHUSUS PREMIUM ❌", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "OWNER", url: "https://t.me/helpboosteryuk" }],
        ],
      },
    });
    return;
  }
  const t = text.split(",");
  if (t.length < 2) {
    bot.sendMessage(chatId, "Invalid format. Usage: /5gb namapanel,idtele");
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + "5gb";
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = "5048";
  const cpu = "140";
  const disk = "5048";
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@Buyeradmin`;
  const akunlo = settings.pp;
  const password = `${username}001`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      // Tambahkan console.log agar kamu tau apa error aslinya di console
      console.log("Pterodactyl API Error:", data.errors); 

      if (
        data.errors[0]?.meta?.rule === "unique" &&
        data.errors[0]?.meta?.source_field === "email"
      ) {
        bot.sendMessage(chatId, "Email&user telah ada di panel vemos.");
      } else {
        bot.sendMessage(
          chatId,
          `Error: ${JSON.stringify(data.errors[0], null, 2)}`
        );
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: spc,
        environment: {
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          MAIN_FILE: "index.js",
          NODE_PACKAGES: "",
          UNNODE_PACKAGES: "",
          GIT_ADDRESS: "",
          BRANCH: "",
          USERNAME: "",
          ACCESS_TOKEN: "",
          NODE_ARGS: ""
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(
      chatId,
      `BERIKUT DATA PANEL ANDA
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? "Unlimited" : server.limits.disk} MB
CPU: ${server.limits.cpu}%`
    );
    if (akunlo) {
      bot.sendAnimation(u, akunlo, {
        caption: `Hai @${u}

|[ DATA PANEL KAMU ]|
🌐 Login : ${domain}
👤 Username : ${user.username}
🔐 Password : ${password} 

|[ RULES ]|
JANGAN DDOS SERVER 
WAJIB TUTUP DOMAIN SAAT SCREENSHOT
JNGAN BAGIKAN DOMAIN KE SIAPAPUN
JANGAN LUPA GANTI PASSWORD PANEL
ADMIN CUMA KASIH DATA 1X
NO RUSUH MAKASIH ITU AJA

CPANEL BY @helpboosteryuk`,
      });
      bot.sendMessage(
        chatId,
        "Data panel berhasil dikirim ke ID Telegram yang dimaksud."
      );
    }
  } else {
    bot.sendMessage(chatId, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
bot.onText(/\/delsrv (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const srv = match[1].trim();

  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(msg.from.id));

  if (!isAdmin) {
    bot.sendMessage(
      chatId,
      "Perintah hanya untuk Owner, OWNER Saya Untuk Menjadi Owner atau Users Premium...",
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "OWNER", url: "https://t.me/dhanreal07" }],
          ],
        },
      }
    );
    return;
  }

  if (!srv) {
    bot.sendMessage(
      chatId,
      "Mohon masukkan ID server yang ingin dihapus, contoh: /delsrv 1234"
    );
    return;
  }

  try {
    let f = await fetch(domain + "/api/application/servers/" + srv, {
      method: "DELETE",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
    });

    let res = f.ok ? { errors: null } : await f.json();

    if (res.errors) {
      bot.sendMessage(chatId, "SERVER TIDAK ADA");
    } else {
      bot.sendMessage(chatId, "SUCCESFULLY DELETE SERVER");
    }
  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, "Terjadi kesalahan saat menghapus server.");
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 6gb
bot.onText(/\/6gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, "KHUSUS PREMIUM ❌", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "OWNER", url: "https://t.me/helpboosteryuk" }],
        ],
      },
    });
    return;
  }
  const t = text.split(",");
  if (t.length < 2) {
    bot.sendMessage(chatId, "Invalid format. Usage: /6gb namapanel,idtele");
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + "6gb";
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = "6048";
  const cpu = "170";
  const disk = "6048";
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@Buyeradmin`;
  const akunlo = settings.pp;
  const password = `${username}001`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      // Tambahkan console.log agar kamu tau apa error aslinya di console
      console.log("Pterodactyl API Error:", data.errors); 

      if (
        data.errors[0]?.meta?.rule === "unique" &&
        data.errors[0]?.meta?.source_field === "email"
      ) {
        bot.sendMessage(chatId, "Email&user telah ada di panel vemos.");
      } else {
        bot.sendMessage(
          chatId,
          `Error: ${JSON.stringify(data.errors[0], null, 2)}`
        );
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: spc,
        environment: {
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          MAIN_FILE: "index.js",
          NODE_PACKAGES: "",
          UNNODE_PACKAGES: "",
          GIT_ADDRESS: "",
          BRANCH: "",
          USERNAME: "",
          ACCESS_TOKEN: "",
          NODE_ARGS: ""
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(
      chatId,
      `BERIKUT DATA PANEL ANDA
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? "Unlimited" : server.limits.disk} MB
CPU: ${server.limits.cpu}%`
    );
    if (akunlo) {
      bot.sendAnimation(u, akunlo, {
        caption: `Hai @${u}

 |[ DATA PANEL KAMU ]|
🌐 Login : ${domain}
👤 Username : ${user.username}
🔐 Password : ${password} 

|[ RULES ]|
JANGAN DDOS SERVER 
WAJIB TUTUP DOMAIN SAAT SCREENSHOT
JNGAN BAGIKAN DOMAIN KE SIAPAPUN
JANGAN LUPA GANTI PASSWORD PANEL
ADMIN CUMA KASIH DATA 1X
NO RUSUH MAKASIH ITU AJA

CPANEL BY @dhanreal07`,
      });
      bot.sendMessage(
        chatId,
        "Data panel berhasil dikirim ke ID Telegram yang dimaksud."
      );
    }
  } else {
    bot.sendMessage(chatId, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 7gb
bot.onText(/\/7gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, "KHUSUS PREMIUM ❌", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "OWNER", url: "https://t.me/helpboosteryuk" }],
        ],
      },
    });
    return;
  }
  const t = text.split(",");
  if (t.length < 2) {
    bot.sendMessage(chatId, "Invalid format. Usage: /7gb namapanel,idtele");
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + "7gb";
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = "7048";
  const cpu = "200";
  const disk = "7048";
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/npm start';
  const email = `${username}@Buyeradmin`;
  const akunlo = settings.pp;
  const password = `${username}001`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });
    const data = await response.json();
if (data.errors) {
      // Tambahkan console.log agar kamu tau apa error aslinya di console
      console.log("Pterodactyl API Error:", data.errors); 

      if (
        data.errors[0]?.meta?.rule === "unique" &&
        data.errors[0]?.meta?.source_field === "email"
      ) {
        bot.sendMessage(chatId, "Email&user telah ada di panel vemos.");
      } else {
        bot.sendMessage(
          chatId,
          `Error: ${JSON.stringify(data.errors[0], null, 2)}`
        );
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: spc,
       environment: {
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          MAIN_FILE: "index.js",
          NODE_PACKAGES: "",
          UNNODE_PACKAGES: "",
          GIT_ADDRESS: "",
          BRANCH: "",
          USERNAME: "",
          ACCESS_TOKEN: "",
          NODE_ARGS: ""
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(
      chatId,
      `BERIKUT DATA PANEL ANDA
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? "Unlimited" : server.limits.disk} MB
CPU: ${server.limits.cpu}%`
    );
    if (akunlo) {
      bot.sendAnimation(u, akunlo, {
        caption: `Hai @${u}

 |[ DATA PANEL KAMU ]|
🌐 Login : ${domain}
👤 Username : ${user.username}
🔐 Password : ${password} 

JANGAN DDOS SERVER 
WAJIB TUTUP DOMAIN SAAT SCREENSHOT
JNGAN BAGIKAN DOMAIN KE SIAPAPUN
JANGAN LUPA GANTI PASSWORD PANEL
ADMIN CUMA KASIH DATA 1X
NO RUSUH MAKASIH ITU AJA

CPANEL BY @helpboosteryuk`,
      });
      bot.sendMessage(
        chatId,
        "Data panel berhasil dikirim ke ID Telegram yang dimaksud."
      );
    }
  } else {
    bot.sendMessage(chatId, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 8gb
bot.onText(/\/8gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, "KHUSUS PREMIUM ❌", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "OWNER", url: "https://t.me/helpboosteryuk" }],
        ],
      },
    });
    return;
  }
  const t = text.split(",");
  if (t.length < 2) {
    bot.sendMessage(chatId, "Invalid format. Usage: /8gb namapanel,idtele");
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + "8gb";
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = "8048";
  const cpu = "230";
  const disk = "8048";
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/npm start';
  const email = `${username}@Buyeradmin`;
  const akunlo = settings.pp;
  const password = `${username}001`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      // Tambahkan console.log agar kamu tau apa error aslinya di console
      console.log("Pterodactyl API Error:", data.errors); 

      if (
        data.errors[0]?.meta?.rule === "unique" &&
        data.errors[0]?.meta?.source_field === "email"
      ) {
        bot.sendMessage(
          chatId,
          "Email already exists. Please use a different email."
        );
      } else {
        bot.sendMessage(
          chatId,
          `Error: ${JSON.stringify(data.errors[0], null, 2)}`
        );
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: spc,
        environment: {
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          MAIN_FILE: "index.js",
          NODE_PACKAGES: "",
          UNNODE_PACKAGES: "",
          GIT_ADDRESS: "",
          BRANCH: "",
          USERNAME: "",
          ACCESS_TOKEN: "",
          NODE_ARGS: ""
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(
      chatId,
      `BERIKUT DATA PANEL ANDA
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? "Unlimited" : server.limits.disk} MB
CPU: ${server.limits.cpu}%`
    );
    if (akunlo) {
      bot.sendAnimation(u, akunlo, {
        caption: `Hai @${u}

 |[ DATA PANEL KAMU ]|
🌐 Login : ${domain}
👤 Username : ${user.username}
🔐 Password : ${password} 

|[ RULES ]|
JANGAN DDOS SERVER 
WAJIB TUTUP DOMAIN SAAT SCREENSHOT
JNGAN BAGIKAN DOMAIN KE SIAPAPUN
JANGAN LUPA GANTI PASSWORD PANEL
ADMIN CUMA KASIH DATA 1X
NO RUSUH MAKASIH ITU AJA

CPANEL BY @helpboosteryuk`,
      });
      bot.sendMessage(
        chatId,
        "Data panel berhasil dikirim ke ID Telegram yang dimaksud."
      );
    }
  } else {
    bot.sendMessage(chatId, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 9gb
bot.onText(/\/9gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, "KHUSUS PREMIUM ❌", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "OWNER", url: "https://t.me/helpboosteryuk" }],
        ],
      },
    });
    return;
  }
  const t = text.split(",");
  if (t.length < 2) {
    bot.sendMessage(chatId, "Invalid format. Usage: /9gb namapanel,idtele");
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + "9gb";
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = "9048";
  const cpu = "260";
  const disk = "9048";
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/npm start';
  const email = `${username}@Buyeradmin`;
  const akunlo = settings.pp;
  const password = `${username}001`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });
    const data = await response.json();
if (data.errors) {
      // Tambahkan console.log agar kamu tau apa error aslinya di console
      console.log("Pterodactyl API Error:", data.errors); 

      if (
        data.errors[0]?.meta?.rule === "unique" &&
        data.errors[0]?.meta?.source_field === "email"
      ) {
        bot.sendMessage(
          chatId,
          "Email already exists. Please use a different email."
        );
      } else {
        bot.sendMessage(
          chatId,
          `Error: ${JSON.stringify(data.errors[0], null, 2)}`
        );
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: spc,
        environment: {
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          MAIN_FILE: "index.js",
          NODE_PACKAGES: "",
          UNNODE_PACKAGES: "",
          GIT_ADDRESS: "",
          BRANCH: "",
          USERNAME: "",
          ACCESS_TOKEN: "",
          NODE_ARGS: ""
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(
      chatId,
      `BERIKUT DATA PANEL ANDA
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? "Unlimited" : server.limits.disk} MB
CPU: ${server.limits.cpu}%`
    );
    if (akunlo) {
      bot.sendAnimation(u, akunlo, {
        caption: `Hai @${u}

|[ DATA PANEL KAMU ]|
🌐 Login : ${domain}
👤 Username : ${user.username}
🔐 Password : ${password} 

|[ RULES ]|
JANGAN DDOS SERVER 
WAJIB TUTUP DOMAIN SAAT SCREENSHOT
JNGAN BAGIKAN DOMAIN KE SIAPAPUN
JANGAN LUPA GANTI PASSWORD PANEL
ADMIN CUMA KASIH DATA 1X
NO RUSUH MAKASIH ITU AJA

CPANEL BY @helpboosteryuk`,
      });
      bot.sendMessage(
        chatId,
        "Data panel berhasil dikirim ke ID Telegram yang dimaksud."
      );
    }
  } else {
    bot.sendMessage(chatId, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 10gb
bot.onText(/\/10gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, "KHUSUS PREMIUM ❌", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "OWNER", url: "https://t.me/helpboosteryuk" }],
        ],
      },
    });
    return;
  }
  const t = text.split(",");
  if (t.length < 2) {
    bot.sendMessage(chatId, "Invalid format. Usage: /10gb namapanel,idtele");
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + "10gb";
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = "10000";
  const cpu = "290";
  const disk = "10000";
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/npm start';
  const email = `${username}@Buyeradmin`;
  const akunlo = settings.pp;
  const password = `${username}001`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });
    const data = await response.json();
if (data.errors) {
      // Tambahkan console.log agar kamu tau apa error aslinya di console
      console.log("Pterodactyl API Error:", data.errors); 

      if (
        data.errors[0]?.meta?.rule === "unique" &&
        data.errors[0]?.meta?.source_field === "email"
      ) {
        bot.sendMessage(
          chatId,
          "Email already exists. Please use a different email."
        );
      } else {
        bot.sendMessage(
          chatId,
          `Error: ${JSON.stringify(data.errors[0], null, 2)}`
        );
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: spc,
        environment: {
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          MAIN_FILE: "index.js",
          NODE_PACKAGES: "",
          UNNODE_PACKAGES: "",
          GIT_ADDRESS: "",
          BRANCH: "",
          USERNAME: "",
          ACCESS_TOKEN: "",
          NODE_ARGS: ""
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(
      chatId,
      `BERIKUT DATA PANEL ANDA
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? "Unlimited" : server.limits.disk} MB
CPU: ${server.limits.cpu}%`
    );
    if (akunlo) {
      bot.sendAnimation(u, akunlo, {
        caption: `Hai @${u}
 |[ DATA PANEL KAMU ]|
🌐 Login : ${domain}
👤 Username : ${user.username}
🔐 Password : ${password} 

|[ RULES ]|
JANGAN DDOS SERVER 
WAJIB TUTUP DOMAIN SAAT SCREENSHOT
JNGAN BAGIKAN DOMAIN KE SIAPAPUN
JANGAN LUPA GANTI PASSWORD PANEL
ADMIN CUMA KASIH DATA 1X
NO RUSUH MAKASIH ITU AJA

CPANEL BY @helpboosteryuk`,
      });
      bot.sendMessage(
        chatId,
        "Data panel berhasil dikirim ke ID Telegram yang dimaksud."
      );
    }
  } else {
    bot.sendMessage(chatId, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
bot.onText(/\/11gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, "KHUSUS PREMIUM ❌", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "OWNER", url: "https://t.me/helpboosteryuk" }],
        ],
      },
    });
    return;
  }
  const t = text.split(",");
  if (t.length < 2) {
    bot.sendMessage(chatId, "Invalid format. Usage: /10gb namapanel,idtele");
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + "10gb";
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = "11000";
  const cpu = "290";
  const disk = "10000";
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/npm start';
  const email = `${username}@Buyeradmin`;
  const akunlo = settings.pp;
  const password = `${username}001`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });
    const data = await response.json();
if (data.errors) {
      // Tambahkan console.log agar kamu tau apa error aslinya di console
      console.log("Pterodactyl API Error:", data.errors); 

      if (
        data.errors[0]?.meta?.rule === "unique" &&
        data.errors[0]?.meta?.source_field === "email"
      ) {
        bot.sendMessage(
          chatId,
          "Email already exists. Please use a different email."
        );
      } else {
        bot.sendMessage(
          chatId,
          `Error: ${JSON.stringify(data.errors[0], null, 2)}`
        );
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: spc,
        environment: {
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          MAIN_FILE: "index.js",
          NODE_PACKAGES: "",
          UNNODE_PACKAGES: "",
          GIT_ADDRESS: "",
          BRANCH: "",
          USERNAME: "",
          ACCESS_TOKEN: "",
          NODE_ARGS: ""
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(
      chatId,
      `BERIKUT DATA PANEL ANDA
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? "Unlimited" : server.limits.disk} MB
CPU: ${server.limits.cpu}%`
    );
    if (akunlo) {
      bot.sendAnimation(u, akunlo, {
        caption: `Hai @${u}

|[ DATA PANEL KAMU ]|
🌐 Login : ${domain}
👤 Username : ${user.username}
🔐 Password : ${password}

|[ RULES ]|
JANGAN DDOS SERVER 
WAJIB TUTUP DOMAIN SAAT SCREENSHOT
JNGAN BAGIKAN DOMAIN KE SIAPAPUN
JANGAN LUPA GANTI PASSWORD PANEL
ADMIN CUMA KASIH DATA 1X
NO RUSUH MAKASIH ITU AJA

CPANEL BY @helpboosteryuk`,
      });
      bot.sendMessage(
        chatId,
        "Data panel berhasil dikirim ke ID Telegram yang dimaksud."
      );
    }
  } else {
    bot.sendMessage(chatId, "Gagal membuat data panel. Silakan coba lagi.");
  }
});

// unli
bot.onText(/\/unli (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));

  if (!isPremium) {
    return bot.sendMessage(chatId, "KHUSUS PREMIUM ❌", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "OWNER", url: "https://t.me/helpboosteryuk" }],
        ],
      },
    }); // <-- STOP semua eksekusi di sini
  }

  const t = text.split(",");
  if (t.length < 2) {
    return bot.sendMessage(chatId, "Invalid format. Usage: /unli namapanel,idtele");
  }

  const username = t[0];
  const u = t[1];
  const name = username + "unli";
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = "0";
  const cpu = "0";
  const disk = "0";
  const email = `${username}@Buyeraadmin`;
  const akunlo = settings.pp;
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/npm start';
  const password = `${username}001`;
  let user;
  let server;

  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });

    const data = await response.json();

if (data.errors) {
      // Tambahkan console.log agar kamu tau apa error aslinya di console
      console.log("Pterodactyl API Error:", data.errors); 

      if (
        data.errors[0]?.meta?.rule === "unique" &&
        data.errors[0]?.meta?.source_field === "email"
      ) {
        bot.sendMessage(chatId, "Email&user telah ada di panel Kyzz.");
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }

    user = data.attributes;

    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: spc,
        environment: {
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          MAIN_FILE: "index.js",
          NODE_PACKAGES: "",
          UNNODE_PACKAGES: "",
          GIT_ADDRESS: "",
          BRANCH: "",
          USERNAME: "",
          ACCESS_TOKEN: "",
          NODE_ARGS: ""
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });

    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }

  if (user && server) {
    bot.sendMessage(
      chatId,
      `BERIKUT DATA PANEL ANDA
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? "Unlimited" : server.limits.disk} MB
CPU: ${server.limits.cpu}%`
    );

    if (akunlo) {
      bot.sendAnimation(u, akunlo, {
        caption: `Hai @${u}

|[ DATA PANEL KAMU ]|
🌐 Login : ${domain}
👤 Username : ${user.username}
🔐 Password : ${password}

|[ RULES ]|
JANGAN DDOS SERVER 
WAJIB TUTUP DOMAIN SAAT SCREENSHOT
JNGAN BAGIKAN DOMAIN KE SIAPAPUN
JANGAN LUPA GANTI PASSWORD PANEL
ADMIN CUMA KASIH DATA 1X
NO RUSUH MAKASIH ITU AJA

CPANEL BY @helpboosteryuk`,
      });

      bot.sendMessage(chatId, "Data panel berhasil dikirim ke ID Telegram yang dimaksud.");
    }
  } else {
    bot.sendMessage(chatId, "Gagal membuat data panel. Silakan coba lagi.");
  }
});

//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// cadmin
bot.onText(/\/cadmin (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(msg.from.id));
  if (!isAdmin) {
    bot.sendMessage(
      chatId,
      "KHUSUS OWNER ❌",
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "OWNER", url: "https://t.me/@helpboosteryuk" }],
          ],
        },
      }
    );
    return;
  }
  const commandParams = match[1].split(",");
  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1].trim();
  if (commandParams.length < 2) {
    bot.sendMessage(
      chatId,
      "Format Salah! Penggunaan: /cadmin namapanel,idtele"
    );
    return;
  }
  const password = panelName + "117";
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: `${panelName}@Buyeradmin`,
        username: panelName,
        first_name: panelName,
        last_name: "Memb",
        language: "en",
        root_admin: true,
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo = `
TYPE: user
➟ ID: ${user.id}
➟ USERNAME: ${user.username}
➟ EMAIL: ${user.email}
➟ NAME: ${user.first_name} ${user.last_name}
➟ LANGUAGE: ${user.language}
➟ ADMIN: ${user.root_admin}
➟ CREATED AT: ${user.created_at}
    `;
    bot.sendMessage(chatId, userInfo);
    bot.sendMessage(
      telegramId,
      `
|[ INFO DATA ADMIN PANEL ]|
🌐  Login : ${domain}
👤  Username : ${user.username}
🔐  Password : ${password} 

|[ RULES ]| 
NO DDOS
NO CPU 90%
NO RUN BOT NET
NO INTIP SERVER
NO RUSUH
SIMPAN DATA BAIK" KARNA ADMIN CUMA NGIRIM DATA 1X

CADMIN BY  @helpboosteryuk
    `
    );
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti."
    );
  }
});
fs.readFile(adminfile, (err, data) => {
  if (err) {
    console.error(err);
  } else {
    adminIDs = JSON.parse(data);
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// listsrv
bot.onText(/\/listsrv/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  // Check if the user is the Owner
  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(msg.from.id));
  if (!isAdmin) {
    bot.sendMessage(
      chatId,
      "KHUSUS OWNER ❌.",
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "OWNER", url: "https://t.me/  helpboosteryuk" }],
          ],
        },
      }
    );
    return;
  }
  let page = 1; // Mengubah penggunaan args[0] yang tidak didefinisikan sebelumnya
  try {
    let f = await fetch(`${domain}/api/application/servers?page=${page}`, {
      // Menggunakan backticks untuk string literal
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
    });
    let res = await f.json();
    let servers = res.data;
    let messageText = "Daftar server aktif yang dimiliki:\n\n";
    for (let server of servers) {
      let s = server.attributes;

      let f3 = await fetch(
        `${domain}/api/client/servers/${s.uuid.split("-")[0]}/resources`,
        {
          method: "GET",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${pltc}`,
          },
        }
      );
      let data = await f3.json();
      let status = data.attributes ? data.attributes.current_state : s.status;

      messageText += `ID Server: ${s.id}\n`;
      messageText += `Nama Server: ${s.name}\n`;
      messageText += `Status: ${status}\n\n`;
    }

    bot.sendMessage(chatId, messageText);
  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, "Terjadi kesalahan dalam memproses permintaan.");
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// listadmin
bot.onText(/\/listadmin/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(msg.from.id));
  if (!isAdmin) {
    bot.sendMessage(
      chatId,
      "KHUSUS OWNER ❌",
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "OWNER", url: "https://t.me/helpboosteryuk" }],
          ],
        },
      }
    );
    return;
  }
  let page = "1";
  try {
    let f = await fetch(`${domain}/api/application/users?page=${page}`, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
    });
    let res = await f.json();
    let users = res.data;
    let messageText = "Berikut list admin :\n\n";
    for (let user of users) {
      let u = user.attributes;
      if (u.root_admin) {
        messageText += `🆔 ID: ${u.id} - 🌟 Status: ${
          u.attributes?.user?.server_limit === null ? "Inactive" : "Active"
        }\n`;
        messageText += `${u.username}\n`;
        messageText += `${u.first_name} ${u.last_name}\n\n`;
        messageText += "By @helpboosteryuk";
      }
    }
    messageText += `Page: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
    messageText += `Total Admin: ${res.meta.pagination.count}`;
    const keyboard = [
      [
        {
          text: "🔙 BACK",
          callback_data: JSON.stringify({
            action: "back",
            page: parseInt(res.meta.pagination.current_page) - 1,
          }),
        },
        {
          text: "🔜 NEXT",
          callback_data: JSON.stringify({
            action: "next",
            page: parseInt(res.meta.pagination.current_page) + 1,
          }),
        },
      ],
    ];
    bot.sendMessage(chatId, messageText, {
      reply_markup: {
        inline_keyboard: keyboard,
      },
    });
   
    //▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
    // batas akhir
  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, "Terjadi kesalahan dalam memproses permintaan.");
  }
});
